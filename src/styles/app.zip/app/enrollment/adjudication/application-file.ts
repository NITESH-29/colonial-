import { Auditable, AuditableObject } from '../../common/auditable-object';
import { Any, JsonObject, JsonProperty } from 'json2typescript';

export interface ApplicationFile extends Auditable {
  applicationId: number;
  name: string;
  fileTypeName: string;
  encodedFileContents: any;
  urlForFile: string;
  urlForPrivilege: string;
  description?: string;
}

@JsonObject('ApplicationFileImpl')
export class ApplicationFileImpl extends AuditableObject {
  @JsonProperty('description', String, true)
  description: string = null;
  @JsonProperty('applicationId', Number, true)
  applicationId = -1;
  @JsonProperty('name', String, true)
  name: string = null;
  @JsonProperty('fileTypeName', String, true)
  fileTypeName: string = null;
  @JsonProperty('encodedFileContents', Any, true)
  encodedFileContents: any = undefined;
  private _baseUrl = 'api/file/content';
  private _viewUrl = 'api/file/view-content';

  get urlForFile(): string {
    const params = Object.entries({
      parentObjectTypeName: 'Application',
      parentObjectId: this.applicationId,
      fileTypeName: this.fileTypeName,
    })
      .map(([k, v]) => `${k}=${v}`)
      .join('&');

    return `${this._baseUrl}?${params}`;
  }

  get urlForViewing(): string {
    return `${this._viewUrl}/${this.id}`;
  }

}
