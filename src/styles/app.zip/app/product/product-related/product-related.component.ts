import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ProductService } from '../products.service';
import { Product } from '../product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-related',
  templateUrl: './product-related.component.html',
  styleUrls: ['./product-related.component.scss'],
})
export class ProductRelatedComponent implements OnInit, OnChanges {

  @Input()
  product: Product;
  initialized = false;
  relatedProducts: Product[] = [];

  cols = [
    { field: 'productNo', header: 'Bond/Policy#' },
    { field: 'fromDate', header: 'From Date' },
    { field: 'toDate', header: 'To Date' },
  ];

  constructor(private productService: ProductService, private router: Router) {

  }

  async ngOnInit(): Promise<void> {
    this.relatedProducts = await this.productService.getRelatedProducts(this.product.id).toPromise();
    this.initialized = true;
  }

  async showProduct(id) {
    await this.router.navigateByUrl(`/product/product-overview?formId=${id}`);
    this.relatedProducts = await this.productService.getRelatedProducts(this.product.id).toPromise();
    window.scroll(0, 0);
  }

  async ngOnChanges(): Promise<void> {
    this.relatedProducts = await this.productService.getRelatedProducts(this.product.id).toPromise();
  }

  hasRelatedProducts() {
    return this.relatedProducts.length > 0;
  }

}
