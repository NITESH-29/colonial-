import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentMethodSelectionTestComponent } from './payment-method-selection/test/payment-method-selection-test/payment-method-selection-test.component';
import { AuthGuard } from '../security/app.auth.guard';
import { AddressTestComponent } from './address/test/address-test/address-test.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { KnockoutDialogComponent } from './knockout-dialog/knockout-dialog.component';
import { EmailListComponent } from './email/email-list/email-list.component';
import { SendEmailComponent } from './email/send-email/send-email.component';

const routes: Routes = [
  { path: 'payment-method', component: PaymentMethodSelectionTestComponent, canActivate: [AuthGuard] },
  { path: 'address', component: AddressTestComponent, canActivate: [AuthGuard] },
  { path: 'not-found', component: NotFoundComponent },
  { path: 'knockout-dialog', component: KnockoutDialogComponent },
  { path: 'email-list', component: EmailListComponent },
  { path: 'send-email', component: SendEmailComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommonComponentsRoutingModule {
}
