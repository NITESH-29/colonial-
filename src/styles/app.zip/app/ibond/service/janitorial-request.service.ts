import { Injectable } from '@angular/core';
import { RequestService } from './request.service';
import * as moment_ from 'moment';


@Injectable({
  providedIn: 'root',
})
export class JanitorialRequestService {
  planObject = {};
  moment = moment_;
  constructor(private requestService: RequestService) { }

  getRequestdata(person, requestBody, formdata, dataSource, addpaymetNode?) {
    const expYr = formdata.cardExpiration || null;
    const expMonth = formdata.month || null;
    requestBody['data'].bondDescription = formdata.bondDescription;
    requestBody['data'].effectiveDate = this.requestService.serializeDate(formdata.effectiveDate);
    requestBody['data'].expiryDate = this.requestService.serializeDate(formdata.expiryDate);

    requestBody['data'].applicantName = formdata.individualName;
    requestBody['data'].applicantEmail = person.email;
    requestBody['data'].applicantAddress = this.getApplicantObject(formdata);
    requestBody['data'].applicantPhone = this.serializePhoneNumber(formdata.individualPhone);
    // requestBody['data'].applicantFax = formdata.individualfax ? this.serializePhoneNumber(formdata.individualfax) : null;
    requestBody['data'].applicantSSNum = null;

    requestBody['data'].businessDetails = this.getBusinessObject(formdata);
    requestBody['data'].homeServiceType = formdata.homeService;
    requestBody['data'].businessType = formdata.businessType ? formdata.businessType.lookupValue : formdata.businessType;
    requestBody['data'].otherHomeServiceTypeDetails = formdata.provideDetails;
    requestBody['data'].staffDetails = this.getStaffDetails(dataSource);
    requestBody['data'].deliveryMethod = this.getDeliveryObject(formdata);
    requestBody['data'].koqOverride = false;

    if (addpaymetNode) {
      requestBody['data'].paymentMethod = this.requestService.getpaymentPlanObject();
      if (requestBody['data'].paymentMethod.resetPaymentDetail) {
        requestBody['data'].paymentMethod.billingFirstName = formdata.billingFirstName;
        requestBody['data'].paymentMethod.billingLastName = formdata.billingLastName || ' ';
        requestBody['data'].paymentMethod.billingPhone = this.serializePhoneNumber(formdata.billingPhone);
        requestBody['data'].paymentMethod.billingAddress = {
          street1: formdata.billingAddress,
          street2: null,
          city: formdata.billingCity,
          state: formdata.billingState,
          zipCode: formdata.billingZipCode,
        },
          requestBody['data'].paymentMethod.cardNumber = formdata.cardNumber ? formdata.cardNumber : null;
        requestBody['data'].paymentMethod.cardCVV = formdata.cardCVV;
        requestBody['data'].paymentMethod.cardExpiration = expMonth + '/' + expYr;
      }
    }
    requestBody['data'].termsAndConditions = this.getTermsAndCondition(formdata);
    requestBody['data'].liabilitiesInsuranceExists = formdata.liabilitiesInsuranceExists ? formdata.liabilitiesInsuranceExists : null;
    requestBody['data'].insuranceCompanyName = formdata.insuranceCompanyName ? formdata.insuranceCompanyName : null;
    requestBody.person = person;
    return requestBody;
  }

  getApplicantObject(formdata) {
    if (formdata) {
      return {
        street1: formdata.individualAddress,
        street2: formdata.individualAddress2,
        city: formdata.individualCity,
        state: formdata.individualState,
        zipCode: formdata.individualZip,
      };
    } else {
      return null;
    }
  }

  getBusinessObject(formdata) {
    // return {
    //   ownerName: formdata.individualName,
    //   ownerAddress: {
    //     street1: formdata.individualAddress,
    //     street2: formdata.individualAddress2,
    //     city: formdata.individualCity,
    //     state: formdata.individualState,
    //     zipCode: formdata.individualZip,
    //   },
    //   ownerPhone: this.serializePhoneNumber(formdata.individualPhone),
    //   ownerFax: formdata.individualfax ? this.serializePhoneNumber(formdata.individualfax) : null,
    // };
    return null;
  }
  getStaffDetails(dataSource) {
    return dataSource;
  }
  getDeliveryObject(formdata) {
    return {
      deliveryMethod: formdata.deliveryMethod,
      copyViaEmail: formdata.copyViaEmail,
    };
  }
  getPaymentObject(formdata) {
    return {
      billingAddress: formdata = {
        street1: formdata.street1,
        zipCode: formdata.zipCode,
        city: formdata.city,
        state: formdata.state,
      },
    };
  }
  getTermsAndCondition(formdata) {
    return {
      readAndAgreeToTerms: formdata.readAndAgreeToTerms,
      premiumAcknowledged: formdata.premiumAcknowledged,
      emailSignature: formdata.emailSignature,
    };
  }

  setPaymentPlanObject(planobj, flag) {
    if (flag) {
      this.planObject = planobj;
      this.planObject['resetPaymentDetail'] = false;
    } else {
      this.planObject = {
        resetPaymentDetail: true,
        paymentPlanTypeId: planobj.paymentPlanTypeId || null,
        billingProfileId: planobj.billingProfileId || null,
        secondaryBillingPersonBillingProfileId: null,
        response: {
          success: null,
          status: null,
          text: null,
          transaction: null,
          date: null,
        },
        personId: planobj.personId || null,
        paymentChannelCode: {
          persistenceId: planobj.persistenceId || null,
          paymentChannelType: {
            persistenceId: 'credit',
            electronic: planobj.electronic || null,
            defaultDisplayText: 'credit',
          },
          defaultDisplayText: planobj.defaultDisplayText || null,
          electronic: planobj.electronic || null,
          creditCard: planobj.creditCard || null,
        },
        billingFirstName: planobj.firstName ? planobj.firstName : '',
        billingLastName: planobj.lastName ? planobj.lastName || ' ' : ' ',
        billingPhone: planobj.billingPhone ? this.serializePhoneNumber(planobj.billingPhone) : null,
        billingAddress: planobj.billingAddress,
        cardNumber: this.serializeCardNumber(planobj.cardNumber),
        cardCVV: planobj.cardCVV,
        cardExpiration: planobj.cardExpiration,
      };
    }
  }
  getpaymentPlanObject() {
    return this.planObject;
  }
  deserializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3') : phoneNumber;
  }

  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  deserializeCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber.replace(/(\d{4})(\d{4})(\d{4})(\d{4})/g, '$1-$2-$3-$4') : cardNumber;
  }

  serializeCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber.replace(/[^\d]/g, '') : cardNumber;
  }
  customDateFormatter(date: string): Date {
    return date ? new Date(this.moment(date).format('MM/DD/YYYY')) : new Date();
  }

}
