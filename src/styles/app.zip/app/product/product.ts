import { JsonObject, JsonProperty } from 'json2typescript';
import { ProductType, ProductTypeImpl } from './product-type';
import { CompanyOffice, CompanyOfficeImpl } from '../common/company-office';
import { Person, PersonImpl } from '../common/person';
import { CurrencyConverter } from '../common/utils/currency-converter';
import { ApplicationDataConverter } from '../enrollment/application/court/model/application-data-converter';
import { ApplicationData, ApplicationDataImpl } from '../enrollment/application/court/model/application-data';
import { Auditable, AuditableProfile } from '../common/auditable-object';
import { Agent, AgentImpl } from '../common/agent';

export interface Product extends Auditable {
  id: number;
  agent: Agent;
  productType: ProductType;
  person: Person;
  companyOffice: CompanyOffice;
  data: any;
  amount: string;
  premium: string;
  status: string;
  court?: string;
  primaryService?: string;
  productNo?: string;
  applicationId: number;
  toDate: Date;
  fromDate: Date;
  renewed: Boolean;
  renewable: Boolean;
  renewal: Boolean;
}

@JsonObject('ProductImpl')
export class ProductImpl extends AuditableProfile implements Product {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('agent', AgentImpl, true)
  agent: Agent = new AgentImpl();

  @JsonProperty('productType', ProductTypeImpl, true)
  productType: ProductType = new ProductTypeImpl();

  @JsonProperty('person', PersonImpl, true)
  person: Person = new PersonImpl();

  @JsonProperty('companyOffice', CompanyOfficeImpl, true)
  companyOffice: CompanyOffice = new CompanyOfficeImpl();

  @JsonProperty('data', ApplicationDataConverter, true)
  data: ApplicationData = new ApplicationDataImpl();

  @JsonProperty('amount', CurrencyConverter, true)
  amount: string = null;

  @JsonProperty('premium', CurrencyConverter, true)
  premium: string = null;

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('court', String, true)
  court: string = null;

  @JsonProperty('primaryService', String, true)
  primaryService: string = null;

  @JsonProperty('productNo', String, true)
  productNo: string = null;

  @JsonProperty('applicationId', Number, true)
  applicationId: number = null;

  @JsonProperty('renewed', Boolean, true)
  renewed: Boolean = null;

  @JsonProperty('renewable', Boolean, true)
  renewable: Boolean = null;

  @JsonProperty('renewal', Boolean, true)
  renewal: Boolean = null;
}
