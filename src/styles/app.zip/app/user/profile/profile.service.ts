import { Injectable } from '@angular/core';
import { PersonSummary } from '../../common/person-summary';
import { AsyncValidatorFn } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpOptions } from '../../common/http-options';
import { AbstractService } from '../../common/services/abstract-service';
import { AvailabilityCheck, getAvailabilityAsyncValidator } from '../availability/get-availability-async-validator';
import { UserImpl } from '../../security/user';
import { AgentSummary, AgentSummaryImpl } from './readonly-referral-information/agent-summary';
import { JsonConvertService } from '../../common/utils/json-convert.service';
import { JsonConvert } from 'json2typescript';

@Injectable()
export class ProfileService extends AbstractService {
  private readonly options: HttpOptions;
  private readonly jsonConvert: JsonConvert;
  private stashedProfile: UserImpl;

  constructor(private http: HttpClient, jsonConvertService: JsonConvertService) {
    super();
    this.jsonConvert = jsonConvertService.getJsonConvert();
    this.options = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      observe: 'body',
    };
  }

  getOtherEmailAvailabilityAsyncValidator(person: PersonSummary): AsyncValidatorFn {
    return getAvailabilityAsyncValidator(
      'email',
      this.checkOtherEmailAvailability.bind(this, person.id)
    );
  }

  getAgentOf(person: PersonSummary): Observable<AgentSummary | null> {
    return this.http.get<AgentSummary>(this.requestURL(`/person/${person.id}/agent`), this.options).pipe(
      map(as => this.jsonConvert.deserialize(as, AgentSummaryImpl)),
      catchError(() => of(null))
    );
  }

  private checkOtherEmailAvailability(personId: number, emailAddress: string): Observable<AvailabilityCheck> {
    const encodedEmail = encodeURIComponent(emailAddress);
    const availabilityUrl = this.requestURL(`/person/${personId}/other-person-with-email/${encodedEmail}`);
    return this.http.head(availabilityUrl, this.options).pipe(
      map(() => false),
      catchError(() => of(true)),
      map(available => ({ available }))
    );
  }

  stashProfile(profile: any) {
    this.stashedProfile = profile;
  }

  unStashProfile(): UserImpl {
    const unStashed = this.stashedProfile;
    this.stashedProfile = undefined;
    return unStashed;
  }
}
