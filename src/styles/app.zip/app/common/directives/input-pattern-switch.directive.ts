import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appSwitchInputPattern]',
})
export class SwitchInputPatternDirective {

  constructor(private element: ElementRef) { }

  isIOS() {
    return /iPhone|iPad|iPod|/i.test(navigator.userAgent);
  }

  @HostListener('touchend', ['$event'])
  public onTouchEnd(event) {
    if (this.isIOS()) {
      this.element.nativeElement.setAttribute('pattern', '[0-9]*');
    }

  }

  @HostListener('keydown blur', ['$event'])
  public onEvent(event) {
    if (this.isIOS()) {
      this.element.nativeElement.setAttribute('pattern', '[\d.,]+');
    }
  }
}
