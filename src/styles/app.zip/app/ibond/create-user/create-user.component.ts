import { Component, OnInit, ViewChild, ElementRef, NgZone, AfterViewInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { PatternValidators } from 'src/app/common/validators/pattern-validators';
import { ValueMatchValidator } from 'src/app/common/validators/value-match-validator';
import { InputValidators } from 'src/app/form-components/validators/input-validators';
import { IbondBaseService } from '../service/ibond-base.service';
import { states } from 'src/app/common/utils/constants';
import { LoginComponent } from 'src/app/ibond/login/login.component';
import { MatDialog, MatChipInputEvent } from '@angular/material';
import { RequestService } from '../service/request.service';
import { AccountService } from 'src/app/user/account.service';
import { SpinnerService } from '../service/spinner.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { ISignUpIndividual, ISignUpCompany } from '../sign-up/sign-up';
import { statesLong } from '../../common/utils/constants';
import { MatAutocompleteSelectedEvent, MatChipList, MatFormField, MatAutocomplete } from '@angular/material';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { SecurityService } from 'src/app/security/security.service';
import { CourtBondFacilitationService } from 'src/app/enrollment/facilitation/court-bond-facilitation.service';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { NoopScrollStrategy } from '@angular/cdk/overlay';
import { UsernamePassword } from 'src/app/user/username-password/username-password-form-group';
import { CreateAgentAccountRequest } from 'src/app/user/request-models/create-account-request';
import { AgencyInformation } from 'src/app/user/business-information/business-information';
import { AgencyOfficeInformation } from 'src/app/user/business-office-information/business-office-information';
import { PersonalInformation } from 'src/app/user/personal-information/personal-information';
import { Location } from '@angular/common';

interface State {
  name: string;
  abbreviation: string;
}
@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss'],
})
export class CreateUserComponent implements OnInit, AfterViewInit {
  subheading = '';
  heading = '';
  imgSignUp = 'assets/img/hand-Icon.svg';
  imgBackIcon = 'assets/img/back-Icon.svg';
  imgPassword = 'assets/img/MaterialIcon.svg';
  signUpForm: FormGroup;
  statesArray = states;
  isCompany = false;
  isChecked: boolean;
  stateList: State[] = statesLong;
  stateNameList = [];
  stateSelected = [];
  @ViewChild('stateInput') stateInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  separatorKeyCodes: number[] = [ENTER, COMMA];
  statesFilter = new FormControl();
  filteredStates: Observable<any[]>;
  zipCodeData;
  returnUrl = '';
  disableCompany = false;
  pageFor = '';
  showFullLoader = false;
  disableAttorneyAgent = false;
  constructor(
    public fb: FormBuilder,
    public baseService: IbondBaseService,
    public matDialog: MatDialog,
    public requestService: RequestService,
    protected accountService: AccountService,
    public spinnerService: SpinnerService,
    public serviceHandlerSnackbar: ServiceHandler,
    public router: Router,
    public securityService: SecurityService,
    public courtBondFacilitationService: CourtBondFacilitationService,
    public zone: NgZone,
    public _route: ActivatedRoute,
    private gtmService: GoogleTagManagerService,
    private location: Location
  ) {
    this.filteredStates = this.statesFilter.valueChanges.pipe(
      // tslint:disable-next-line: deprecation
      startWith(null),
      map((state: string | null) => state ? this._filter(state) : this.stateNameList.slice()));
  }

  ngOnInit() {
    this.initializeForm();
    this.signUpForm.get('username').setAsyncValidators(
      this.accountService.getUsernameAvailabilityAsyncValidator()
    );
    this.stateList.forEach(stateName => {
      this.stateNameList.push(stateName.name);
    });
    this.signUpForm.get('email').setAsyncValidators(
      this.accountService.getEmailAvailabilityAsyncValidator()
    );
    this.populateAnonymousUser();
    if (this.courtBondFacilitationService.getAnonymousQuote() &&
      this.courtBondFacilitationService.getAnonymousQuote().companyName === null) {
      this.isChecked = true;
      this.signUpForm.controls['applicantName'].patchValue(
        this.courtBondFacilitationService.getAnonymousQuote().firstName + ' ' +
        this.courtBondFacilitationService.getAnonymousQuote().lastName
      );
    }
    if (this.courtBondFacilitationService.getAnonymousQuote()) {
      this.disableAttorneyAgent = true;
    }
    this._route.queryParams.subscribe((route: Params) => {
      this.returnUrl = route['returnUrl'];
    });
    this.pageFor = this._route.snapshot.queryParams['type'];
    if (this.pageFor === 'attorney') {
      this.signUpForm.controls['standardOrAttorney'].setValue('attorney');
      this.changeAndApplyValidators(this.signUpForm.controls['standardOrAttorney'].value);
    } else if (this.pageFor === 'client') {
      this.signUpForm.controls['standardOrAttorney'].setValue('standardUser');
      this.changeAndApplyValidators(this.signUpForm.controls['standardOrAttorney'].value);
    } else if (this.pageFor === 'agent') {
      this.signUpForm.controls['standardOrAttorney'].setValue('insuranceAgent');
      this.changeAndApplyValidators(this.signUpForm.controls['standardOrAttorney'].value);
    }
    this.signUpForm.controls['standardOrAttorney'].valueChanges.subscribe(value => {
      this.changeAndApplyValidators(value);
    });
  }
  ngAfterViewInit(): void {
    if (this.pageFor === 'attorney') {
      setTimeout(() => {
        this.partnershipStartGtmEvent('partnership-start', '', '',
          'attorney'
        );
      }, 1000);
    }
  }
  initializeForm(): void {
    this.signUpForm = this.fb.group({
      standardOrAttorney: this.fb.control('standardUser'),
      referralCode: this.fb.control(null, []),
      firstName: this.fb.control(null, [Validators.required]),
      initial: this.fb.control(null, Validators.maxLength(1)),
      lastName: this.fb.control(null, [Validators.required]),
      phone: this.fb.control(null, [Validators.required, PatternValidators.phoneNumber()]),
      email: this.fb.control(null, [Validators.required, PatternValidators.email()]),
      applicantName: this.fb.control(null),
      street1: this.fb.control(null, [Validators.required]),
      street2: this.fb.control(null, []),
      city: this.fb.control(null, [Validators.required]),
      state: this.fb.control(null, [Validators.required]),
      zipCode: this.fb.control(null, [Validators.required, PatternValidators.zipCode()]),
      username: this.fb.control(null, [Validators.required, InputValidators.noSpaces, Validators.maxLength(50)]),
      password: this.fb.control(null, [Validators.required, Validators.minLength(10),
      Validators.maxLength(62), PatternValidators.alphanumeric()]),
      practiceState: this.fb.control('no', []),
      confirmPassword: this.fb.control(null, [Validators.required, Validators.minLength(10), Validators.maxLength(62)]),
      attorneyState: this.fb.control('no'),
      stateList: this.fb.control(null),
      applicantNameCheck: this.fb.control(null),
      agencyName: this.fb.control(null),
      memberOfNasbp: this.fb.control(false),
      einNumber: this.fb.control(null),
      licenseNumber: this.fb.control(null),
    },
      {
        validator: ValueMatchValidator.matchingValues('password', 'confirmPassword'),
      });
  }

  populateAnonymousUser() {
    const anonymousUserData = this.courtBondFacilitationService.getAnonymousQuote();
    this.isCompany = anonymousUserData ? !anonymousUserData.isCompany : this.isCompany;
    this.disableCompany = anonymousUserData ? !anonymousUserData.isCompany : this.disableCompany;
    this.signUpForm.patchValue({
      firstName: anonymousUserData ? anonymousUserData.firstName : '',
      lastName: anonymousUserData ? anonymousUserData.lastName : '',
      phone: anonymousUserData ? anonymousUserData.phone : '',
      email: anonymousUserData ? anonymousUserData.email : '',
      applicantName: anonymousUserData ? anonymousUserData.companyName : '',
      applicantNameCheck: anonymousUserData ? !anonymousUserData.isCompany : null,
    });
  }

  checkedApplicantBox() {
    if (this.courtBondFacilitationService.getAnonymousQuote().companyName != null) {
      this.isCompany = true;
    }
  }
  addState(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.stateSelected.push(value.trim());
    }
    if (input) {
      input.value = '';
    }
    this.statesFilter.setValue(null);
  }

  remove(item: string): void {
    const index = this.stateSelected.indexOf(item);
    if (index >= 0) {
      this.stateSelected.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.stateSelected.push(event.option.viewValue);
    this.stateInput.nativeElement.value = '';
    this.statesFilter.setValue(null);
  }

  nameOfState(state?: State): string | undefined {
    return state ? state.name : undefined;
  }

  private _filter(value) {
    if (value) {
      const filterValue = value.toLowerCase();
      return this.stateNameList.filter(state => state.toLowerCase().indexOf(filterValue) === 0);
    }
  }

  checkboxEvent(event) {
    if (event.checked && this.signUpForm.controls['firstName'].value && this.signUpForm.controls['lastName'].value) {
      this.signUpForm.controls['applicantName'].patchValue(
        this.signUpForm.controls['firstName'].value + ' ' +
        this.signUpForm.controls['lastName'].value);
      this.isCompany = true;
      this.signUpForm.controls['applicantName'].disable();
    } else {
      this.signUpForm.controls['applicantName'].enable();
      this.isCompany = false;
      this.signUpForm.controls['applicantName'].patchValue(null);
    }
  }

  getStatesPracticedIn(selectedArray) {
    const selectedAbbr = [];
    selectedArray.forEach(stateNames => {
      const statesNames = this.stateList.find(state => state.name === stateNames);
      selectedAbbr.push(statesNames.abbreviation);
    });
    return selectedAbbr;
  }

  agentSignUpObject(): CreateAgentAccountRequest {
    const personalInformation: PersonalInformation = {
      firstName: this.signUpForm.value['firstName'],
      initial: this.signUpForm.value['initial'],
      lastName: this.signUpForm.value['lastName'],
      suffix: null,
      salutation: null,
      phone: this.signUpForm.value['phone'] || null,
      email: this.signUpForm.value['email'],
      profession: null,
      address: null,
    };

    const usernamePassword: UsernamePassword = {
      username: this.signUpForm.value['username'],
      password: this.signUpForm.value['password'],
      confirmPassword: this.signUpForm.value['confirmPassword'],
    };

    const agencyInformation: AgencyInformation = {
      name: this.signUpForm.value['agencyName'],
      memberOfNasbp: this.signUpForm.value['memberOfNasbp'],
      einNumber: this.signUpForm.value['einNumber'],
    };

    const agencyOfficeInformation: AgencyOfficeInformation = {
      name: this.signUpForm.value['agencyName'],
      website: null,
      email: this.signUpForm.value['email'],
      phone: this.signUpForm.value['phone'],
      fax: null,
      sicCode: null,
      officeType: null,
      address: {
        street1: this.signUpForm.value['street1'] || null,
        street2: this.signUpForm.value['street2'] || null,
        city: this.signUpForm.value['city'],
        state: this.signUpForm.value['state'],
        zipCode: this.signUpForm.value['zipCode'],
      },
      title: null,
      licenseNumber: this.signUpForm.value['licenseNumber'],
    };

    const agentDetails: CreateAgentAccountRequest = {
      personalInformation,
      usernamePassword,
      agencyInformation,
      agencyOfficeInformation,
    };
    return agentDetails;
  }

  signUp() {
    if (this.signUpForm.controls['standardOrAttorney'].value === 'standardUser') {
      this.signUpForm.controls['agencyName'].updateValueAndValidity();
    }
    const signUpRequestBodyAttorney = {
      personalInformation: {
        firstName: this.signUpForm.value.firstName,
        initial: this.signUpForm.value.initial,
        lastName: this.signUpForm.value.lastName,
        suffix: null,
        salutation: null,
        phone: this.signUpForm.value.phone || null,
        email: this.signUpForm.value.email,
        profession: null,
        address: null,
      },
      firmInformation: {
        name: this.signUpForm.value.applicantName,
      },
      firmOfficeInformation: {
        address: {
          id: null,
          createdBy: null,
          createdAt: null,
          updatedBy: null,
          updatedAt: null,
          fromDate: null,
          toDate: null,
          street1: this.signUpForm.value.street1 || null,
          street2: this.signUpForm.value.street2 || null,
          city: this.signUpForm.value.city,
          state: this.signUpForm.value.state,
          zipCode: this.signUpForm.value.zipCode,
          countyName: null,
        },
        website: null,
        phone: this.signUpForm.value.phone,
        fax: null,
        email: this.signUpForm.value.email,
        sicCode: null,
        name: this.signUpForm.value.applicantName,
        officeType: null,
        title: null,
      },
      usernamePassword: {
        username: this.signUpForm.value.username,
        password: this.signUpForm.value.password,
        confirmPassword: this.signUpForm.value.confirmPassword,
      },
      statesPracticedIn: this.getStatesPracticedIn(this.stateSelected),
    };
    if (this.signUpForm.valid) {
      this.spinnerService.show();
      this.showFullLoader = true;
      window.scroll(0, 0);
      if (this.signUpForm.value.standardOrAttorney === 'standardUser') {
        this.baseService.signUpStandardUser(this.requestObject()).subscribe((response) => {
          if (response) {
            this.securityService.login(this.signUpForm.get('username').value, this.signUpForm.get('password').value)
              .then((result) => {
                if (result) {
                  if (this.returnUrl) {
                    this.router.navigateByUrl(this.returnUrl);
                  } else {
                    this.router.navigate(['/dashboard']);
                    this.spinnerService.hide();
                  }
                }
              });
          }
        }, (err) => {
          this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
          this.spinnerService.hide();
          this.showFullLoader = false;
        });
      } else if (this.signUpForm.value.standardOrAttorney === 'insuranceAgent') {
        this.accountService.createAgentAccount(this.agentSignUpObject()).then((response) => {
          if (response) {
            this.securityService.login(this.signUpForm.get('username').value, this.signUpForm.get('password').value)
              .then((result) => {
                if (result) {
                  if (this.returnUrl) {
                    this.router.navigateByUrl(this.returnUrl);
                  } else {
                    this.router.navigate(['/dashboard']);
                    this.spinnerService.hide();
                  }
                }
              });
          }
        }).catch((error) => {
          this.spinnerService.hide();
          this.showFullLoader = false;
          this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
        });
      } else {
        this.baseService.signUpAttorney(signUpRequestBodyAttorney).subscribe((response) => {
          if (response) {
            this.partnershipCompleteGtmEvent('partnership-complete', '', '',
              'attorney'
            );
            this.securityService.login(this.signUpForm.get('username').value, this.signUpForm.get('password').value)
              .then((result) => {
                if (result) {
                  if (this.returnUrl) {
                    this.router.navigateByUrl(this.returnUrl);
                  } else {
                    this.router.navigate(['/dashboard']);
                    this.spinnerService.hide();
                  }
                }
              });
          }
        }, (err) => {
          this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
          this.spinnerService.hide();
          this.showFullLoader = false;

        });
      }
    } else {
      this.signUpForm.controls['email'].markAsTouched();
      this.baseService.scrollIfFormHasErrors(this.signUpForm);
      this.serviceHandlerSnackbar.showErrorMessage('Please fix validation errors before saving.');
    }
  }

  get isStandardUser() {
    return this.signUpForm.controls['standardOrAttorney'].value === 'standardUser';
  }

  get isAttorneyUser() {
    return this.signUpForm.controls['standardOrAttorney'].value === 'attorney';
  }

  get isInsuranceAgent() {
    return this.signUpForm.controls['standardOrAttorney'].value === 'insuranceAgent';
  }

  get isPracticeState() {
    return this.signUpForm.controls['practiceState'].value === 'yes';
  }
  requestObject(): ISignUpIndividual | ISignUpCompany {
    if (this.isCompany === true) {
      return this.requestObjectIndividual();
    } else {
      return this.requestObjectCompany();
    }
  }
  requestObjectIndividual(): ISignUpIndividual {
    return {
      personalInformation: {
        firstName: this.signUpForm.value.firstName,
        initial: this.signUpForm.value.initial || null,
        // initial: null,
        lastName: this.signUpForm.value.lastName,
        suffix: null,
        salutation: null,
        phone: this.requestService.serializePhoneNumber(this.signUpForm.value.phone),
        email: this.signUpForm.value.email,
        // applicantName: this.signUpForm.value.profession,
        profession: null,
        address: {
          street1: this.signUpForm.value.street1,
          street2: this.signUpForm.value.street2,
          city: this.signUpForm.value.city,
          state: this.signUpForm.value.state,
          zipCode: this.signUpForm.value.zipCode,
        },
      },
      usernamePassword: {
        username: this.signUpForm.value.username,
        password: this.signUpForm.value.password,
        confirmPassword: this.signUpForm.value.confirmPassword,
      },
      referralCode: this.signUpForm.value.referralCode || '',
    };
  }

  requestObjectCompany(): ISignUpCompany {
    return {
      personalInformation: {
        firstName: this.signUpForm.value.firstName,
        initial: this.signUpForm.value.initial || null,
        lastName: this.signUpForm.value.lastName,
        suffix: null,
        salutation: null,
        phone: this.requestService.serializePhoneNumber(this.signUpForm.value.phone),
        email: this.signUpForm.value.email,
        profession: null,
        address: null,
      },
      businessInformation: {
        name: this.signUpForm.value.applicantName,
      },
      businessOfficeInformation: {
        name: this.signUpForm.value.applicantName,
        website: null,
        email: this.signUpForm.value.email,
        phone: this.requestService.serializePhoneNumber(this.signUpForm.value.phone),
        fax: null,
        sicCode: null,
        officeType: 'Main',
        address: {
          street1: this.signUpForm.value.street1,
          street2: this.signUpForm.value.street2,
          city: this.signUpForm.value.city,
          state: this.signUpForm.value.state,
          zipCode: this.signUpForm.value.zipCode,
          countyName: null,
        },
        title: null,
      },
      usernamePassword: {
        username: this.signUpForm.value.username,
        password: this.signUpForm.value.password,
        confirmPassword: this.signUpForm.value.confirmPassword,
      },
      referralCode: this.signUpForm.value.referralCode || '',
    };
  }

  login() {
    const dialogRef = this.matDialog.open(LoginComponent, {
      data: { clickFrom: 'signup', url: '' },
      scrollStrategy: new NoopScrollStrategy(),
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.router.navigate(['/dashboard']);
      }
    }, error => {
    });
  }

  setAddress(addrObj): void {
    this.zone.run(() => {
      if (addrObj) {
        const addr = addrObj;
        this.signUpForm.controls.street1.setValue(addr['address']);
        this.signUpForm.controls.zipCode.setValue(addr['postal_code']);
        this.signUpForm.controls.city.setValue(addr['locality']);
        this.signUpForm.controls.state.setValue(addr['admin_area_l1']);
        this.signUpForm.updateValueAndValidity();
      }
    });

  }
  get confirmPassword() {
    return this.signUpForm.get('confirmPassword');
  }
  get confirmPasswordErrorMessage(): string {
    return this.confirmPassword.hasError('required') ? 'Confirm new password is required.' :
      this.confirmPassword.hasError('minlength') ? 'Confirm new password must have minimum length of 10.' :
        this.confirmPassword.hasError('valueMatch') ? 'Passwords do not match.' : '';
  }
  getZipCode(zipCode, eventName): void {
    this.baseService.getZipCode(zipCode.target.value).subscribe((response) => {
      this.zipCodeData = response;
      if (eventName === 'user') {
        this.signUpForm.controls.city.setValue(this.zipCodeData['city']);
        this.signUpForm.controls.state.setValue(this.zipCodeData['state']);
      }
    });
  }
  get password() {
    return this.signUpForm.get('password');
  }
  get invalidLengthCondition(): boolean {
    return this.displayPasswordLengthError && this.password.touched;
  }
  get displayPasswordLengthError(): boolean {
    return (this.password.hasError('minlength') || this.password.hasError('maxlength'))
      || (this.password.touched && (this.password.value === '' || this.password.value === null));
  }
  get validLengthCondition(): boolean {
    return !this.displayPasswordLengthError && this.password.touched;
  }
  get invalidPatternCondition(): boolean {
    return (this.displayAlphanumericError && this.password.touched) ||
      (this.password.touched && this.password.value === '');
  }
  get displayAlphanumericError(): boolean {
    return (this.password.touched && this.password.hasError('pattern')) ||
      (this.password.touched && (this.password.value === '' || this.password.value === null));
  }
  get validPatternCondition(): boolean {
    return !this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }

  changeUser() {
    if (this.signUpForm.controls['standardOrAttorney'].value === 'standardUser') {
      this.partnershipStartGtmEvent('partnership-start', '', '',
        'attorney'
      );
    }
  }

  changeAndApplyValidators(value) {
    if (value === 'insuranceAgent') {
      this.signUpForm.controls['agencyName'].setValidators([Validators.required]);
      this.signUpForm.controls['einNumber'].setValidators([Validators.maxLength(10), Validators.pattern(/^[1-9]\d?-\d{7}$/)]);
      this.signUpForm.controls['licenseNumber'].setValidators([Validators.maxLength(450)]);
      this.signUpForm.controls['applicantName'].clearValidators();
    } else {
      this.signUpForm.controls['applicantName'].setValidators([Validators.required]);
      this.signUpForm.controls['einNumber'].clearValidators();
      this.signUpForm.controls['licenseNumber'].clearValidators();
      this.signUpForm.controls['agencyName'].clearValidators();
    }
    this.signUpForm.updateValueAndValidity();
  }

  partnershipStartGtmEvent(event, bondType, bondPremium, userType) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`
    );
  }

  partnershipCompleteGtmEvent(event, bondType, bondPremium, userType) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`
    );
  }

  backTo() {
    // this.router.navigate(['/secure/login']);
    this.location.back();
  }

  get user(): string {
    let user = '';
    if (this.isAttorneyUser) {
      user = 'Attorney';
    } else if (this.isInsuranceAgent) {
      user = 'Agent';
    } else if (this.isStandardUser) {
      user = 'User';
    }
    return user;
  }
}
