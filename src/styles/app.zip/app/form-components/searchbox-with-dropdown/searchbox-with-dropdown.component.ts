import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SearchObject } from './search-object';
import { SearchboxWithDropdownFormGroup } from './searchbox-with-dropdown-form-group';

@Component({
  selector: 'app-searchbox-dropdown',
  templateUrl: './searchbox-with-dropdown.component.html',
  styleUrls: ['./searchbox-with-dropdown.component.scss'],
})
export class SearchboxWithDropdownComponent implements OnInit {

  @Input()
  formGroup: SearchboxWithDropdownFormGroup;

  @Input()
  searchList: Array<SearchObject>;

  @Output()
  searchEvent: EventEmitter<void> = new EventEmitter<void>();

  ngOnInit() {
  }

  searchEventHandler() {
    this.searchEvent.emit();
  }

}

