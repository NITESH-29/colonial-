import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { AccountService } from '../account.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { EmployeeEnrollmentService } from './employee-enrollment.service';
import { UsernamePasswordFormGroup } from '../username-password/username-password-form-group';

@Component({
  selector: 'app-employee-enrollment',
  templateUrl: './employee-enrollment.component.html',
  styleUrls: ['./employee-enrollment.component.css'],
})
export class EmployeeEnrollmentComponent implements OnInit {
  initialPasswordForm: UsernamePasswordFormGroup;
  token: string;
  employeeId: string;
  disableSubmit = false;

  constructor(
    private accountService: AccountService,
    private router: Router,
    private snackbar: MatSnackBar,
    private employeeEnrollmentService: EmployeeEnrollmentService,
    private securityService: SecurityService,
    private activatedRoute: ActivatedRoute,
    private serviceHandler: ServiceHandler) {
  }

  ngOnInit() {
    this.employeeId = this.activatedRoute.snapshot.params.id;
    this.token = this.activatedRoute.snapshot.queryParams.token;

    this.initialPasswordForm = new UsernamePasswordFormGroup();

    this.initialPasswordForm.get('username').setAsyncValidators(
      this.accountService.getUsernameAvailabilityAsyncValidator()
    );
  }

  async saveInitialPassword() {
    this.disableSubmit = true;
    const { username, password } = this.initialPasswordForm.getRawValue();
    try {
      await this.employeeEnrollmentService.createEmployeeUser(this.token, username, password, this.employeeId);
      this.snackbar.open('User created.', null, {
        duration: 6000,
        panelClass: ['confirmation_snack_bar'],
      });
      await this.securityService.login(username, password);
      await this.router.navigateByUrl('/');
    } catch (httpClientError) {
      this.disableSubmit = false;
      this.serviceHandler.showErrorMessage(`${httpClientError.error.message}`);
    }
  }

  get username(): FormControl {
    return this.initialPasswordForm.get('username') as FormControl;
  }

  get password(): FormControl {
    return this.initialPasswordForm.get('password') as FormControl;
  }
}
