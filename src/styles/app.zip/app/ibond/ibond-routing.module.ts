import { RouterModule, Routes } from '@angular/router';
import { GetQuotesComponent } from './get-quotes/get-quotes.component';
import { ApplicationSubmitComponent } from './application-submit/application-submit.component';
import { LoggedInResolver } from '../enrollment/application/providers/logged-in.resolver';
import { NgModule } from '@angular/core';
import { ApplicationFormComponent } from './application-form/application-form.component';
import { AuthGuard } from '../security/app.auth.guard';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { AttorneyGuard } from '../user/role-guard/attorney.guard';

const routes: Routes = [
  { path: '', redirectTo: 'getquotes/landp', pathMatch: 'full' },
  { path: 'getquotes', redirectTo: 'landp', pathMatch: 'full' },
  {
    path: 'getquotes/:bondType',
    component: GetQuotesComponent,
    data: { breadcrumb: 'Quote' },
    resolve: { loggedIn: LoggedInResolver },
    canActivate: [AttorneyGuard],
  },
  {
    path: 'getquotes/:bondType/:id',
    component: GetQuotesComponent,
    data: { breadcrumb: 'Quote' },
    canActivate: [AuthGuard, AttorneyGuard],
  },
  {
    path: 'application/:bondType/:id',
    component: ApplicationFormComponent,
    data: { breadcrumb: 'application' },
    canActivate: [AuthGuard, AttorneyGuard],
  },
  {
    path: ':client_id/:client_type/application/:bondType',
    component: ApplicationFormComponent,
    data: { breadcrumb: 'application' },
    resolve: { loggedIn: LoggedInResolver },
  },
  {
    path: 'application/:bondType',
    component: ApplicationFormComponent,
    data: { breadcrumb: 'application' },
    resolve: { loggedIn: LoggedInResolver },
    canActivate: [AttorneyGuard],
  },
  { path: 'confirm/:bondType/:id', component: ApplicationSubmitComponent, canActivate: [AuthGuard, AttorneyGuard] },
  { path: 'product/product-overview', component: ProductOverviewComponent, canActivate: [AuthGuard] },
  { path: 'enrollment/application-overview', data: { queryString: true }, component: ApplicationSubmitComponent, canActivate: [AuthGuard] },
  { path: 'create-user', component: CreateUserComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IbondRoutingModule { }
