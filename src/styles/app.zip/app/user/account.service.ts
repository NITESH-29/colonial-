import { AbstractService } from '../common/services/abstract-service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CreateAccountRequest } from './request-models/create-account-request';
import { UserImpl } from '../security/user';
import { ServiceHandler } from '../common/utils/service-handler.service';
import { JsonConvertService } from '../common/utils/json-convert.service';
import { JsonConvert } from 'json2typescript';
import { HttpOptions } from '../common/http-options';
import { UsernameAvailabilityRequest } from './availability/username-availability-request';
import { UsernameAvailabilityResponse } from './availability/username-availability-response';
import { Observable } from 'rxjs';
import { EmailAvailabilityRequest } from './availability/email-availability-request';
import { EmailAvailabilityResponse } from './availability/email-availability-response';
import { AsyncValidatorFn } from '@angular/forms';
import { AvailabilityCheck, getAvailabilityAsyncValidator } from './availability/get-availability-async-validator';
import { ApplicationPopulateService } from '../ibond/service/application-populate.service';

export type AccountCreator = (req: CreateAccountRequest) => Promise<UserImpl>;

@Injectable()
export class AccountService extends AbstractService {
  private readonly options: HttpOptions;
  private readonly jsonConvert: JsonConvert;

  constructor(
    private http: HttpClient,
    private serviceHandler: ServiceHandler,
    jsonConvertService: JsonConvertService,
    private applicationPopulateService: ApplicationPopulateService
  ) {
    super();

    this.options = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      observe: 'body',
    };

    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  async createClientAccount(req: CreateAccountRequest): Promise<UserImpl> {
    return this.createAccount('Client', req);
  }

  async createAttorneyAccount(req: CreateAccountRequest): Promise<UserImpl> {
    return this.createAccount('Attorney', req);
  }

  async createAgentAccount(req: CreateAccountRequest): Promise<UserImpl> {
    return this.createAccount('Agent', req);
  }

  checkUsernameAvailability(req: UsernameAvailabilityRequest): Observable<UsernameAvailabilityResponse> {
    return this.checkAvailability('username', req) as Observable<UsernameAvailabilityResponse>;
  }

  checkEmailAvailability(req: EmailAvailabilityRequest): Observable<EmailAvailabilityResponse> {
    return this.checkAvailability('email', req) as Observable<EmailAvailabilityResponse>;
  }

  getUsernameAvailabilityAsyncValidator(): AsyncValidatorFn {
    return getAvailabilityAsyncValidator(
      'username',
      requestedUsername => this.checkUsernameAvailability({ requestedUsername })
    );
  }

  getEmailAvailabilityAsyncValidator(): AsyncValidatorFn {
    return getAvailabilityAsyncValidator(
      'email',
      requestedEmail => this.checkEmailAvailability({ requestedEmail })
    );
  }

  private async createAccount(accountType: string, req: CreateAccountRequest): Promise<UserImpl> {
    const createdUser = await this.http.post(this.requestURL(accountType.toLowerCase()), req, this.options).toPromise();
    // localStorage.setItem("createdUser", JSON.stringify(createdUser));
    this.applicationPopulateService.setCreatedUser(createdUser);
    this.serviceHandler.handleConfirm(`${accountType} Account Created`);
    return this.jsonConvert.deserialize(createdUser, UserImpl) as UserImpl;
  }

  private checkAvailability(type: string, req: UsernameAvailabilityRequest | EmailAvailabilityRequest): Observable<AvailabilityCheck> {
    return this.http.post(this.requestURL(`availability/${type}`), req, this.options) as Observable<AvailabilityCheck>;
  }

  requestURL(path: string): string {
    const accountServicePrefix = '/account';
    return super.requestURL(`${accountServicePrefix}/${path}`);
  }
}
