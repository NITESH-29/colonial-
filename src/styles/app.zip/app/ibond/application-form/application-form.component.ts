import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IbondBaseService } from '../service/ibond-base.service';
import { GlobalConstants } from '../constant/global.constant';

@Component({
  selector: 'app-application-form',
  templateUrl: './application-form.component.html',
  styleUrls: ['./application-form.component.scss'],
})
export class ApplicationFormComponent implements OnInit, OnDestroy {
  bondType: string;
  applicationId: number;
  signUp = false;
  applicantInfo = {};
  myClass = 'display-none stepper-containt';

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public lpService: IbondBaseService
  ) { }
  ngOnInit() {
    this.activatedRoute.params.subscribe(parms => {
      this.bondType = parms.bondType;
      this.applicationId = parms.id;
    });
    this.lpService.getSignUpValue().subscribe(val => {
      this.signUp = val || false;
      if (this.signUp) {
        this.myClass = 'display-unset stepper-containt';
      } else {
        this.myClass = 'display-none stepper-containt';
      }
      // [style.display]="signUp ? 'unset' : 'none'"

    });
    this.lpService.getApplicantInfo().subscribe(data => {
      this.applicantInfo = data;
    });
  }
  assignApplicationId(value) {
    this.applicationId = value;
  }

  ngOnDestroy(): void {
    this.lpService.setSignUpValue(false);
  }
}
