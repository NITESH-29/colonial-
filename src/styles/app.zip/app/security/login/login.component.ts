import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Params, Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { SecurityService } from '../security.service';
import { UserService } from '../user.service';
import { ClientService } from '../../user/client/client.service';
import { JsonConvert } from 'json2typescript';
import { AppConfigService } from '../../app-config-service';
import { CourtBondFacilitationService } from '../../enrollment/facilitation/court-bond-facilitation.service';
import { ApplicationPopulateService } from 'src/app/ibond/service/application-populate.service';
import { UserIdleService } from 'angular-user-idle';

@Component({
  templateUrl: 'login.component.html',
  providers: [UserService, ClientService],
  styleUrls: ['login.component.scss'],
})

export class LoginComponent implements OnInit, OnDestroy {
  model: {
    username: string;
    password: string;
  };
  loginForm: FormGroup;
  returnUrl: string;
  errorMessage: string;
  initialized: boolean;
  colonialPhoneNumber: string;

  jsonConvert: JsonConvert;
  hide = true;
  sutoken: any;

  constructor(@Inject(DOCUMENT) private document,
    public fb: FormBuilder,
    private _route: ActivatedRoute,
    private router: Router,
    private securityService: SecurityService,
    private userIdleService: UserIdleService,
    private courtBondFacilitationService: CourtBondFacilitationService,
    private applicationPopulateService: ApplicationPopulateService,
    appConfigService: AppConfigService) {
    appConfigService.getConfig().subscribe(config => this.colonialPhoneNumber = config.colonialPhoneNumber);
  }

  ngOnInit() {
    sessionStorage.removeItem('applicationId');
    sessionStorage.removeItem('originState');
    this.document.body.classList.add('login-background');
    this.document.body.classList.remove('main-body-background');
    // If we're here, we need to logout first.
    this._route.queryParams.subscribe((route: Params) => {
      this.returnUrl = route['returnUrl'];
      this.sutoken = route['sutoken'];
      this.initialized = false;
    });
    if (!this.sutoken) {
      this.securityService.logout().then(() => {
        this.userIdleService.stopWatching();
        this.loginForm = this.fb.group({
          username: ['', [Validators.required]],
          password: ['', [Validators.required]],
        });
        this.errorMessage = null;
        this.initialized = true;
        if (!this.courtBondFacilitationService.getApplicationDetails().anonymousQuote) {
          this.courtBondFacilitationService.getApplicationDetails().type = null;
          this.courtBondFacilitationService.getApplicationDetails().amount = null;
          this.courtBondFacilitationService.getApplicationDetails().premium = null;
          this.courtBondFacilitationService.getApplicationDetails().applicant = null;
          this.courtBondFacilitationService.getApplicationDetails().anonymousQuote = null;
        }
        this.applicationPopulateService.resetData();
      });

    }
  }

  ngOnDestroy() {
    this.document.body.classList.remove('login-background');
    this.document.body.classList.add('main-body-background');
  }

  login() {
    this.securityService.login(this.loginForm.get('username').value, this.loginForm.get('password').value)
      .then(data => {
        if (data && data.hasEmployeePermissions) {
          this.router.navigateByUrl(`/special-form`);
        } else {
          if (this.returnUrl == null) {
            this.router.navigateByUrl(`/`);
          } else {
            this.router.navigateByUrl(this.returnUrl);
          }
        }
      })
      .catch((errorResponse) => {
        if (![401, 403].includes(errorResponse.status)) {
          this.errorMessage = 'Unexpected server error. Please try again later.';
        } else {
          if (errorResponse.error) {
            this.errorMessage = errorResponse.error.message || 'Invalid username or password';
          } else {
            this.errorMessage = 'Invalid username or password';
          }
        }
      });
  }

  createAccount() {
    if (this.returnUrl == null ||
      this.returnUrl === `/dashboard`) {
      this.router.navigateByUrl('ibond/create-user');
    } else {
      this.router.navigate([`/ibond/create-user`],
        { queryParams: { returnUrl: this.returnUrl } } as NavigationExtras);
    }
  }

  resetErrors() {
    this.errorMessage = null;
  }
}
