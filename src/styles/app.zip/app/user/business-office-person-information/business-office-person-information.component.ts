import { Component, Input } from '@angular/core';
import { BusinessOfficePersonInformationFormGroup } from './business-office-person-information-form-group';
import { salutations } from '../../common/utils/constants';

@Component({
  selector: 'app-business-office-person-information',
  templateUrl: './business-office-person-information.component.html',
})
export class BusinessOfficePersonInformationComponent {
  @Input() formGroup: BusinessOfficePersonInformationFormGroup;
  @Input() label = 'Contact Information';
  get salutations(): string[] { return salutations; }
}
