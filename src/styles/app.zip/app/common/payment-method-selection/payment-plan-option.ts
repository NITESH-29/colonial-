import { PaymentFrequencyType } from './payment_frequency_type';
import { PaymentPlanTypeModel } from './payment-plan-type-model';

enum PaymentPlanOptionType { // Not const enum so we preserve the 'mapping' code.
  SINGLE_PAYMENT = 'S',
  RECURRING_PAYMENT = 'R',
}

const PAYMENT_PLAN_OPTION_PREFIX_SINGLE_PAYMENT = PaymentPlanOptionType.SINGLE_PAYMENT + '_';
const PAYMENT_PLAN_OPTION_PREFIX_RECURRING_PAYMENT = PaymentPlanOptionType.RECURRING_PAYMENT + '_';

export class PaymentPlanOption {
  optionValue: string; // The unique value that identifies the option.
  optionLabel: string; // The text to be displayed for the option.
  paymentPlanOptionType: PaymentPlanOptionType; // The 'type' of option.
  paymentFrequencyType: PaymentFrequencyType;

  public static createSingleInstallmentPaymentPlanOption(paymentFrequencyType: PaymentFrequencyType)
    : PaymentPlanOption {
    let paymentPlanOption: PaymentPlanOption;

    const optionLabel = 'Single Payment';

    paymentPlanOption = new PaymentPlanOption();
    paymentPlanOption.optionValue = PaymentPlanOption.createSinglePaymentPlanOptionValue();
    paymentPlanOption.optionLabel = optionLabel;
    paymentPlanOption.paymentPlanOptionType = PaymentPlanOptionType.SINGLE_PAYMENT;
    paymentPlanOption.paymentFrequencyType = paymentFrequencyType;
    return paymentPlanOption;
  }

  public static createRecurringPaymentsPaymentPlanOption(paymentFrequencyType: PaymentFrequencyType): PaymentPlanOption {
    let paymentPlanOption: PaymentPlanOption;

    const optionLabel = `${paymentFrequencyType.defaultDisplayText} Payments`;

    paymentPlanOption = new PaymentPlanOption();
    paymentPlanOption.optionValue = PaymentPlanOption.createRecurringPaymentsPaymentPlanOptionValue(paymentFrequencyType);
    paymentPlanOption.optionLabel = optionLabel;
    paymentPlanOption.paymentPlanOptionType = PaymentPlanOptionType.RECURRING_PAYMENT;
    paymentPlanOption.paymentFrequencyType = paymentFrequencyType;
    return paymentPlanOption;
  }

  public static createSinglePaymentPlanOptionValue(): string {
    let optionValue: string;
    optionValue = `${PAYMENT_PLAN_OPTION_PREFIX_SINGLE_PAYMENT}`;
    return optionValue;
  }

  public static createRecurringPaymentsPaymentPlanOptionValue(paymentFrequencyType: PaymentFrequencyType): string {
    let optionValue: string;
    optionValue = `${PAYMENT_PLAN_OPTION_PREFIX_RECURRING_PAYMENT}${paymentFrequencyType.persistenceId}`;
    return optionValue;
  }

  public static createPaymentPlanOptionOptionValue(paymentPlanTypeModel: PaymentPlanTypeModel): string {
    let optionValue: string;
    if (paymentPlanTypeModel.isSingleInstallment()) {
      optionValue = PaymentPlanOption.createSinglePaymentPlanOptionValue();
    } else {
      optionValue = PaymentPlanOption.createRecurringPaymentsPaymentPlanOptionValue(paymentPlanTypeModel.paymentFrequencyType);
    }
    return optionValue;
  }

  /**
   * Extract the 'identifier' value from the option value.
   * @param optionValue to be examined.
   */
  public static extractOptionId(optionValue: string): string | null {
    let optionId: string | null;
    if (!!optionValue) {
      if (optionValue.startsWith(PAYMENT_PLAN_OPTION_PREFIX_SINGLE_PAYMENT)) {
        optionId = null;
      } else if (optionValue.startsWith(PAYMENT_PLAN_OPTION_PREFIX_RECURRING_PAYMENT)) {
        optionId = optionValue.substr(PAYMENT_PLAN_OPTION_PREFIX_RECURRING_PAYMENT.length);
      } else {
        optionId = null;
      }
    } else {
      optionId = null;
    }
    return optionId;
  }

  public static extractOptionType(optionValue: string): PaymentPlanOptionType | null {
    let optionType: PaymentPlanOptionType;
    if (!!optionValue) {
      if (optionValue.startsWith(PAYMENT_PLAN_OPTION_PREFIX_SINGLE_PAYMENT)) {
        optionType = PaymentPlanOptionType.SINGLE_PAYMENT;
      } else if (optionValue.startsWith(PAYMENT_PLAN_OPTION_PREFIX_RECURRING_PAYMENT)) {
        optionType = PaymentPlanOptionType.RECURRING_PAYMENT;
      } else {
        optionType = null;
      }
    } else {
      optionType = null;
    }
    return optionType;
  }

  public static isSinglePaymentOption(optionValue: string): boolean {
    let isOption: boolean;
    const optionType = PaymentPlanOption.extractOptionType(optionValue);
    isOption = optionType === PaymentPlanOptionType.SINGLE_PAYMENT;
    return isOption;
  }

  public static isRecurringPaymentOption(optionValue: string): boolean {
    let isOption: boolean;
    const optionType = PaymentPlanOption.extractOptionType(optionValue);
    isOption = optionType === PaymentPlanOptionType.RECURRING_PAYMENT;
    return isOption;
  }

  public isSinglePaymentOption(): boolean {
    let isOption: boolean;
    isOption = PaymentPlanOption.isSinglePaymentOption(this.optionValue);
    return isOption;
  }

  public isRecurringPaymentOption(): boolean {
    let isOption: boolean;
    isOption = PaymentPlanOption.isRecurringPaymentOption(this.optionValue);
    return isOption;
  }

  public getOptionId(): string | null {
    return PaymentPlanOption.extractOptionId(this.optionValue);
  }

  public getOptionType(): string {
    return PaymentPlanOption.extractOptionType(this.optionValue);
  }
}
