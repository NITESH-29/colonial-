import { JsonObject, JsonProperty } from 'json2typescript';
import { CurrencyConverter } from '../../common/utils/currency-converter';
import { Auditable, AuditableObject } from '../../common/auditable-object';
import { PhoneNumberConverter } from '../../common/utils/phone-number-converter';

export interface AnonymousQuote extends Auditable {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  amount: string;
  premium: string;
  isCompany?: boolean;
  companyName?: string;
  premiumRateId?: number;
}

@JsonObject('AnonymousQuoteImpl')
export class AnonymousQuoteImpl extends AuditableObject implements AnonymousQuote {
  @JsonProperty('firstName', String, true)
  firstName: string = undefined;

  @JsonProperty('lastName', String, true)
  lastName: string = undefined;

  @JsonProperty('email', String, true)
  email: string = undefined;

  @JsonProperty('phone', PhoneNumberConverter, true)
  phone: string = undefined;

  @JsonProperty('amount', CurrencyConverter, true)
  amount: string = undefined;

  @JsonProperty('premium', CurrencyConverter, true)
  premium: string = undefined;

  @JsonProperty('company', Boolean, true)
  isCompany?: boolean = undefined;

  @JsonProperty('companyName', String, true)
  companyName?: string = undefined;

  @JsonProperty('premiumRateId', Number, true)
  premiumRateId?: number = undefined;
}
