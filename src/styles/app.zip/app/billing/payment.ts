import { AuditableObject } from '../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../common/utils/date-converter';
import { PaymentPlan } from './payment-plan';
import { Safe } from './safe';

@JsonObject('Payment')
export class Payment extends AuditableObject {
  @JsonProperty('paymentDate', DateConverter, true)
  paymentDate: Date = null;

  @JsonProperty('reversed', Boolean, true)
  reversed: boolean = null;

  @JsonProperty('amount', Number, true)
  amount: number = null;

  @JsonProperty('paymentPlan', PaymentPlan, true)
  paymentPlan: PaymentPlan = null;

  @JsonProperty('safe', Safe, true)
  safe: Safe = null;
}
