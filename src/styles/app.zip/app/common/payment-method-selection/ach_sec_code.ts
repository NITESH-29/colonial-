/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('AchSecCode')
export class AchSecCode extends AbstractIdentifierEnum {
  private static _values: Map<string, AchSecCode> = new Map<string, AchSecCode>();
  public static PPD = new AchSecCode('PPD', 'PPD (Prearranged Payment and Deposit)');
  public static WEB = new AchSecCode('WEB', 'WEB (Internet-Initiated Entry)');
  public static TEL = new AchSecCode('TEL', 'TEL (Telephone-Initiated Entry)');
  public static CCD = new AchSecCode('CCD', 'CCD (Cash Concentration and Disbursement)');

  // We don't register defaultDisplayText with JSON->TypeScript lib as we don't need the server's value.
  get defaultDisplayText(): string {
    return this._defaultDisplayText;
  }

  /**
   * Constructing an AbstractIdentifierEnum registers it in the static set of enum instances.
   * @param persistenceId
   * @param _defaultDisplayText
   */
  private constructor(
    persistenceId: string, // Relates the enum with the server enum representation.
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): AchSecCode {
    return AchSecCode._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): AchSecCode[] {
    return Array.from(AchSecCode._values.values());
  }

  protected registerEnum(): void {
    if (AchSecCode._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid AchSecCode 'enum' identifier: ${this.persistenceId}`);
    }
    AchSecCode._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class AchSecCodeConverter extends AbstractIdentifierEnumConverter<AchSecCode> {
  deserialize(enumObject: any): AchSecCode {
    let enumInstance: AchSecCode;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = AchSecCode.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}
