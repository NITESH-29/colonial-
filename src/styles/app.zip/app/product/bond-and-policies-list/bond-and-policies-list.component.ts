import {
  Component,
  OnInit,
} from '@angular/core';
import * as Moment from 'moment';
import { extendMoment } from 'moment-range';
import { UserImpl } from '../../security/user';
import { SecurityService } from '../../security/security.service';
import { MatTabChangeEvent } from '@angular/material';
import { ProductService } from '../products.service';
import { Product } from '../product';
import { FormControl, FormGroup } from '@angular/forms';
import { TableDefaultDetails } from '../../form-components/generic-table-search/table-default-details';
import { ActivatedRoute } from '@angular/router';

const moment = extendMoment(Moment);

@Component({
  selector: 'app-bond-and-policies-list',
  templateUrl: './bond-and-policies-list.component.html',
  styleUrls: ['./bond-and-policies-list.component.scss'],
})
export class BondAndPoliciesListComponent implements OnInit {

  tableDefaultDetails: TableDefaultDetails;
  user: UserImpl;

  constructor(private securityService: SecurityService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.user = this.securityService.user;
    const status = this.route.snapshot.paramMap.get('status');
    if (status) {
      this.tableDefaultDetails = {
        defaultStatus: this.convertStatus(status),
        bondClassification: 'Court', // default to court cause it's the only one for now
      };
    } else {
      this.tableDefaultDetails = {
        defaultStatus: 'All',
        bondClassification: 'Court', // default to court cause it's the only one for now
      };
    }
  }

  convertStatus(statusParam: string): string {
    let defaultStatus;
    switch (statusParam) {
      case 'open':
        defaultStatus = 'Open';
        break;
      case 'closed':
        defaultStatus = 'Closed';
        break;
      case 'past-due':
        defaultStatus = 'Past Due';
        break;
      case 'renewal-ready':
        defaultStatus = 'Open - Renewal Ready';
        break;
      case 'pending-renewal':
        defaultStatus = 'Pending Renewal';
        break;
      default:
        defaultStatus = 'All';
        break;
    }
    return defaultStatus;
  }


}
