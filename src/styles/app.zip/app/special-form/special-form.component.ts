import { DOCUMENT } from '@angular/common';
import { Component, Inject, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-special-form',
  templateUrl: './special-form.component.html',
  styleUrls: ['./special-form.component.scss'],
})
export class SpecialFormComponent implements OnInit {

  constructor(private router: Router, @Inject(DOCUMENT) private document) { }
  pdfStage = `Validate & Generate PDF`;
  ngOnInit() {
    this.document.body.classList.add('mat-app-background');
    this.document.body.classList.remove('main-body-background');
    const urls = this.router.routerState.snapshot.url.split('/');
    switch (urls[urls.length - 1]) {
      case 'generate-pdf': this.pdfStage = 'Validate & Generate PDF'; break;
      case 'manage-pdf': this.pdfStage = 'Manage PDF'; break;
    }
  }

  validateClicked() {
    this.pdfStage = `Validate & Generate PDF`;
    this.router.navigateByUrl('/special-form/generate-pdf');
  }

  manageClicked() {
    this.pdfStage = `Manage PDF`;
    this.router.navigateByUrl('/special-form/manage-pdf');
  }

}
