import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { PaymentConstants } from '../constants/payment-constants';

@Injectable({
  providedIn: 'root',
})

export class PaymentService {
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  public paymentApplicantDetailsObj = {
    'application_firstName': '',
    'application_lastName': '',
    'application_address1': '',
    'application_address2': '',
    'application_city': '',
    'application_state': '',
    'application_zipCode': '',
    'application_phone': '',
  };
  constructor(
    private httpClient: HttpClient
  ) { }

  getPaymentdetails(id) {
    //  console.log('----> ', PaymentConstants.GET_PAYMENT_METHOD);
    return this.httpClient.get(PaymentConstants.GET_PAYMENT_METHOD + '/' + id);
  }

  async getSavedBillingProfile(id) {
    return await this.httpClient.get(PaymentConstants.GET_SAVED_BILLING_PROFILE
      + '/' + id + '?validFilterValue=true&deactivatedFilterValue=false').toPromise();
  }

  getApplicationDetailsById(id) {
    return this.httpClient.get(PaymentConstants.GET_APPLICATION_BY_ID + id);
  }

  getZipCode(zipCode) {
    return this.httpClient.get(PaymentConstants.LNP_GET_ZIP_CODE + zipCode);
  }

  async checkAlreadyExistCard(requestObject) {
    return await this.httpClient.post(PaymentConstants.CARD_AVAILABILITY, requestObject).toPromise();
  }

  deserializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3') : phoneNumber;
  }

  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  getStates(): Observable<any> {
    return this.httpClient.get(PaymentConstants.GET_STATE);
  }
  isEmpty(value: any) {
    let isEmpty: boolean = value === null || value === undefined ? true : false;
    if (!isEmpty && value instanceof Array) {
      isEmpty = value.length === 0;
    }
    if (!isEmpty && typeof value === 'string') {
      isEmpty = value.trim().length === 0;
    }
    if (!isEmpty && value instanceof Object && !(value instanceof Date) && !(value instanceof String)) {
      isEmpty = Object.getOwnPropertyNames(value).length === 0;
    }
    return isEmpty;
  }

}
