import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from './auditable-object';
import { PersonSummary, PersonSummaryImpl } from './person-summary';
import { CompanyOfficeSummary, CompanyOfficeSummaryImpl } from './company-office-summary';

export interface CompanyOfficePerson {
  id: number;
  active: boolean;
  responsiblePerson: boolean;
  person: PersonSummary;
  title: string;
  companyOffice: CompanyOfficeSummary;
}

@JsonObject('CompanyOfficePersonImpl')
export class CompanyOfficePersonImpl extends AuditableObject implements CompanyOfficePerson {
  @JsonProperty('active', Boolean, true)
  active: boolean = null;

  @JsonProperty('person', PersonSummaryImpl, true)
  person: PersonSummary = new PersonSummaryImpl();

  @JsonProperty('companyOffice', CompanyOfficeSummaryImpl, true)
  companyOffice: CompanyOfficeSummary = new CompanyOfficeSummaryImpl();

  @JsonProperty('responsiblePerson', Boolean, true)
  responsiblePerson: boolean = null;

  @JsonProperty('title', String, true)
  title: string = null;
}
