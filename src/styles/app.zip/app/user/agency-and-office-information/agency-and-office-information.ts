import { Address } from '../../enrollment/application/court/model/common/address';

export interface AgencyAndOfficeInformation {
  id: string;
  name: string;
  website: string;
  phone: string;
  fax: string;
  email: string;
  sicCode: string;
  einNumber: string;
  licenseNumber: string;
  memberOfNasbp: boolean;
  address: Address;
}
