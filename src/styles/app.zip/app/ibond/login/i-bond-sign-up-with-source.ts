export interface IBondSignUpWithSource {
  incomingFrom: string;
}
