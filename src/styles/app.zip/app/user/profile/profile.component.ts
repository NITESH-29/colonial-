import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { SecurityService } from '../../security/security.service';
import { ProfileFormGroup } from './profile-form-group';
import { UserImpl } from '../../security/user';
import { UserService } from '../../security/user.service';
import { PersonAddressImpl } from '../../common/person-address';
import { PreviousRouteService } from '../../common/services/previous-route.service';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ProfileService } from './profile.service';
import { Router } from '@angular/router';
import { AttorneyReferralListEntryComponent } from '../attorney-referral-list/attorney-referral-list-entry.component';
import { of } from 'rxjs';

type PersonKind = 'Personal' | 'Agent' | 'Attorney';
type BusinessKind = 'Company' | 'Agency' | 'Firm';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  formGroup: ProfileFormGroup;
  disableUsernamePassword = true;
  user: UserImpl;

  personKind: PersonKind = 'Personal';
  businessKind: BusinessKind = 'Company';

  @ViewChild('referralListComponent') referralListComponent: AttorneyReferralListEntryComponent;
  private isAddingStates: boolean;

  /**
   *
   * @param securityService
   * @param userService
   * @param profileService
   * @param previousRouteService - unused but necessary, if it not yet been initialized, it needs to be initialized by this time
   * so it records the proper previous route.
   * @param serviceHandler
   * @param router
   */
  constructor(
    private securityService: SecurityService,
    private userService: UserService,
    private profileService: ProfileService,
    private previousRouteService: PreviousRouteService,
    private serviceHandler: ServiceHandler,
    private router: Router
  ) { }

  async ngOnInit() {
    await this.securityService.refreshCurrentUser().subscribe(
      (user) => {
        this.user = user;
        this.initialize();
      }
    );
  }

  @HostListener('window:beforeunload', ['$event'])
  refresh($event) {
    return (false);
  }

  get personalLabel(): string {
    return `${this.personKind} information`;
  }

  get companyLabel(): string {
    return `${this.businessKind} information`;
  }

  initialize(freshlySavedUser?: UserImpl) {
    const currentUser = of(freshlySavedUser ? freshlySavedUser : this.securityService.user);
    currentUser.subscribe(
      user => {
        this.formGroup = new ProfileFormGroup(user, false, { isAddressRequired: true });

        this.user = user;

        const formValue = this.user;
        if (this.user.hasAgentRole || this.user.hasAttorneyRole) {
          const { companyOfficePersons: [{ title }] } = formValue.person;
          formValue.person['title'] = title;
        }

        this.formGroup.patchValue(formValue);
        this.assignLabels();

        const data = this.profileService.unStashProfile();

        if (data) {
          this.formGroup.patchValue(data);
        }

        this.formGroup.get('personalInformation.email').setAsyncValidators(
          this.profileService.getOtherEmailAvailabilityAsyncValidator(this.user.person)
        );
      }
    );
  }

  save() {
    const referralListExistsAndIsValid = (this.referralListComponent)
      ? this.referralListComponent.valid
      : true;

    if (this.formGroup.valid && referralListExistsAndIsValid) {
      const updatedUserInfo = this.formGroup.getRawValue();
      // TODO: find a way to not do what is about to happen
      // since the form groups do not contain all the data we need, we must pull only what we need
      // from updatedUserInfo and put it in user
      // start of things i want to delete
      this.user.person.firstName = updatedUserInfo.person.firstName;
      this.user.person.initial = updatedUserInfo.person.initial;
      this.user.person.lastName = updatedUserInfo.person.lastName;
      this.user.person.suffix = updatedUserInfo.person.suffix;
      this.user.person.salutation = updatedUserInfo.person.salutation;
      this.user.person.phone = updatedUserInfo.person.phone;
      this.user.person.email = updatedUserInfo.person.email;
      this.user.person.profession = updatedUserInfo.person.profession;
      if (!this.user.person.personAddresses || this.user.person.personAddresses.length === 0) {
        this.user.person.personAddresses = [];
        this.user.person.personAddresses.push(new PersonAddressImpl());
      }
      this.user.person.personAddresses[0].street1 = updatedUserInfo.person.personAddresses[0].street1;
      this.user.person.personAddresses[0].street2 = updatedUserInfo.person.personAddresses[0].street2;
      this.user.person.personAddresses[0].city = updatedUserInfo.person.personAddresses[0].city;
      this.user.person.personAddresses[0].state = updatedUserInfo.person.personAddresses[0].state;
      this.user.person.personAddresses[0].zipCode = updatedUserInfo.person.personAddresses[0].zipCode;

      const allAddressFieldsFalsy = !Object.values(this.user.person.personAddresses[0]).reduce((a, b) => a || b, null);

      if (allAddressFieldsFalsy) {
        this.user.person.personAddresses = [];
      }

      if (this.user.hasAgentRole || this.user.hasAttorneyRole) {
        this.user.person.companyOfficePersons[0].title = updatedUserInfo.person['title'];
      }

      if (this.user.hasAttorneyRole) {
        this.user.agent.statesPracticedIn = updatedUserInfo.agent.statesPracticedIn;
      }

      // end of things I want to delete
      // this could be possible by either storing user info in the service
      // or sending the data as is to the backend and let it handle it there.
      this.userService.updateUser(this.user).then(() => {
        this.initialize.bind(this);
        this.router.navigateByUrl('/');
      },
        (error: HttpErrorResponse) => {
          this.serviceHandler.showErrorMessage(`Could not save profile: ${error.statusText}`);
          console.error(error);
        }
      );
    } else {
      CommonUtilities.markAllTouched(this.formGroup);
      this.serviceHandler.showErrorMessage('Please fix validation errors before saving.');
    }
  }

  statesChanged(states: string[]): void {
    this.formGroup.statesPracticedIn.setValue(states);
  }

  isAddingStatesChanged(value: boolean): void {
    this.isAddingStates = value;
  }

  cancel() {
    this.router.navigateByUrl('/');
  }

  get personId() {
    return this.user.person.id;
  }

  onCompanyNavigated() {
    this.profileService.stashProfile(this.formGroup.getRawValue());
  }

  private assignLabels(): void {
    if (this.user.hasAgentRole) {
      this.personKind = 'Agent';
      this.businessKind = 'Agency';
    } else if (this.user.hasAttorneyRole) {
      this.personKind = 'Attorney';
      this.businessKind = 'Firm';
    } else {
      this.personKind = 'Personal';
      this.businessKind = 'Company';
    }
  }
}
