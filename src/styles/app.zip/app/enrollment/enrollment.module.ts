import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EnrollmentRoutingModule } from './enrollment-routing.module';

import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import {
  CalendarModule,
  CheckboxModule,
  DataListModule, EditorModule, PaginatorModule, TabViewModule,
} from 'primeng/primeng';
// Material
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatProgressBarModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatSnackBarModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule, MatTooltipModule,
} from '@angular/material';
import { MatStepperModule } from '@angular/material/stepper';
import { ApplicantInfoComponent } from './applicant-info/applicant-info.component';
import { TableModule } from 'primeng/table';
import { ApplicationListComponent } from './application-list/application-list.component';
import { ApplicationOverviewComponent } from './application-overview/application-overview.component';

import { AdjudicationComponent } from './adjudication/adjudication.component';
import { CommonComponentsModule } from '../common/common-components.module';
import { UserModule } from '../user/user.module';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { FormComponentsModule } from '../form-components/form-components.module';
import { ProductModule } from '../product/product.module';
import { FactorsPreventingSubmissionComponent } from './adjudication/factors-preventing-submission/factors-preventing-submission.component';
import { FileVerificationsComponent } from './adjudication/file-verifications/file-verifications.component';
import { AdditionalDocumentsComponent } from './adjudication/additional-documents/additional-documents.component';
import { ApplicationActivityComponent } from './adjudication/application-activity/application-activity.component';
import { AttorneyInformationComponent } from './adjudication/attorney-information/attorney-information.component';
import { ObligeeInformationComponent } from './adjudication/obligee-information/obligee-information.component';
import { ApplicationInformationComponent } from './adjudication/application-information/application-information.component';
import { CollateralComponent } from './adjudication/collateral/collateral.component';
import { ColonialTableModule } from '../colonial-table/colonial-table.module';
import { ApplicationNoteService } from './adjudication/application-note.service';
import { ConfirmationSnackBarComponent } from './adjudication/confirmation-snack-bar/confirmation-snack-bar.component';
import { OtherActionsComponent } from './adjudication/other-actions/other-actions.component';
import { FileCardComponent } from './adjudication/file-card/file-card.component';
import { AddlDocCardComponent } from './adjudication/additional-documents/addl-doc-card/addl-doc-card.component';
import { AdjudicationFileUploadComponent } from './adjudication/adjudication-file-upload/adjudication-file-upload.component';
import { ApplicationActionConfirmationDialogComponent } from './adjudication/application-action-confirmation-dialog/application-action-confirmation-dialog.component';
import { SelectEmailDialogComponent } from './adjudication/select-email-dialog/select-email-dialog.component';
import { AdjudicationFilesComponent } from './adjudication/adjudication-files/adjudication-files.component';
import { CreditScoreDialogComponent } from './adjudication/factors-preventing-submission/credit-score-dialog/credit-score-dialog.component';
import { KnockoutQuestionDialogComponent } from './adjudication/factors-preventing-submission/knockout-question-dialog/knockout-question-dialog.component';
import { SoftHoldQuestionsComponent } from './adjudication/soft-hold-questions/soft-hold-questions.component';
import { SoftHoldQuestionOverrideDialogComponent } from './adjudication/soft-hold-questions/soft-hold-question-override-dialog/soft-hold-question-override-dialog.component';
import { SortNotesPipe } from './adjudication/application-activity/sort-notes.pipe';


@NgModule({
  imports: [
    CommonModule,
    EnrollmentRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    CommonComponentsModule,
    FormComponentsModule,
    UserModule,
    ProductModule,
    ColonialTableModule,

    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    TableModule,
    PaginatorModule,
    TabViewModule,
    EditorModule,

    // Material Stuff
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDividerModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatStepperModule,
    MatSlideToggleModule,
    MatTooltipModule,
  ],
  declarations: [
    ApplicantInfoComponent,
    ApplicationListComponent,
    ApplicationOverviewComponent,
    AdjudicationComponent,
    FactorsPreventingSubmissionComponent,
    FileVerificationsComponent,
    AdditionalDocumentsComponent,
    ApplicationActivityComponent,
    AttorneyInformationComponent,
    ObligeeInformationComponent,
    ApplicationInformationComponent,
    CollateralComponent,
    ConfirmationSnackBarComponent,
    OtherActionsComponent,
    FileCardComponent,
    AddlDocCardComponent,
    AdjudicationFileUploadComponent,
    ApplicationActionConfirmationDialogComponent,
    SelectEmailDialogComponent,
    AdjudicationFilesComponent,
    CreditScoreDialogComponent,
    KnockoutQuestionDialogComponent,
    SoftHoldQuestionsComponent,
    SoftHoldQuestionOverrideDialogComponent,
    SortNotesPipe,
  ],
  providers: [
    ApplicationNoteService,
  ],
  exports: [
    ApplicantInfoComponent,
    FactorsPreventingSubmissionComponent,
    FileVerificationsComponent,
    AdditionalDocumentsComponent,
    ApplicationActivityComponent,
    AttorneyInformationComponent,
    ObligeeInformationComponent,
    ApplicationInformationComponent,

    // Material Stuff
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatStepperModule,
    MatSlideToggleModule,
  ],
  entryComponents: [
    ConfirmationSnackBarComponent,
    AdjudicationFileUploadComponent,
    ApplicationActionConfirmationDialogComponent,
    SelectEmailDialogComponent,
    CreditScoreDialogComponent,
    KnockoutQuestionDialogComponent,
    SoftHoldQuestionOverrideDialogComponent,
  ],
})
export class EnrollmentModule {
}
