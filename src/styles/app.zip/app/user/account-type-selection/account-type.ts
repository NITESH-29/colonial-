export type AccountTypeName = 'Insurance Agent' | 'Attorney' | 'Client' | 'Personal/Company';

export interface AccountType {
  title: AccountTypeName;
  description: string;
  routerLink: string;
}
