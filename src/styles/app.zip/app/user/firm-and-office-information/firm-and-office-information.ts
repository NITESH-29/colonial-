import { Address } from '../../enrollment/application/court/model/common/address';

export interface FirmAndOfficeInformation {
  id: string;
  name: string;
  website: string;
  phone: string;
  fax: string;
  email: string;
  sicCode: string;
  address: Address;
}
