import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { GetQuotesService } from '../service/get-quotes.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginComponent } from 'src/app/ibond/login/login.component';
import { MatDialog } from '@angular/material';
import { SecurityService } from 'src/app/security/security.service';
import { UserImpl } from 'src/app/security/user';
import { IbondBaseService } from '../service/ibond-base.service';
import { ChangeBondComponent } from '../common/change-bond/change-bond.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { SpinnerService } from '../service/spinner.service';
import { CurrencyFormatter } from '../../common/utils/currency-formatter';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { RequestService } from '../service/request.service';
import { VaFiduciaryRequestService } from '../service/va-fiduciary-request.service';
import { PoRequestService } from '../service/po-request.service';
import { LostCarTitleRequestService } from '../service/lost-car-title-request.service';
import { exists } from 'fs';
import { Location } from '@angular/common';
import { NoopScrollStrategy } from '@angular/cdk/overlay';

@Component({
  selector: 'app-get-quotes',
  templateUrl: './get-quotes.component.html',
  styleUrls: ['./get-quotes.component.scss'],
})
export class GetQuotesComponent implements OnInit {
  showPremium = false;
  heading = '';
  subheading = 'Start by providing the information below. We\'ll make this fast & simple!';
  imgYearCheck = 'assets/icons/checked-icon.svg';
  imgContinue = 'assets/img/hand-Icon.svg';
  calculatedPremium = {
    amount: 0,
    premium: 0,
  };
  twoYearPremium: '';
  threeYearPremium: '';
  getQuoteClick = false;
  loggedIn = false;
  user: UserImpl = null;
  userId: number;
  bondType = '';
  quoteform;
  isValid = false;
  applicationId: number;
  errorObject: object;
  termForm: FormGroup;
  responseData;
  bondTerm = '1';
  action: string;
  classificationId: number;
  constructor(
    private getQuotesService: GetQuotesService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private matDialog: MatDialog,
    private securityService: SecurityService,
    private lpService: IbondBaseService,
    private serviceHandlerSnackbar: ServiceHandler,
    private spinnerService: SpinnerService,
    private ref: ChangeDetectorRef,
    private gtmService: GoogleTagManagerService,
    private requestService: RequestService,
    private poRequestService: PoRequestService,
    private vaRequestService: VaFiduciaryRequestService,
    private lostCarTitleRequestService: LostCarTitleRequestService,
    private location: Location
  ) { }

  ngOnInit() {
    this.initializeparam();
    this.termForm = new FormGroup({
      'bondTerm': new FormControl(1),
    });
  }
  initializeparam(): void {
    this.activatedRoute.params.subscribe(parms => {
      this.bondType = parms.bondType;
      this.classificationId = this.activatedRoute.snapshot.queryParams['id'];
      this.applicationId = parms.id;
      this.calculatedPremium = {
        amount: 0,
        premium: 0,
      };
      this.showPremium = false;
      this.getQuoteClick = false;
      setTimeout(() => {
        const gtmBondType = this.requestService.setBondType(this.bondType);
        this.gtmService.sendEvent(
          'bond-quote-visit',
          `${gtmBondType}`,
          '',
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
          '',
          ''
        );
      }, 2000);
      this.initializeHeading();
    });
    this.activatedRoute.queryParams.subscribe(parms => {
      if (parms) {
        this.action = this.activatedRoute.snapshot.queryParams['action'];
      }
    });
    this.securityService.loggedIn$.subscribe(
      loggedIn$ => {
        this.loggedIn = loggedIn$;
        if (this.loggedIn) {
          this.user = this.securityService.user;
          this.userId = this.user.person.id;

        }
      }
    );
    if (this.applicationId || this.action === 'edit') {
      this.getApplicationDetailsById();
    }
  }

  initializeHeading() {
    this.heading = `Get a quote in minutes and purchase bonds online directly from Colonial`;
  }
  getApplicationDetailsById() {
    if (this.loggedIn) {
      const localData = JSON.parse(localStorage.getItem('temp_application'));
      if (this.applicationId) {
        this.lpService.getApplicationDetailsById(this.applicationId).subscribe(response => {
          this.responseData = response;
        });
      } else {
        this.responseData = localData;
      }
    } else {
      const appData = JSON.parse(localStorage.getItem('temp_application'));
      this.responseData = appData;
    }
  }
  login() {
    const dialogRef = this.matDialog.open(LoginComponent, {
      data: { clickFrom: 'header' },
      scrollStrategy: new NoopScrollStrategy(),
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
      }
    });
  }

  showSelectOptionForPremium(): boolean {
    const showSelectOptionForPremium = ['airport_security', 'employee_dishonesty', 'janitorial'];
    return showSelectOptionForPremium.indexOf(this.bondType) > -1 || (this.quoteform && this.quoteform.value.bondClassification &&
      this.quoteform.value.bondClassification.classificationName === 'Airport Security') ? true : false;
  }
  changeBond() {
    const dialogRef = this.matDialog.open(ChangeBondComponent, {
      data: {
        clickFrom: 'header',
        isAttorneyUser: this.isAttorney(),
      },
      scrollStrategy: new NoopScrollStrategy(),
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
      }
    });
  }
  getFormControlData(form) {
    this.showPremium = false;
    const callOfficeForQuote = form.value.bondClassification ? form.value.bondClassification.callOfficeForQuote : null;
    if (form.valid) {
      this.quoteform = form;
      this.isValid = true;
    } else {
      this.isValid = false;
    }
    if (callOfficeForQuote) {
      this.isValid = false;
    }

  }
  onSliderSlid() {
    if (this.getQuoteClick) {
      this.calculateQuote();
    }
  }

  calculateQuote() {
    this.spinnerService.show();
    switch (this.bondType) {
      case 'landp':
        switch (this.quoteform.value.classificationName) {
          case 'Registered Investment Adviser':
            this.calculateQuoteRiaOfficial();
            break;
          case 'Airport Security':
            this.calculateQuoteAirportSecurity();
            break;
          case 'Lost Car Title':
            this.calculateQuoteLostCarTitle();
            break;
          default:
            this.calculateQuoteLandP();
            break;
        }
        break;
      case 'notary':
        this.calculateQuoteNotary();
        break;
      case 'airport_security':
        this.calculateQuoteAirportSecurity();
        break;
      case 'employee_dishonesty':
        this.calculateEmployeeDishonesty();
        break;
      case 'po':
        this.calculateQuotePublicOfficial();
        break;
      case 'ria':
        this.calculateQuoteRiaOfficial();
        break;
      case 'vafiduciary':
        this.calculateQuoteVafiduciary();
        break;
      case 'janitorial':
        this.calculateJanitorial();
        break;
      case 'lost_instrument':
        this.calculateQuoteLostInstrument();
        break;
      case 'lost_car_title':
        this.calculateQuoteLostCarTitle();
        break;
      default:
        this.spinnerService.hide();
        break;
    }
  }

  calculateQuoteLandP() {
    if (this.quoteform.valid) {
      const request_obj = {
        'companyOrPersonal': this.quoteform.value.productType,
        'lpBondDetailsId': this.quoteform.value.bondClassification.id,
        'amount': this.quoteform.value.amount,
        'company': this.quoteform.value.productType === 'company' ? true : false,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
        'email': this.quoteform.value.individualEmail,
      };
      if (request_obj['company'] === true) {
        request_obj['companyName'] = this.quoteform.value.companyName;
      } else {
        request_obj['email'] = this.quoteform.value.individualEmail;
      }
      this.getQuotesService.getPremiumCalculationLandP(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.requestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
        const classificationName = this.quoteform.value.bondClassification.classificationName;
        const IPgroup = this.requestService.ipGroup;
        this.getQuoteGtmEvent('bond-quote', 'license and permit', this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
          IPgroup, classificationName ? classificationName : '',
          this.requestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }

  calculateQuoteNotary() {
    if (this.quoteform.valid) {
      const request_obj = {
        'amount': CurrencyFormatter.toRawNumber(this.quoteform.value.amount),
        'company': false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };

      this.getQuotesService.getPremiumCalculationNotary(request_obj).subscribe(
        (response: any) => {
          this.spinnerService.hide();
          this.calculatedPremium = response['premium'];
          this.getQuotesService.bondPremiumForGTM = response['premium'];
          this.showPremium = true;
          this.getQuoteClick = true;
          this.requestService.quoteId = response['anonymousQuote'].id;
          localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
          this.getQuoteGtmEvent('bond-quote', this.bondType, this.calculatedPremium.premium,
            this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.requestService.quoteId, '', '');
        },
        (error: any) => {
          this.spinnerService.hide();
          this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
        }
      );
    }
  }
  calculateEmployeeDishonesty() {
    if (this.quoteform.valid) {
      const request_obj = {
        'amount': this.quoteform.value.amount,
        // tslint:disable-next-line: radix
        'noOfEmployees': parseInt(this.quoteform.value.noOfEmployees),
        'company': this.quoteform.value.companyName && this.quoteform.value.companyName.length ? true : false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };
      this.getQuotesService.getPremiumEmployeeDishonesty(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.threeYearPremium = response['premium'].threeYearPremium;
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.requestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', this.bondType, this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.requestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }
  calculateQuoteAirportSecurity() {
    this.spinnerService.show();
    if (this.quoteform.valid) {
      const request_obj = {
        'companyOrPersonal': this.quoteform.value.productType,
        'lpBondDetailsId': this.quoteform.value.bondClassification.id,
        'amount': this.quoteform.value.amount,
        'company': this.quoteform.value.productType === 'company' ? true : false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };
      if (request_obj['company'] === true) {
        request_obj['companyName'] = this.quoteform.value.companyName;
      } else {
        request_obj['email'] = this.quoteform.value.individualEmail;
      }
      this.getQuotesService.getPremiunCalculationAirportSecurity(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.twoYearPremium = response['premium'].twoYearPremium;
        this.threeYearPremium = response['premium'].threeYearPremium;
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.requestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', 'airport_security', this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.requestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }
  calculateQuoteLostInstrument() {
    this.spinnerService.show();
    if (this.quoteform.valid) {
      const request_obj = {
        'companyOrPersonal': this.quoteform.value.productType,
        'amount': this.quoteform.value.amount,
        'company': this.quoteform.value.productType === 'company' ? true : false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
        'productType': this.quoteform.value.productType,
      };
      if (request_obj['company'] === true) {
        request_obj['companyName'] = this.quoteform.value.companyName;
      } else {
        request_obj['email'] = this.quoteform.value.individualEmail;
      }
      this.getQuotesService.getPremiunCalculationLostInstrument(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.requestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', this.bondType, this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.requestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }
  calculateQuotePublicOfficial() {
    if (this.quoteform.valid) {
      const request_obj = {
        'handlesPublicFund': this.quoteform.value.handlesPublicFund,
        'publicOfficialBondChoice': this.quoteform.value.classificationName,
        'amount': this.quoteform.value.amount,
        'lpBondDetailsId': this.quoteform.value.bondClassification.id,
        'company': false,
        'email': this.quoteform.value.publicFundsEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };
      this.getQuotesService.getPremiunCalculationPublicOfficial(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.poRequestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.poRequestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', this.bondType, this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.poRequestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
      });
    }
  }
  calculateQuoteRiaOfficial() {
    if (this.quoteform.valid) {
      const request_obj = {
        'companyOrPersonal': this.quoteform.value.productType,
        'amount': CurrencyFormatter.toRawNumber(this.quoteform.value.amount),
        // 'company': this.quoteform.value.productType === 'company' ? true : false,
        'company': false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };
      if (request_obj['company'] === true) {
        request_obj['companyName'] = this.quoteform.value.companyName;
      } else {
        request_obj['email'] = this.quoteform.value.individualEmail;
      }
      this.getQuotesService.getPremiumCalculation(request_obj, 'ria').subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.requestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', 'ria', this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.requestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }

  calculateQuoteVafiduciary() {
    if (this.quoteform.valid) {
      const request_obj = {
        'amount': this.quoteform.value.amount,
        'lpBondDetailsId': this.quoteform.value.lpBondDetailsId,
        'company': false,
        'email': this.quoteform.value.bondEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };
      this.getQuotesService.getPremiunCalculationVafiduciary(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.vaRequestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.vaRequestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', 'va fiduciary', this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.vaRequestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }
  calculateJanitorial() {
    if (this.quoteform.valid) {
      const request_obj = {
        'amount': this.quoteform.value.amount,
        // tslint:disable-next-line: radix
        'noOfEmployees': parseInt(this.quoteform.value.noOfEmployees),
        'company': this.quoteform.value.productType === 'company' ? true : false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
      };
      this.getQuotesService.getPremiumJanitorial(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.threeYearPremium = response['premium'].threeYearPremium;
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.requestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.requestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', this.bondType, this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '', this.requestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }

  calculateQuoteLostCarTitle() {
    if (this.quoteform.valid) {
      const request_obj = {
        'amount': this.quoteform.value.amount,
        'lpBondDetailsId': 454,
        'company': this.quoteform.value.productType === 'company' ? true : false,
        'email': this.quoteform.value.individualEmail,
        'firstName': this.quoteform.value.firstName,
        'lastName': this.quoteform.value.lastName,
        'phone': this.quoteform.value.phone,
        'productFor': this.quoteform.value.productType,
      };
      if (request_obj['company'] === true) {
        request_obj['companyName'] = this.quoteform.value.companyName;
      } else {
        request_obj['email'] = this.quoteform.value.individualEmail;
      }
      this.getQuotesService.getPremiumLostCarTitle(request_obj).subscribe(response => {
        this.spinnerService.hide();
        this.calculatedPremium = response['premium'];
        this.threeYearPremium = response['premium'].threeYearPremium;
        this.getQuotesService.bondPremiumForGTM = response['premium'];
        this.showPremium = true;
        this.getQuoteClick = true;
        this.lostCarTitleRequestService.quoteId = response['anonymousQuote'].id;
        localStorage.setItem('quote_id', JSON.stringify(this.lostCarTitleRequestService.quoteId));
        this.getQuoteGtmEvent('bond-quote', 'lost car', this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', '', '',
          this.lostCarTitleRequestService.quoteId, '', '');
      }, (error) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }

  checkForLandpAndAirportAmountChange(data, amount) {
    if (this.bondType === 'landp' || this.bondType === 'airport_security') {
      if (amount >= 10000 || data.smallLargeApplication === 2) {
        if (this.user.person.companyOfficePersons.length && data.termsAndConditions && !data.termsAndConditions.companyEmailSignature &&
          data.productFor === 'company') {
          return this.addAndPatchSignatures(data);
        } else {
          return data;
        }
      } else {
        return data;
      }
    } else {
      return data;
    }
  }

  addAndPatchSignatures(data) {
    data.termsAndConditions.companyEmailSignature = data.applicantEmail;
    data.termsAndConditions.emailSignature = this.user.person.email;
    data.individualEmailSignature = this.user.person.email;
    return data;
  }

  startApplication(): void {
    this.spinnerService.show();
    const subBonds = ['Registered Investment Adviser', 'Airport Security',
      'Lost Car Title/Defective Vehicle Title (Includes Donated Vehicle)', 'Lost Car Title'];
    const request_obj = this.getRequestBody();
    request_obj['person'] = {
      id: this.userId,
    };
    if (this.applicationId) {
      if (this.responseData && request_obj) {
        const restrictedForUpdate = ['applicantPersonalName', 'applicantCompanyName'];
        for (const key of Object.keys(request_obj['data'])) {
          if ((key === 'applicantQuestions' && this.bondType === 'airport_security') || restrictedForUpdate.indexOf(key) >= 0) {
            // do not update
          } else if (key === 'companyName' && !this.isAgentOrAttorney()) {
            if (request_obj['data'][key] && request_obj['data'][key].length && request_obj['data']['productFor'] === 'company') {
              this.responseData['data']['applicantName'] = request_obj['data'][key];
            } else {
              this.responseData['data']['applicantName'] = request_obj['data'].firstName + ' ' + request_obj['data'].lastName;
            }
          } else {
            const value = request_obj['data'][key];
            this.responseData['data'][key] = value;
          }
        }
        this.responseData['amount'] = request_obj['amount'];
        this.responseData['premium'] = request_obj['premium'];
        this.responseData['data'] = this.checkForLandpAndAirportAmountChange(this.responseData['data'], this.responseData['amount']);
      }
      const localdata = localStorage.getItem('temp_application');
      const localdat1 = JSON.parse(localdata);
      if (!localdat1) {
        // this.responseData['data'].termsAndConditions = pnull;
        this.lpService.saveAndContinueApplication(this.responseData, this.applicationId, false)
          .then((response => {
            this.spinnerService.hide();
            localStorage.removeItem('temp_application');
            this.navigateToApplication(response['id']);
          }), (error: any) => {
            this.spinnerService.hide();
            this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
          });
      } else {
        localStorage.setItem('temp_application', JSON.stringify(this.responseData));
        this.spinnerService.hide();
        this.navigateToApplication(this.responseData['id']);
      }
    } else {
      localStorage.setItem('temp_application', JSON.stringify(request_obj));
      if (this.showSelectClientButton()) {
        if (this.bondType === 'landp' && subBonds.includes(this.quoteform.value.bondClassification.classificationName)) {
          this.router.navigate(['/user/clients'], {
            queryParams: {
              bondType:
                this.findSubBondId(this.quoteform.value.bondClassification.classificationName),
            },
          });
        } else {
          this.router.navigate(['/user/clients'], { queryParams: { bondType: this.bondType } });
        }
        return;
      }
      const quoteId = localStorage.getItem('quote_id');
      const classificationName =
        this.quoteform.value.bondClassification ? this.quoteform.value.bondClassification : '';
      const IPgroup = this.requestService.ipGroup;
      this.spinnerService.hide();
      this.navigateToApplication(null);
      let gtmBondType = this.requestService.setBondType(this.bondType);
      if (this.bondType === 'landp'
        && subBonds.indexOf(this.quoteform.value.classificationName) > -1) {
        gtmBondType = this.requestService.setBondType(this.quoteform.value.classificationName);
      }
      if (this.bondTerm === '1') {
        this.getQuoteGtmEvent('bond-app-start', `${gtmBondType}`, this.calculatedPremium.premium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
          IPgroup, classificationName.classificationName,
          quoteId, 'new', this.applicationId || '');
      } else if (this.bondTerm === '2') {
        this.getQuoteGtmEvent('bond-app-start', `${gtmBondType}`, this.twoYearPremium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
          IPgroup, classificationName.classificationName,
          quoteId, 'new', this.applicationId || '');
      } else {
        this.getQuoteGtmEvent('bond-app-start', `${gtmBondType}`, this.threeYearPremium,
          this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
          IPgroup, classificationName.classificationName,
          quoteId, 'new', this.applicationId || '');
      }
    }
  }

  isAgentOrAttorney() {
    return this.user && (this.user.hasAttorneyRole || this.user.hasAgentRole);
  }

  navigateToApplication(id) {
    if (id) {
      if (this.bondType === 'landp') {
        switch (this.quoteform.value.bondClassification.classificationName) {
          case 'Registered Investment Adviser':
            this.router.navigate(['ibond/application', 'ria', id]);
            break;
          case 'Airport Security':
            this.router.navigate(['ibond/application', 'airport_security', id]);
            break;
          case 'Lost Car Title':
            this.router.navigate(['ibond/application', 'lost_car_title', id]);
            break;
          case 'Lost Car Title/Defective Vehicle Title (Includes Donated Vehicle)':
            this.router.navigate(['ibond/application', 'lost_car_title', id]);
            break;
          default:
            this.router.navigate(['ibond/application', this.bondType, id]);
            break;
        }
      } else {
        this.router.navigate(['ibond/application', this.bondType, id]);
      }
    } else {
      if (this.bondType === 'landp') {
        switch (this.quoteform.value.classificationName) {
          case 'Registered Investment Adviser':
            this.router.navigate(['ibond/application', 'ria']);
            break;
          case 'Airport Security':
            this.router.navigate(['ibond/application', 'airport_security']);
            break;
          case 'Lost Car Title':
            this.router.navigate(['ibond/application', 'lost_car_title']);
            break;
          default:
            this.router.navigate(['ibond/application', this.bondType]);
            break;
        }
      } else {
        this.router.navigate(['ibond/application', this.bondType]);
      }
    }
  }

  findSubBondId(subBond) {
    switch (subBond) {
      case 'Registered Investment Adviser':
        return 'ria';
      case 'Airport Security':
        return 'airport_security';
      case 'Lost Car Title':
        return 'lost_car_title';
      case 'Lost Car Title/Defective Vehicle Title (Includes Donated Vehicle)':
        return 'lost_car_title';
      default:
        return subBond;
    }
  }

  getRequestBody() {
    let requestBody = {};
    switch (this.bondType) {
      case 'landp':
        if (this.quoteform.value.classificationName === 'Registered Investment Adviser' || (this.quoteform.value.bondClassification &&
          this.quoteform.value.bondClassification.classificationName === 'Registered Investment Adviser')) {
          requestBody = this.getQuotesService.createApplicationRequestRia(this.quoteform,
            this.calculatedPremium);
        } else if (this.quoteform.value.classificationName === 'Airport Security' || (this.quoteform.value.bondClassification &&
          this.quoteform.value.bondClassification.classificationName === 'Airport Security')) {
          requestBody = this.getQuotesService.createApplicationRequestAirportSecurity(this.quoteform,
            this.calculatedPremium, this.termForm);
        } else if (this.quoteform.value.classificationName === 'Lost Car Title/Defective Vehicle Title (Includes Donated Vehicle)' ||
          (this.quoteform.value.bondClassification && this.quoteform.value.bondClassification.classificationName ===
            'Lost Car Title/Defective Vehicle Title (Includes Donated Vehicle)')) {
          requestBody = this.getQuotesService.createApplicationLostCarTitle(this.quoteform,
            this.calculatedPremium);
        } else {
          requestBody = this.getQuotesService.createApplicationRequestLandP(this.quoteform,
            this.calculatedPremium);
        }
        break;
      case 'notary':
        requestBody = this.getQuotesService.createApplicationRequestNotary(this.quoteform,
          this.calculatedPremium);
        break;
      case 'po':
        requestBody = this.getQuotesService.createApplicationRequestPublicOfiicial(this.quoteform,
          this.calculatedPremium);
        break;
      case 'airport_security':
        requestBody = this.getQuotesService.createApplicationRequestAirportSecurity(this.quoteform,
          this.calculatedPremium, this.termForm);
        break;
      case 'employee_dishonesty':
        requestBody = this.getQuotesService.createApplicationEmployeeDishonesty(this.quoteform,
          this.calculatedPremium, this.termForm);
        break;
      case 'ria':
        requestBody = this.getQuotesService.createApplicationRequestRia(this.quoteform,
          this.calculatedPremium);
        break;
      case 'janitorial':
        requestBody = this.getQuotesService.createApplicationJanitorial(this.quoteform,
          this.calculatedPremium, this.termForm);
        break;
      case 'vafiduciary':
        requestBody = this.getQuotesService.createApplicationVafiduciary(this.quoteform.value,
          this.calculatedPremium);
        break;
      case 'lost_instrument':
        requestBody = this.getQuotesService.createApplicationLostInstrument(this.quoteform,
          this.calculatedPremium);
        break;
      case 'lost_car_title':
        requestBody = this.getQuotesService.createApplicationLostCarTitle(this.quoteform,
          this.calculatedPremium);
        break;
      default:
        break;
    }

    return requestBody;
  }
  getQuoteGtmEvent(event, bondType, bondPremium, userType, lpGroup, lpBond, quoteId, bondClass?, applicationID?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }
  isAttorney() {
    if (this.user && this.user.hasAttorneyRole) {
      return true;
    } else if (this.user && this.user.hasAgentRole) {
      return true;
    } else {
      return false;
    }
  }
  isAgent() {
    return this.user && this.user.hasAgentRole;
  }
  showSelectClientButton(): boolean {
    return (this.isAttorney() || this.isAgent()) && !this.applicationId;
  }
  returnBack() {
    this.location.back();
  }
}
