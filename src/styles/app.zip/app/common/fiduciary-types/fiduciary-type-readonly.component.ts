import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-fiduciary-type-readonly',
  templateUrl: './fiduciary-type-readonly.component.html',
  styleUrls: ['./fiduciary-type-readonly.component.css'],
})
export class FiduciaryTypeReadonlyComponent {
  @Input()
  fiduciaryType: string;
}
