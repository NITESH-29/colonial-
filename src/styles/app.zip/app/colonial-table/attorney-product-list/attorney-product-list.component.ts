import { Component, Input } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';
import { Subject } from 'rxjs/index';
import { TableDefaultDetails } from '../../form-components/generic-table-search/table-default-details';

@Component({
  selector: 'app-attorney-product-list',
  templateUrl: './attorney-product-list.component.html',
  styleUrls: ['./attorney-product-list.component.scss'],
})
export class AttorneyProductListComponent {

  @Input()
  tableDefaultDetails: TableDefaultDetails;

  mode = 'Court';

  tabs: string[] = [
    'Court',
    'Professional Liability',
  ];

  filtersEventSubject: Subject<any> = new Subject();

  constructor() {
  }

  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {
    this.switchMode(tabChangeEvent.tab.textLabel.toLocaleLowerCase());
  }

  switchMode(modeVal) {
    this.mode = modeVal;
  }

  emitFiltersSubject() {
    this.filtersEventSubject.next();
  }

}
