import { DeliveryMethod } from '../../enrollment/application/court/model/common/delivery-method';
import { AddressMapper } from '../address/address-mapper';

export class DeliveryMethodSelectionMapper {
  /**
   * Populate a DeliveryMethod instance from an deliveryMethod FormGroup's rawValues.
   * @param deliveryMethod instance to be populated from 'rawValues'.
   * @param deliveryMethodRawValues  'rawValues' to populate instance.
   */
  static populateDeliveryMethod(deliveryMethod: DeliveryMethod, deliveryMethodRawValues: any | null): DeliveryMethod {
    deliveryMethod.deliveryMethod = deliveryMethodRawValues ? deliveryMethodRawValues.deliveryMethod : null;
    deliveryMethod.deliveryName = deliveryMethodRawValues ? deliveryMethodRawValues.deliveryName : null;
    deliveryMethod.deliveryPhone = deliveryMethodRawValues ? deliveryMethodRawValues.deliveryPhone : null;
    deliveryMethod.copyViaEmail = deliveryMethodRawValues ? deliveryMethodRawValues.copyViaEmail : null;
    AddressMapper.populateAddress(deliveryMethod.deliveryAddress
      , deliveryMethodRawValues && deliveryMethodRawValues.deliveryAddress ?
        deliveryMethodRawValues.deliveryAddress : null);
    return deliveryMethod;
  }

  /**
   * Create an object of values to be 'patched' into a DeliveryMethod FormGroup.
   * @param deliveryMethod source of values to be patched.
   */
  static createDeliveryMethodFormGroupPatchValues(deliveryMethod: DeliveryMethod | null): any {
    const patchValues = {
      deliveryMethod: deliveryMethod ? deliveryMethod.deliveryMethod : null,
      deliveryPhone: deliveryMethod ? deliveryMethod.deliveryPhone : null,
      deliveryName: deliveryMethod ? deliveryMethod.deliveryName : null,
      copyViaEmail: deliveryMethod ? deliveryMethod.copyViaEmail : null,
      deliveryAddress: AddressMapper.createAddressFormGroupPatchValues(deliveryMethod ? deliveryMethod.deliveryAddress : null),
    };
    return patchValues;
  }
}
