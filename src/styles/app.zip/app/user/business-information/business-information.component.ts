import { Component, Input } from '@angular/core';
import { BusinessInformationFormGroup } from './business-information-form-group';

@Component({
  selector: 'app-business-information',
  templateUrl: './business-information.component.html',
})
export class BusinessInformationComponent {
  @Input() formGroup: BusinessInformationFormGroup;

  @Input() businessLabel = 'Company';

  @Input() showHeader = false;
}
