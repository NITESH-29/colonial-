import { NgModule } from '@angular/core';
import { CourtBondFacilitationService } from './court-bond-facilitation.service';
import { CourtBondFacilitationPostLoginGuard } from './court-bond-facilitation-post-login-guard.service';

@NgModule({
  providers: [
    CourtBondFacilitationService,
    CourtBondFacilitationPostLoginGuard,
  ],
})
export class EnrollmentFacilitationModule { }
