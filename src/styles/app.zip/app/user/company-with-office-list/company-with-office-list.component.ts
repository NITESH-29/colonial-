import { Component, OnInit } from '@angular/core';
import { CompanyWithOfficeListFormGroup } from './company-with-office-list-form-group';
import { PersonBusinessService } from '../providers/person-business.service';
import { CompanyModel } from '../models/company-model';
import { SecurityService } from '../../security/security.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { PreviousRouteService } from '../../common/services/previous-route.service';
import { BusinessOfficeInformationFormGroup } from '../business-office-information/business-office-information-form-group';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { ServiceHandler } from '../../common/utils/service-handler.service';

@Component({
  selector: 'app-business',
  templateUrl: './company-with-office-list.component.html',
  styleUrls: ['./company-with-office-list.component.css'],
})
export class CompanyWithOfficeListComponent implements OnInit {
  company: CompanyModel;

  formGroup: CompanyWithOfficeListFormGroup;
  returnUrl: string;

  constructor(
    private personBusinessService: PersonBusinessService,
    private securityService: SecurityService,
    private serviceHandler: ServiceHandler,
    private previousRouteService: PreviousRouteService,
    private location: Location,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.returnUrl = this.previousRouteService.getPreviousUrl();
    this.formGroup = new CompanyWithOfficeListFormGroup();
    if (this.route.snapshot.data['company']) {
      this.company = this.route.snapshot.data['company'];
      this.formGroup.patchValue(this.company);
    }

    this.formGroup.companyOfficeList.officeTypeChanges.subscribe(({ index, officeType }) => {
      if (officeType === 'Main') {
        this.setAllOtherOfficeTypesToBranchExcept(index);
      }
    });

    const user = this.securityService.user;

    // Lock down office type and primary service for AgencyOffices: when user is either an Agent or Attorney
    const lockDownOfficeType = (businessOfficeInformation: BusinessOfficeInformationFormGroup) => {
      if (user.hasAgentRole || user.hasAttorneyRole) {
        businessOfficeInformation.officeType.setValue('Branch');
        businessOfficeInformation.officeType.disable();
      }
    };

    // Initial pass
    this.formGroup.companyOfficeList.controls.forEach(lockDownOfficeType);

    // Lock down newly added FormGroups too
    let originalNumCompanyOffices = this.formGroup.companyOfficeList.length;

    this.formGroup.companyOfficeList.valueChanges.subscribe(nextCompanyOffices => {
      if (nextCompanyOffices.length > originalNumCompanyOffices) {
        originalNumCompanyOffices = nextCompanyOffices.length;
        this.formGroup.companyOfficeList.controls.forEach(lockDownOfficeType);
      }
    });
  }

  async save() {
    if (this.formGroup.valid) {
      const company: CompanyModel = this.formGroup.getRawValue();
      const personId: number = this.securityService.user.person.id;
      if (!this.company || !this.company.id) {
        this.company = await this.personBusinessService.createCompany(company, personId);
      } else {
        company.id = this.company.id;
        this.company = await this.personBusinessService.updateCompany(company, personId);
      }
      this.formGroup.patchValue(this.company);
      await this.router.navigateByUrl(this.returnUrl);
    } else {
      CommonUtilities.markAllTouched(this.formGroup);
      this.serviceHandler.showErrorMessage('Please fix validation errors before saving.');
    }
  }

  goBack() {
    this.location.back();
  }

  private setAllOtherOfficeTypesToBranchExcept(index: number): void {
    this.formGroup.companyOfficeList.controls
      .forEach((ctl: BusinessOfficeInformationFormGroup, idx: number) => {
        if (idx !== index) {
          ctl.officeType.setValue('Branch');
        }
      });
  }
}
