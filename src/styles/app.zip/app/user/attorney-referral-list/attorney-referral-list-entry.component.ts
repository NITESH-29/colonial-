import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatChipList, MatFormField } from '@angular/material';
import { statesLong } from '../../common/utils/constants';
import { Observable } from 'rxjs';
import { map, startWith, tap } from 'rxjs/operators';

interface State {
  name: string;
  abbreviation: string;
}

@Component({
  selector: 'app-attorney-referral-list-entry',
  templateUrl: './attorney-referral-list-entry.component.html',
  styleUrls: ['./attorney-referral-list-entry.component.scss'],
})
export class AttorneyReferralListEntryComponent implements OnInit {
  @Input() set states(stateAbbrevs: string[]) {
    this.statesInternal = stateAbbrevs
      .map(abbrev => this.allStates.find(s => s.abbreviation === abbrev))
      .filter(Boolean);
  }

  get states(): string[] {
    return this.statesInternal.map(_ => _.abbreviation);
  }

  @Output() statesChange: EventEmitter<string[]>;

  @Output() isAddingStates: EventEmitter<boolean>;

  separatorKeyCodes: number[] = [ENTER, COMMA];
  statesFilter: FormControl;
  filteredStates: Observable<State[]>;
  listAdditionDesired: FormControl;

  @ViewChild('stateInput') set si(element: ElementRef<HTMLInputElement>) {
    this.stateInput = element;

    if (this.stateInput) {
      this.stateInput.nativeElement.addEventListener('keydown', ({ key }) => {
        if (key === 'Enter' && this.currentFilteredStates.length === 1) {
          const [theState] = this.currentFilteredStates;
          this.addState(theState);
        }
      });
    }
  }

  @ViewChild('container') container: ElementRef<HTMLDivElement>;
  @ViewChild('referralList') set rl(element: MatFormField) {
    this.referralList = element;

    if (this.referralList && this.container) {
      const containerElement = this.container.nativeElement;
      const referralListElement = this.referralList._elementRef.nativeElement;

      const onResize = () => {
        const outerWidth = containerElement.clientWidth;
        const formFieldWidthShouldBe = outerWidth - 30;
        referralListElement
          .querySelector('.mat-form-field-wrapper')
          .style
          .width = `${formFieldWidthShouldBe}px`;
      };

      window.addEventListener('resize', onResize);
      onResize();
    }
  }

  @ViewChild('chipList') chipList: MatChipList;

  private stateInput: ElementRef<HTMLInputElement>;
  private currentFilteredStates: State[];
  private referralList: MatFormField;
  private allStates: State[];
  private statesInternal: State[];
  private isValid: boolean;

  constructor() {
    this.allStates = Array.from(statesLong);
    this.currentFilteredStates = [];
    this.states = [];
    this.statesInternal = [];
    this.statesChange = new EventEmitter<string[]>();
    this.isAddingStates = new EventEmitter<boolean>();
    this.isAddingStates.emit(undefined);
  }

  ngOnInit(): void {
    this.listAdditionDesired = new FormControl(this.statesInternal.length > 0);
    this.listAdditionDesired.valueChanges.subscribe(b => {
      if (!b) {
        this.statesInternal = [];
        this.emitStateChange();
      }
      this.isAddingStates.emit(b);
    });

    this.statesFilter = new FormControl(null);
    this.filteredStates = this.statesFilter.valueChanges.pipe(
      startWith<string | State>(''),
      map(value => typeof value === 'string' ? value : value && value.name),
      map(name => name ? this.filter(name) : this.allStates.slice()),
      tap(states => this.currentFilteredStates = states)
    );
  }

  nameOfState(state?: State): string | undefined {
    return state ? state.name : undefined;
  }

  stateSelected(event: MatAutocompleteSelectedEvent): void {
    const { option: { value: state } } = event;
    this.addState(state);
  }

  addState(state: State): void {
    this.statesInternal.push(state);
    this.stateInput.nativeElement.value = '';
    this.statesFilter.setValue(null);

    this.emitStateChange();
  }

  removeState(selectedState: State): void {
    const index = this.statesInternal.findIndex(({ name, abbreviation }) =>
      name === selectedState.name &&
      abbreviation === selectedState.abbreviation
    );

    if (index >= 0) {
      this.statesInternal.splice(index, 1);
    }

    this.emitStateChange();
  }

  get valid(): boolean {
    this.checkErrorState();
    return this.isValid;
  }

  checkErrorState(): void {
    if (this.chipList) {
      this.chipList.errorState = (this.statesInternal.length < 1) && this.listAdditionDesired.value === true;
      this.chipList._markAsTouched();
      this.isValid = !this.chipList.errorState;
    } else {
      this.isValid = true;
    }
  }

  private emitStateChange() {
    this.checkErrorState();
    this.statesChange.emit(this.states);
  }

  private filter(filter: string): State[] {
    const filterValue = filter.toLowerCase();
    const selectedStateNames = this.statesInternal.map(_ => _.name);

    return this.allStates.filter(({ name, abbreviation }) =>
      !selectedStateNames.includes(name) &&
      (abbreviation.toLowerCase().startsWith(filterValue) || name.toLowerCase().startsWith(filterValue))
    );
  }
}
