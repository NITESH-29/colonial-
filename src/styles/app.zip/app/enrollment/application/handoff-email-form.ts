import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../../common/auditable-object';

export interface HandoffEmailForm {
  recipient: string;
  subject: string;
  optionalMessage: string;
  body: string;
}

@JsonObject('HandoffEmailFormImpl')
export class HandoffEmailFormImpl extends AuditableObject implements HandoffEmailForm {
  @JsonProperty('recipient', String, true)
  recipient: string = null;

  @JsonProperty('subject', String, true)
  subject: string = null;

  @JsonProperty('optionalMessage', String, true)
  optionalMessage: string = null;

  @JsonProperty('body', String, true)
  body: string = null;
}
