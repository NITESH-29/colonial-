import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { Person } from 'src/app/common/person';
import { Subscription, Subject } from 'rxjs';
import { UserImpl } from 'src/app/security/user';
import * as moment_ from 'moment';
import { GlobalConstants } from '../constant/global.constant';
import { PersonAddressImpl } from 'src/app/common/person-address';
import { states } from 'src/app/common/utils/constants';
import { OnInit, ViewChild, OnChanges, Output, EventEmitter, NgZone, SimpleChanges, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material';
import { SecurityService } from 'src/app/security/security.service';
import { IbondBaseService } from '../service/ibond-base.service';
import { RequestService } from '../service/request.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { GetQuotesService } from '../service/get-quotes.service';
import { SpinnerService } from '../service/spinner.service';
import { Location } from '@angular/common';
import { LoginComponent } from '../login/login.component';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { ApplicantDetailInformationFormGroup } from './application-form-groups/applicant-detail-information/applicant-detail-information-form-group';
import { BondDetailInformationFormGroup } from './application-form-groups/bond-detail-information/bond-detail-information-form-group';
import { BondHolderDetailInformationFormGroup } from './application-form-groups/bond-holder-detail-information/bond-holder-detail-information-form-group';
import { CommonUtilities } from 'src/app/common/utils/common-utilities';
import { ApplicationPopulateService } from '../service/application-populate.service';
import { PatternValidators } from 'src/app/common/validators/pattern-validators';
import { SendToClientComponent } from '../common/send-to-client/send-to-client.component';
import { takeUntil } from 'rxjs/operators';
import { NoopScrollStrategy } from '@angular/cdk/overlay';

export abstract class IbondApplicationBaseComponent implements OnInit, OnChanges, OnDestroy {
  // Common variables in bonds
  @Output() applicationIdEmitter = new EventEmitter<number>();

  // Comman form group
  bondDetailForm: FormGroup;
  applicantDetailForm: FormGroup;
  obligeeDetailForm: FormGroup;
  deliveryAndPaymentForm: FormGroup;
  indemnificationSignatureForm: FormGroup;
  lostInstrumentDetailForm: FormGroup;
  staffDetailForm: FormGroup;
  vehicleDetailForm: FormGroup;
  businessDetailForm: FormGroup;
  veteranAffairsDetailsForm: FormGroup;
  applicationId: number;
  inputReadonly = true;
  person: Person;
  LPSummaryData: string;
  quoteData: object;
  step = 'step1';
  bondType = '';
  showFormError = false;
  openExpension = 1;
  zipCodeData: object;
  loggedIn: boolean;
  loggedIn$: Subscription;
  user: UserImpl = null;
  userId: number;
  productFor = 'individual';
  statesArray = states;
  // remove this variable once obselete components are removed
  dataSource = [];
  url;

  // Date Logic
  moment = moment_;
  date = new Date();
  term: number;
  min_expiration_date: Date;
  expiryDate: Date;
  expiration_year_date: Date;

  // Payment related details
  selectPaymentMethod = false;
  selectedPaymentMethod: string;
  deliveryMethod = GlobalConstants.DELIVERY_METHOD;
  paymentMethod: any[] = [];
  expiration: any[] = this.getExpirationYear();
  expirationMonth = GlobalConstants.EXPIRATION_MONTH;

  personAddressimp: PersonAddressImpl;
  stepOneDisabled = false;
  isCardDetailsEntered = false;
  smallLargeApplication = 1;

  showDeliveryMethodText = false;
  accordionHeaderHeight = '40px';
  stepperFormArray: FormArray;
  showBondDetail: boolean;
  bondClassificationName;
  addAgreementNode = false;
  companyProfile = false;
  attorneyClientId: any;
  attorneyClientType: string;
  attorneyClientDetails: any;
  staffDetailData = [];
  bondConfig: any;
  subscriptions: Subscription[] = [];
  unsubscribe$ = new Subject();
  protected constructor(
    public matDialog: MatDialog,
    public fb: FormBuilder,
    public securityService: SecurityService,
    public lpService: IbondBaseService,
    // Will make it generic
    public requestService,
    public activatedRoute: ActivatedRoute,
    public router: Router,
    public serviceHandlerSnackbar: ServiceHandler,
    public getQuotesService: GetQuotesService,
    public applicationPopulate: ApplicationPopulateService,
    public spinnerService: SpinnerService,
    public location: Location,
    term,
    public gtmService: GoogleTagManagerService,
    public zone?: NgZone
  ) {
  }

  ngOnInit() {
    // Common code for all the bond
    this.activatedRoute.params
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(params => {
        this.applicationId = params.id;
        this.bondType = params.bondType;
        if (params.client_id && params.client_type) {
          this.attorneyClientId = params.client_id;
          this.attorneyClientType = params.client_type;
          this.setApplicantDetailsForAttorney(params.client_id, params.client_type);
        }
      });
    this.url = this.router.url;

    // Login Functionality
    this.securityService.loggedIn$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(
        loggedIn$ => {
          if (!this.loggedIn) {
            this.loggedIn = loggedIn$;
            if (this.loggedIn) {
              const localdata = localStorage.getItem('temp_application');
              if (localdata) {
                this.quoteData = JSON.parse(localdata);
              }
              this.user = this.securityService.user;
              this.person = this.user.person;
              this.afterLogin(this.user);
            }
            if (this.step === 'step2') {
              this.addAgreementNode = true;
            }
            if (this.applicationPopulate.isLoggedInFromSignUp) {
              if (this.applicationPopulate.incomingFrom && this.applicationPopulate.incomingFrom === 'saveForLater') {
                this.checkSaveForLater(this.step);
              } else if (this.applicationPopulate.incomingFrom && this.applicationPopulate.incomingFrom === 'saveAndContinue') {
                this.checkSaveAndContinue(this.step);
              }
            }
          }
        });
  }

  // Method implemented by child class
  //  Later mark contract methods as abstract.
  getExpirationYear(): any { }
  initializeForm(): any { }
  afterLogin(user): any { }
  getQuoteData(): any { }
  ngOnChanges(): any { }
  showSummary(): any { }
  getApplicationDetailsById(): any { }
  buildRequestObject(request_obj): any { }
  assignRequestObject(request_obj): any { }
  updateQuoteData(quoteData): any { }
  storedApplicationData(): void { }
  ifStepOneValid(step): void { }
  submitLostInstrumentDetailForm(): any { }
  submitStaffDetailForm(): any { }
  veteranFileUpload(): Promise<any> { return new Promise(resolve => resolve(false)); }
  publicOfficialFileUpload(): Promise<any> { return new Promise(resolve => resolve(false)); }

  indemnificationForm(): void {
    this.indemnificationSignatureForm = this.fb.group({
      premiumAcknowledged: this.fb.control(''),
      agreeToAutoRenewal: this.fb.control(true, [Validators.required]),
      readAndAgreeToTerms: this.fb.control('', [Validators.required]),
      readAndAgreeToTermsCompany: this.fb.control('', [Validators.required]),
      applicantPersonalName: this.fb.control('', [Validators.required]),
      applicantCompanyName: this.fb.control('', [Validators.required]),
      companyEmailSignature: this.fb.control('', [Validators.required, PatternValidators.email()]),
      emailSignature: this.fb.control('', [Validators.required, PatternValidators.email()]),
      ownerName: this.fb.control('', [Validators.required]),
      ssn: this.fb.control('', [Validators.required, PatternValidators.ssn()]),
      ssnCheckbox: this.fb.control(false, [Validators.pattern('true')]),
      ssnAddressCheckbox: this.fb.control(true, []),
      street1: this.fb.control('', [Validators.required]),
      street2: this.fb.control(''),
      city: this.fb.control('', [Validators.required]),
      state: this.fb.control('', [Validators.required]),
      zipCode: this.fb.control('', [Validators.required]),
    });
  }

  // Implemented methods
  checkSaveForLater(step) {
    if (!this.applicationId && localStorage.getItem('temp_application')) {
      this.isUserLogin(step, 'saveForLater');
    } else {
      this.saveForLater(step);
    }
  }

  checkSaveAndContinue(step) {
    if (!this.applicationId && localStorage.getItem('temp_application')) {
      if (step === 'step1') {
        if (this.loggedIn) {
          this.isUserLogin(step, 'saveAndContinue');
        } else {
          this.step = 'step2';
          this.openExpension = 0;
          this.ifStepOneValid(this.step);
        }
      } else {
        this.isUserLogin(step, 'saveAndContinue');
      }
    } else {
      this.saveAndContinue(step);
    }
    this.submitConditionalSummarySection();
  }

  submitConditionalSummarySection() {
    switch (this.bondType) {
      case 'lost_instrument':
        this.submitLostInstrumentDetailForm();
        break;
      case 'janitorial':
      case 'employee_dishonesty':
        this.submitStaffDetailForm();
        break;
    }
  }

  isUserLogin(step, incomingFrom) {
    if (this.loggedIn === true) {
      this.createApplication(step, incomingFrom);
    } else {
      let signatureValidation = true;
      if (step !== 'step1') {
        signatureValidation = this.validateEmailSignatureTerm(this.quoteData['data'].amount,
          this.applicantDetailForm.value.applicantEmail, this.bondType) ? false : true;
      }
      if (this.applicantDetailForm.valid && signatureValidation) {
        this.storedApplicationData();
        if (incomingFrom === 'saveAndContinue') {
          this.step = 'step2';
          this.openExpension = 0;
        }
        const signUpdata = this.applicantDetailForm.value;
        signUpdata.incomingFrom = incomingFrom;
        signUpdata['productFor'] = this.quoteData['data'].productFor;
        this.lpService.setApplicantInfo(signUpdata);
        this.lpService.setSignUpValue(true);
      } else {
        this.openExpension = 2;
        CommonUtilities.markAllTouched(this.applicantDetailForm);
        this.scrollIfFormHasErrors(this.applicantDetailForm);
      }
    }
  }
  async updateApplication() {
    let formdata = {};
    formdata = this.assignRequestObject(formdata);
  }

  createApplication(step, incomingFrom) {
    const request_obj = JSON.parse(localStorage.getItem('temp_application'));
    request_obj['person'] = this.person;
    request_obj['data'] = this.buildRequestObject(request_obj['data']);
    if (this.user && this.user.agent) {
      this.quoteData['agent'] = this.user.agent;
    }

    this.spinnerService.show();
    let signatureValidation = true;
    if (step === 'step2') {
      signatureValidation = this.validateEmailSignatureTerm(this.quoteData['data'].amount, this.applicantDetailForm.value.applicantEmail,
        this.bondType) ? false : true;
    }
    if (signatureValidation) {
      this.getQuotesService.createApplication(this.requestService.getRequestData(this.bondType, this.person,
        this.quoteData, request_obj['data'],
        this.staffDetailData, (step === 'step2' || this.addAgreementNode) ? true : false, false)
      ).subscribe(async response => {
        // We need to check if the request is from SaveforLater or SaveAndContinue
        // Based on this the routing will take place
        //  SaveForLater -> /dashboard
        // SaveAndContinue -> next page of application

        this.applicationId = response['id'];
        if (response['person'] && !this.isAttorneyOrAgent()) {
          this.person = response['person'];
          this.securityService.user.person = this.person;
        }
        this.applicationPopulate.resetApplicationData();
        this.applicationIdEmitter.emit(this.applicationId);
        if (this.applicationPopulate.isLoggedInFromSignUp) {
          this.applicationPopulate.isLoggedInFromSignUp = false;
        }
        if (incomingFrom === 'saveAndContinue') {
          // Code for Save and Continue
          let vafiduciaryResult = true;
          let poResult = true;
          let isUpdateNeeded = false;
          if (response['status'] === 'Hold' || response['status'] === 'Declined') {
            this.spinnerService.hide();
            this.router.navigate(['ibond/confirm/', this.bondType, this.applicationId]);
          } else {
            this.step === 'step1' ? this.step = 'step2' : this.step = 'step3';
            this.openExpension = 0;
            this.ifStepOneValid(this.step);
            this.quoteData = response;
            if (this.bondType === 'vafiduciary' && sessionStorage.getItem('veteran_letter')) {
              isUpdateNeeded = true;
              await this.veteranFileUpload().then(varesponse => {
                vafiduciaryResult = varesponse;
              });
            }
            if (sessionStorage.getItem('po_file')) {
              isUpdateNeeded = true;
              await this.publicOfficialFileUpload().then(poresponse => {
                poResult = poresponse;
              });
            }

            if ((vafiduciaryResult || poResult) && isUpdateNeeded) {
              // * Update the form data and send it to reponse
              await this.updateApplication();
            }

            this.spinnerService.hide();
            this.location.replaceState('ibond/application/' + this.bondType + '/' + this.applicationId);
          }


        } else if (incomingFrom === 'saveForLater') {
          // Code for Save for Later
          let isUpdateNeeded = false;
          let vafiduciaryResult = true;
          let poResult = true;
          if (this.bondType === 'vafiduciary' && sessionStorage.getItem('veteran_letter')) {
            isUpdateNeeded = true;
            await this.veteranFileUpload().then(varesponse => {
              vafiduciaryResult = varesponse;
            });
          }

          if (sessionStorage.getItem('po_file')) {
            isUpdateNeeded = true;
            await this.publicOfficialFileUpload().then(poresponse => {
              poResult = poresponse;
            });
          }


          this.applicationId = response['id'];
          if (vafiduciaryResult && poResult) {
            if (isUpdateNeeded) {
              this.updateApplication();
            }
            this.spinnerService.hide();
            this.serviceHandlerSnackbar.handleConfirm('Saving form...');
            this.router.navigate(['/dashboard']).then(() => {
              this.applicationPopulate.resetApplicationData();
            });
          } else {
            // if Special bond form fail then stay on that page
            this.spinnerService.hide();
            this.location.replaceState('ibond/application/' + this.bondType + '/' + this.applicationId);
          }
        }
      }, error => {
        //  Error handling for service
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    } else {
      this.spinnerService.hide();
    }
  }

  saveAndContinue(value) {
    this.spinnerService.show();
    this.openExpension = 0;
    let formdata = {};
    formdata = this.buildRequestObject(formdata);
    if (this.loggedIn === true) {
      this.saveApplication(formdata, value);
    } else {
      this.storedApplicationData();
      const dialogRef = this.matDialog.open(LoginComponent, {
        data: { clickFrom: 'saveAndContinue', url: this.url },
        scrollStrategy: new NoopScrollStrategy(),
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.saveApplication(formdata, value);
        }
        this.spinnerService.hide();
      });
    }

  }

  saveAndApply() {
    this.spinnerService.show();
    const formdata = {};
    // this.indemnificationSignatureForm.controls['emailSignature'].setErrors({ notValid: false });
    this.lpService.getApplicationDetailsById(this.applicationId).subscribe((response: any) => {
      Object.assign(formdata, response, this.deliveryAndPaymentForm.value);
      // response.data.termsAndConditions = this.requestService.getTermsAndCondition(formdata);
      // this.requestService.setPaymentPlanObject(response['data'].paymentMethod, true);
      response.data.paymentMethod = this.requestService.addPaymentNodeAndResetData(formdata);
      response.data.deliveryMethod = this.requestService.getDeliveryObject();
      const applicantEmail = response.data.applicantEmail ? response.data.applicantEmail : this.user.person.email;
      const bondType = response.data.bondClassification;
      this.lpService.saveAndApply(this.applicationId, response).subscribe((applicationRes) => {
        if (applicationRes) {
          if (response['person'] && !this.isAttorneyOrAgent()) {
            this.person = response['person'];
            this.securityService.user.person = this.person;
          }
          this.spinnerService.hide();
          this.serviceHandlerSnackbar.handleConfirm('Saving form...');
          this.router.navigate(['ibond/confirm', this.bondType, this.applicationId]);
        }
        this.lpService.paymentErrorMessage.next({ 'errorKey': false, 'errorMessage': '' });
      }, (error: any) => {
        this.spinnerService.hide();
        if (error['error'].message) {
          this.lpService.paymentErrorMessage.next({ 'errorKey': true, 'errorMessage': error['error'].message });
          this.serviceHandlerSnackbar.showErrorMessage(error['error'].message);
        } else {
          this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
        }
      });
    });
  }

  saveForLater(value) {
    let formdata = {};
    formdata = this.buildRequestObject(formdata);
    this.quoteData = this.updateQuoteData(this.quoteData);
    this.applicationPopulate.isFormSavedForLater = true;
    if (this.loggedIn === true) {
      this.spinnerService.show();
      const reqData = this.requestService.getRequestData(this.bondType, this.person,
        this.quoteData, formdata, this.staffDetailData, true,
        (value === 'step3') ? true : false);
      if (value === 'step3' && !reqData['data'].paymentMethod.billingProfileId) {
        reqData['data'].paymentMethod.cardNumber = null;
        reqData['data'].paymentMethod.cardCVV = null;
        reqData['data'].paymentMethod.resetPaymentDetail = true;
      }
      this.lpService.saveForLater(reqData, this.applicationId).subscribe((response => {
        if (response) {
          this.spinnerService.hide();
          this.applicationPopulate.resetApplicationData();
          if (this.applicationPopulate.isLoggedInFromSignUp) {
            this.applicationPopulate.isLoggedInFromSignUp = false;
          }
          this.serviceHandlerSnackbar.handleConfirm('Saving form...');
          this.router.navigate(['/dashboard']).then(() => {
            this.applicationPopulate.resetApplicationData();
          });
        }

      }), (error: any) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    } else {
      this.storedApplicationData();
      const dialogRef = this.matDialog.open(LoginComponent, {
        data: { clickFrom: 'saveForLater', url: this.url },
        scrollStrategy: new NoopScrollStrategy(),
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.spinnerService.show();
          formdata = this.updatePersonInfoAfterLogin();
          this.lpService.saveForLater(this.requestService.getRequestData(this.bondType, this.person,
            this.quoteData, formdata, (value === 'step2') ? true : false, (value === 'step3') ? true : false), this.applicationId)
            .subscribe((response => {
              if (response) {
                this.applicationPopulate.resetApplicationData();
                this.serviceHandlerSnackbar.handleConfirm('Saving form...');
                this.router.navigate(['/dashboard']).then(() => {
                  this.applicationPopulate.resetApplicationData();
                });
              }
            }), (error: any) => {
              this.spinnerService.hide();
              this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
            });
        } else {
          this.spinnerService.hide();
        }
      });
    }
  }
  saveApplication(formdata, step): void {
    formdata = this.updatePersonInfoAfterLogin();
    this.quoteData = this.updateQuoteData(this.quoteData);
    let signatureValidation = true;
    if (step === 'step2') {
      signatureValidation = this.validateEmailSignatureTerm(this.quoteData['data'].amount, this.applicantDetailForm.value.applicantEmail,
        this.bondType) ? false : true;
    }
    if (signatureValidation) {
      this.lpService.saveAndContinueApplication(this.requestService.getRequestData(this.bondType,
        this.person, this.quoteData, formdata, this.staffDetailData,
        true, false), this.applicationId, step === 'step2' ? true : false)
        .then((response => {
          if (response) {
            if (response['person'] && !this.isAttorneyOrAgent()) {
              this.person = response['person'];
              this.securityService.user.person = this.person;
            }
            if (response['data'].paymentMethod && response['data'].paymentMethod.billingProfileId) {
              this.requestService.setPaymentPlanObject(response['data'].paymentMethod, true);
            }
            if (this.applicationPopulate.isLoggedInFromSignUp) {
              this.applicationPopulate.isLoggedInFromSignUp = false;
            }
            if (response['status'] === 'Hold' || response['status'] === 'Declined') {
              this.spinnerService.hide();
              this.router.navigate(['ibond/confirm/', this.bondType, this.applicationId]);
            } else {
              this.spinnerService.hide();
              this.serviceHandlerSnackbar.handleConfirm('Saving form...');
              localStorage.removeItem('temp_application');
              localStorage.removeItem('quote_id');
              if (step === 'step1') {
                this.step = 'step2';
              } else {
                this.step = 'step3';
              }
              this.openExpension = 0;
              this.ifStepOneValid(this.step);
              if (this.step === 'step3' || this.step === 'step2') {
                // this.ngOnChanges();
              }
              window.scrollTo(0, 0);
              this.ifStepOneValid(step);
            }
          }
        }), (error: any) => {
          this.spinnerService.hide();
          this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
        });
    } else {
      this.spinnerService.hide();
    }
  }



  validateEmailSignature(controlEmail, applicantEmail) {
    if (controlEmail !== applicantEmail) {
      this.indemnificationSignatureForm.controls['emailSignature'].markAsTouched();
      return true;
    } else {
      return false;
    }
    // return controlEmail !== applicantEmail;
  }

  updatePersonInfoAfterLogin() {
    let formdata = {};
    formdata = this.buildRequestObject(formdata);
    return formdata;
  }

  validateEmailSignatureTerm(bondAmount, ownerEmail, bondType) {
    const localData = JSON.parse(localStorage.getItem('temp_application'));
    let validateEmail = {
      applicant: false,
      company: false,
    };
    switch (this.bondType) {
      case 'landp':
      case 'airport_security':
        validateEmail = this.validateSignatureForAirportAndLandP(bondAmount);
        break;
      case 'notary':
      case 'po':
      case 'vafiduciary':
      case 'employee_dishonesty':
      case 'janitorial':
        validateEmail.applicant = this.signatureCheck(this.indemnificationSignatureForm.value.emailSignature);
        validateEmail.company = null;
        break;
      default:
        if (this.productFor === 'company') {
          validateEmail.applicant = this.signatureCheck(this.indemnificationSignatureForm.value.emailSignature);
          validateEmail.company = this.signatureCheck(this.indemnificationSignatureForm.value.companyEmailSignature);
        } else {
          validateEmail.applicant = this.signatureCheck(this.indemnificationSignatureForm.value.emailSignature);
          validateEmail.company = null;
        }
        break;
    }
    this.applicationPopulate.emailSignatureValid = validateEmail.applicant;
    this.applicationPopulate.companySignatureValid = validateEmail.company;
    if (this.productFor === 'company') {
      if (!validateEmail.applicant) {
        this.indemnificationSignatureForm.controls['emailSignature'].markAsTouched();
        this.indemnificationSignatureForm.controls['emailSignature'].setErrors({ notValid: true });
      }
      if (this.bondConfig.showCompanySignature) {
        if (validateEmail.company === false) {
          this.indemnificationSignatureForm.controls['companyEmailSignature'].markAsTouched();
          this.indemnificationSignatureForm.controls['companyEmailSignature'].setErrors({ notValid: true });
        }
      }
      if (this.bondConfig.showCompanySignature) {
        if (validateEmail.applicant && validateEmail.company) {
          return false;
        } else {
          return true;
        }
      } else {
        if (validateEmail.applicant) {
          return false;
        } else {
          return true;
        }
      }
    } else {
      if (validateEmail.applicant) {
        return false;
      } else {
        this.indemnificationSignatureForm.controls['emailSignature'].setErrors({ notValid: true });
        // this.indemnificationSignatureForm.controls['emailSignature'].updateValueAndValidity();
        this.indemnificationSignatureForm.controls['emailSignature'].markAsTouched();
        return true;
      }
    }
  }

  validateSignatureForAirportAndLandP(bondAmount) {
    const localData = JSON.parse(localStorage.getItem('temp_application'));
    const validateEmail = {
      applicant: false,
      company: false,
    };
    if (bondAmount >= 10000 || this.smallLargeApplication === 2) {
      if (this.productFor === 'company') {
        validateEmail.applicant = this.signatureCheck(this.indemnificationSignatureForm.value.emailSignature);
        validateEmail.company = this.signatureCheck(this.indemnificationSignatureForm.value.companyEmailSignature);
      } else {
        validateEmail.applicant = this.signatureCheck(this.indemnificationSignatureForm.value.emailSignature);
        validateEmail.company = null;
      }
    } else {
      validateEmail.applicant = this.signatureCheck(this.indemnificationSignatureForm.value.emailSignature);
      validateEmail.company = null;
    }
    return validateEmail;
  }

  signatureCheck(email) {
    const sigEmail = String(email);
    const localData = JSON.parse(localStorage.getItem('temp_application'));
    return sigEmail.toLowerCase() === (this.person ?
      this.person.email.toLowerCase() : (this.applicantDetailForm.value.applicantEmail ?
        this.applicantDetailForm.value.applicantEmail.toLowerCase() : (localData['data'].email ?
          localData['data'].email.toLowerCase() : ''))) ? true : false;
  }

  checkCompanyExist() {
    if (this.person) {
      if (this.person.companyOfficePersons.length > 0) {
        return true;
      }
    } else {
      return false;
    }
  }

  onSelectDeliveryMethod(value) {
    if (value === 'FedEx' || value === 'UPS') {
      this.showDeliveryMethodText = true;
    } else {
      this.showDeliveryMethodText = false;
    }
  }

  scrollTo(el: Element): void {
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }

  scrollToError(): void {
    const firstElementWithError = document.querySelector('.ng-invalid');
    this.scrollTo(firstElementWithError);
  }

  async scrollIfFormHasErrors(form: FormGroup): Promise<any> {
    await form.invalid;
    this.scrollToError();
  }

  setApplicantDetailsForAttorney(client_id, client_type) {
    this.spinnerService.show();
    this.lpService.getClientDetailsForAttorney(client_id, client_type).subscribe((res => {
      this.attorneyClientDetails = res;
      if (client_type === 'Person') {
        this.applicantDetailForm.patchValue({
          firstName: res['firstName'],
          lastName: res['lastName'],
          companyName: res['firstName'] + ' ' + res['lastName'],
          applicantPhone: res['phone'] ? this.requestService.deserializePhoneNumber(res['phone']) : '',
          applicantEmail: res['email'],
          applicantFax: res['fax'] ? this.requestService.deserializePhoneNumber(res['fax']) : '',
          applicantStreet1: res['personAddresses'].length > 0 ? res['personAddresses'][0].street1 : '',
          applicantStreet2: res['personAddresses'].length > 0 ? res['personAddresses'][0].street2 : '',
          applicantCity: res['personAddresses'].length > 0 ? res['personAddresses'][0].city : '',
          applicantState: res['personAddresses'].length > 0 ? res['personAddresses'][0].state : '',
          applicantZipCode: res['personAddresses'].length > 0 ? res['personAddresses'][0].zipCode : '',
          // applicantCounty: res['personAddresses'].length > 0 ? res['personAddresses'][0].coutny : '',
          applicantNameCheck: true,
        });
      } else {
        this.applicantDetailForm.patchValue({
          firstName: res['firstName'],
          lastName: res['lastName'],
          companyName: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.name : '',
          applicantPhone: res['companyOfficePersons'].length > 0 ?
            this.requestService.deserializePhoneNumber(res['companyOfficePersons'][0].companyOffice.phone) : '',
          applicantEmail: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.email : '',
          applicantFax: res['companyOfficePersons'].length > 0 ?
            this.requestService.deserializePhoneNumber(res['companyOfficePersons'][0].companyOffice.fax) : '',
          applicantStreet1: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.address.street1 : '',
          applicantStreet2: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.address.street2 : '',
          applicantCity: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.address.city : '',
          applicantState: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.address.state : '',
          applicantZipCode: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.address.zipCode : '',
          // applicantCounty: res['companyOfficePersons'].length > 0 ? res['companyOfficePersons'][0].companyOffice.address.coutny : '',
          applicantNameCheck: false,
        });
      }
      this.spinnerService.hide();
    }), (err) => {
      this.spinnerService.hide();
      this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      this.router.navigate(['/dashboard']);
    });
  }

  createApplicationForAttorney(step, clickFrom) {
    this.spinnerService.show();
    if (this.applicationId) {
      this.updateApplicationForAttorney();
    } else {
      let request_obj = JSON.parse(localStorage.getItem('temp_application'));
      request_obj['data'] = this.buildRequestObject(request_obj['data']);
      request_obj = this.requestService.getRequestData(this.bondType, this.attorneyClientDetails,
        this.quoteData, request_obj['data'], this.staffDetailData, (step === 'step3' || this.addAgreementNode) ? true : false, false);
      request_obj['data']['productFor'] = (this.attorneyClientType === 'Person') ? 'individual' : this.attorneyClientType.toLowerCase();
      request_obj['person'] = (this.attorneyClientType === 'Company') ? null : this.attorneyClientDetails;
      request_obj['agent'] = this.user.agent;
      request_obj['companyOffice'] = (this.attorneyClientType === 'Company') ? { id: this.attorneyClientId } : null;
      request_obj['data']['applicantCreditCheckAddress'] = null;
      request_obj['data']['termsAndConditions'] = null;
      this.getQuotesService.createApplication(request_obj).subscribe(async response => {
        this.applicationId = response['id'];
        if (response['person'] && !this.isAttorneyOrAgent()) {
          this.person = response['person'];
          this.securityService.user.person = this.person;
        }
        // localStorage.removeItem('temp_application');
        // localStorage.removeItem('quote_id');
        this.applicationIdEmitter.emit(this.applicationId);
        // Code for Save and Continue
        let vafiduciaryResult = true;
        const poResult = true;
        let isUpdateNeeded = false;
        if (response['status'] === 'Hold' || response['status'] === 'Declined') {
          this.spinnerService.hide();
          this.router.navigate(['ibond/confirm/', this.bondType, this.applicationId]);
        } else {
          this.quoteData = response;
          if (this.bondType === 'vafiduciary' && sessionStorage.getItem('veteran_letter')) {
            isUpdateNeeded = true;
            await this.veteranFileUpload().then(varesponse => {
              vafiduciaryResult = varesponse;
            });
          }

          if ((vafiduciaryResult || poResult) && isUpdateNeeded) {
            // * Update the form data and send it to reponse
            await this.updateApplication();
          }

          this.spinnerService.hide();
          if (clickFrom === 'sendToClient') {
            this.location.replaceState('ibond/' + this.attorneyClientId + '/' +
              this.attorneyClientType + '/application/' + this.bondType + '/' + this.applicationId);
            this.step = step;
            this.lpService.getSendToClientEmail(this.applicationId).subscribe((res) => {
              const dialogRef = this.matDialog.open(SendToClientComponent, { data: res, scrollStrategy: new NoopScrollStrategy() });
              dialogRef.afterClosed().subscribe(result => {
                if (result) {
                  this.spinnerService.show();
                  // tslint:disable-next-line:no-shadowed-variable
                  this.lpService.sendMailToClient(this.applicationId).subscribe((res) => {
                    this.spinnerService.hide();
                    this.applicationPopulate.resetApplicationData();
                    this.serviceHandlerSnackbar.handleConfirm('Email sent successfully!');
                    // this.router.navigate(['/dashboard']);
                    // this.router.navigateByUrl('/enrollment/applications');
                    this.router.navigate(['/dashboard']).then(() => {
                      this.applicationPopulate.resetApplicationData();
                    });
                  }, (err) => {
                    this.spinnerService.hide();
                    this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
                  });
                } else {
                  this.spinnerService.hide();
                }
              }, (err) => {
                this.spinnerService.hide();
                this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
              });
            }, (err) => {
              this.spinnerService.hide();
              this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
            });
          } else if (clickFrom === 'saveForLater') {
            this.serviceHandlerSnackbar.handleConfirm('Saving form...');
            this.router.navigate(['/dashboard']).then(() => {
              this.applicationPopulate.resetApplicationData();
            });
          }
        }
      }, err => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }
  }

  updateApplicationForAttorney() {
    this.lpService.getSendToClientEmail(this.applicationId).subscribe((res) => {
      const dialogRef = this.matDialog.open(SendToClientComponent, { data: res, scrollStrategy: new NoopScrollStrategy() });
      this.spinnerService.hide();
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          // tslint:disable-next-line:no-shadowed-variable
          this.lpService.sendMailToClient(this.applicationId).subscribe((res) => {
            this.updateAttorneyApplication('step1');
            this.spinnerService.hide();
            this.serviceHandlerSnackbar.handleConfirm('Email sent successfully!');
            // this.router.navigate(['/dashboard']);
            // this.router.navigateByUrl('/enrollment/applications');
            this.router.navigate(['/dashboard']).then(() => {
              this.applicationPopulate.resetApplicationData();
            });
          }, (err) => {
            this.spinnerService.hide();
            this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
          });
        } else {
          this.spinnerService.hide();
        }
      }, (err) => {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
      });
    }, (err) => {
      this.spinnerService.hide();
      this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
    });
  }

  updateAttorneyApplication(step) {
    let formdata = {};
    formdata = this.buildRequestObject(formdata);
    this.quoteData = this.updateQuoteData(this.quoteData);
    this.spinnerService.show();
    const requestObject = this.requestService.getRequestData(
      this.bondType,
      (this.attorneyClientType === 'Company') ? null : this.quoteData['person'],
      this.quoteData,
      formdata,
      this.staffDetailData,
      (step === 'step2' || step === 'step3') ? true : false,
      (step === 'step3') ? true : false
    );
    requestObject['agent'] = this.user.agent;
    requestObject['companyOffice'] = (this.attorneyClientType === 'Company') ? this.quoteData['companyOffice'] : null;
    this.lpService.saveForLater(requestObject, this.applicationId).subscribe((response => {
      if (response) {
        this.spinnerService.hide();
        this.serviceHandlerSnackbar.handleConfirm('Saving form...');
        this.router.navigate(['/dashboard']).then(() => {
          this.applicationPopulate.resetApplicationData();
        });
      }
    }), (error: any) => {
      this.spinnerService.hide();
      this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
    });
  }

  isAttorneyOrAgent() {
    return this.user && (this.user.hasAgentRole || this.user.hasAttorneyRole);
  }

  ngOnDestroy(): void {
    // this.subscriptions.forEach(subs => {
    //   subs.unsubscribe();
    // });
  }
}
