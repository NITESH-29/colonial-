import { CompanyModel } from '../models/company-model';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { PersonBusinessService } from './person-business.service';
import { SecurityService } from '../../security/security.service';
import { AgencyModel } from '../models/agency-model';

@Injectable()
export class PersonCompanyResolver implements Resolve<CompanyModel | AgencyModel> {
  constructor(
    private personBusinessService: PersonBusinessService,
    private securityService: SecurityService
  ) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<CompanyModel | AgencyModel> {
    const companyId = +route.params['id'];
    const personId = this.securityService.user.person.id;
    return this.personBusinessService.getBusinessForPerson(personId, companyId) as Promise<CompanyModel | AgencyModel>;
  }
}
