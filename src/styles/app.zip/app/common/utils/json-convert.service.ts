import { Injectable } from '@angular/core';
import { JsonConvert, OperationMode, ValueCheckingMode } from 'json2typescript';

@Injectable({
  providedIn: 'root',
})
export class JsonConvertService {

  private readonly convert: JsonConvert;

  constructor() {
    this.convert = new JsonConvert();
    this.convert.operationMode = OperationMode.ENABLE; // Change to OperationMode.LOGGING to see some debug data
    this.convert.ignorePrimitiveChecks = false; // don't allow assigning number to string etc.
    this.convert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL; // never allow null
  }

  getJsonConvert(): JsonConvert {
    return this.convert;
  }
}
