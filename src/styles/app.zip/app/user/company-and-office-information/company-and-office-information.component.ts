import { Component, Input } from '@angular/core';
import { CompanyAndOfficeInformationFormGroup } from './company-and-office-information-form-group';

@Component({
  selector: 'app-company-and-office-information',
  templateUrl: './company-and-office-information.component.html',
})
export class CompanyAndOfficeInformationComponent {
  @Input() formGroup: CompanyAndOfficeInformationFormGroup;
  @Input() titleLabel = 'Your Title';
}
