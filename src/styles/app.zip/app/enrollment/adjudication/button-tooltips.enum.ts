/**
 * These are strings attached to various buttons (first word of name) for
 * tooltips when the operation is not available.
 */
export enum ButtonTooltips {
  APPROVE_SOFT_HOLD = 'Cannot approve an application that has soft hold issues',
  APPROVE_KNOCKED_OUT = 'Cannot approve an application that is knocked out',
  APPROVE_NOT_VERIFIED = 'Cannot approve until all required files are verified.',
  APPROVE_WRONG_STATUS = 'Cannot approve an application that is not in submitted status.',
  APPROVE_BAD_CREDIT_SCORE = 'Cannot approve an application with a bad credit score',
  CLOSE_WRONG_STATUS = 'Cannot close an application that is in a final status.',
  DECLINE_WRONG_STATUS = 'Cannot decline an application where the application is not submitted or on hold.',
  DELETE_NO_FILE = 'No file to delete.',
  DELETE_CLOSED_APPLICATION = 'Cannot delete a file of a closed or completed application.',
  UPLOAD_CLOSED_APPLICATION = 'Cannot upload a file to a closed or completed application.',
  UPLOAD_NO_SP_BOND_FORM = 'Special Bond Form required to upload Completed Special Bond Form.',
  UPLOAD_EXISTING_WARNING = 'Delete existing file in order to upload replacement file.',
  VERIFY_NO_FILE = 'No file to verify.',
  VERIFY_CLOSED_APPLICATION = 'Cannot verify a file of a closed application.',
  VIEW_NO_FILE = 'No file to view.',
}
