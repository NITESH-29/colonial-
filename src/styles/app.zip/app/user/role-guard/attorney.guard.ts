import { Injectable } from '@angular/core';
import { SecurityService } from 'src/app/security/security.service';
import { UserImpl } from 'src/app/security/user';
import { RoleGuard } from './role.guard';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AttorneyGuard extends RoleGuard {
  constructor(securityService: SecurityService,
    public router: Router,
    public serviceHandlerSnackbar: ServiceHandler) {
    super(securityService);
  }

  protected hasPermission(user: UserImpl, params: any): boolean {
    if (user.hasAttorneyRole) {
      if (params.bondType === 'lost_instrument' || params.bondType === 'vafiduciary' || this.router.url.includes('logout')) {
        return true;
      } else {
        this.serviceHandlerSnackbar.showErrorMessage('You are not allowed to access this page.');
        this.router.navigate(['/dashboard']);
        return false;
      }
    } else {
      return true;
    }
  }
}
