import { AdjudicationConfiguration, AdjudicationConfigurationImpl } from '../application/adjudication-configuration';
import { ApplicationImpl } from '../application/application';
import { AdjudicationFile } from './adjudication-file';
import { JsonObject, JsonProperty } from 'json2typescript';
import { ApplicantAndPurchaserImpl, PurchaserRoles } from './applicant-and-purchaser';

@JsonObject('AdjudicationPacket')
export class AdjudicationPacket {
  @JsonProperty('configuration', AdjudicationConfigurationImpl, true)
  configuration: AdjudicationConfiguration = null;
  @JsonProperty('application', ApplicationImpl, true)
  application: ApplicationImpl = null;
  @JsonProperty('extraProductVerifications', [AdjudicationFile], true)
  extraProductVerifications: AdjudicationFile[] = undefined;
  @JsonProperty('otherFiles', [AdjudicationFile], true)
  otherFiles: AdjudicationFile[] = undefined;
  @JsonProperty('collateralFile', AdjudicationFile, true)
  collateralFile: AdjudicationFile = undefined;
  @JsonProperty('requiresCollateral', Boolean, true)
  requiresCollateral = false;
  @JsonProperty('role', String, true)
  role = '';
  @JsonProperty('applicantAndPurchaser', ApplicantAndPurchaserImpl, true)
  applicantAndPurchaser = undefined;
  @JsonProperty('applicationFile', AdjudicationFile, true)
  applicationFile: AdjudicationFile = undefined;

  /**
   * In order to report who uploaded a file (User or Employee), we use this.
   *
   * This needs to be more complex if we are distinguishing client from agent from employee.
   */
  enableFileCreatorIdentification(): void {
    const applicationCreatedBy = this.application.createdBy;
    this.extraProductVerifications.forEach(evp => {
      evp.applicantName = applicationCreatedBy;
    });
    if (!!this.collateralFile) {
      this.collateralFile.applicantName = applicationCreatedBy;
    }
    this.otherFiles.forEach(otherFile => {
      otherFile.applicantName = applicationCreatedBy;
    });
  }
  get isStartedByAttorney(): boolean {
    return this.role === PurchaserRoles.ATTORNEY;
  }
}
