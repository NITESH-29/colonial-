import { Component, Input, OnInit } from '@angular/core';
import { PersonalInformationFormGroup } from './personal-information-form-group';
import { salutations } from '../../common/utils/constants';

@Component({
  selector: 'app-personal-information',
  templateUrl: './personal-information.component.html',
  styleUrls: ['./personal-information.component.css'],
})
export class PersonalInformationComponent implements OnInit {
  @Input() formGroup: PersonalInformationFormGroup;
  @Input() label = 'Contact Information';
  @Input() disableName = false;
  get salutations(): any { return salutations; }

  ngOnInit() {
    if (this.disableName) {
      this.formGroup.get('firstName').disable();
      this.formGroup.get('lastName').disable();
      this.formGroup.get('email').disable();
    }
  }
}
