import { Component, Input } from '@angular/core';
import { BusinessOfficeInformationFormGroup } from './business-office-information-form-group';

@Component({
  selector: 'app-business-office-information',
  templateUrl: './business-office-information.component.html',
})
export class BusinessOfficeInformationComponent {
  @Input() formGroup: BusinessOfficeInformationFormGroup;

  @Input() titleLabel = 'Your Title';

  @Input() businessLabel = 'Company';

  @Input() showHeader = false;

  @Input() showOfficeType = false;

  get officeTypes(): string[] {
    return ['Main', 'Branch'];
  }
}
