import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApplicationService } from '../application/application.service';
import { PaymentMethodSelectionService } from '../../common/payment-method-selection/payment-method-selection.service';
import { map } from 'rxjs/operators';
import { FileModel } from '../../common/file-upload/file-model';
import { splitIntoWords } from '../../common/utils/helper-fns';
import { PaymentChannelCode } from '../../common/payment-method-selection/payment_channel_code';
import { PaymentMethod } from '../application/court/model/common/payment-method';
import { PaymentFrequencyType } from '../../common/payment-method-selection/payment_frequency_type';
import {
  AppliedPaymentPlanTypeModel,
  PaymentPlanTypeModel,
} from '../../common/payment-method-selection/payment-plan-type-model';
import { Subscription } from 'rxjs';
import { ApplicationImpl } from '../application/application';
import { CurrencyFormatter } from '../../common/utils/currency-formatter';
import { CourtBondTypeDisplayNames, ProfessionalLiabilityBondType } from '../application/common/bond-types';

export enum FileTypes {
  applicationFile = 'applicationFile',
  // completedSpecialBondFile = 'completedSpecialBondFile',
  courtOrderFile = 'courtOrderFile',
  judgmentFile = 'judgmentFile',
  personalFinancialFile = 'personalFinancialFile',
  // specialBondFile = 'specialBondFile',
  letterOfCreditFile = 'letterOfCreditFile',
  wireTransferFile = 'wireTransferFile',
}

@Component({
  selector: 'app-application-overview',
  templateUrl: './application-overview.component.html',
  styleUrls: ['./application-overview.component.css'],
})
export class ApplicationOverviewComponent implements OnInit, OnDestroy {

  overviewData: ApplicationImpl;

  formId = -1;
  // a subscription whose sole purpose is to support cleanup of subscriptions.
  private _rootCleanupSubscription: Subscription = new Subscription();
  bondClassification: string;
  appliedPaymentPlanType: AppliedPaymentPlanTypeModel; // Undefined if application has no PaymentMethod info. E.G. if knocked-out.
  fileList: FileModel[] = [];

  constructor(private paymentMethodService: PaymentMethodSelectionService,
    private applicationService: ApplicationService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.formId = this.activatedRoute.snapshot.queryParams['formId'];
    if (this.formId && this.formId > -1) {
      const applicationId = this.formId;
      this._rootCleanupSubscription.add(
        this.applicationService.getBondOverview(applicationId).subscribe((overview) => {
          this.overviewData = overview;

          if (this.overviewData.data.bondClassification === ProfessionalLiabilityBondType.Pnl) {
            this.bondClassification = 'Professional Liability';
          } else {
            this.bondClassification = CourtBondTypeDisplayNames[this.overviewData.data.bondClassification];
          }

          const applicationPaymentPlan = this.overviewData.data.applicationPaymentPlan;
          if (!!applicationPaymentPlan) {
            const paymentPlanTypeModel = applicationPaymentPlan.paymentPlanTypeModel;
            if (!!paymentPlanTypeModel && !!paymentPlanTypeModel.id) {
              // We have a fully baked applicationPaymentPlan.
              this.appliedPaymentPlanType = applicationPaymentPlan;
            }
          }
        }));

      // Get application file list, excluding the application pdf
      this._rootCleanupSubscription.add(
        this.applicationService.getFileListForApplication(this.formId)
          .pipe(map(fs => fs.filter(f => f.fileTypeName !== FileTypes.applicationFile)))
          .subscribe(files => this.fileList = files));
    }
  }

  ngOnDestroy(): void {
    this._rootCleanupSubscription.unsubscribe();
  }

  displayName(file: FileModel): string {
    return splitIntoWords(file.fileTypeName).join(' ');
  }

  isPNL() {
    return this.overviewData.data.bondClassification === 'pnl';
  }

  get applicationFileType(): string {
    return FileTypes.applicationFile;
  }

  get isDisplayPaymentInformation() {
    let isDisplay;
    isDisplay = !!this.paymentMethodData && !!this.appliedPaymentPlanType;
    return isDisplay;
  }

  get paymentMethodData(): PaymentMethod {
    return this.overviewData.data.paymentMethod;
  }

  get paymentChannelCode(): PaymentChannelCode {
    return this.paymentMethodData.paymentChannelCode;
  }

  get paymentPlanTypeModel(): PaymentPlanTypeModel {
    return !!this.appliedPaymentPlanType
      ? this.appliedPaymentPlanType.paymentPlanTypeModel : undefined;
  }

  get paymentFrequencyType(): PaymentFrequencyType {
    return !!this.paymentPlanTypeModel
      ? this.paymentPlanTypeModel.paymentFrequencyType : undefined;
  }

  formatCurrency(amount: number): string {
    return CurrencyFormatter.formatMoney(amount);
  }
}
