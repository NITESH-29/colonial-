import { Address, AddressImpl } from '../../enrollment/application/court/model/common/address';
import { JsonObject, JsonProperty } from 'json2typescript';
import { OfficeType } from '../../common/company-office-summary';
import { PhoneNumberConverter } from '../../common/utils/phone-number-converter';
import { AgentModel, AgentModelImpl } from './agency-office-person-model';

export interface AgencyOfficeModel {
  id: number;
  name: string;
  licenseNumber: string;
  address: Address;
  email: string;
  website: string;
  phone: string;
  fax: string;
  officeType: OfficeType;
  sicCode: string;
  clientsId: number;
  agentId: number;
  agents: AgentModel[];
}

@JsonObject('AgencyOfficeModelImpl')
export class AgencyOfficeModelImpl implements AgencyOfficeModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('agentId', Number, true)
  agentId: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('licenseNumber', String, true)
  licenseNumber: string = null;

  @JsonProperty('address', AddressImpl, true)
  address: Address = null;

  @JsonProperty('email', String, true)
  email: string = null;

  @JsonProperty('website', String, true)
  website: string = null;

  @JsonProperty('phone', PhoneNumberConverter, true)
  phone: string = null;

  @JsonProperty('fax', PhoneNumberConverter, true)
  fax: string = null;

  @JsonProperty('officeType', String, true)
  officeType: OfficeType = null;

  @JsonProperty('siccode', String, true)
  sicCode: string = null;

  @JsonProperty('clientsId', Number, true)
  clientsId: number = null;

  @JsonProperty('agents', [AgentModelImpl], true)
  agents: AgentModel[] = [];
}
