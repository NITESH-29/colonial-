import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';
import { DateValidators } from '../validators/date-validators';

@Component({
  selector: 'app-appointment-date',
  templateUrl: './appointment-date.component.html',
  styleUrls: ['./appointment-date.component.css'],
})
export class AppointmentDateComponent implements OnInit {

  @Input() appointmentDateFormGroup: FormGroup;

  appointmentDateValidators = [DateValidators.datePatternValidator()];

  constructor() { }

  get appointmentDate(): FormControl {
    return this.appointmentDateFormGroup.get('appointmentDate') as FormControl;
  }

  get futureAppointmentWillNotify(): FormControl {
    return this.appointmentDateFormGroup.get('futureAppointmentWillNotify') as FormControl;
  }

  ngOnInit(): void {

    if (this.futureAppointmentWillNotify) {
      this.futureAppointmentWillNotify
        .valueChanges.pipe(distinctUntilChanged())
        .subscribe(b => { if (b) { this.appointmentDate.setValue(''); } });
    }

    if (this.appointmentDate) {
      this.appointmentDate
        .valueChanges.pipe(distinctUntilChanged((x, y) => (x + '') === (y + '')))
        .subscribe(d => { if (d) { this.futureAppointmentWillNotify.setValue(false); } });
    }
  }

  shouldShowAppointmentError = () =>
    (this.appointmentDateFormGroup.errors &&
      this.appointmentDateFormGroup.errors['exactlyOneRequired'] &&
      !(this.futureAppointmentWillNotify.untouched && this.appointmentDate.untouched)) ||
    (this.futureAppointmentWillNotify.dirty &&
      !this.futureAppointmentWillNotify.value &&
      this.appointmentDate.value === '')

}
