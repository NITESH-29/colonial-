import { JsonObject, JsonProperty } from 'json2typescript';
import { CompanyOfficeModel, CompanyOfficeModelImpl } from './company-office-model';

export interface CompanyModel {
  id: number;
  name: string;
  companyOffices: CompanyOfficeModel[];
}

@JsonObject('CompanyModelImpl')
export class CompanyModelImpl implements CompanyModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('companyOffices', [CompanyOfficeModelImpl], true)
  companyOffices: CompanyOfficeModel[] = [];
}
