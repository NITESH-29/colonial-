import { ApplicationFileImpl } from './application-file';
import { JsonObject, JsonProperty } from 'json2typescript';
import { FileTypes } from '../application-overview/application-overview.component';
import { FileType, FileTypeImpl } from './file-type';

@JsonObject('AdjudicationFile')
export class AdjudicationFile {
  @JsonProperty('applicationFile', ApplicationFileImpl, true)
  applicationFile: ApplicationFileImpl = null;
  @JsonProperty('fileType', FileTypeImpl, true)
  fileType: FileType = null;
  @JsonProperty('sortOrder', Number, true)
  sortOrder = -1;
  @JsonProperty('required', Boolean, true)
  required = false;
  @JsonProperty('externalProductVerification', Boolean, true)
  externalProductVerification = false;
  @JsonProperty('collateral', Boolean, true)
  collateral = false;
  @JsonProperty('verified', Boolean, true)
  verified = false;
  @JsonProperty('existingFile', Boolean, true)
  existingFile = false;
  @JsonProperty('filledBy', Boolean, true)
  filledBy = false;
  private _uniqueId: string = null;
  private _applicantName: string = null;

  get label(): string {
    return this.fileType.description;
  }

  get fileId(): number {
    if (this.existingFile) {
      return this.applicationFile.id;
    } else if (this.filledBy === false) {
      return -1;
    }
  }

  calculateUniqueId(): string {
    let safeFn = '';
    if (this.existingFile) {
      const applicationId = this.applicationFile.applicationId;
      const fileId = this.applicationFile.id;
      safeFn = 'file-' + applicationId + '-' + fileId;
    } else {
      safeFn = 'missingFile';
    }
    return `${this.fileType.name}-${safeFn}`;
  }

  get uploadedBy(): string {
    if (!this.existingFile) {
      return 'nobody yet';
    } else if (this._applicantName === null) {
      return 'not set up';
    } else {
      const createdBy = this.applicationFile.createdBy;
      if (createdBy === this._applicantName) {
        return 'applicant';
      } else {
        return 'employee';
      }
    }
  }

  get uniqueId(): string {
    if (this._uniqueId === null) {
      this._uniqueId = this.calculateUniqueId();
    }
    return this._uniqueId;
  }

  get statusText(): string {
    return this.verified ? 'Verified' : 'Not verified';
  }

  setVerified(b: boolean): void {
    this.verified = b;
  }

  /**
   * Multi-factor `verified` status:
   *   - existing file can be verified
   *   - required file is NOT verified
   *   - otherwise, passes as verified
   */
  get verificationStatus(): boolean {
    if (this.existingFile) {
      return this.verified;
    } else {
      return !this.isRequired;
    }
  }

  get requiredText(): string {
    if (this.existingFile) {
      return `Uploaded by ${this.uploadedBy}`;
    } else if (this.isRequired) {
      return 'Is Required';
    } else if (this.filledBy) {
      return 'Entered by Applicant';
    } else {
      return 'Not required';
    }
  }

  set applicantName(value: string) {
    this._applicantName = value;
  }

  get toggleDisabled(): boolean {
    return this.isRequired && !this.existingFile;
  }

  get autoPassed(): boolean {
    return !this.isRequired && !this.existingFile;
  }

  get urlForFile(): string {
    return this.applicationFile.urlForFile;
  }

  get urlForViewing(): string {
    return this.applicationFile.urlForViewing;
  }

  get isApplicationPdf(): boolean {
    return this.existingFile &&
      this.fileType.name === FileTypes.applicationFile;
  }

  get isRequired(): boolean {
    if (this.required) { return true; }
    // if (this.fileType.name === FileTypes.personalFinancialFile) {
    //   this.required = true;
    //   return true;
    // }
    return false;
  }
}
