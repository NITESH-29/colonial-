import { AfterViewInit, Component, ElementRef, EventEmitter, HostListener, Input, Output, OnChanges } from '@angular/core';
import { Column } from './column';
import { LazyLoadEvent } from 'primeng/api';
import { ListLinkClickEvent, IconActionListEvent } from './list-link-click-event';
import { Page, Pageable, PageableConverter } from '../../common/pagination';

@Component({
  selector: 'app-generic-pageable-list',
  templateUrl: './generic-pageable-list.component.html',
  styleUrls: ['./generic-pageable-list.component.scss'],
})
export class GenericPageableListComponent implements AfterViewInit, OnChanges {

  @Input()
  loading: boolean;

  @Input()
  page: Page<any>;

  @Input()
  cols: Column[];

  @Input()
  numberOfRows: number;

  @Input()
  sortField: string;

  @Input()
  sortOrder: number;

  @Input() disableDeleteIcon: boolean;

  @Output()
  pageableEvent: EventEmitter<Pageable> = new EventEmitter<Pageable>(true);

  @Output()
  listLinkClickEvent: EventEmitter<ListLinkClickEvent> = new EventEmitter<ListLinkClickEvent>(true);

  @Output()
  iconActionClickEvent: EventEmitter<IconActionListEvent> = new EventEmitter<IconActionListEvent>(true);

  displayScrollText: boolean;

  element = this.elementRef.nativeElement;

  canOnlyScrollRight: boolean;
  canOnlyScrollLeft: boolean;




  constructor(private elementRef: ElementRef) {

  }

  pageableEventHandler(event: LazyLoadEvent) {
    const pageable: Pageable = PageableConverter.fromLazyLoadEvent(event);
    this.pageableEvent.emit(pageable);
  }

  clickEvent(data: any, column?: any) {
    const columnFieldName: string = column.field;
    if (column.link) {
      this.listLinkClickEvent.emit({ columnFieldName, data });
    }
  }

  fullCellClickEvent(data: any, columnFieldName?: string) {
    this.listLinkClickEvent.emit({ columnFieldName, data });
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.checkForScrolling();
  }

  ngOnChanges() {
    // setTimeout(() => {
    //   window.scrollTo(
    //     {
    //       top: 0,
    //       behavior: 'smooth',
    //     }
    //   );
    // }, 1000);
  }
  ngAfterViewInit(): void {
    setTimeout(() => {
      this.checkForScrolling();
      const pTableElementThatScrolls = this.element.querySelector('.ui-table-scrollable-body');
      pTableElementThatScrolls.addEventListener('scroll', (e) => {
        this.checkForScrolling();
      });
    }, 1000);
  }


  checkForScrolling() {
    const pTableElementThatScrolls = this.element.querySelector('.ui-table-scrollable-body');
    const table = this.element.querySelector('.ui-table-scrollable-body-table');
    if (pTableElementThatScrolls.scrollWidth > pTableElementThatScrolls.clientWidth) {
      this.canOnlyScrollRight = true;
      this.displayScrollText = true;

      if (pTableElementThatScrolls.scrollLeft === 0) {
        this.canOnlyScrollRight = true;
        this.canOnlyScrollLeft = false;
      }

      if (pTableElementThatScrolls.scrollLeft + pTableElementThatScrolls.offsetWidth === table.offsetWidth) {
        this.canOnlyScrollRight = false;
        this.canOnlyScrollLeft = true;
      }

      if (pTableElementThatScrolls.scrollLeft > 0 &&
        (pTableElementThatScrolls.scrollLeft + pTableElementThatScrolls.offsetWidth !== table.offsetWidth)) {
        this.canOnlyScrollRight = false;
        this.canOnlyScrollLeft = false;
      }

    } else {
      this.displayScrollText = false;
    }
  }

  iconClick(data: any, action: any) {
    this.iconActionClickEvent.emit({ data, action });
  }

  getIconStatusClass(_icon) {
    if (this.disableDeleteIcon === true && _icon.name === 'delete') {
      return 'icon-disable-style';
    }
  }
}
