import { Address } from '../../enrollment/application/court/model/common/address';

export interface PersonalInformation {
  firstName: string;
  initial?: string;
  lastName: string;
  suffix?: string;
  salutation?: string;
  phone?: string;
  email?: string;
  profession?: string;
  address?: Address | null;
}
