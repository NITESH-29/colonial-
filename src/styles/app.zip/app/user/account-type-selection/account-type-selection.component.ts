import { Component } from '@angular/core';
import { AccountType } from './account-type';

@Component({
  selector: 'app-account-type-selection',
  templateUrl: './account-type-selection.component.html',
  styleUrls: ['./account-type-selection.component.scss'],
})
export class AccountTypeSelectionComponent {

  constructor() { }

  get accountTypes(): Array<AccountType> {
    return [
      /* {
        title: 'Insurance Agent',
        description: 'You will have the ability to apply for all Colonial Surety products on behalf of your clients.',
        routerLink: '/user/create-agent',
       }, */
      {
        title: 'Personal/Company',
        description: 'If you wish to apply for bonds and policies for yourself and/or for your business',
        routerLink: '/user/create-client',
      },
      {
        title: 'Attorney',
        description: 'You will have the ability to apply for court & fiduciary products on behalf of your clients',
        routerLink: '/user/create-attorney',
      },
    ];
  }

}
