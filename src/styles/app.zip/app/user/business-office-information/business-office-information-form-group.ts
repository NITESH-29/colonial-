import { AddressFormGroup } from '../../common/address/address-form-group';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { BusinessOfficeInformation } from './business-office-information';
import { CompanyOfficeModel, CompanyOfficeModelImpl } from '../models/company-office-model';
import { CompanyOfficePersonModelImpl } from '../models/company-office-person-model';
import { PatternValidators } from '../../common/validators/pattern-validators';

type IsRequiredFn = () => boolean;
export type FormGroupOptions<T> = { [P in keyof T]?: IsRequiredFn };
export type BusinessOfficeInformationFormGroupOptions = FormGroupOptions<BusinessOfficeInformation>;

const defaultBusinessOfficeInformationGroupOptions = {
  name: () => true,
  email: () => true,
  phone: () => true,
  sicCode: () => true,
  address: () => true,
  title: () => true,
  officeType: () => false,
};

export class BusinessOfficeInformationFormGroup extends FormGroup {
  constructor(opts: BusinessOfficeInformationFormGroupOptions = defaultBusinessOfficeInformationGroupOptions) {
    super({
      id: new FormControl(null),
      companyOfficePersonId: new FormControl(null),
      name: new ConditionalRequireFormControl(null, opts.name, Validators.maxLength(450)),
      website: new FormControl(null, Validators.maxLength(50)),
      email: new ConditionalRequireFormControl(null, opts.email, [PatternValidators.email(), Validators.maxLength(75)]),
      phone: new ConditionalRequireFormControl(null, opts.phone, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      fax: new FormControl(null, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      sicCode: new ConditionalRequireFormControl(null, opts.sicCode, Validators.maxLength(8)),
      title: new ConditionalRequireFormControl(null, opts.title, Validators.maxLength(140)),
      officeType: new ConditionalRequireFormControl(null, opts.officeType, Validators.maxLength(60)),
      address: new AddressFormGroup(opts.address),
    });
  }

  // noinspection JSAnnotator
  patchValue(value: Partial<CompanyOfficeModel>): void {
    super.patchValue({
      id: value.id,
      name: value.name,
      website: value.website,
      email: value.email,
      phone: value.phone,
      fax: value.fax,
      sicCode: value.sicCode,
      officeType: value.officeType,
      address: value.address,
      title: value.companyOfficePersons && value.companyOfficePersons.length > 0 && value.companyOfficePersons[0].title,
      companyOfficePersonId: value.companyOfficePersons && value.companyOfficePersons.length > 0 && value.companyOfficePersons[0].id,
    });
  }

  getRawValue(): CompanyOfficeModel {
    const companyOffice: CompanyOfficeModelImpl = new CompanyOfficeModelImpl();
    companyOffice.id = this.id.value;
    companyOffice.address = this.address.getRawValue();
    companyOffice.sicCode = this.sicCode.value;
    companyOffice.email = this.email.value;
    companyOffice.fax = this.fax.value;
    companyOffice.name = this.name.value;
    companyOffice.website = this.website.value;
    companyOffice.officeType = this.officeType.value;
    companyOffice.phone = this.phone.value;
    companyOffice.companyOfficePersons.push(new CompanyOfficePersonModelImpl());
    companyOffice.companyOfficePersons[0].responsiblePerson = true;
    companyOffice.companyOfficePersons[0].title = this.title.value;
    companyOffice.companyOfficePersons[0].id = this.companyOfficePersonId.value;
    return companyOffice;
  }

  get id(): FormControl {
    return this.get('id') as FormControl;
  }

  get companyOfficePersonId(): FormControl {
    return this.get('companyOfficePersonId') as FormControl;
  }

  get name(): FormControl {
    return this.get('name') as FormControl;
  }

  get website(): FormControl {
    return this.get('website') as FormControl;
  }

  get email(): FormControl {
    return this.get('email') as FormControl;
  }

  get phone(): FormControl {
    return this.get('phone') as FormControl;
  }

  get fax(): FormControl {
    return this.get('fax') as FormControl;
  }

  get title(): FormControl {
    return this.get('title') as FormControl;
  }

  get sicCode(): FormControl {
    return this.get('sicCode') as FormControl;
  }

  get officeType(): FormControl {
    return this.get('officeType') as FormControl;
  }

  get address(): AddressFormGroup {
    return this.get('address') as AddressFormGroup;
  }
}
