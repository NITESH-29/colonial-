import { Injectable } from '@angular/core';
import { JsonConvert } from 'json2typescript';
import { HttpClient } from '@angular/common/http';
import { UtilService } from '../../common/utils/util.service';
import { Employee, EmployeeImpl } from './employee/employee';


@Injectable()
export class AdminService {
  requestUrl = '/api/admin/employee';
  private jsonConvert: JsonConvert;

  constructor(private http: HttpClient) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async createAndInviteEmployee(employee: Employee) {
    const requestBody = this.jsonConvert.serialize(employee);
    const response = await this.http.post(this.requestUrl, requestBody).toPromise();
    return this.jsonConvert.deserialize(response, EmployeeImpl);
  }

  async updateEmployee(employee: Employee): Promise<Employee> {
    const requestBody = this.jsonConvert.serialize(employee);
    const response = await this.http.put(this.requestUrl, requestBody).toPromise();
    return this.jsonConvert.deserialize(response, EmployeeImpl) as EmployeeImpl;
  }

  async resendInvitation(id: number) {
    await this.http.post(`${this.requestUrl}/${id}/resend-invite`, null).toPromise();
  }

  async removeEmployee(id: number) {
    await this.http.delete(`${this.requestUrl}/${id}`).toPromise();
  }
}
