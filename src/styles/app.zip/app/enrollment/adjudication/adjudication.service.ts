import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../../common/utils/util.service';
import { throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ApplicationNote } from './application-note';
import { ApplicationFile } from './application-file';
import { Observable } from 'rxjs/Observable';
import { EmailMessage } from '../../common/email/email-message';
import { AdjudicationPacket } from './adjudication-packet';
import { Application } from '../application/application';
import { ApplicationStatus } from './application-status.enum';

type ServiceCall<T = any> = (id: number) => Observable<T | Object>;
enum ServiceMethod {
  GET, PUT,
}
@Injectable({
  providedIn: 'root',
})
export class AdjudicationService {
  private updateNotes = new EventEmitter<boolean>();

  constructor(
    private http: HttpClient,
    private securityService: SecurityService,
    private serviceHandler: ServiceHandler
  ) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  private requestURL = 'api/colonial/adjudicate';
  private jsonConvert: JsonConvert;

  adjudicate: ServiceCall = this.serviceReturner<AdjudicationPacket>('adjudication-packet', ServiceMethod.GET, AdjudicationPacket);
  approve: ServiceCall = this.serviceReturner('approve', ServiceMethod.PUT);
  verifyFile: ServiceCall = this.serviceReturner('verify-file', ServiceMethod.PUT);
  unverifyFile: ServiceCall = this.serviceReturner('unverify-file', ServiceMethod.PUT);
  verifyFinancials: ServiceCall = this.serviceReturner('verify-financial', ServiceMethod.PUT);
  unverifyFinancials: ServiceCall = this.serviceReturner('unverify-financial', ServiceMethod.PUT);


  async closeApplication(applicationId: number, reason: string) {
    await this.http.put(`/api/colonial/adjudicate/close/${applicationId}`, reason).toPromise();
  }

  async declineApplication(applicationId: number, reason: string) {
    await this.http.put(`/api/colonial/adjudicate/decline/${applicationId}`, reason).toPromise();
  }

  async revertApplication(applicationId: number, reason: string) {
    await this.http.put(`/api/colonial/adjudicate/revert-status/${applicationId}`, reason).toPromise();
  }

  async releaseHeldApplication(applicationId: number, reason: null) {
    await this.http.put(`/api/colonial/adjudicate/release-application/${applicationId}`, reason).toPromise();
  }

  creditOverride(applicationId: number, value: boolean) {
    return this.http.put(`/api/colonial/adjudicate/credit-override/${applicationId}`, {
      'value': value,
    });
  }

  softHoldOverride(applicationId: number) {
    return this.http.put(`/api/colonial/adjudicate/override-soft-hold/${applicationId}`, null);
  }

  serviceReturner<T>(verb: string, type: ServiceMethod, someT: any = null): ServiceCall<T> {
    const self = this;
    switch (type) {
      case ServiceMethod.GET:
        return function(id: number): Observable<T | Object> {
          return self.http.get(`${self.requestURL}/${verb}/${id}`).pipe(
            catchError((error) =>
              throwError(self.serviceHandler.showErrorMessage(`An error occurred on application ${verb}`))),
            map(json => {
              return self.jsonConvert.deserializeObject(json, someT) as T;
            })

          );
        };
      case ServiceMethod.PUT:
        return function(id: number): Observable<T | Object> {
          return self.http.put(`${self.requestURL}/${verb}/${id}/`, null, {}).pipe(
            catchError((error) => {
              return throwError(self.serviceHandler.showErrorMessage(`An error occurred on application ${verb}`));
            })
          );
        };
    }
  }


  getApplicationFiles(): Observable<ApplicationFile[]> {
    return null;
  }

  addNote(note: ApplicationNote): Observable<ApplicationNote> {
    return null;
  }

  getApplicationNotes(applicationId: number): Observable<ApplicationNote[]> {
    return null;
  }

  sendEmail(email: EmailMessage): Observable<EmailMessage> {
    return null;
  }

  isReadyForAdjudication(application: Application): boolean {
    return !!application &&
      (application.status === ApplicationStatus.SUBMITTED);
  }

  koqOverride(applicationId: number, value: boolean) {
    return this.http.put(`/api/colonial/adjudicate/koq-override/${applicationId}`, {
      'value': value,
    });
  }

  emitUpdateNotes(flag) {
    this.updateNotes.emit(flag);
  }

  getUpdateNotes() {
    return this.updateNotes;
  }

}
