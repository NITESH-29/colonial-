import { FormControl, FormGroup } from '@angular/forms';
import { SearchboxWithDropdownFormGroup } from '../searchbox-with-dropdown/searchbox-with-dropdown-form-group';
import { SearchObject } from '../searchbox-with-dropdown/search-object';
import * as moment from 'moment';

export class GenericTableSearchFormGroup extends FormGroup {

  constructor(defaultStatus: string, searchboxSearchObjects: SearchObject[]) {
    super({
      status: new FormControl(defaultStatus),
      dateRange: new FormControl([
        moment().subtract(1, 'months').toDate(), // a month ago
        new Date(), // today
      ]),
      searchbox: new SearchboxWithDropdownFormGroup(searchboxSearchObjects),
    });
  }


  /**
   * had to name this statusFormControl because status is already used
   * by abstract form control
   */
  get statusFormControl(): FormControl {
    return this.get('status') as FormControl;
  }

  get dateRange(): FormControl {
    return this.get('dateRange') as FormControl;
  }

  get searchbox(): SearchboxWithDropdownFormGroup {
    return this.get('searchbox') as SearchboxWithDropdownFormGroup;
  }


  getRawValue(): any {

    // declare possible variables.
    let status;
    let startDate: String;
    let endDate: String;

    // check the status search bar here, we don't want anything if it's "all"
    if (this.statusFormControl.value !== 'All') {
      status = this.statusFormControl.value;
    }
    // date range comes back as an array
    const dateRange = this.dateRange.value;
    if (dateRange && dateRange[0] && dateRange[1]) {
      startDate = moment(dateRange[0]).format('MM/DD/YYYY');
      endDate = moment(dateRange[1]).add(1, 'day').format('MM/DD/YYYY');
    }

    // searchbox, we can just grab the raw value since it's it's own thing.

    const searchbox = this.searchbox.getRawValue();

    return {
      status,
      startDate,
      endDate,
      ...searchbox,
    };
  }
}
