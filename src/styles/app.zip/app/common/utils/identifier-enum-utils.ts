import { IdentifierEnum } from './identifier-enum';

export class IdentifierEnumUtils {
  /**
   * Sort identifierEnums by the position of their persistenceId in provided array.
   * Order of enums not in 'ordered' array is preserved.
   * @param orderedIdentifierEnums array of IdentifierEnums in desired display order.
   * @param identifierEnums array of identifierEnums to be sorted in situ.
   */
  static orderByDisplayPrecedence<T extends IdentifierEnum>(orderedIdentifierEnums: T[], identifierEnums: T[]): T[] {
    if (orderedIdentifierEnums.length < identifierEnums.length) {
      // displayPrecedence of at least one enumValue hasn't been provided.
      // Add a 'displayPrecedence' property.
      // Initialize it to a large enough value to so as to preserve position of the unspecified-order enum(s).
      identifierEnums.forEach((enumValue, index, array) => {
        enumValue['displayPrecedence'] = array.length + index;
      });
    }
    // Now set the 'displayPrecedence' of those that we know about.
    orderedIdentifierEnums.forEach((orderedIdentifierEnum, displayPrecedenceIndex) => {
      const knownEnumValue = identifierEnums.find(enumValue => enumValue.persistenceId === orderedIdentifierEnum.persistenceId);
      if (!!knownEnumValue) {
        knownEnumValue['displayPrecedence'] = displayPrecedenceIndex;
      }
    });
    // Can now sort by 'displayPrecedence' which will sort by:
    // - order explicitly specified
    // - and preserve order of those that were not explicitly specified.
    identifierEnums.sort(
      (enumValue_1, enumValue_2) => enumValue_1['displayPrecedence'] - enumValue_2['displayPrecedence']);
    return identifierEnums;
  }
}
