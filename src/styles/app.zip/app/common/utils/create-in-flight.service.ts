import { Injectable, OnDestroy } from '@angular/core';

@Injectable()
export class CreateInFlightService implements OnDestroy {
  private _applicantId: number;
  private _bondType: string;
  private _bondId: number;
  private _bondAmount: number;
  private _bondPremium: number;

  constructor() {
  }

  registerCreate(bondType: string,
    bondAmount: number,
    bondPremium: number) {
    this._bondType = bondType;
    this._bondAmount = bondAmount;
    this._bondPremium = bondPremium;
  }

  set applicantId(applicantId: number) {
    this._applicantId = applicantId;
  }

  isReadyToCreate(): boolean {
    if (this._applicantId &&
      this._bondType &&
      this._bondAmount &&
      this._bondPremium) {
      return true;
    }
    return false;
  }

  isBondCreated(): boolean {
    if (this._applicantId &&
      this._bondType &&
      this._bondId &&
      this._bondAmount &&
      this._bondPremium) {
      return true;
    }
    return false;
  }

  get applicantId(): number {
    return this._applicantId;
  }

  set bondId(value: number) {
    this._bondId = value;
  }

  get bondId(): number {
    return this._bondId;
  }

  get bondAmount(): number {
    return this._bondAmount;
  }

  get bondPremium(): number {
    return this._bondPremium;
  }

  set bondType(value: string) {
    this._bondType = value;
  }

  get bondType(): string {
    return this._bondType;
  }

  toString(): string {
    return (`CreateInFlightService
                     _applicantId: ${this._applicantId},
                     _bondType: ${this._bondType},
                     _bondId: ${this._bondId},
                     _bondAmount: ${this._bondAmount},
                     _bondPremium: ${this._bondPremium}`);

  }

  ngOnDestroy() {
    this._applicantId = null;
    this._bondType = null;
    this._bondId = null;
    this._bondAmount = null;
    this._bondPremium = null;
  }
}
