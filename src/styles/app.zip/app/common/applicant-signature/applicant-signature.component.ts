import {
  Component,
  Input,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
} from '@angular/forms';

@Component({
  selector: 'app-applicant-signature',
  templateUrl: './applicant-signature.component.html',
  styleUrls: ['./applicant-signature.component.css'],
})
export class ApplicantSignatureComponent {

  @Input()
  signatureFormGroup: FormGroup;

  @Input()
  emailLabel: string;

  @Input()
  nameLabel: string;

  @Input()
  isCompany = false;

  constructor() {
  }

  get signatureName(): FormControl {
    return this.signatureFormGroup.get('signatureName') as FormControl;
  }

  get emailSignature(): FormControl {
    return this.signatureFormGroup.get('emailSignature') as FormControl;
  }

  get emailSignatureErrorMessage(): string {
    return this.emailSignature.hasError('required') ? 'Email Signature is required.' :
      this.emailSignature.hasError('pattern') ? 'Not a valid email.' :
        this.emailSignature.hasError('valueMatch') ? 'Email Signature must match Applicant Email' : '';
  }

  get companyEmailSignature(): FormControl {
    return this.signatureFormGroup.get('companyEmailSignature') as FormControl;
  }

  get companyEmailSignatureErrorMessage(): string {
    return this.companyEmailSignature.hasError('required') ? 'Company Signature is required.' :
      this.companyEmailSignature.hasError('pattern') ? 'Not a valid email.' :
        this.companyEmailSignature.hasError('valueMatch') ? 'Email Signature must match Company Email' : '';
  }


  get emailSignatureLabel() {
    return this.emailLabel ? this.emailLabel : 'Applicant Email';
  }

  get signatureNameLabel() {
    return this.nameLabel ? this.nameLabel : 'Applicant Name';
  }

}
