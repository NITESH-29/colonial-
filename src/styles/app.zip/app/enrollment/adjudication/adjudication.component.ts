import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicationService } from '../application/application.service';
import { Observable, Subscription } from 'rxjs';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { CheckboxValidator } from '../../common/validators/checkbox-validator';
import { SecurityService } from '../../security/security.service';
import { FileUploadConfig } from '../../common/file-upload/file-upload-config';
import { AdjudicationService } from './adjudication.service';
import { AdjudicationControl } from './adjudication-control';
import { PaymentMethod } from '../application/court/model/common/payment-method';
import { PaymentChannelCode } from '../../common/payment-method-selection/payment_channel_code';
import { PaymentMethodSelectionService } from '../../common/payment-method-selection/payment-method-selection.service';
import 'rxjs/add/operator/withLatestFrom';
import 'rxjs/add/operator/combineLatest';
import { AdjudicationPacket } from './adjudication-packet';
import { AdjudicationFile } from './adjudication-file';
import { FileType, FileTypeImpl } from './file-type';
import { ApplicationImpl } from '../application/application';
import { AppealsSupersedeasCourtApplicationImpl } from '../application/court/model/appeals-supersedeas-court-application';
import { MatDialog } from '@angular/material';
import { ApplicationActionConfirmationDialogComponent } from './application-action-confirmation-dialog/application-action-confirmation-dialog.component';
import { ConfirmationDialogComponent } from '../../common/confirmation-dialog/confirmation-dialog.component';
import { ApplicationStatus } from './application-status.enum';
import { ApplicantAndPurchaser } from './applicant-and-purchaser';
import { ButtonTooltips } from './button-tooltips.enum';
import { CourtBondTypeDisplayNames } from '../application/common/bond-types';
import { AdjudicationEvent, AdjudicationEventName } from './adjudication-event';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

export enum CollateralType {
  LETTER_OF_CREDIT = 'Letter of Credit',
  WIRE_TRANSFER = 'Wire Transfer',
}
import { SendEmailDialogComponent } from '../../common/email/send-email-dialog/send-email-dialog.component';
import { FileTypes } from '../application-overview/application-overview.component';

@Component({
  selector: 'app-adjudication',
  templateUrl: './adjudication.component.html',
  styleUrls: ['./adjudication.component.scss'],
})
export class AdjudicationComponent extends AdjudicationControl implements OnInit, OnDestroy {
  private softHoldStatus = false;
  private fileVerificationStatus = false;
  private collateralStatus = false;
  private creditScoreStatus = false;
  private koqStatus = false;

  constructor(private applicationService: ApplicationService,
    private adjudicationService: AdjudicationService,
    securityService: SecurityService,
    private paymentMethodService: PaymentMethodSelectionService,
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private route: ActivatedRoute,
    private matDialog: MatDialog,
    private serviceHandler: ServiceHandler) {

    super(securityService);
  }

  get checkReceived(): FormControl {
    return this.adjudicationFormGroup.get('checkReceived') as FormControl;
  }

  get disableDecline(): boolean {
    return this.disableByStatusExceptFor(ApplicationStatus.SUBMITTED, ApplicationStatus.HOLD, ApplicationStatus.SOFT_HOLD);
  }

  get allConditionsMet() {
    const overallStatus =
      this.collateralOK() &&
      this.softHoldOK() &&
      this.koQuestionsOK() &&
      this.creditScoreOK() &&
      this.fileVerificationsOK();
    return overallStatus;
  }

  get disableApproval(): boolean {
    return this.disableNotSuitableStatus ||
      !this.allConditionsMet;
  }

  get disableApprovalReason(): string {
    if (!this.creditScoreOK()) {
      return ButtonTooltips.APPROVE_BAD_CREDIT_SCORE;
    } else if (!this.koQuestionsOK()) {
      return ButtonTooltips.APPROVE_KNOCKED_OUT;
    } else if (!this.softHoldOK()) {
      return ButtonTooltips.APPROVE_SOFT_HOLD;
    } else if (this.disableNotSuitableStatus) {
      return ButtonTooltips.APPROVE_WRONG_STATUS;
    } else if (!this.allConditionsMet) {
      return ButtonTooltips.APPROVE_NOT_VERIFIED;
    } else {
      return 'No particular reason, apparently: should not be disabled';
    }
  }

  get disableNotSuitableStatus(): boolean {
    return this.disableByStatusExceptFor(ApplicationStatus.SUBMITTED);
  }

  get paymentMethodData(): PaymentMethod {
    return this.overviewData.data.paymentMethod;
  }

  get paymentChannelCode(): PaymentChannelCode {
    return this.paymentMethodData.paymentChannelCode;
  }

  get hasCreditOrKoQs(): boolean {
    return (!!this.configuration &&
      (this.configuration.requiresCreditScore ||
        this.configuration.requiresKoQuestions));
  }
  get isStartedByAttorney(): boolean {
    return this.adjudicationPacket.isStartedByAttorney;
  }

  get creditCheckPass() {
    return this.adjudicationPacket.application.creditScoreOverride ||
      (this.adjudicationPacket.application.person.creditScore >= this.adjudicationPacket.configuration.creditScoreThreshold);
  }
  userName: string;
  formId = -1;
  paymentMethod: string;
  bondClassification: string;

  isCreditCard = false;
  configurationObservable: Observable<AdjudicationPacket>;
  adjudicationPacket: AdjudicationPacket;
  private everythingSubscription: Subscription;
  // a subscription whose sole purpose is to support cleanup of subscriptions.
  private _rootCleanupSubscription: Subscription = new Subscription();

  adjudicationFormGroup: FormGroup;
  fileUploadConfig: FileUploadConfig;
  initialized: boolean;

  allFilesVerified = false;

  @Output()
  fileUploadEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  extraProductVerifications: AdjudicationFile[];
  otherFiles: AdjudicationFile[];
  collateral: AdjudicationFile;
  applicantAndPurchaser: ApplicantAndPurchaser;
  role: string;
  public disableDeclineReason = ButtonTooltips.DECLINE_WRONG_STATUS;

  private static synthesizeNonExistentButRequiredFile() {
    const collateral = new AdjudicationFile();
    collateral.required = true;
    collateral.existingFile = false;
    return collateral;
  }

  private static collateralTypeForApplication(application: ApplicationImpl): FileType {
    if (application.productType.code !== 'supersedeas') {
      return null;
    }
    const fileType = new FileTypeImpl();
    if (application.data instanceof AppealsSupersedeasCourtApplicationImpl) {
      const asData: AppealsSupersedeasCourtApplicationImpl = application.data;
      if (asData.typeOfCollateral === CollateralType.LETTER_OF_CREDIT) {
        fileType.name = FileTypes.letterOfCreditFile;
        fileType.description = CollateralType.LETTER_OF_CREDIT;
      } else if (asData.typeOfCollateral === CollateralType.WIRE_TRANSFER) {
        fileType.name = FileTypes.wireTransferFile;
        fileType.description = CollateralType.WIRE_TRANSFER;
      } else {
        fileType.name = 'adjudicationFile';
        fileType.description = `Not sure about ${asData.typeOfCollateral}`;
      }
    } else {
      fileType.name = 'adjudicationFile';
      fileType.description = `${application.productType.code} has confused us`;
    }
    return fileType;
  }

  private static constructCollateral(packet: AdjudicationPacket): AdjudicationFile {
    if (!packet.requiresCollateral) {
      return null;
    }
    if (packet.collateralFile) {
      return packet.collateralFile;
    }
    const collateral = AdjudicationComponent.synthesizeNonExistentButRequiredFile();
    collateral.fileType = AdjudicationComponent.collateralTypeForApplication(packet.application);
    return collateral;
  }

  ngOnInit(): void {
    this.formId = this.route.snapshot.queryParams.formId;
    this.adjudicationFormGroup = new FormGroup({
    });

    if (this.formId && this.formId > -1) {
      this.applicationId = this.formId;
      // Bond application-overview gives us everything. Otherwise call getAdjudicationOverview
      this.configurationObservable = this.adjudicationService.adjudicate(this.applicationId);
      this.everythingSubscription =
        this.configurationObservable
          .subscribe((packet) => {
            this.updateFromPacket(packet);

            this.bondClassification = CourtBondTypeDisplayNames[this.overviewData.data.bondClassification];

            if (this.isCreditCard) {
              this.isCreditCard = this.paymentChannelCode.isCreditCard();
            }

            if (this.isPaperCheck) {
              this.adjudicationFormGroup.addControl('checkReceived', new FormControl(false, CheckboxValidator.requireTrue()));
            }

            this.getBadgeColorForStatus();

            this.allFilesVerified = false;
            this.initialized = true;
          });

      this.userName = this.securityService.user.person.fullName;
    }
  }

  async updateForm() {
    const updatePacket: AdjudicationPacket = await this.adjudicationService.adjudicate(this.applicationId).toPromise();
    this.updateFromPacket(updatePacket);
    this.getBadgeColorForStatus();
  }

  private updateFromPacket(packet) {
    this.adjudicationPacket = packet;
    packet.enableFileCreatorIdentification();
    this.collateral = AdjudicationComponent.constructCollateral(packet);
    this.overviewData = packet.application;
    this.configuration = packet.configuration;
    this.extraProductVerifications = packet.extraProductVerifications;
    this.otherFiles = packet.otherFiles;
    this.applicantAndPurchaser = packet.applicantAndPurchaser;
    this.role = packet.role;
  }

  ngOnDestroy() {
    this.everythingSubscription.unsubscribe();
    this._rootCleanupSubscription.unsubscribe();
  }

  async approveApplication() {
    if (this.disableApproval) {
      return;
    }
    this.matDialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Are you sure you want to approve this application?',
        acceptLabel: 'Yes',
        acceptedResult: true,
        rejectLabel: 'No',
        rejectedResult: false,
      },
    })
      .afterClosed().subscribe(async response => {
        if (response) {
          await this.adjudicationService.approve(this.overviewData.id).toPromise();
          this.setStatusAndBadgeColor(ApplicationStatus.COMPLETED);
          this.serviceHandler.handleConfirm('This application\'s status has been changed to Approved');
        }
      });

  }

  async revertApplication() {
    this.matDialog.open(ApplicationActionConfirmationDialogComponent, {
      data: {
        actionName: 'revert',
      },
    }).afterClosed().subscribe(async response => {
      if (response) {
        const reason = response.reasonText;
        const updateOnRevert = true;
        await this.adjudicationService.revertApplication(this.overviewData.id, reason);
        this.setStatusAndBadgeColor(ApplicationStatus.IN_PROGRESS);
        this.serviceHandler.handleConfirm('This application\'s status has been changed to Reverted');
        this.adjudicationService.emitUpdateNotes(updateOnRevert);
      }
    });
  }

  async closeApplication() {
    this.matDialog.open(ApplicationActionConfirmationDialogComponent, {
      data: {
        actionName: 'close',
      },
    }).afterClosed().subscribe(async response => {
      if (response) {
        await this.adjudicationService.closeApplication(this.overviewData.id, response.reasonText);
        this.setStatusAndBadgeColor(ApplicationStatus.CLOSED);
        this.serviceHandler.handleConfirm(' This application\'s status has been changed to Closed.');
      }
    });
  }

  async declineApplication() {
    if (this.disableDecline) {
      return;
    }
    this.matDialog.open(ApplicationActionConfirmationDialogComponent, {
      data: {
        actionName: 'decline',
      },
    }).afterClosed().subscribe(async response => {
      if (response) {
        const reasonText = response.reasonText;
        this.matDialog.open(SendEmailDialogComponent, {
          data: {
            emailTypeCode: 'application_declined',
            parentObjectTypeName: 'Application',
            parentObjectId: this.overviewData.id,
            customFields: {
              reasonText: response.reasonText,
            },
          },
          autoFocus: false,
        }).afterClosed().subscribe(async emailResponse => {
          if (emailResponse === 1) {
            await this.adjudicationService.declineApplication(this.overviewData.id, reasonText);
            this.setStatusAndBadgeColor(ApplicationStatus.DECLINED);
            await this.serviceHandler.handleConfirm('This application\'s status has been changed to Declined.');
            const updateOnDecline = true;
            this.adjudicationService.emitUpdateNotes(updateOnDecline);
          } else if (response === -1) {
            await this.serviceHandler.handleError('Application was not declined, please try again.');
          }
        });
      }
    });
  }

  isPaperCheck() {
    return this.paymentChannelCode.isPaperCheck();
  }

  private setStatusAndBadgeColor(newStatus: string): void {
    this.overviewData.status = newStatus;
    this.getBadgeColorForStatus();
    window.scrollTo(0, 0);
  }

  getBadgeColorForStatus() {
    switch (this.overviewData.status) {
      case ApplicationStatus.SUBMITTED:
        this.statusColor = '#99D1FA';
        break;
      case ApplicationStatus.IN_PROGRESS:
        this.statusColor = '#FAF699';
        break;
      case ApplicationStatus.COMPLETED:
        this.statusColor = '#A6FA99';
        break;
      case ApplicationStatus.DECLINED:
        this.statusColor = '#FA9999';
        break;
      case ApplicationStatus.HOLD:
      case ApplicationStatus.SOFT_HOLD:
        this.statusColor = '#FAD399';
        break;
      case ApplicationStatus.CLOSED:
        this.statusColor = '#E699FA';
        break;
    }
  }

  /**
   * This function captures events from child components and
   * updates the disabled status of the approve button and
   * also reloads notes.
   *
   * @param event
   */
  async processAdjudicationEvent(event: AdjudicationEvent) {
    switch (event.eventName) {
      case AdjudicationEventName.CREDIT_SCORE_CHECKED:
        this.creditScoreStatus = event.value;
        this.checkFactorsPreventingSubmission();
        this.updateForm();
        break;
      case AdjudicationEventName.KNOCKOUT_QUESTIONS_PASSED:
        this.koqStatus = event.value;
        this.checkFactorsPreventingSubmission();
        this.updateForm();
        break;
      case AdjudicationEventName.COLLATERAL_VERIFIED:
        this.collateralStatus = event.value;
        this.updateForm();
        break;
      case AdjudicationEventName.ONE_FILE_VERIFICATION_CHANGE:
        console.log(`Unusual: should not receive ${event} at this level`);
        this.updateForm();
        break;
      case AdjudicationEventName.FILES_VERIFIED:
        this.allFilesVerified = event.value;
        this.fileVerificationStatus = event.value;
        this.updateForm();
        break;
      case AdjudicationEventName.FILE_DELETED:
        this.allFilesVerified = event.value;
        this.fileVerificationStatus = event.value;
        this.updateForm();
        break;
      case AdjudicationEventName.FILE_UPLOADED:
        this.updateForm();
        break;
      default:
        throw new Error(`invalid event name '${event.eventName}'`);
    }
  }

  handleSoftHoldEvent(verified: boolean) {
    this.softHoldStatus = verified;
  }

  handleCreditScoreEvent(verified: boolean) {
    this.creditScoreStatus = verified;
  }

  handleKOQEvent(verified: boolean) {
    this.koqStatus = verified;
  }

  handleUploadEvent(event: boolean) {
    this.processAdjudicationEvent(
      {
        eventName: AdjudicationEventName.FILE_UPLOADED,
        value: event,
        applicationId: this.overviewData.id,
      });
  }

  private fileVerificationsOK() {
    return this.configuration.fileTypes.length === 0 || this.fileVerificationStatus;
  }

  private creditScoreOK() {
    return !this.configuration.requiresCreditScore || this.creditScoreStatus;
  }

  private koQuestionsOK() {
    return !this.configuration.requiresKoQuestions || this.koqStatus;
  }

  private softHoldOK() {
    return !this.configuration.hasSoftHoldQuestions || this.softHoldStatus;
  }

  private collateralOK() {
    return !this.configuration.requiresCollateral || this.collateralStatus;
  }

  private async checkFactorsPreventingSubmission() {
    if (this.overviewData.status === ApplicationStatus.HOLD &&
      this.creditScoreOK() &&
      this.koQuestionsOK()) {
      await this.adjudicationService.releaseHeldApplication(this.overviewData.id, null);
      this.setStatusAndBadgeColor(ApplicationStatus.IN_PROGRESS);
    }
  }
}
