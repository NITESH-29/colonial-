import { FormControl, FormGroup } from '@angular/forms';
import { BusinessInformation } from './business-information';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { CompanyModel, CompanyModelImpl } from '../models/company-model';

type IsRequiredFn = () => boolean;
export type FormGroupOptions<T> = { [P in keyof T]?: IsRequiredFn };
export type BusinessInformationFormGroupOptions = FormGroupOptions<BusinessInformation>;

const defaultBusinessInformationFormGroupOptions = {
  name: () => true,
};

export class BusinessInformationFormGroup extends FormGroup {
  constructor(opts: BusinessInformationFormGroupOptions = defaultBusinessInformationFormGroupOptions) {
    super({
      id: new FormControl(),
      name: new ConditionalRequireFormControl(null, opts.name),
    });
  }

  // noinspection JSAnnotator
  patchValue(value: Partial<CompanyModel>): void {
    super.patchValue({
      id: value.id,
      name: value.name,
    });
  }

  getRawValue(): CompanyModel {
    const companyModel: CompanyModel = new CompanyModelImpl();
    companyModel.id = this.id.value;
    companyModel.name = this.name.value;
    return companyModel;
  }

  get id(): FormControl {
    return this.get('id') as FormControl;
  }

  get name(): FormControl {
    return this.get('name') as FormControl;
  }
}
