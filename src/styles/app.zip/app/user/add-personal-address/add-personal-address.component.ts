import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AddressFormGroup } from '../../common/address/address-form-group';
import { PersonalAddressService } from './personal-address.service';
import { AddressModel } from '../../common/address/address';
import { PersonalAddress } from './personal-address';
import { CommonUtilities } from '../../common/utils/common-utilities';

@Component({
  selector: 'app-add-personal-address',
  templateUrl: './add-personal-address.component.html',
  styleUrls: ['./add-personal-address.component.css'],
})
export class AddPersonalAddressComponent implements OnInit {

  @Input()
  personId: number;

  @Output()
  addressAdded: EventEmitter<void> = new EventEmitter<void>();

  @Output()
  canceled: EventEmitter<void> = new EventEmitter<void>();

  addressFormGroup: AddressFormGroup;

  constructor(private personalAddressService: PersonalAddressService) { }

  ngOnInit() {
    this.addressFormGroup = new AddressFormGroup(() => true);
  }

  async save() {
    if (!this.addressFormGroup.valid) {
      CommonUtilities.markAllTouched(this.addressFormGroup);
      return;
    }
    const addressModel: AddressModel = this.addressFormGroup.getRawValue();
    const response: PersonalAddress = await this.personalAddressService.save(this.personId, addressModel);
    if (response) {
      this.addressAdded.emit();
    }
  }

}
