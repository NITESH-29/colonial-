import { Company, CompanyImpl } from './company';
import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableProfile } from './auditable-object';
import { PhoneNumberConverter } from './utils/phone-number-converter';
import { Address, AddressImpl } from '../enrollment/application/court/model/common/address';

export type OfficeType = 'Main' | 'Branch';

export interface CompanyOfficeSummary {
  id: number;
  agentId: number;
  name: string;
  address: Address;
  email: string;
  website: string;
  phone: string;
  fax: string;
  officeType: OfficeType;
  clientsId: number;
  company: Company;
  siccode: string;
}

@JsonObject('CompanyOfficeSummaryImpl')
export class CompanyOfficeSummaryImpl extends AuditableProfile implements CompanyOfficeSummary {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('agentId', Number, true)
  agentId: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('address', AddressImpl, true)
  address: Address = null;

  @JsonProperty('email', String, true)
  email: string = null;

  @JsonProperty('website', String, true)
  website: string = null;

  @JsonProperty('phone', PhoneNumberConverter, true)
  phone: string = null;

  @JsonProperty('fax', PhoneNumberConverter, true)
  fax: string = null;

  @JsonProperty('officeType', String)
  officeType: OfficeType = null;

  @JsonProperty('clientsId', Number, true)
  clientsId: number = null;

  @JsonProperty('company', CompanyImpl, true)
  company: Company = new CompanyImpl();

  @JsonProperty('siccode', String, true)
  siccode: string = null;
}
