import { Address } from '../../enrollment/application/court/model/common/address';
import { OfficeType } from '../../common/company-office-summary';

export interface BusinessOfficeInformation {
  name: string;
  website?: string;
  email: string;
  phone: string;
  fax?: string;
  sicCode?: string | null;
  officeType?: OfficeType;
  address: Address | null;
  title?: string;
}

export interface AgencyOfficeInformation extends BusinessOfficeInformation {
  licenseNumber: string;
}
