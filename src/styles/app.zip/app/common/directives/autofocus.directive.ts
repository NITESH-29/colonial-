import { Directive, ElementRef, Input, AfterViewInit } from '@angular/core';

@Directive({
  selector: '[appAutofocus]',
})
export class AutofocusDirective implements AfterViewInit {
  private focus = true;

  constructor(private el: ElementRef) { }

  ngAfterViewInit() {
    if (this.focus) {
      window.setTimeout(() => this.el.nativeElement.focus());
    }
  }

  @Input() set appAutofocus(condition: boolean) {
    this.focus = condition;
  }
}
