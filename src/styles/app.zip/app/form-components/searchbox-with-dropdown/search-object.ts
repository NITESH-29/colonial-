export interface SearchObject {
  controlName: string;
  labelName: string;
}
