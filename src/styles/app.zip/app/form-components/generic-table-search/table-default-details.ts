

export interface TableDefaultDetails {
  defaultStatus: string;
  bondClassification: string;
}
