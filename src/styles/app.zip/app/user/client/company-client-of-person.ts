import { JsonObject, JsonProperty } from 'json2typescript';
import { ClientData, ClientDataImpl } from './client-data';

/**
 * This is the shape of the response returned from the `/client/{personId}/company-of-client` rest endpoint.
 * It is not intended to be used to post to the server.
 */
export interface CompanyClientOfPerson {
  personId: number;
  companyClient: ClientData;
}

@JsonObject('CompanyClientOfPersonImpl')
export class CompanyClientOfPersonImpl implements CompanyClientOfPerson {
  @JsonProperty('personId', Number, true)
  personId: number = null;

  @JsonProperty('companyClient', ClientDataImpl, true)
  companyClient: ClientData = null;
}
