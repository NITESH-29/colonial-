import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SecurityService } from '../../security/security.service';
import { PersonBusinessService } from '../providers/person-business.service';
import { Router } from '@angular/router';
import { CompanyModel } from '../models/company-model';
import { CompanyAndOfficeInformationFormGroup } from '../company-and-office-information/company-and-office-information-form-group';
import { CompanyOfficePersonModelImpl } from '../models/company-office-person-model';
import { CompanyOfficeModelImpl } from '../models/company-office-model';
import { Location } from '@angular/common';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { AccountService } from '../account.service';

type ActionType = 'Add' | 'Edit';

@Component({
  selector: 'app-company-with-single-office',
  templateUrl: './company-with-single-office.component.html',
})
export class CompanyWithSingleOfficeComponent implements OnInit {
  @Input() company: CompanyModel;
  @Output() companySaved = new EventEmitter<CompanyModel>();

  formGroup: CompanyAndOfficeInformationFormGroup;

  action: ActionType;
  clientsId = null;
  clicked = false;
  helpText: string;
  constructor(
    private securityService: SecurityService,
    private personBusinessService: PersonBusinessService,
    private router: Router,
    private location: Location,
    private accountService: AccountService
  ) {
    this.companySaved = new EventEmitter<CompanyModel>(true);
  }

  ngOnInit(): void {
    this.formGroup = new CompanyAndOfficeInformationFormGroup();

    if (this.company.id) {
      this.clientsId = this.company.companyOffices.length > 0 ? this.company.companyOffices[0].clientsId : null;
      this.action = 'Edit';
      const { id, name, companyOffices: [companyOffice] } = this.company;
      const { website, phone, fax, email, sicCode, address, companyOfficePersons: [{ title }] } = companyOffice;

      this.formGroup.patchValue(
        { id, name, title, website, email, phone, fax, sicCode, address }
      );
      this.formGroup.get('name').disable();
      this.formGroup.get('email').disable();
      this.helpText = `Please call our Customer Service team to edit your company name.`;
    } else {
      this.action = 'Add';
    }
    this.formGroup.valueChanges.subscribe((value) => {
      if (value.email) {
        if (this.securityService.user && (this.securityService.user.person.email !== value.email)) {
          this.formGroup.get('email').setAsyncValidators(
            this.accountService.getEmailAvailabilityAsyncValidator()
          );
        } else {
          this.formGroup.get('email').clearAsyncValidators();
        }
      }
    });
  }

  async save(): Promise<void> {
    if (this.formGroup.valid) {
      const {
        name, title, website, email, phone, fax, sicCode, address,
      } = this.formGroup.getRawValue();

      let { companyOffices: [companyOffice] } = this.company;

      let companyOfficePerson;

      if (companyOffice) {
        companyOffice.agentId = this.securityService.user ? this.securityService.user.person.agentId : null;
        companyOffice.clientsId = this.clientsId;
        companyOfficePerson = companyOffice.companyOfficePersons.shift();
      } else {
        companyOffice = new CompanyOfficeModelImpl();
        companyOffice.agentId = this.securityService.user ? this.securityService.user.person.agentId : null;
        companyOffice.clientsId = this.clientsId;
        companyOffice.officeType = 'Main';

        companyOfficePerson = new CompanyOfficePersonModelImpl();
        companyOfficePerson.responsiblePerson = true;
      }

      companyOfficePerson.title = title;
      const updatedCompanyOffice = Object.assign(companyOffice,
        { name, address, email, website, phone, fax, sicCode, companyOfficePersons: [companyOfficePerson] }
      );

      this.company = Object.assign(this.company, {
        ...{ name, companyOffices: [updatedCompanyOffice] },
      });

      const personId = this.securityService.user.person.id;
      const savedAgency = await (this.company.id
        ? this.personBusinessService.updateCompany(this.company, personId)
        : this.personBusinessService.createCompany(this.company, personId));
      this.companySaved.emit(savedAgency);
    } else {
      CommonUtilities.markAllTouched(this.formGroup);
    }
  }

  goBack(): void {
    this.location.back();
  }
}
