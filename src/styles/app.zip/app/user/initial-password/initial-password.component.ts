import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { SecurityService } from '../../security/security.service';
import { ValueMatchValidator } from '../../common/validators/value-match-validator';
import { Validators } from '@angular/forms';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/pairwise';
import { AccountService } from '../account.service';
import { InputValidators } from '../../form-components/validators/input-validators';
import { PatternValidators } from '../../common/validators/pattern-validators';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';


@Component({
  selector: 'app-initial-password',
  templateUrl: './initial-password.component.html',
  styleUrls: ['./initial-password.component.css'],
})

export class InitialPasswordComponent implements OnInit {
  initialPasswordForm: FormGroup;
  token: string;
  applicationId: string;
  bondType: string;
  redirectUrl: string;
  // attoryFlowBondType = GlobalConstants.ATTORNEY_FLOW_BOND_TYPE_IBOND;
  attoryFlowBondType = GlobalConstants.IBOND_CODE_ARRAY;

  constructor(public fb: FormBuilder,
    private accountService: AccountService,
    private router: Router,
    private snackbar: MatSnackBar,
    private securityService: SecurityService,
    private activatedRoute: ActivatedRoute,
    private serviceHandler: ServiceHandler) {
  }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe((route: Params) => {
      this.token = route['token'];

      this.activatedRoute.params.subscribe((thisRoute: Params) => {
        this.applicationId = thisRoute['id'];
        this.bondType = thisRoute['bondType'];
        // Check bond type is of Ibond or not.
        const isIbondFlow = this.attoryFlowBondType.indexOf(this.bondType) > -1;
        const isInsuranceProduct = GlobalConstants.INSURANCE_CODE_ARRAY.indexOf(this.bondType) > -1;
        if (isIbondFlow) {
          this.redirectUrl = `/ibond/application/${this.bondType}/${this.applicationId}`;
        } else if (isInsuranceProduct) {
          this.redirectUrl = `/insurance/evaluator?applicationId=${this.applicationId}`;
        } else {
          this.redirectUrl = `/enrollment/application/${this.bondType}/${this.applicationId}`;
        }

        this.initialPasswordForm = this.fb.group(
          {
            username: ['', [Validators.required, InputValidators.noSpaces, Validators.maxLength(50)]],
            password: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(62), PatternValidators.alphanumeric()]],
            passwordConfirm: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(62)]],
          },
          {
            validator: [ValueMatchValidator.matchingValues('password', 'passwordConfirm')],
          }
        );

        this.initialPasswordForm.get('username').setAsyncValidators(
          this.accountService.getUsernameAvailabilityAsyncValidator()
        );
      });
    });
  }

  saveInitialPassword() {
    if (this.initialPasswordForm.valid) {
      const { username, password, passwordConfirm } = this.initialPasswordForm.value;
      this.securityService.setInitialPassword(this.token, username, password, this.applicationId)
        .subscribe(() => {
          this.snackbar.open('User created.', null, {
            duration: 6000,
            panelClass: ['confirmation_snack_bar'],
          });
          this.securityService
            .login(username, password)
            .then(() => this.router.navigateByUrl(`${this.redirectUrl}`));
          this.initialPasswordForm.reset();
        }, (httpClientError: any) => {
          this.serviceHandler.showErrorMessage(`${httpClientError.error.message}`);
        }
        );
    } else {
      CommonUtilities.markAllTouched(this.initialPasswordForm);
    }
  }

  get username(): FormControl {
    return this.initialPasswordForm.get('username') as FormControl;
  }

  get password(): FormControl {
    return this.initialPasswordForm.get('password') as FormControl;
  }

  get passwordConfirm(): FormControl {
    return this.initialPasswordForm.get('passwordConfirm') as FormControl;
  }

  get displayPasswordLengthError(): boolean {
    return (this.password.hasError('minlength') || this.password.hasError('maxlength'))
      || (this.password.touched && this.password.value === '');
  }

  get displayAlphanumericError(): boolean {
    return (this.password.touched && this.password.hasError('pattern')) || (this.password.touched && this.password.value === '');
  }

  clearConfirmPassword() {
    this.initialPasswordForm.get('passwordConfirm').setValue('');
  }

  // Conditions driving dynamic styles in template
  get validLengthCondition(): boolean {
    return !this.displayPasswordLengthError && this.password.touched;
  }

  get validPatternCondition(): boolean {
    return !this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }

  get invalidLengthCondition(): boolean {
    return this.displayPasswordLengthError && this.password.touched;
  }

  get invalidPatternCondition(): boolean {
    return (this.displayAlphanumericError && this.password.touched) ||
      (this.password.touched && this.password.value === '');
  }
}
