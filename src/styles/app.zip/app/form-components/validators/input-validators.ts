import { AbstractControl, ValidationErrors } from '@angular/forms';

export class InputValidators {
  /**
   * We have this functionality elsewhere, but the issue was that a form group validator, we don't need to check anything other than
   * one field at a time.  Created it how it should be here, but left the other one since I figured other things depend on it.  This can
   * be used just like Validators.required, in that you don't need to include parenthesis
   *
   * @param control
   */
  static noSpaces(control: AbstractControl): ValidationErrors | null {
    return control.value !== null && typeof control.value === 'string' && control.value.includes(' ') ? { 'space': true } : null;
  }
}
