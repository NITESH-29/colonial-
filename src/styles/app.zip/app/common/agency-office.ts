import { AuditableProfile } from './auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';
import { Agency } from './agency';
import { AddressImpl, AddressModel } from './address/address';

export interface AgencyOffice {
  id: number;
  agencyId: number;
  name: string;
  referralCode: string;
  address: AddressModel;
  agency: Agency;
}

@JsonObject('AgencyOffice')
export class AgencyOffice extends AuditableProfile implements AgencyOffice {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('agencyId', Number, true)
  agencyId: number;

  @JsonProperty('name', String, true)
  name: string;

  @JsonProperty('referralCode', String, true)
  referralCode: string;

  @JsonProperty('referralCode', AddressImpl, true)
  address: AddressModel = new AddressImpl();

  @JsonProperty('agency', Agency, true)
  agency: Agency = null;
}
