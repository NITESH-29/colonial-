import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { IbondBaseService } from '../service/ibond-base.service';
import { Product } from '../../product/product';
import { ProductDocument } from '../../product/product-documents/product-document';
import { ProductService } from '../../product/products.service';
import { AppConfigService } from '../../app-config-service';

@Component({
  selector: 'app-product-overview',
  templateUrl: './product-overview.component.html',
  styleUrls: ['./product-overview.component.scss'],
})
export class ProductOverviewComponent implements OnInit {
  loader = false;
  imgPDF = 'assets/icons/pdf.svg';
  imgDownload = 'assets/icons/download.svg';
  imgPrint = 'assets/icons/print.svg';
  applicationData: any;
  heading = '';
  secondaryHeading = '';
  subheading = '';
  applicationId: number;
  productData: object;
  headingName = '';
  bondDescription = '';
  bondType: string;
  pdfDocData = [];
  applicationStatus = '';
  headingIcon = 'assets/icons/tick.svg';
  bondInsuredByCompany = ['employee_dishonesty', 'janitorial'];
  @Input()
  product: Product;
  productNo: number;
  productDocuments: ProductDocument[] = [];
  colonialPhoneNumber: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private lpService: IbondBaseService,
    private productService: ProductService,
    public router: Router,
    appConfigService: AppConfigService) {
    appConfigService.getConfig().subscribe(config => this.colonialPhoneNumber = config.colonialPhoneNumber);
  }

  ngOnInit() {
    this.productNo = this.activatedRoute.snapshot.queryParams['formId'];
    this.getproductDetails(this.productNo);
    // this.getApplicationDetailsById();
  }

  getApplicationDetailsById() {
    this.loader = true;
    this.lpService.getApplicationDetailsById(this.applicationId).subscribe((data: any[]) => {
      this.applicationData = data;
      if (this.applicationData['status'] === 'Completed') {
        this.headingName = this.applicationData['data']['applicantName'];
        this.bondType = this.applicationData['data']['bondClassification'];
        this.bondDescription = this.applicationData['data'].bondDescription;
      } else {
        this.loader = false;
      }
      this.loader = false;
    });
  }
  getproductDetails(id) {
    this.lpService.getProductDetailsById(id).subscribe((data: any[]) => {
      this.productData = data;
      this.applicationStatus = this.productData['status'];
      this.applicationId = this.productData['applicationId'];
      this.getApplicationDetailsById();
      this.getProductDocuments(this.productNo);
      this.loader = false;
    });
  }
  getProductDocuments(productId) {
    this.productService.getProductDocuments(productId).subscribe((data: any[]) => {
      if (this.applicationData && this.applicationData['data'].specialBondForm) {
        this.pdfDocData = data;
      } else {
        this.pdfDocData = data.filter(val => val.fileTypeName !== 'specialBondFile');
      }
      this.pdfDocData.forEach(item => {
        item.name = item.name.replace(/_/g, '-');
      });
      this.loader = false;
    });
  }

  returnHome() {
    this.router.navigate(['/dashboard']);
  }
  getTotalPlanAmount() {
    const selectDeliveryMethod = this.applicationData['data'].deliveryMethod.deliveryMethod;
    const deliveryMethodFees = ['FedEx', 'UPS'];
    if (deliveryMethodFees.indexOf(selectDeliveryMethod) > -1) {
      return this.applicationData['data'].applicationPaymentPlan.totalPlanAmount;
    } else {
      return this.applicationData['premium'];
    }
  }

  getDeliveryFeesAmount() {
    const selectDeliveryMethod = this.applicationData['data'].deliveryMethod.deliveryMethod;
    const deliveryMethodFees = ['FedEx', 'UPS'];
    if (deliveryMethodFees.indexOf(selectDeliveryMethod) > -1) {
      return this.applicationData['data'].applicationPaymentPlan.paymentPlanLines['0'].amount;
    } else {
      return 0;
    }
  }
  getInsuredName() {
    // if (this.bondInsuredByCompany.indexOf(this.bondType) !== -1) {
    //   return this.applicationData['data']['businessDetails'].ownerName;
    // } else {
    return this.applicationData['data'].applicantName;
    // }
  }

  getAddressDetails(fieldName) {
    // if (this.bondInsuredByCompany.indexOf(this.bondType) !== -1) {
    //   if (fieldName === 'street2' && this.applicationData['data']['businessDetails'].ownerAddress.street2) {
    //     return ', ' + this.applicationData['data']['businessDetails'].ownerAddress.street2;
    //   }
    //   return this.applicationData['data']['businessDetails'].ownerAddress[fieldName];
    // } else {
    if (fieldName === 'street2' && this.applicationData['data'].applicantAddress.street2) {
      return ', ' + this.applicationData['data'].applicantAddress.street2;
    }
    return this.applicationData['data'].applicantAddress[fieldName];
    // }
  }

  getImageName(fileName) {
    const fileType = fileName.split('.').reverse()[0];
    if (fileType === 'pdf' || fileType === 'PDF') {
      return 'assets/icons/pdf.svg';
    } else if (fileType === 'doc' || fileType === 'docx') {
      return 'assets/icons/doc.png';
    } else if (fileType === 'png' || fileType === 'PNG') {
      return 'assets/icons/img.png';
    } else if (fileType === 'jpeg' || fileType === 'JPEG') {
      return 'assets/icons/img.png';
    } else if (fileType === 'jpg' || fileType === 'JPG') {
      return 'assets/icons/img.png';
    } else {
      return 'assets/icons/doc.png';
    }
  }
}
