import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from './common/not-found/not-found.component';
import { AuthGuard } from './security/app.auth.guard';

const appRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // Dashboard
  { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
  { path: 'ibond', loadChildren: './ibond/ibond.module#IbondModule', data: { newlayout: 'ibond' } },
  { path: 'insurance', loadChildren: './insurance/insurance.module#InsuranceModule', data: { newlayout: 'insurance' } },
  { path: 'enrollment', loadChildren: './enrollment/enrollment.module#EnrollmentModule' },
  { path: 'product', loadChildren: './product/product.module#ProductModule' },
  { path: 'billing', loadChildren: './billing/billing.module#BillingModule' },
  { path: 'secure', loadChildren: './security/security.module#SecurityModule' },
  { path: 'com', loadChildren: './common/common-components.module#CommonComponentsModule' },
  { path: 'user', loadChildren: './user/user.module#UserModule' },
  { path: 'special-form', loadChildren: './special-form/special-form.module#SpecialFormModule', canActivate: [AuthGuard] },
  // load PageNotFound here, or redirect to home
  { path: '**', component: NotFoundComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      {
        enableTracing: false,
        scrollPositionRestoration: 'enabled',
      }
    ),
  ],
  exports: [
    RouterModule,
  ],
})
export class AppRoutingModule { }
