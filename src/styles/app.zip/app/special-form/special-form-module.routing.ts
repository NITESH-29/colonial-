import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { ValidatePDFComponent } from './validate-pdf/validate-pdf.component';
import { GeneratePDFComponent } from './generate-pdf/generate-pdf.component';
import { ManagePDFComponent } from './manage-pdf/manage-pdf.component';
import { SpecialFormComponent } from './special-form.component';
import { AuthGuard } from '../security/app.auth.guard';
import { EmployeeDefaultGuard } from '../user/role-guard/employee-default.guard';

const routes: Routes = [
  {
    path: '',
    component: SpecialFormComponent,
    children: [
      { path: '', redirectTo: 'generate-pdf', pathMatch: 'full' },
      { path: 'generate-pdf', component: ValidatePDFComponent, canActivate: [EmployeeDefaultGuard] },
      { path: 'manage-pdf', component: ManagePDFComponent, canActivate: [EmployeeDefaultGuard] },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SpecialFormModuleRouting { }
