import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../common/utils/date-converter';

export interface UserRoleRef {
  id: number;
  role: string;
  authority: string;
  createdBy: string;
  createdAt: Date;
  updatedBy: string;
  updatedAt: Date;
}

@JsonObject('UserRoleRefImpl')
export class UserRoleRefImpl implements UserRoleRef {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('role', String, true)
  role: string = null;

  @JsonProperty('authority', String, true)
  authority: string = null;

  @JsonProperty('createdBy', String, true)
  createdBy: string = null;

  @JsonProperty('createdAt', DateConverter, true)
  createdAt: Date = null;

  @JsonProperty('updatedBy', String, true)
  updatedBy: string = null;

  @JsonProperty('updatedAt', DateConverter, true)
  updatedAt: Date = null;
}
