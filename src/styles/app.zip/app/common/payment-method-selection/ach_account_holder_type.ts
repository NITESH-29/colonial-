/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('AchAccountHolderType')
export class AchAccountHolderType extends AbstractIdentifierEnum {
  private static _values: Map<string, AchAccountHolderType> = new Map<string, AchAccountHolderType>();
  public static BUSINESS = new AchAccountHolderType('business', 'Business');
  public static PERSONAL = new AchAccountHolderType('personal', 'Personal');

  // We don't register defaultDisplayText with JSON->TypeScript lib as we don't need the server's value.
  get defaultDisplayText(): string {
    return this._defaultDisplayText;
  }

  /**
   * Constructing an AbstractIdentifierEnum registers it in the static set of enum instances.
   * @param persistenceId
   * @param _defaultDisplayText
   */
  private constructor(
    persistenceId: string, // Relates the enum with the server enum representation.
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): AchAccountHolderType {
    return AchAccountHolderType._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): AchAccountHolderType[] {
    return Array.from(AchAccountHolderType._values.values());
  }

  public isBusinessAccount(): boolean {
    return this === AchAccountHolderType.BUSINESS;
  }

  protected registerEnum(): void {
    if (AchAccountHolderType._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid AchAccountHolderType 'enum' identifier: ${this.persistenceId}`);
    }
    AchAccountHolderType._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class AchAccountHolderTypeConverter extends AbstractIdentifierEnumConverter<AchAccountHolderType> {
  deserialize(enumObject: any): AchAccountHolderType {
    let enumInstance: AchAccountHolderType;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = AchAccountHolderType.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}
