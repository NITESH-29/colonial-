import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductRoutingModule } from './product-routing.module';
import { BondAndPoliciesListComponent } from './bond-and-policies-list/bond-and-policies-list.component';
import { ProductDocumentsComponent } from './product-documents/product-documents.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { ProductPaymentComponent } from './product-payment/product-payment.component';
import { ProductRelatedComponent } from './product-related/product-related.component';
import { ProductRenewalComponent } from './product-renewal/product-renewal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonComponentsModule } from '../common/common-components.module';
import { FormComponentsModule } from '../form-components/form-components.module';
import { UserModule } from '../user/user.module';
import {
  CalendarModule,
  CheckboxModule,
  DataListModule,
  EditorModule,
  PaginatorModule,
  TabViewModule
} from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { ColonialTableModule } from '../colonial-table/colonial-table.module';
import { MaterialModule } from './../material.module';
import { ProductMaintenanceComponent } from './product-maintenance/product-maintenance.component';
import { ApplicationOverviewComponent } from './product-maintenance/application-overview/application-overview.component';
import { RefundAmountDialogComponent } from './product-maintenance/refund-amount-dialog/refund-amount-dialog.component';
import { ProductMaintenanceRightPanelComponent } from './product-maintenance/product-maintenance-right-panel/product-maintenance-right-panel.component';

import { ProductEditComponent } from './product-maintenance/product-edit/product-edit.component';
import { UpdateClientProfileComponent } from './product-maintenance/update-client-profile/update-client-profile.component';

@NgModule({
  imports: [
    CommonModule,
    ProductRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    CommonComponentsModule,
    FormComponentsModule,
    UserModule,
    ColonialTableModule,

    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    TableModule,
    PaginatorModule,
    TabViewModule,
    EditorModule,

    // Material Stuff
    MaterialModule,
  ],
  declarations: [
    BondAndPoliciesListComponent,
    ProductDocumentsComponent,
    ProductListComponent,
    ProductOverviewComponent,
    ProductPaymentComponent,
    ProductRelatedComponent,
    ProductRenewalComponent,
    ProductMaintenanceComponent,
    ApplicationOverviewComponent,
    RefundAmountDialogComponent,
    ProductMaintenanceRightPanelComponent,
    ProductEditComponent,
    UpdateClientProfileComponent,
  ],
  exports: [
    ProductListComponent,
  ],
  entryComponents: [RefundAmountDialogComponent],
})
export class ProductModule { }
