import { Component, EventEmitter, Input, Output } from '@angular/core';
import { SecurityService } from 'src/app/security/security.service';
import { ClientData } from '../../user/client/client-data';

@Component({
  selector: 'app-select-applicant',
  templateUrl: './select-applicant.component.html',
  styleUrls: ['./select-applicant.component.css'],
})
export class SelectApplicantComponent {

  @Input()
  clients?: Array<ClientData>;

  @Input()
  returnUrl: string;

  @Input()
  onlyPersons: boolean;

  @Input()
  onlyCompanyOffices: boolean;

  @Output()
  clientSelected: EventEmitter<ClientData> = new EventEmitter<ClientData>();

  @Output()
  addNewClientRequested: EventEmitter<void> = new EventEmitter<void>();

  constructor(
    private securityService: SecurityService
  ) { }

  selectClient(client: ClientData) {
    this.clientSelected.emit(client);
  }

  addNewClient() {
    this.addNewClientRequested.emit();
  }

  get displayMessage() {
    return (this.securityService.user.hasAttorneyRole || this.securityService.user.hasAgentRole) ?
      'Please select / Add your client' : 'Please select yourself or your company to start the purchase';
  }

}
