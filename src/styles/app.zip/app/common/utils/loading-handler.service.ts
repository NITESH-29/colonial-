import { Injectable } from '@angular/core';

@Injectable()
export class LoadingHandlerService {

  static loading = false;

  constructor() {
  }

  showLoader() {
    LoadingHandlerService.loading = true;
    document.body.style.cursor = 'wait';
  }

  hideLoader() {
    setTimeout(() => {
      LoadingHandlerService.loading = false;
      document.body.style.cursor = 'default';
    }, 400);
  }
}
