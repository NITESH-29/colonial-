import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from './utils/date-converter';
import { Profile, Profiles } from './profile';

export interface Auditable {
  createdBy: string;
  createdAt: Date;
  updatedBy: string;
  updatedAt: Date;
}

@JsonObject('AuditableObject')
export class AuditableObject implements Auditable {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('createdBy', String, true)
  createdBy: string = null;

  @JsonProperty('createdAt', DateConverter, true)
  createdAt: Date = null;

  @JsonProperty('updatedBy', String, true)
  updatedBy: string = null;

  @JsonProperty('updatedAt', DateConverter, true)
  updatedAt: Date = null;
}

@JsonObject('AuditableProfile')
export class AuditableProfile extends AuditableObject implements Profile {
  @JsonProperty('fromDate', DateConverter, true)
  fromDate: Date = null;

  @JsonProperty('toDate', DateConverter, true)
  toDate: Date = null;

  isOverlap(profile: Profile): boolean {
    return Profiles.isOverlap(this, profile);
  }
}
