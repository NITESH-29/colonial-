import { Directive, ElementRef, HostListener } from '@angular/core';

const keys = ['Backspace', 'Delete', 'ArrowRight', 'ArrowLeft', '/', '-', '.'];

@Directive({
  selector: '[appCalendarMask]',
})

export class CalendarMaskDirective {

  keyPressed: string;

  constructor(private element: ElementRef) {
  }

  @HostListener('input')
  public onChange(): void {
    this.applyMask(this.getValue());
  }

  @HostListener('keypress', ['$event'])
  public onKeyPress(event): void {
    this.keyPressed = event.key;

    if (!Number.isInteger(parseInt(event.key, 10)) && keys.indexOf(event.key) === -1) {
      event.stopPropagation();
    }
  }

  private applyMask(value): void {
    // replace all '-' and '.' with '/'
    this.setValue(this.getValue().replace(/[-|.]/gi, '/'));
  }

  private getValue(): string {
    return this.element.nativeElement.getElementsByTagName('input')[0].value.trim();
  }

  private setValue(value: string): void {
    this.element.nativeElement.getElementsByTagName('input')[0].value = value.trim();
  }
}
