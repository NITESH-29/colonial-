import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { ServiceHandler } from './service-handler.service';


@Injectable()
export class FileService {
  requestURL = 'api/court/application';

  constructor(private http: HttpClient, private serviceHandler: ServiceHandler) {
  }

  upload(file, applicationId, filePrefix): Observable<any> {
    const url = `${this.requestURL}/file/${filePrefix}`;

    const headers = new HttpHeaders().append('Accept', 'application/json');

    const formData: FormData = new FormData();
    formData.append('file', file);

    return this.http.post(url, formData, { headers: headers })
      .map((res) => {
        this.serviceHandler.handleConfirm('Upload Successful!');
        return res;
      })
      .catch((error) => this.serviceHandler.handleError(error));

  }

  deleteFile(applicationId, filePrefix): Observable<any> {
    const url = `${this.requestURL}/${applicationId}/file/${filePrefix}`;

    return this.http.delete(url)
      .map((res) => {
        if (res === true) {
          this.serviceHandler.handleConfirm('File deleted');
        }
      })
      .catch((error) => this.serviceHandler.handleError(error));
  }
}
