import { Component, Input } from '@angular/core';
import { BasicInputFormFieldComponent } from '../input-form-fields/basic/basic-input-form-field.component';

@Component({
  selector: 'app-complex-select-form-field',
  templateUrl: './complex-select-form-field.component.html',
})
export class ComplexSelectFormFieldComponent<T> extends BasicInputFormFieldComponent {
  @Input()
  list: T[];

  @Input()
  value: (x: T) => string;

  @Input()
  display: (x: T) => string;

  constructor() { super(); }
}
