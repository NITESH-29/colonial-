import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API_URL } from '../constant/i-bond-constant';
import { BehaviorSubject } from 'rxjs';
import { ISignUpIndividual, ISignUpCompany } from '../sign-up/sign-up';
import { FormGroup } from '@angular/forms';
@Injectable({
  providedIn: 'root',
})
export class IbondBaseService {
  private dataSource = new BehaviorSubject<any>({});
  private dataApplicant = new BehaviorSubject<any>({});
  private summaryClickEvent = new BehaviorSubject<any>({});
  public showSignup = new BehaviorSubject<boolean>(false);
  public paymentErrorMessage = new BehaviorSubject<any>({});

  constructor(
    private httpClient: HttpClient
  ) { }

  getFormData() {
    return this.dataSource.asObservable();
  }

  setFormData(data) {
    this.dataSource.next(data);
  }

  getSignUpValue() {
    return this.showSignup.asObservable();
  }

  setSignUpValue(value) {
    this.showSignup.next(value);
  }

  summaryEditClickEvent(data) {
    this.summaryClickEvent.next(data);
  }

  listenEditEvent() {
    return this.summaryClickEvent.asObservable();
  }
  async saveAndContinueApplication(request_obj, applicationId, performTermsandConditionValidation) {
    // const REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/save-for-later/';
    // const REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/';
    let REQUEST_URL = '';
    // if (request_obj.data['paymentMethod']) {
    //   REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/' + applicationId + '?processPaymentMethod=true';
    // } else {
    //   REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/' + applicationId;
    // }
    if (performTermsandConditionValidation) {
      REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/' + applicationId +
        '?performTermsandConditionValidation=true';
    } else {
      REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/' + applicationId +
        '?performTermsandConditionValidation=false';
    }

    return await this.httpClient.put(REQUEST_URL, request_obj).toPromise();
  }
  getZipCode(zipCode) {
    return this.httpClient.get(API_URL.LNP_GET_ZIP_CODE + zipCode);
  }
  getApplicationDetailsById(id) {
    return this.httpClient.get(API_URL.GET_APPLICATION_BY_ID + id);
  }
  saveAndApply(applicationId, request_obj) {
    const REQUEST_URL = 'api/application/submit/' + request_obj.data['bondClassification'] + '/';
    return this.httpClient.put(REQUEST_URL + applicationId, request_obj);
  }
  getPaymentdetails(id) {
    return this.httpClient.get(API_URL.GET_PAYMENT_METHOD + '/' + id);
  }
  async getSavedBillingProfile(id) {
    return await this.httpClient.get(API_URL.GET_SAVED_BILLING_PROFILE
      + '/' + id + '?validFilterValue=true&deactivatedFilterValue=false').toPromise();
  }
  getProductDetailsById(id) {
    return this.httpClient.get(API_URL.GET_PRODUCT_BY_ID + id);
  }
  async uploadFile(reqBody) {
    // tslint:disable-next-line:radix
    reqBody.parentObjectId = reqBody.parentObjectId ? parseInt(reqBody.parentObjectId) : null;
    const response = await this.httpClient.post(API_URL.UPLOAD_FILE, reqBody);
    return response.toPromise();
  }
  getBusinessType() {
    return this.httpClient.get(API_URL.EMP_DIS_BOND_TYPE);
  }
  saveForLater(request_obj, applicationId) {
    const REQUEST_URL = 'api/application/' + request_obj.data['bondClassification'] + '/save-for-later/';
    return this.httpClient.put(REQUEST_URL + applicationId, request_obj);
  }
  getLostInstrumentType() {
    return this.httpClient.get(API_URL.GET_LOST_INSTRUMENT_TYPE);
  }

  getApplicantInfo() {
    return this.dataApplicant.asObservable();
  }

  setApplicantInfo(data) {
    this.dataApplicant.next(data);
  }

  signUpStandardUser(request_obj: ISignUpIndividual | ISignUpCompany) {
    return this.httpClient.post(API_URL.SIGNUP, request_obj);
  }
  // signCompany(request_obj: ISignUpIndividual | ISignUpCompany) {
  //   return this.httpClient.post(API_URL.SIGNUP, request_obj);
  // }
  signUpAttorney(request_obj) {
    return this.httpClient.post(API_URL.SIGNUPATTORNEY, request_obj);
  }

  getClientDetailsForAttorney(client_id, client_type) {
    const url = (client_type === 'Person') ? API_URL.GET_PERSON_DETAIL + client_id :
      API_URL.GET_COMPANY_DETAIL + client_id + '/responsible-person';
    return this.httpClient.get(url);
  }

  deserializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3') : phoneNumber;
  }

  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  getSendToClientEmail(applicationId) {
    const url = API_URL.GET_SEND_TO_CLIENT_EMAIL + applicationId;
    return this.httpClient.get(url);
  }

  sendMailToClient(applicationId) {
    const url = API_URL.SEND_MAIL_TO_CLIENT + applicationId;
    return this.httpClient.put(url, { optionalMessage: '' });
  }
  scrollTo(el: Element): void {
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }

  scrollToError(): void {
    const firstElementWithError = document.querySelector('.ng-invalid');
    this.scrollTo(firstElementWithError);
  }

  async scrollIfFormHasErrors(form: FormGroup): Promise<any> {
    await form.invalid;
    this.scrollToError();
  }

  async checkAlreadyExistCard(requestObject) {
    return await this.httpClient.post(API_URL.CARD_AVAILABILITY, requestObject).toPromise();
  }

  getProductTypesByLob() {
    const URL = API_URL.PRODUCT_TYPES_BY_LOB + '2';
    return this.httpClient.get(URL);
  }

  getActivePaymentMethod(date) {
    const url = API_URL.GET_ALL_ACTIVE_PAYMENT_METHODS + date;
    return this.httpClient.get(url);
  }

  addCard(requestBody) {
    return this.httpClient.post(API_URL.ADD_CARD, requestBody);
  }

  async getSavedCardList(personId) {
    const url = API_URL.GET_SAVED_BILLING_PROFILE + '/' + personId + '?deactivatedFilterValue=false';
    return await this.httpClient.get(url).toPromise();
  }

  getCardDetailsById(cardId) {
    return this.httpClient.get(API_URL.GET_CARD_DETAILS_BY_ID + cardId);
  }

  updateCard(requestBody, cardId) {
    const url = API_URL.ADD_CARD + '/' + cardId;
    return this.httpClient.put(url, requestBody);
  }

  makeCardAsDefault(requestBody, cardId) {
    const url = API_URL.MAKE_CARD_DEFAULT + cardId;
    return this.httpClient.put(url, requestBody);
  }

  deleteCard(requestBody, cardId) {
    const url = API_URL.DELETE_CARD + cardId;
    return this.httpClient.put(url, requestBody);
  }
}
