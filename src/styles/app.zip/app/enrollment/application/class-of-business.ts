import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../../common/auditable-object';

export interface ClassOfBusiness {
  id: number;
  name: string;
  hazardClass: string;
}

@JsonObject('ClassOfBusinessImpl')
export class ClassOfBusinessImpl extends AuditableObject implements ClassOfBusiness {
  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('hazardClass', String, true)
  hazardClass: string = null;
}
