import { FormControl, FormGroup } from '@angular/forms';
import { SearchObject } from './search-object';


export class SearchboxWithDropdownFormGroup extends FormGroup {


  constructor(searchObjects: SearchObject[]) {
    const obj = {};
    let searchCategoryDefault;
    // this needs to be a for loop, a for each didn't do what i wanted
    // make this all functional-like sometime in the future if you please.
    for (let i = 0; i < searchObjects.length; i++) {
      const searchObject = searchObjects[i];
      if (!searchCategoryDefault) {
        // the search dropdown will default to the first item in the list.
        searchCategoryDefault = searchObject.controlName;
      }
      obj[searchObject.controlName] = new FormControl(null);
    }

    // this adds all of the "searchObjects" that you've added as formControls.  See the getter for how this works.
    super({
      ...obj,
      searchCategory: new FormControl(searchCategoryDefault),
    });
  }

  /**
   * The searchInput is a FormControl that changes based on what you've selected in the dropdown
   */

  get searchInput(): FormControl | null {
    return this.get(this.searchCategory.value.toString()) as FormControl;
  }

  get searchCategory(): FormControl {
    return this.get('searchCategory') as FormControl;
  }

  nullAllSearchInputs() {
    Object.keys(this.controls).forEach((controlName) => {
      if (controlName !== 'searchCategory') {
        this.get(controlName).setValue(null);
      }
    });
  }


  getRawValue(): any {
    const obj = {};
    obj[this.searchCategory.value] = this.searchInput.value;
    return obj;
  }
}
