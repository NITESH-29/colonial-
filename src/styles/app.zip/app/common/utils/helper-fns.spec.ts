import { splitIntoWords } from './helper-fns';

describe('splitIntoWords', () => {
  it('should be a function', () => {
    expect(splitIntoWords instanceof Function).toBeTruthy();
  });

  describe('should handle all our known file types (for file upload active subjects)', () => {
    const knownFileTypes = {
      applicationFile: ['Application', 'File'],
      completedSpecialBondFile: ['Completed', 'Special', 'Bond', 'File'],
      courtOrderFile: ['Court', 'Order', 'File'],
      judgmentFile: ['Judgment', 'File'],
      personalFinancialFile: ['Personal', 'Financial', 'File'],
      specialBondFile: ['Special', 'Bond', 'File'],
    };

    Object.entries(knownFileTypes).forEach(([fileType, expectedWords]) => {
      it(`should return [${expectedWords}] for '${fileType}'`, () => {
        expect(splitIntoWords(fileType)).toEqual(expectedWords);
      });
    });
  });
});
