import { NgModule, APP_INITIALIZER } from '@angular/core';
import { CommonModule, TitleCasePipe, CurrencyPipe } from '@angular/common';
import { IbondRoutingModule } from './ibond-routing.module';
import { MaterialModule } from '../material.module';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HeadingPanelComponent } from './common/heading-panel/heading-panel.component';
import { IbondBaseService } from './service/ibond-base.service';
import { LoggedInResolver } from '../enrollment/application/providers/logged-in.resolver';
import { GetQuotesComponent } from './get-quotes/get-quotes.component';
import { GetQuoteNotaryComponent } from './get-quotes/get-quotes-notary/get-quote-notary.component';
import { GetQuoteLandPComponent } from './get-quotes/get-quotes-landp/get-quote-landp.component';
import { ApplicationSubmitComponent } from './application-submit/application-submit.component';
import { CommonComponentsModule } from '../common/common-components.module';
import { ApplicationFormComponent } from './application-form/application-form.component';
import { ChangeBondComponent } from './common/change-bond/change-bond.component';
import { GetQuotePoComponent } from './get-quotes/get-quote-po/get-quote-po.component';
import { VerticalStepperComponent } from './common/vertical-stepper/vertical-stepper.component';
import { PaymentChannelComponent } from './common/payment-channel/payment-channel.component';
import { GetQuotesAsComponent } from './get-quotes/get-quotes-as/get-quotes-as.component';
import { GetQuoteEmpDishonestyComponent } from './get-quotes/get-quote-emp-dishonesty/get-quote-emp-dishonesty.component';
import { BreadcrumbComponent } from './common/breadcrumb/breadcrumb.component';
import { GetQuotesRiaComponent } from './get-quotes/get-quotes-ria/get-quotes-ria.component';
import { GetQuotesVafiduciaryComponent } from './get-quotes/get-quotes-vafiduciary/get-quotes-vafiduciary.component';
import { GetQuoteJanitorialComponent } from './get-quotes/get-quote-janitorial/get-quote-janitorial.component';
import { AgreementComponent } from './common/agreement/agreement.component';
import { GetQuoteLostInstrumentComponent } from './get-quotes/get-quote-lost-instrument/get-quote-lost-instrument.component';
import { GetQuotesLostCarTitleComponent } from './get-quotes/get-quotes-lost-car-title/get-quotes-lost-car-title.component';
import { IbondSpecialFormComponent } from './common/ibond-special-form/ibond-special-form.component';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { SelectDropdownFormFieldComponent } from './common/select-dropdown-form-field/select-dropdown-form-field.component';
import { PhoneNumberPipe } from './common/pipes/phone-number.pipe';
import { ApplicantDetailInformationComponent } from './application-form/application-form-groups/applicant-detail-information/applicant-detail-information.component';
import { GetQuotesPersonalDetailsComponent } from './common/get-quotes-personal-details/get-quotes-personal-details.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AccountService } from '../user/account.service';
import { BondHolderDetailInformationComponent } from './application-form/application-form-groups/bond-holder-detail-information/bond-holder-detail-information.component';
import { BondDetailInformationComponent } from './application-form/application-form-groups/bond-detail-information/bond-detail-information.component';
import { SaveAndContinueButtonComponent } from './common/save-and-continue-button/save-and-continue-button.component';
import { GenericApplicationFormComponent } from './application-form/generic-application/generic-application-form.component';
import { GenericApplicationFormSummaryComponent } from './application-form/generic-application/generic-application-form-summary/generic-application-form-summary.component';
import { ApplicationQuestionsComponent } from './application-form/application-form-groups/application-questions/application-questions.component';
import { StaffDetailInformationComponent } from './application-form/application-form-groups/staff-detail-information/staff-detail-information.component';
import { LostInstrumentDetailInformationComponent } from './application-form/application-form-groups/lost-instrument-detail-information/lost-instrument-detail-information.component';
import { VehicleDetailInformationComponent } from './application-form/application-form-groups/vehicle-detail-information/vehicle-detail-information.component';
import { VeteranAffairDetailInformationComponent } from './application-form/application-form-groups/veteran-affair-detail-information/veteran-affair-detail-information.component';
import { UspsContractNumberFormComponent } from './application-form/application-form-groups/usps-contract-number-form/usps-contract-number-form.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { SendToClientComponent } from './common/send-to-client/send-to-client.component';
import { AirportListMatChipComponent } from './application-form/application-form-groups/mat-chip-questions/airport-list-mat-chip.component';
import { BusinessDetailInformationComponent } from './application-form/application-form-groups/business-detail-information/business-detail-information.component';
import { CustomCurrencyPipe } from './common/pipes/custom-currency.pipe';

@NgModule({
  imports: [
    CommonModule,
    IbondRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CommonComponentsModule,
  ],
  declarations: [
    GetQuotesComponent,
    HeadingPanelComponent,
    GetQuoteNotaryComponent,
    GetQuoteLandPComponent,
    ApplicationFormComponent,
    ApplicationSubmitComponent,
    VerticalStepperComponent,
    BreadcrumbComponent,
    ChangeBondComponent,
    GetQuotePoComponent,
    PaymentChannelComponent,
    GetQuotesAsComponent,
    GetQuoteEmpDishonestyComponent,
    GetQuotesRiaComponent,
    GetQuotesVafiduciaryComponent,
    GetQuoteJanitorialComponent,
    AgreementComponent,
    GetQuoteLostInstrumentComponent,
    GetQuotesLostCarTitleComponent,
    IbondSpecialFormComponent,
    ProductOverviewComponent,
    SelectDropdownFormFieldComponent,
    PhoneNumberPipe,
    CustomCurrencyPipe,
    ApplicantDetailInformationComponent,
    GetQuotesPersonalDetailsComponent,
    SignUpComponent,
    BondHolderDetailInformationComponent,
    BondDetailInformationComponent,
    SaveAndContinueButtonComponent,
    GenericApplicationFormComponent,
    GenericApplicationFormSummaryComponent,
    ApplicationQuestionsComponent,
    StaffDetailInformationComponent,
    LostInstrumentDetailInformationComponent,
    VehicleDetailInformationComponent,
    VeteranAffairDetailInformationComponent,
    AirportListMatChipComponent,
    UspsContractNumberFormComponent,
    CreateUserComponent,
    SendToClientComponent,
    BusinessDetailInformationComponent,
  ],
  providers: [
    IbondBaseService,
    LoggedInResolver,
    TitleCasePipe,
    CurrencyPipe,
    AccountService,
  ],
  entryComponents: [
  ],
})
export class IbondModule { }
