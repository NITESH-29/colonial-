import { PersonImpl } from '../../common/person';
import { Client, ClientImpl } from '../../common/client';
import { CompanyOfficePersonImpl } from '../../common/company-office-person';
import { CompanyAndOfficeInformation } from '../company-and-office-information/company-and-office-information';

export interface ClientFormData {
  personalInformation: PersonImpl;
  companyAndOfficeInformation?: CompanyAndOfficeInformation;
  referralCode?: string;
}

export function convertClientFormDataToClient(formData: ClientFormData, client: Client = new ClientImpl()): Client {
  const { personalInformation, companyAndOfficeInformation, referralCode } = formData;

  const cop = new CompanyOfficePersonImpl();
  cop.responsiblePerson = true;
  cop.title = companyAndOfficeInformation.title;
  client.person.companyOfficePersons = [cop];

  client.person.email = personalInformation.email;
  client.person.fax = personalInformation.fax;
  client.person.firstName = personalInformation.firstName;
  client.person.initial = personalInformation.initial;
  client.person.lastName = personalInformation.lastName;

  if (client.person.personAddresses.length > 0) {
    client.person.personAddresses.forEach((address, idx) => {
      const newAddress = personalInformation.personAddresses[idx];
      address.street1 = newAddress.street1;
      address.street2 = newAddress.street2;
      address.zipCode = newAddress.zipCode;
      address.city = newAddress.city;
      address.state = newAddress.state;
    });
  } else {
    client.person.personAddresses = personalInformation.personAddresses;
  }

  client.person.personAddresses = client.person.personAddresses.filter(
    pa => Object.values(pa).reduce((a, b) => a || b, null)
  );

  client.person.phone = personalInformation.phone;
  client.person.profession = personalInformation.profession;
  client.person.salutation = personalInformation.salutation;
  client.person.suffix = personalInformation.suffix;

  if (!!client.companyOffice) {
    client.companyOffice.company.name = companyAndOfficeInformation.name;

    // TODO - Remove this line when we remove company.siccode
    client.companyOffice.company.siccode = companyAndOfficeInformation.sicCode;

    client.companyOffice.address = companyAndOfficeInformation.address;
    client.companyOffice.email = companyAndOfficeInformation.email;
    client.companyOffice.fax = companyAndOfficeInformation.fax;
    // client.companyOffice.id = +companyAndOfficeInformation.id || null;
    client.companyOffice.name = companyAndOfficeInformation.name;
    client.companyOffice.officeType = 'Main';
    client.companyOffice.phone = companyAndOfficeInformation.phone;
    client.companyOffice.siccode = companyAndOfficeInformation.sicCode;
    client.companyOffice.website = companyAndOfficeInformation.website;
  }

  client.referralCode = referralCode;

  return client;
}

export function convertClientToClientFormData(client: Client): ClientFormData {
  const personalInformation: PersonImpl = new PersonImpl();
  personalInformation.email = client.person.email;
  personalInformation.firstName = client.person.firstName;
  personalInformation.initial = client.person.initial;
  personalInformation.lastName = client.person.lastName;
  personalInformation.phone = client.person.phone;
  personalInformation.profession = client.person.profession;
  personalInformation.salutation = client.person.salutation;
  personalInformation.suffix = client.person.suffix;
  personalInformation.personAddresses = client.person.personAddresses;
  personalInformation.companyOfficePersons = client.person.companyOfficePersons;

  const {
    name: companyOfficeName,
    website, phone, fax, email,
    siccode: companyOfficeSicCode, address,
    company: { id, siccode: companySicCode, name: companyName },
  } = client.companyOffice;

  const cops = client.person.companyOfficePersons;
  const title = cops.length > 0 ? cops.shift().title : '';

  const companyAndOfficeInformation: CompanyAndOfficeInformation = {
    id: id && id.toString() || null,
    name: companyName || companyOfficeName,
    title, website, phone, fax, email,
    // TODO - Get it from companyOffice only when we remove company.siccode
    sicCode: companyOfficeSicCode || companySicCode,
    address,
  };

  const referralCode = client.referralCode;

  return {
    personalInformation,
    companyAndOfficeInformation,
    referralCode,
  };
}
