import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../security/app.auth.guard';
import { AdminGuard } from '../role-guard/admin.guard';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeDefaultGuard } from '../role-guard/employee-default.guard';
import { AttorneyReferralListComponent } from './attorney/attorney-referral-list.component';
import { EmployeePlusGuard } from '../role-guard/employee-plus.guard';

const routes: Routes = [
  { path: '', component: AdminHomeComponent, canActivate: [AuthGuard, AdminGuard] },
  { path: 'employee', component: EmployeeComponent, canActivate: [AuthGuard, EmployeeDefaultGuard] },
  { path: 'employee/:id', component: EmployeeComponent, canActivate: [AuthGuard, EmployeeDefaultGuard] },
  { path: 'attorney-referral', component: AttorneyReferralListComponent, canActivate: [AuthGuard, EmployeePlusGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {
}
