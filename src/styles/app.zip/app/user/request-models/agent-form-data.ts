import { AgencyAndOfficeInformation } from '../agency-and-office-information/agency-and-office-information';
import { UsernamePassword } from '../username-password/username-password-form-group';
import { BusinessOfficePersonInformation } from '../business-office-person-information/business-office-person-information';

export interface AgentFormData {
  personalInformation: BusinessOfficePersonInformation;
  agencyAndOfficeInformation: AgencyAndOfficeInformation;
  usernamePassword: UsernamePassword;
}
