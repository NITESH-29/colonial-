import { AuditableObject } from '../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';
import { Product, ProductImpl } from '../product';

@JsonObject('ProductRenewal')
export class ProductRenewal extends AuditableObject {

  @JsonProperty('previousProduct', ProductImpl, true)
  previousProduct: Product = null;

  @JsonProperty('newProduct', ProductImpl, true)
  newProduct: Product = null;

  @JsonProperty('originalProduct', ProductImpl, true)
  originalProduct: Product = null;
}
