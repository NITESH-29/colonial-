export const applicationStatuses = [
  'All',
  'In Progress',
  'Submitted',
  // 'Awaiting Payment',
  'Completed',
  'Hold',
  // 'Soft Hold',
];
