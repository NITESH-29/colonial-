import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../products.service';
import { ApplicationService } from '../../enrollment/application/application.service';
import { ProductRenewalService } from './product-renewal.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { MatDialog } from '@angular/material';
import {
  PaymentMethodSelectionFormGroup,
  PaymentMethodSelectionFormGroupConfig,
} from '../../common/payment-method-selection/payment-method-selection-form-group';
import { Subscription } from 'rxjs';
import { PaymentMethodInitializationData } from '../../common/payment-method-selection/payment-method-initialization-data';
import { SecurityService } from '../../security/security.service';
import { Client, ClientImpl } from '../../common/client';
import { CompanyOfficeImpl } from '../../common/company-office';
import { PersonImpl } from '../../common/person';
import { ApplicationImpl } from '../../enrollment/application/application';
import { BillingPersonImpl, RolePaymentDefinition } from '../../common/payment-method-selection/billing-person';
import { PersonService } from '../../common/person-service';
import { PaymentMethod, PaymentMethodImpl } from '../../enrollment/application/court/model/common/payment-method';
import { ApplicationData } from '../../enrollment/application/court/model/application-data';
import { CommonUtilities } from '../../common/utils/common-utilities';

@Component({
  selector: 'app-product-renewal',
  templateUrl: './product-renewal.component.html',
  styleUrls: ['./product-renewal.component.scss'],
})

export class ProductRenewalComponent implements OnInit {
  static readonly PAYMENT_INFORMATION_FORM_GROUP_NAME = 'paymentInformation';

  applicationData: ApplicationData;
  product: Product;
  renewalFormGroup: FormGroup;
  initialized = false;
  renewalUntil: Date = null;
  renewalDate: Date = null;
  originalProduct: Product = null;
  // a subscription whose sole purpose is to support cleanup of subscriptions.
  private _rootCleanupSubscription: Subscription = new Subscription();
  // Groups payment method data common to applications/products to reduce number of 'inputs'.
  paymentMethodInitializationData: PaymentMethodInitializationData;
  applicationId: number;
  disableRenewButton = false;


  constructor(private activatedRoute: ActivatedRoute,
    private productService: ProductService,
    private applicationService: ApplicationService,
    private productRenewalService: ProductRenewalService,
    private securityService: SecurityService,
    private personService: PersonService,
    private formBuilder: FormBuilder,
    private router: Router,
    private serviceHandler: ServiceHandler,
    private sendEmailDialog: MatDialog) {
  }

  async ngOnInit(): Promise<void> {
    await this.loadData();
  }

  private async loadData() {
    // query param ?productId=123
    const productId = this.activatedRoute.snapshot.queryParams['productId'];

    this.product = await this.productService.getProductOverview(productId).toPromise();
    this.originalProduct = await this.productRenewalService.getOriginalProduct(productId).toPromise();
    const application = await this.applicationService.getById(this.product.applicationId);
    this.applicationId = application.id;
    this.applicationData = application.data;
    this.renewalDate = new Date();
    this.renewalDate.setDate(this.product.fromDate.getDate() + 1);
    this.renewalUntil = this.renewalDate;
    this.renewalUntil.setFullYear(this.renewalDate.getFullYear() + 1);
    this.renewalUntil.setDate(this.renewalUntil.getDate() - 5);
    this.renewalFormGroup = this.formBuilder.group(
      {
        renewalDate: this.renewalDate,
        renewalUntil: this.renewalUntil,
        productId: this.product.id,
      }
    );
    this.renewalFormGroup.addControl(ProductRenewalComponent.PAYMENT_INFORMATION_FORM_GROUP_NAME
      , this.createPaymentInformationFormGroup());

    this.paymentMethodInitializationData = this.createPaymentMethodInitializationData(application);

    this.renewalFormGroup.patchValue(this.createPaymentMethod());

    this.populatePaymentMethodInitializationData(this.paymentMethodInitializationData, application);
    this.initialized = true;
  }

  private createPaymentInformationFormGroup(): PaymentMethodSelectionFormGroup {
    let paymentMethodSelectionFormGroup: PaymentMethodSelectionFormGroup;
    const paymentMethodSelectionFormGroupConfig: PaymentMethodSelectionFormGroupConfig = {
      isRequired: true,
      isDisabled: false,
    };
    paymentMethodSelectionFormGroup = new PaymentMethodSelectionFormGroup(this._rootCleanupSubscription
      , paymentMethodSelectionFormGroupConfig);
    return paymentMethodSelectionFormGroup;
  }

  private createPaymentMethod(): PaymentMethod {
    const paymentMethodImpl = new PaymentMethodImpl();

    return paymentMethodImpl;
  }

  private createPaymentMethodInitializationData(application: ApplicationImpl): PaymentMethodInitializationData {
    let paymentMethodInitializationData: PaymentMethodInitializationData;

    const currentUserIsSteward = this.securityService.user && this.securityService.user.isSteward;

    // see if the application has an agent associated
    const applicant: Client = new ClientImpl();
    if (application.companyOffice) {
      applicant.companyOffice = new CompanyOfficeImpl();
      applicant.companyOffice.id = application.companyOffice.id;
    } else if (application.person) {
      applicant.person = new PersonImpl();
      applicant.person.id = application.person.id;
    }

    let applicantIsPersonOfAgent;
    {
      applicantIsPersonOfAgent = currentUserIsSteward &&
        applicant.person &&
        applicant.person.id &&
        applicant.person.id === this.securityService.user.person.id;
    }
    let applicantIsCompanyOfficeOfAgent;
    {
      applicantIsCompanyOfficeOfAgent = currentUserIsSteward &&
        applicant.companyOffice &&
        applicant.companyOffice.id &&
        this.securityService.user.person.companyOfficePersons.some(
          cop => cop.responsiblePerson && cop.companyOffice.id === applicant.companyOffice.id
        );
    }
    const agentIsApplicant = applicantIsPersonOfAgent || applicantIsCompanyOfficeOfAgent;

    paymentMethodInitializationData = new PaymentMethodInitializationData(agentIsApplicant
      , currentUserIsSteward
      , true // Don't allow agent to select existing client BPs.
      , true // paymentMethodToBeUsedImmediately is always true for Product Renewal.
    );

    return paymentMethodInitializationData;
  }

  /**
   * Populate initialization data for Product-Renewal Payment data collection.
   */
  private populatePaymentMethodInitializationData(paymentMethodInitializationData: PaymentMethodInitializationData
    , application: ApplicationImpl) {
    {
      // ApplicantBillingPerson
      if (!!application.person) {
        // Application-responsible-party is an individual person or agent.
        const personSummary = application.person;
        const overrideAddress = undefined;
        const rolePaymentDefinition = RolePaymentDefinition.clientRolePaymentDefinition;
        const billingPerson = BillingPersonImpl
          .createBillingPersonFromPersonSummary(personSummary, rolePaymentDefinition, overrideAddress);
        paymentMethodInitializationData.applicantBillingPerson$.next(billingPerson);
      } else if (!!application.companyOffice) {
        // Application-responsible-party is the company office responsible person. We need to fetch their personSummary.
        // Can't rely on this.applicant.companyOffice  because it is not fully populated.
        this.personService.getCompanyOfficeResponsiblePersonByCompanyOfficeId(application.companyOffice.id)
          .then((personSummary) => {
            // Use the company-office address instead of the company-office-responsible-person's address.
            const overrideAddress = application.companyOffice.address;
            const rolePaymentDefinition = RolePaymentDefinition.clientRolePaymentDefinition;
            const billingPerson = BillingPersonImpl
              .createBillingPersonFromPersonSummary(personSummary, rolePaymentDefinition, overrideAddress);
            paymentMethodInitializationData.applicantBillingPerson$.next(billingPerson);
          });
      } else {
        paymentMethodInitializationData.applicantBillingPerson$.next(null);
      }
    }
    {
      // Secondary Billing Person
      if (!!application.agent && application.agent.id) {
        // The application has an agent. The agent is therefore the secondary BillingPerson if:
        // - The agent is not the applicant.
        // - The agent is the logged-in user.
        // Note that we're actually settling for logged-in user is a steward
        // and not checking if the logged-in user is the application's agent.
        if (!paymentMethodInitializationData.agentIsApplicant
          && paymentMethodInitializationData.currentUserIsSteward) {
          // We have a Secondary Billing Person.
          // Agent is acting on somebody else's behalf, billing address should be the agent's company's address.
          const loggedInUser = this.securityService.user;
          const overrideAddress = loggedInUser.person.companyOfficePersons[0].companyOffice.address;
          const billingPerson = BillingPersonImpl.createBillingPersonFromUser(loggedInUser, overrideAddress);
          paymentMethodInitializationData.secondaryBillingPerson$.next(billingPerson);
        } else {
          // No Secondary Billing Person
          paymentMethodInitializationData.secondaryBillingPerson$.next(null);
        }
      } else {
        paymentMethodInitializationData.secondaryBillingPerson$.next(null);
      }
    }
  }

  get productNo() {
    return this.product.productNo;
  }

  get paymentInformationFormGroup(): FormGroup {
    return this.renewalFormGroup.get(ProductRenewalComponent.PAYMENT_INFORMATION_FORM_GROUP_NAME) as FormGroup;
  }

  async renewProduct() {
    if (this.renewalFormGroup.valid) {
      this.disableRenewButton = true;
      const paymentMethod = this.paymentInformationFormGroup.getRawValue() as PaymentMethod;
      try {
        const product = await this.productRenewalService.renewProduct(this.product.id, this.renewalDate, paymentMethod).toPromise();
        this.serviceHandler.handleConfirm('Product Renewed');
        // await this.router.navigateByUrl('/product/bonds-and-policies');
        await this.router.navigateByUrl('/dashboard');
      } catch (error) {
        this.disableRenewButton = false;
        this.serviceHandler.handleError(error);
      }
    } else {
      CommonUtilities.markAllTouched(this.renewalFormGroup); // Trigger display of field validation errors.
      this.serviceHandler.showErrorMessage('There are errors in your product renewal request, please fix them before proceeding.');
    }
  }

  async cancel() {
    await this.router.navigateByUrl(`/product/product-overview?formId=${this.product.id}`);
  }

}
