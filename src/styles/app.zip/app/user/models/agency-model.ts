import { AgencyOfficeModel, AgencyOfficeModelImpl } from './agency-office-model';
import { JsonObject, JsonProperty } from 'json2typescript';

export interface AgencyModel {
  id: number;
  name: string;
  memberOfNasbp: boolean;
  einNumber: string;
  agencyOffices: AgencyOfficeModel[];
}

@JsonObject('AgencyModelImpl')
export class AgencyModelImpl implements AgencyModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('memberOfNasbp', Boolean, true)
  memberOfNasbp: boolean = null;

  @JsonProperty('einNumber', String, true)
  einNumber: string = null;

  @JsonProperty('agencyOffices', [AgencyOfficeModelImpl], true)
  agencyOffices: AgencyOfficeModel[] = [];
}
