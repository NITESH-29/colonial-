export interface UsernameAvailabilityRequest {
  requestedUsername: string;
}
