import { HttpHeaders, HttpParams } from '@angular/common/http';

// Define a type alias for the anonymous structural type defined for the third parameter to angular http's verb methods,
// copied here for your convenience from colonial-ui/node_modules/@angular/common/http/src/client.d.ts
export interface HttpOptions {
  headers?: HttpHeaders | {
    [header: string]: string | string[];
  };
  observe?: 'body';
  params?: HttpParams | {
    [param: string]: string | string[];
  };
  reportProgress?: boolean;
  responseType?: 'json';
  withCredentials?: boolean;
}
