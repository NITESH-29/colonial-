import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadConfig } from '../file-upload/file-upload-config';
import { DocumentUploadComponent } from '../document-upload/document-upload.component';

@Component({
  selector: 'app-describe-assets',
  templateUrl: './describe-assets.component.html',
  styleUrls: ['./describe-assets.component.css'],
})
export class DescribeAssetsComponent extends DocumentUploadComponent implements OnInit {

  @Input()
  describeAssetFormGroup: FormGroup;

  // FileUploadConfig for uploading the Contact info file.
  fileUploadConfig: FileUploadConfig;

  @Input()
  disableDescribeAssetsButton: boolean;

  constructor() {
    super();
    this.fileUploadConfig = new FileUploadConfig();
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx,.jpg,.jpeg';
  }

  ngOnInit() {
  }

  get uploadPersonal(): FormControl {
    return this.describeAssetFormGroup.get('uploadPersonal') as FormControl;
  }

  get personalFinancialFile(): FormGroup {
    return this.describeAssetFormGroup.get('personalFinancialFile') as FormGroup;
  }

  get applicantFinancialInfoFormGroup(): FormGroup {
    return this.describeAssetFormGroup.get('applicantFinancialInfo') as FormGroup;
  }
}
