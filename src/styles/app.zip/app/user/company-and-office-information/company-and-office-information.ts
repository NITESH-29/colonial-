import { Address } from '../../enrollment/application/court/model/common/address';

export interface CompanyAndOfficeInformation {
  id: string;
  name: string;
  title: string;
  website: string;
  phone: string;
  fax: string;
  email: string;
  sicCode: string;
  address: Address;
}
