import { AbstractControl, AsyncValidatorFn } from '@angular/forms';
import { Observable, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

export interface AvailabilityCheck { available: boolean; }

export function getAvailabilityAsyncValidator(
  availabilityType: string,
  availabilityObsFn: (x: string) => Observable<AvailabilityCheck>
): AsyncValidatorFn {
  return (ctl: AbstractControl) => {
    return timer(700).pipe(
      switchMap(
        () => availabilityObsFn(ctl.value).pipe(
          map(({ available }) => available ? null : { [`${availabilityType}Available`]: false })
        )
      ));
  };
}
