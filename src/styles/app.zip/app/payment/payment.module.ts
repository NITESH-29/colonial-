import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { MaterialModule } from '../material.module';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonComponentsModule } from '../common/common-components.module';
import { PaymentChannelComponent } from './component/payment-channel/payment-channel.component';

@NgModule({
  declarations: [PaymentChannelComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CommonComponentsModule,
  ],
  providers: [
    TitleCasePipe,
  ],
  exports: [PaymentChannelComponent],
})
export class PaymentModule { }
