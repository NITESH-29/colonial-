import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AgencyModel } from '../models/agency-model';
import { AgencyAndOfficeInformationFormGroup } from '../agency-and-office-information/agency-and-office-information-form-group';
import { SecurityService } from '../../security/security.service';
import { PersonBusinessService } from '../providers/person-business.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-firm-with-single-office',
  templateUrl: './firm-with-single-office.component.html',
})
export class FirmWithSingleOfficeComponent implements OnInit {
  @Input() firm: AgencyModel;
  @Output() firmSaved = new EventEmitter<AgencyModel>();

  formGroup: AgencyAndOfficeInformationFormGroup;

  constructor(
    private securityService: SecurityService,
    private personBusinessService: PersonBusinessService,
    private router: Router,
    private location: Location,
    private accountService: AccountService
  ) {
    this.firmSaved = new EventEmitter<AgencyModel>(true);
  }

  ngOnInit(): void {
    this.formGroup = new AgencyAndOfficeInformationFormGroup({ memberOfNasbp: () => false });

    if (this.firm) {

      const { id, name, agencyOffices: [agencyOffice] } = this.firm;
      const { website, phone, fax, email, sicCode, address } = agencyOffice;

      this.formGroup.patchValue(
        { id, name, website, phone, fax, email, sicCode, address }
      );
    }
    this.formGroup.valueChanges.subscribe((value) => {
      if (value.email) {
        this.formGroup.get('email').setAsyncValidators(
          this.accountService.getEmailAvailabilityAsyncValidator()
        );
      }
    });
  }

  async save(): Promise<void> {
    if (this.formGroup.valid) {
      const {
        name, website, phone, fax, email, sicCode, address,
      } = this.formGroup.getRawValue();

      const { agencyOffices: [agencyOffice] } = this.firm;

      const updatedAgencyOffice = Object.assign(agencyOffice,
        { name, address, email, website, phone, fax, sicCode }
      );

      this.firm = Object.assign(this.firm, {
        ...{ name, agencyOffices: [updatedAgencyOffice] },
      });

      const personId = this.securityService.user.person.id;

      const savedAgency = await this.personBusinessService.updateAgency(this.firm, personId);
      this.firmSaved.emit(savedAgency);
    } else {
      CommonUtilities.markAllTouched(this.formGroup);
    }
  }

  goBack(): void {
    this.location.back();
  }
}
