export enum AdjudicationEventName {
  COLLATERAL_VERIFIED = 'Collateral Verified',
  ONE_FILE_VERIFICATION_CHANGE = 'OneFileVerificationChange',
  FILE_UPLOADED = 'FileUploaded',
  FILE_DELETED = 'FileDeleted',
  FILES_VERIFIED = 'FilesVerified',
  CREDIT_SCORE_CHECKED = 'CreditScoreChecked',
  KNOCKOUT_QUESTIONS_PASSED = 'KnockoutQuestionsPassed',
}

export interface AdjudicationEvent {
  eventName: AdjudicationEventName;
  applicationId: number;
  value: any;
}
