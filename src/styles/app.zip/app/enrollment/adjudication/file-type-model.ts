import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject('FileTypeModel')
export class FileTypeModel {

  @JsonProperty('description', String, true)
  description: string = null;

  @JsonProperty('name', String, true)
  name: string = null;
}
