import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatProgressBarModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatSnackBarModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { UserService } from './user.service';
import { SecurityService } from './security.service';
import { CalendarModule, CheckboxModule, DataListModule } from 'primeng/primeng';
import { AuthGuard } from './app.auth.guard';
import { SecurityRoutingModule } from './security-routing.module';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { CommonComponentsModule } from '../common/common-components.module';
import { LoginPopupComponent } from './login-popup/login-popup.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';

@NgModule({
  imports: [
    CommonModule,
    SecurityRoutingModule,
    ReactiveFormsModule,
    CommonComponentsModule,

    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,

    // Material Stuff
    MatAutocompleteModule,
    MatButtonModule,
    MatFormFieldModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatProgressBarModule,
    FlexLayoutModule,
  ],
  declarations: [
    LoginComponent,
    ForgotPasswordComponent,
    ChangePasswordComponent,
    ResetPasswordComponent,
    LoginPopupComponent,
    ForgotUsernameComponent,
  ],
  providers: [
    UserService,
    AuthGuard,
  ],
  exports: [
    LoginComponent,
    ForgotPasswordComponent,
    ChangePasswordComponent,
    ResetPasswordComponent,
    LoginPopupComponent,
  ],
  entryComponents: [
    LoginPopupComponent,
  ],
})
export class SecurityModule {
  // constructor (@Optional() @SkipSelf() parentModule: SecurityModule) {
  //   if (parentModule) {
  //     throw new Error(
  //       'SecurityModule is already loaded. Import it in the AppModule only');
  //   }
  // }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SecurityModule,
      providers: [
        SecurityService,
      ],
    };
  }
}
