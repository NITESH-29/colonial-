import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
import { IbondBaseService } from 'src/app/ibond/service/ibond-base.service';
import { SecurityService } from 'src/app/security/security.service';
import { UserImpl } from 'src/app/security/user';
import { MatDialog } from '@angular/material';
import { ConfirmationDialogComponent } from 'src/app/common/confirmation-dialog/confirmation-dialog.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { DOCUMENT } from '@angular/platform-browser';
import { NoopScrollStrategy } from '@angular/cdk/overlay';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./../../../styles/i-bond-theme.scss'],
})
export class PaymentComponent implements OnInit, OnDestroy {
  isDefault = true;
  paymentCardList = [];
  loggedIn: boolean;
  user: UserImpl;
  userId: number;
  showAddCard = false;
  cardId: number;
  isEdit = false;
  cardPosition: number;
  defaultBillingProfileId: number;

  constructor(
    // tslint:disable-next-line: deprecation
    @Inject(DOCUMENT) private document,
    private spinnerService: SpinnerService,
    private lpService: IbondBaseService,
    private securityService: SecurityService,
    private matDialog: MatDialog,
    private serviceHandler: ServiceHandler
  ) { }

  async ngOnInit() {
    this.document.body.classList.remove('court-bond-theme');
    this.document.body.classList.add('colonial-new-theme');
    // this.document.body.classList.add('mat-app-background');
    // this.document.body.classList.remove('main-body-background');
    this.securityService.loggedIn$.subscribe(loggedIn$ => {
      this.loggedIn = loggedIn$;
      if (this.loggedIn) {
        this.user = this.securityService.user;
        this.userId = this.user.person.id;
        // this.refreshUserDetail();
        this.defaultBillingProfileId = this.user.person.defaultBillingProfileId;
      }
    });
    await this.getSavedBillingProfile();
  }
  async getSavedBillingProfile() {
    this.spinnerService.show();
    await this.lpService.getSavedCardList(this.userId).then((response: any) => {
      if (response) {
        this.spinnerService.hide();
        this.paymentCardList = response;
        if (this.paymentCardList.length === 1) {
          this.setCardAsDefault(this.paymentCardList[0].id);
          this.paymentCardList[0]['defaultProfile'] = true;
        } else {
          this.paymentCardList.forEach((item, index) => {
            if (item.id === this.defaultBillingProfileId) {
              this.paymentCardList[index]['defaultProfile'] = true;
            } else {
              this.paymentCardList[index]['defaultProfile'] = false;
            }
          });
        }
      }
    }, (error) => {
      this.spinnerService.hide();
    });
  }

  makeDefault(cardId) {
    const dialogRef = this.matDialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Are you sure you want to make this card as default?',
        acceptLabel: 'Yes',
        acceptedResult: true,
        rejectLabel: 'No',
        rejectedResult: false,
        isIbond: true,
      },
      scrollStrategy: new NoopScrollStrategy(),
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.setCardAsDefault(cardId, true);
      }
    });
  }

  setCardAsDefault(cardId, showMessage = false) {
    this.spinnerService.show();
    this.lpService.makeCardAsDefault({}, cardId).subscribe(res => {
      if (res) {
        this.spinnerService.hide();
        this.refreshUserDetail();
        this.defaultBillingProfileId = cardId;
        if (showMessage) {
          this.serviceHandler.handleConfirm('Card Updated Successfully!');
          this.getSavedBillingProfile();
        }
      }
    }, err => {
      this.spinnerService.hide();
      this.serviceHandler.handleError('Something went wrong!');
    });
  }

  editCard(cardId, cardPosition) {
    this.isEdit = true;
    this.cardPosition = cardPosition;
    this.cardId = cardId;
  }

  deleteCard(cardDetail) {
    if (cardDetail.defaultProfile === false) {
      const dialogRef = this.matDialog.open(ConfirmationDialogComponent, {
        data: {
          title: 'Are you sure you want to delete this card?',
          acceptLabel: 'Yes',
          acceptedResult: true,
          rejectLabel: 'No',
          rejectedResult: false,
          isIbond: true,
        },
        scrollStrategy: new NoopScrollStrategy(),
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.spinnerService.show();
          this.lpService.deleteCard({}, cardDetail.id).subscribe(res => {
            if (res) {
              this.spinnerService.hide();
              this.serviceHandler.handleConfirm('Card Deleted Successfully!');
              this.getSavedBillingProfile();
            }
          }, err => {
            this.spinnerService.hide();
            this.serviceHandler.handleError('Something went wrong!');
          });
        }
      });
    } else {
      this.serviceHandler.showErrorMessage('Unable to delete default card!');
    }
  }

  addCard() {
    window.scroll(0, 0);
    this.showAddCard = true;
  }

  saveCard() {
    window.scroll(0, 0);
    this.showAddCard = false;
    this.getSavedBillingProfile();
  }

  cancelCard() {
    window.scroll(0, 0);
    this.showAddCard = false;
  }

  cancelEditCard() {
    window.scroll(0, 0);
    this.isEdit = false;
    this.cardPosition = null;
    this.cardId = null;
    this.getSavedBillingProfile();
  }

  refreshUserDetail() {
    this.securityService.refreshCurrentUser().subscribe(res => {
      if (res) {
        this.user = res;
      }
    }, err => {
      this.serviceHandler.handleError('Something went wrong!');
    });
  }
  ngOnDestroy(): void {
    this.document.body.classList.add('court-bond-theme');
    this.document.body.classList.remove('colonial-new-theme');
  }
}
