import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from '../../security/security.service';
import { Router } from '@angular/router';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { UserImpl } from 'src/app/security/user';
import { Subscription } from 'rxjs';
import { RequestService } from '../service/request.service';
import { IbondBaseService } from '../service/ibond-base.service';
import { GlobalConstants } from '../constant/global.constant';
import { GetQuotesService } from '../service/get-quotes.service';
import { UserIdleService } from 'angular-user-idle';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  hide = true;
  loginForm: FormGroup;
  errorMessage: string;
  redirectUrl;
  user: UserImpl = null;
  loggedIn: boolean;
  loggedIn$: Subscription;
  bondType = '';
  ibondBondType = GlobalConstants.IBOND_CODE_ARRAY;
  constructor(
    public dialogRef: MatDialogRef<LoginComponent>,
    public fb: FormBuilder,
    private securityService: SecurityService,
    private userIdleService: UserIdleService,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private gtmService: GoogleTagManagerService,
    public requestService: RequestService,
    public baseService: IbondBaseService,
    private quoteService: GetQuotesService
  ) {
  }

  ngOnInit() {
    this.userIdleService.stopWatching();
    this.loginForm = this.fb.group({
      username: this.fb.control('', [Validators.required]),
      password: this.fb.control('', [Validators.required]),
    });
    if (this.data['url']) {
      this.redirectUrl = this.data['url'];
    }
    this.errorMessage = null;
    this.securityService.loggedIn$.subscribe(
      loggedIn$ => {
        this.loggedIn = loggedIn$;
        if (this.loggedIn) {
          this.user = this.securityService.user;
        }

      }
    );
    const routeToken = location.pathname.split('/');
    this.bondType = routeToken[routeToken.length - 1] ? routeToken[routeToken.length - 1] : '';
    const localData = JSON.parse(localStorage.getItem('temp_application'));
    const quoteId = localStorage.getItem('quote_id');
    let premium = localData && localData.data ? localData.data.premium : null;
    premium = premium ? premium : (this.quoteService.bondPremiumForGTM ? this.quoteService.bondPremiumForGTM['premium'] : '');
    this.quoteService.bondPremiumForGTM = null;
    const classification = localData.data.classificationName ? localData.data.classificationName : '';
    const IPgroup = this.requestService.ipGroup;
    if (this.ibondBondType.indexOf(this.bondType) > -1) {
      const gtmBondType = this.requestService.setBondType(this.bondType);
      this.registerUserGtmEvent('bond-app-login', gtmBondType, premium,
        this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
        IPgroup, classification, quoteId ? quoteId : '', 'new', ''
      );
    } else {
      this.registerUserGtmEvent('bond-app-login', '', premium,
        this.user ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', IPgroup, classification,
        quoteId ? quoteId : '', 'new', ''
      );
    }
  }

  close(): void {
    this.dialogRef.close();
  }
  onSignin(): void {
    if (this.loginForm.valid) {
      this.securityService.login(this.loginForm.value.username, this.loginForm.value.password).then((loginData) => {
        const returnData = {
          response: loginData,
          page: this.data,
        };
        this.baseService.setSignUpValue(false);
        this.dialogRef.close(returnData);
      })
        .catch((errorResponse) => {
          if (![401, 403].includes(errorResponse.status)) {
            this.errorMessage = 'Unexpected Server Error. Please try again later.';
          } else {
            if (errorResponse.error) {
              this.errorMessage = errorResponse.error.message || 'Invalid username or password';
            } else {
              this.errorMessage = 'Invalid username or password';
            }
          }
        });
    }
  }
  createAccount() {
    const localData = JSON.parse(localStorage.getItem('temp_application'));
    const classification = localData.data.classificationName ? localData.data.classificationName : '';
    const IPgroup = this.requestService.ipGroup;
    let gtmBondType: string;
    const checkBondType = localData ? localData['data'].bondClassification : '';
    if (checkBondType === 'landp') {
      gtmBondType = 'license and permit';
    } else if (checkBondType === 'lost_car_title') {
      gtmBondType = 'lost car';
    } else if (checkBondType === 'vafiduciary') {
      gtmBondType = 'va fiduciary';
    } else {
      gtmBondType = checkBondType;
    }
    const quoteId = localStorage.getItem('quote_id');
    this.dialogRef.close();
    this.registerUserGtmEvent('bond-app-register', gtmBondType,
      localData ? localData['data'].premium : '',
      this.user && this.user.userRoles ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous',
      IPgroup, classification, quoteId, 'new', ''
    );
    if (this.redirectUrl) {
      this.router.navigate([`/user/create-client`], { state: { redirectUrl: this.redirectUrl } });
    } else {
      this.router.navigate([`/user/create-client`]);
    }
  }
  forgotPassword() {
    this.dialogRef.close();
    this.router.navigate([`/secure/forgot-password`]);
  }

  forgotUsername() {
    this.dialogRef.close();
    this.router.navigate([`/secure/forgot-username`]);
  }

  registerUserGtmEvent(event, bondType, bondPremium, userType, lpGroup, lpBond, quoteId, bondClass?, applicationID?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }
}
