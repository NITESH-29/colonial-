import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfLiabilityRoutingModule } from './prof-liability-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ProfLiabilityRoutingModule,
  ],
  declarations: [],
})
export class ProfLiabilityModule { }
