import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { AppConfigService } from '../app-config-service';
import { UtilMethodsService } from '../insurance/services/util-method.service';
import { SecurityService } from './security.service';
import { StringConstants } from '../insurance/constants/string-constants';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  private cookieName: string;
  appConfig;
  constructor(private router: Router, acs: AppConfigService, public securityService: SecurityService,
    public stringConstant: StringConstants) {
    acs.getConfig().subscribe(config => {
      this.appConfig = config;
      this.cookieName = config.cookieName;
    });
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req.clone()).catch(x => this.handleError(x));
  }

  private handleError(err: HttpErrorResponse): Observable<any> {
    // Don't redirect when trying to log in, that'll just clobber the error message
    // and then return you back to the login url, except now the error message is gone
    // Also don't redirect when trying to refresh the current user; let AuthGuard handle that
    const exemptUrlFragments = ['login', 'currentUser'];
    const Forbidden = 403;

    if (err.status === Forbidden && !exemptUrlFragments.some(fragment => err.url.includes(fragment))) {
      if (sessionStorage.getItem('originState') === 'rails') {
        this.securityService.getAccessToken().then(response => {
          let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
          if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
            railsUrl = this.appConfig.colonial_erisa_TPA_url;
          }
          if (UtilMethodsService.isEmpty(sessionStorage.getItem('applicationId'))) {
            // tslint:disable-next-line: max-line-length
            const paramRails = `?sutoken=${response}&applicationId=${sessionStorage.getItem('applicationId')}&applicationStatus=In Progress&errMessage=${err.error.responseDesc}`;
            console.log(this.securityService.requestURL(paramRails));
            sessionStorage.removeItem('originState');
            window.open(`${railsUrl}${paramRails}`, '_self');
          } else {
            console.log(this.securityService.requestURL(`?sutoken=${response}&errMessage=${err.error.responseDesc}`));
            sessionStorage.removeItem('originState');
            window.open(`${railsUrl}?sutoken=${response}&errMessage=${err.error.responseDesc}`, '_self');
          }
        });
      } else {
        const url = (!!document.cookie && document.cookie.includes(this.cookieName)) ? '/enrollment' : '/secure/login';
        this.router.navigateByUrl(url);
      }
    }
    return throwError(err);
  }
}
