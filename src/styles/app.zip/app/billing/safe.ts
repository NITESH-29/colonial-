import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../common/auditable-object';

@JsonObject('Safe')
export class Safe extends AuditableObject {
  @JsonProperty('token', String, true)
  token: string = null;
}
