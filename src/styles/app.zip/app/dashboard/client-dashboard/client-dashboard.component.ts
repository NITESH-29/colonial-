import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  OnDestroy,
  ElementRef
} from '@angular/core';
import { ApplicationService } from '../../enrollment/application/application.service';
import { MatPaginator, MatTableDataSource, MatSort, MatDialog } from '@angular/material';
import { ProductListService } from '../../colonial-table/product-list-common/product-list.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup } from '../../../../node_modules/@angular/forms';
import { ChangeBondComponent } from '../../ibond/common/change-bond/change-bond.component';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
import { DashboardService } from '../dashboard.service';
import { Location, DOCUMENT } from '@angular/common';
import { NoopScrollStrategy } from '@angular/cdk/overlay';
import { ClientsApplicationsListComponent } from './clients-applications-list/clients-applications-list.component';
import { Pageable } from 'src/app/common/pagination';
import * as moment from 'moment';
import { ClientsActiveProductsListComponent } from './clients-products-list-active/clients-active-products-list.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { start } from 'repl';

@Component({
  selector: 'app-client-dashboard',
  templateUrl: './client-dashboard.component.html',
  styleUrls: ['./client-dashboard.component.scss'],
})
export class ClientDashboardComponent implements OnInit, OnDestroy {
  isSearchEnable = false;
  isPendingList = false;
  isActiveList = false;
  isHistoryList = false;
  initialized = false;
  showSearch = false;
  pendingCol = ['id', 'productTypeName', 'createdAt', 'status', 'action'];
  activeCol = ['productNo', 'productTypeName', 'clientName', 'fromDate', 'status', 'action'];
  displayedColumns: string[] = this.pendingCol;
  dataSource = new MatTableDataSource();
  dashboardCount = 0;
  pendingProductList = [];
  pendingProductCount = 0;
  activeProductListCount = 0;
  historyProductList = [];
  historyProductListCount = 0;
  status = [
    { value: '', name: 'Select' },
    { value: 'Pending', name: 'Pending' },
    { value: 'In Progress', name: 'In Progress' },
    { value: 'Submitted', name: 'Submitted' },
    { value: 'Hold', name: 'Hold' },
    { value: 'Soft Hold', name: 'Soft Hold' },
  ];
  searchForm: FormGroup;
  filterByStatus = '';
  today = new Date();
  validStartDate = this.today;
  validEndDate = this.today;
  inputReadonly = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(ClientsApplicationsListComponent) clientsApplicationsListComponent: ClientsApplicationsListComponent;
  @ViewChild(ClientsActiveProductsListComponent) clientsActiveProductsListComponent: ClientsActiveProductsListComponent;
  constructor(
    public applicationService: ApplicationService,
    public productListService: ProductListService,
    private router: Router,
    private fb: FormBuilder,
    private matDialog: MatDialog,
    public spinnerService: SpinnerService,
    private dashboardService: DashboardService,
    private activatedRoute: ActivatedRoute,
    private location: Location,
    private serviceHandler: ServiceHandler,
    @Inject(DOCUMENT) private document
  ) {
    if (!this.filterByStatus) {
      this.applicationService.searchApplication('');
    }
  }

  ngOnInit() {
    this.document.body.classList.add('general-theme');
    this.getDasboardCount();
    let redirectToProductPage;
    // this.activatedRoute.queryParams.subscribe(params => {
    //   console.log('This is the data from the backend page', params);
    //   redirectToProductPage = params.redirectToProductPage;
    // });
    this.activatedRoute.queryParams.subscribe(params => {
      console.log('This is the data from the backend page', params);
      redirectToProductPage = params.redirectToProductPage;
    });
    console.log('redirectToProductPage >>> ', redirectToProductPage);
    if (redirectToProductPage === 'true') {
      // this.showProductList('Product', 0);
      this.location.replaceState('/dashboard');
      this.isActiveList = true;
    } else {
      this.isPendingList = true;
    }
    this.initializeDateFilter();
    this.searchForm.controls['startDate'].valueChanges.subscribe((value) => {
      this.validEndDate = new Date(value);
    });
  }

  initializeDateFilter() {
    this.searchForm = this.fb.group({
      startDate: [''],
      endDate: [''],
    });
  }

  getQuote() {
    const dialogRef = this.matDialog.open(ChangeBondComponent, { scrollStrategy: new NoopScrollStrategy() });
    // const dialogRef = this.matDialog.open(ChangeBondComponent, { data: { clickFrom: 'header' } });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // this.alreadyRegistered = false;
        // console.log('Response Data : ', result);
      }
    });
  }
  showProductList(val, enableFilter) {
    this.searchForm.reset();
    this.isPendingList = false;
    this.isActiveList = false;
    this.isHistoryList = false;
    if (!enableFilter) {
      this.applicationService.searchApplication('');
      if (val === 'Application') {
        this.applicationService.clearApplicationSearch(true);
      }
    }
    if (val === 'Application') {
      setTimeout(() => {
        this.isPendingList = true;
        this.isActiveList = false;
        this.isHistoryList = false;
      }, 500);
    } else if (val === 'Products') {
      this.isPendingList = false;
      this.isActiveList = true;
      this.isHistoryList = false;
    } else if (val === 'History') {
      this.isPendingList = false;
      this.isActiveList = false;
      this.isHistoryList = true;
    }
  }

  async getDasboardCount() {
    const countResponse = await this.dashboardService.getApplicationStatuses();
    this.pendingProductCount = this.getApplicationCount(countResponse);
    this.activeProductListCount = this.toNumber(countResponse['products']['Open']);
    this.dashboardCount = Number(this.pendingProductCount) + Number(this.activeProductListCount);
    this.historyProductListCount = this.toNumber(countResponse['products']['Closed']);
  }

  getApplicationCount(countResponse): number {
    return this.toNumber(countResponse['applications']['In Progress']) +
      this.toNumber(countResponse['applications']['Pending Review']) +
      this.toNumber(countResponse['applications']['Hold']) +
      this.toNumber(countResponse['applications']['Submitted']) +
      this.toNumber(countResponse['applications']['Pending']) +
      this.toNumber(countResponse['applications']['Declined']) +
      this.toNumber(countResponse['applications']['Completed']);
  }
  filterListByStatus(val) {
    this.isPendingList = false;
    this.isActiveList = false;
    this.isHistoryList = false;
    this.filterByStatus = val.filter;
    this.applicationService.searchApplication(val.filter);
    setTimeout(() => {
      this.showProductList(val.tab, 1);
    }, 500);
  }
  toNumber(num): number {
    return num ? Number(num) : 0;
  }

  editPendingApplication(id, code, status) {
    if (status === 'Soft Hold') {
      // http://localhost:4200/ibond/confirm/vafiduciary/905
      this.router.navigate(['ibond/confirm', code, id]);
    } else {
      this.router.navigate(['ibond/application', code, id]);
    }
  }

  ngOnDestroy(): void {
    this.document.body.classList.remove('general-theme');
  }

  searchInDateRange() {
    if (this.checkDateRange()) {
      this.isSearchEnable = true;
      const pageable: Pageable = {
        page: 0,
        size: 20,
        sort: ['id', 'desc'],
      };
      if (this.isPendingList) {
        this.clientsApplicationsListComponent.pageableEvent(pageable, this.getDateRange());
      } else if (this.isActiveList) {
        this.clientsActiveProductsListComponent.pageableEvent(pageable, this.getDateRange());
      }
    } else {
      this.serviceHandler.showErrorMessage('Please enter valid date range');
    }
  }

  checkDateRange(): boolean {
    const startDate = this.startDate.value;
    const endDate = this.endDate.value;
    if (startDate === '' || endDate === '' || !(moment(startDate).isBefore(moment(endDate)) || moment(startDate).isSame(moment(endDate)))) {
      return false;
    }
    return true;
  }

  getDateRange(): string[] {
    let startDate: string;
    let endDate: string;
    startDate = moment(this.startDate.value).format('MM/DD/YYYY');
    endDate = moment(this.endDate.value).add(1, 'day').format('MM/DD/YYYY');
    return [startDate, endDate];
  }

  get isStartDateValid() {
    return this.startDate.value !== '';
  }

  get startDate() {
    return this.searchForm.controls['startDate'];
  }

  get endDate() {
    return this.searchForm.controls['endDate'];
  }

  clearDateInput() {
    this.searchForm.get('startDate').reset();
    this.searchForm.get('endDate').reset();
    if (this.isSearchEnable) {
      this.isSearchEnable = false;
      if (this.isPendingList) {
        this.clientsApplicationsListComponent.pageableEvent({
          page: 0,
          size: 20,
          sort: ['id', 'desc'],
        }, []);
      } else if (this.isActiveList) {
        this.clientsActiveProductsListComponent.pageableEvent({
          page: 0,
          size: 20,
          sort: ['id', 'desc'],
        }, []);
      }
    }
  }
}
