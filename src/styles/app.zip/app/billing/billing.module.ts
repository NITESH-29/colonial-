import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalendarModule, CheckboxModule, DataListModule } from 'primeng/primeng';

// Material
import {
  MatAutocompleteModule, MatFormFieldModule,
  MatButtonModule, MatButtonToggleModule,
  MatCardModule, MatCheckboxModule,
  MatChipsModule, MatDatepickerModule, MatDialogModule, MatGridListModule,
  MatIconModule, MatInputModule, MatListModule,
  MatMenuModule, MatProgressBarModule, MatRadioModule, MatSelectModule,
  MatSidenavModule, MatSnackBarModule, MatTableModule, MatTabsModule,
  MatToolbarModule, MatDividerModule,
} from '@angular/material';
import { MatStepperModule } from '@angular/material/stepper';
import { CommonComponentsModule } from '../common/common-components.module';
import { BillingRoutingModule } from './billing-routing.module';
import { TableModule } from 'primeng/table';
import { PaymentPlanComponent } from './payment-plan/payment-plan.component';
import { PaymentPlanService } from './payment-plan/payment-plan.service';
import { PaymentService } from './payment/payment.service';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  imports: [
    CommonModule,
    BillingRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    CommonComponentsModule,

    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    TableModule,

    // Material Stuff
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDividerModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatStepperModule,
  ],
  declarations: [
    DashboardComponent,
    PaymentPlanComponent,
    PaymentComponent,
  ],
  exports: [
    DashboardComponent,
    PaymentPlanComponent,
    PaymentComponent,
    // Material Stuff
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatStepperModule,
  ],
  providers: [
    PaymentPlanService,
    PaymentService,
  ],
})
export class BillingModule {
}
