import { Component, Input } from '@angular/core';
import { FormControl } from '@angular/forms';

/**
 * FormErrorComponent
 * There is a very similar component in common.  The issue there is that one takes in a formGroup, as well as the property name to get the
 * form control.  That is absolutely fine, but when I started making each form input into it's own component, I didn't want to have to pass
 * around the entire form group if I didn't have to.  I tried to change the other one to just accept a formControl instead, but that
 * didn't work.  I will gladly refactor these together someday, or make the old one work with form controls if i have to.  I just did
 * this in the interest of keeping the inputs as thin as possible.
 */
@Component({
  selector: 'app-form-error',
  templateUrl: './form-error.component.html',
  styleUrls: ['./form-error.component.css'],
})
export class FormErrorComponent {

  @Input()
  control: FormControl;

  @Input()
  label: string;

  constructor() { }

  showErrorMessage(error: string): string {
    let message;
    switch (error) {
      case 'required':
        message = `${this.label} is required.`;
        break;
      case 'minlength':
        message = `${this.label} must be at least ${this.getValueFromErrorKey(error).requiredLength} characters long.`;
        break;
      case 'maxlength':
        message = `${this.label} must be at most ${this.getValueFromErrorKey(error).requiredLength} character(s) long.`;
        break;
      case 'email':
        message = `${this.label} must be an email address.`;
        break;
      case 'pattern':
        message = `${this.label} has an invalid format.`;
        break;
      case 'space':
        message = `${this.label} cannot contain any spaces.`;
        break;
      case 'emailAvailable':
      case 'usernameAvailable':
        message = `${this.label} is not available.`;
        break;
      case 'dateOfBirthValidator':
        message = `${this.label} ${this.control.value} has an invalid date format.`;
        break;
      default:
        console.error(`Unknown error code: ${error}`);
        break;
    }
    return message;
  }

  getValueFromErrorKey(error: string) {
    return this.control.errors[error];
  }

  get errorKeys(): Array<string> {
    return Object.keys(this.control.errors);
  }

}
