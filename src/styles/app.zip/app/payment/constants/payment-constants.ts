export class PaymentConstants {
  public static GET_PAYMENT_METHOD = 'api/payment-plan-type/calculated/list/application';
  public static GET_SAVED_BILLING_PROFILE = 'api/billing-profile/person';
  public static GET_APPLICATION_BY_ID = 'api/application/';
  public static LNP_GET_ZIP_CODE = 'api/util/usps/zip/';
  public static CARD_AVAILABILITY = 'api/billing-profile/availability';
  public static GET_STATE = 'api/insurance/states';
  public static EXPIRATION_MONTH = [
    '01/Jan',
    '02/Feb',
    '03/Mar',
    '04/Apr',
    '05/May',
    '06/June',
    '07/July',
    '08/Aug',
    '09/Sep',
    '10/Oct',
    '11/Nov',
    '12/Dec',
  ];
  public static paymentTypeID = {
    'visa': [4, 9],
    'master-card': [5, 10],
    'american-express': [6, 11],
    'discover': [7, 12],
  };

  public static APPLICANT_DETAILS_PAYMENT = {
    'application_firstName': '',
    'application_lastName': '',
    'application_address1': '',
    'application_address2': '',
    'application_city': '',
    'application_state': '',
    'application_zipCode': '',
    'application_phone': '',
  };
}
