import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../common/utils/util.service';
import { SecurityService } from '../security/security.service';
import { UserImpl } from '../security/user';
import { Product, ProductImpl } from './product';
import { Observable } from 'rxjs';
import { ProductDocument } from './product-documents/product-document';
import { ProductSummary } from './product-summary';


@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private requestURL = 'api/product';
  private jsonConvert: JsonConvert;


  constructor(private http: HttpClient,
    private securityService: SecurityService) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async getAllSummaryList(): Promise<Array<ProductSummary>> {
    const user: UserImpl = this.securityService.user;
    let productList: any;

    if (user.hasEmployeePermissions) { // Colonial superuser gets all applications
      productList = await this.http.get(`${this.requestURL}/colonial/list`).toPromise();
    } else if (user.isSteward) { // Steward gets applications of her clients
      productList = await this.http.get(`${this.requestURL}/list/agent/${user.agent.id}`).toPromise();
    } else { // Client only gets her applications
      productList = await this.http.get(`${this.requestURL}/list/person/${user.person.id}`).toPromise();
    }

    return this.jsonConvert.deserializeArray(productList, ProductSummary);
  }

  getProductOverview(id: number): Observable<Product> {
    return this.http.get(`${this.requestURL}/${id}`)
      .map((product: Product) => this.jsonConvert.deserialize(product, ProductImpl) as ProductImpl);
  }

  getProductDocuments(productId: Number): Observable<ProductDocument[]> {
    return this.http.get(`api/product-document?productId=${productId}`)
      .map((documents: ProductDocument[]) => this.jsonConvert.deserializeArray(documents, ProductDocument));
  }

  getRelatedProducts(productId: Number): Observable<Product[]> {
    return this.http.get(`${this.requestURL}/list/related/${productId}`)
      .map((products: Product[]) => this.jsonConvert.deserializeArray(products, ProductImpl));
  }

}
