import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../security/app.auth.guard';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { ProductRenewalComponent } from './product-renewal/product-renewal.component';
import { BondAndPoliciesListComponent } from './bond-and-policies-list/bond-and-policies-list.component';
import { ProductMaintenanceComponent } from './product-maintenance/product-maintenance.component';
import { ApplicationOverviewComponent } from './product-maintenance/application-overview/application-overview.component';
import { ProductEditComponent } from './product-maintenance/product-edit/product-edit.component';
import { UpdateClientProfileComponent } from './product-maintenance/update-client-profile/update-client-profile.component';

const routes: Routes = [
  { path: 'bonds-and-policies', component: BondAndPoliciesListComponent, canActivate: [AuthGuard] }, // default route of module
  { path: 'bonds-and-policies/:status', component: BondAndPoliciesListComponent, canActivate: [AuthGuard] }, // default route of module
  { path: 'product-overview', component: ProductOverviewComponent, canActivate: [AuthGuard] },
  { path: 'renew-product', component: ProductRenewalComponent, canActivate: [AuthGuard] },
  { path: 'product-maintenance', component: ProductMaintenanceComponent, canActivate: [AuthGuard] },
  { path: 'application-overview', component: ApplicationOverviewComponent, canActivate: [AuthGuard] },
  { path: 'product-edit', component: ProductEditComponent, canActivate: [AuthGuard] },
  { path: 'update-client-profile', component: UpdateClientProfileComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProductRoutingModule {

}
