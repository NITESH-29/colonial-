import { Pipe, PipeTransform } from '@angular/core';


@Pipe({ name: 'considerDotNotation' })
export class ConsiderDotNotationPipe implements PipeTransform {
  transform(data: any, fieldName: any): any {
    fieldName = fieldName as String;
    if (fieldName.indexOf('.') < 0) {
      return data[fieldName];
    } else {
      let returnData = data;
      const fieldNames = fieldName.split('.');
      for (let i = 0; i < fieldNames.length; i++) {
        returnData = returnData[fieldNames[i]];
      }
      return returnData;
    }
  }
}
