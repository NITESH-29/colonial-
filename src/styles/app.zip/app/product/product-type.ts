import { JsonObject, JsonProperty } from 'json2typescript';
import { LineOfBusiness } from '../enrollment/application/line-of-business';

export interface ProductType {
  id: number;
  name: string;
  code: string;
  lineOfBusiness: LineOfBusiness;
}

@JsonObject('ProductTypeImpl')
export class ProductTypeImpl implements ProductType {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('code', String, true)
  code: string = null;

  @JsonProperty('lineOfBusiness', LineOfBusiness, true)
  lineOfBusiness: LineOfBusiness = null;
}
