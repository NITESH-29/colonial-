import { CompanyOffice, CompanyOfficeImpl } from './company-office';
import { JsonObject, JsonProperty } from 'json2typescript';
import { Person, PersonImpl } from './person';
import { ClientDisplayType, ClientType } from '../user/client/client-data';

export interface Client {
  person: Person;
  companyOffice: CompanyOffice;
  referralCode: string;
  readonly username: string;
  readonly isCompany: boolean;
  readonly isPerson: boolean;
  readonly isNew: boolean;
  readonly id: number;
  readonly clientType: ClientType;
  readonly name: string;
  readonly email: string;
  readonly phone: string;
  readonly displayType: ClientDisplayType;
  readonly applicantPersonId: number;
}

@JsonObject('ClientImpl')
export class ClientImpl implements Client {
  @JsonProperty('person', PersonImpl, true)
  person: PersonImpl = new PersonImpl();

  @JsonProperty('companyOffice', CompanyOfficeImpl, true)
  companyOffice: CompanyOffice = new CompanyOfficeImpl();

  @JsonProperty('referralCode', String, true)
  referralCode: string = null;

  @JsonProperty('username', String, true)
  username: string = null;

  get isCompany(): boolean {
    return this.companyOffice && this.companyOffice.id !== null;
  }

  get isPerson(): boolean {
    return this.person && this.person.id !== null;
  }

  get isNew(): boolean {
    return this.id === null;
  }

  get id(): number {
    return this.isPerson ? this.person.id : this.companyOffice.id;
  }

  get clientType(): ClientType {
    return this.isCompany ? 'C' : 'P';
  }

  get name(): string {
    return this.isPerson ? this.person.fullName : this.companyOffice.company.name;
  }

  get email(): string {
    return this.isPerson ? this.person.email : this.companyOffice.email;
  }

  get phone(): string {
    return this.isPerson ? this.person.phone : this.companyOffice.phone;
  }

  get displayType(): ClientDisplayType {
    return this.clientType === 'P' ? 'Person' : 'Company';
  }

  get applicantPersonId(): number {
    let applicantPersonId = this.id;
    if (this.isCompany) {
      applicantPersonId = this.companyOffice.responsiblePerson.id;
    }
    return applicantPersonId;
  }
}
