import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../common/utils/util.service';
import { DashboardData, DashboardDataImpl } from './dashboard-data';
import { map } from 'rxjs/operators';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root',
})

export class DashboardService {
  private requestURL = 'api/enrollment/dashboard';
  private jsonConvert: JsonConvert;

  constructor(private http: HttpClient) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  downloadReports(userId: number, frmDate: string, toDate: string) {
    const headerOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/pdf',
    });

    const requestOptions = {
      headers: headerOptions,
      responseType: 'blob' as 'blob',
    };

    const todayDate = moment().format('DD_MM_YYYY_HH_mm_ss');

    this.http.get(`api/agentReport/${userId}?toDate=${toDate}&fromDate=${frmDate}&typeOfResponse=pdf`, requestOptions)
      .pipe(map((data: any) => {

        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(data, `Agent_Report_${todayDate}.pdf`);
          return;
        }

        const blob = new Blob([data], { type: 'application/pdf' });
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = `Agent_Report_${todayDate}.pdf`;
        link.dispatchEvent(new MouseEvent(`click`, {
          bubbles: true,
          cancelable: true,
          view: window,
        })
        );
        window.URL.revokeObjectURL(link.href);
      })).subscribe(
        data => { },
        error => { }
      );
  }

  async getApplicationStatuses(): Promise<DashboardData> {
    const applicationAndBondStatuses = await this.http.get(`${this.requestURL}`).toPromise();
    return this.jsonConvert.deserialize(applicationAndBondStatuses, DashboardDataImpl) as DashboardDataImpl;
  }
}
