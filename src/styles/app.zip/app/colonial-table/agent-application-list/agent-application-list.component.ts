import { Component, Input, ViewChild } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';
import { TableDefaultDetails } from '../../form-components/generic-table-search/table-default-details';
import { Subject } from 'rxjs/index';
import { AgentCourtApplicationsComponent } from './agent-court-applications/agent-court-applications.component';

@Component({
  selector: 'app-agent-application-list',
  templateUrl: './agent-application-list.component.html',
  styleUrls: ['./agent-application-list.component.scss'],
})
export class AgentApplicationListComponent {

  @Input()
  tableDefaultDetails: TableDefaultDetails;

  @ViewChild(AgentCourtApplicationsComponent) agentCourtApplicationsComponent: AgentCourtApplicationsComponent;
  mode = 'Court';

  tabs: string[] = [
    'Court',
    'Professional Liability',
  ];

  filtersEventSubject: Subject<any> = new Subject();

  constructor() {
  }

  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {
    this.switchMode(tabChangeEvent.tab.textLabel.toLocaleLowerCase());
  }

  switchMode(modeVal) {
    this.mode = modeVal;
  }

  emitFiltersSubject() {
    this.filtersEventSubject.next();
  }

}
