import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { ApplicationImpl } from '../application/application';
import { ApplicationService } from '../application/application.service';
import { AgentHandoffService } from './agent-handoff.service';
import { HandoffEmailForm } from '../application/handoff-email-form';

@Component({
  selector: 'app-agent-handoff',
  providers: [AgentHandoffService],
  templateUrl: './agent-handoff.component.html',
  styleUrls: ['./agent-handoff.component.scss'],
})
export class AgentHandoffComponent implements OnInit {
  returnUrl: string;
  emailApplicantForm: FormGroup;
  submitted = false;
  applicationId: number;
  application: ApplicationImpl;
  isExternalBond = true;
  applicantEmail: string;
  emailSubject: string;
  emailContent: string;
  handoffEmailForm: HandoffEmailForm;
  disableSubmit = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private snackbar: MatSnackBar,
    private applicationService: ApplicationService,
    private route: ActivatedRoute,
    private agentHandoffService: AgentHandoffService
  ) { }

  ngOnInit() {
    this.route.params.subscribe(
      async (params) => {
        if (params.id) {
          this.applicationId = +params.id;
          this.handoffEmailForm = await this.agentHandoffService.getEmailContents(this.applicationId);
          this.applicantEmail = this.handoffEmailForm.recipient;
          this.emailSubject = this.handoffEmailForm.subject;
          this.emailContent = this.handoffEmailForm.body;
          this.emailApplicantForm = this.fb.group(
            {
              optionalMessage: [''],
            }
          );
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'];
        }
      }
    );
  }

  async emailApplicant() {
    this.disableSubmit = true;
    this.submitted = true;
    await this.agentHandoffService.emailApplicantForHandOff(this.applicationId, this.emailApplicantForm.value.optionalMessage).toPromise();
    // await this.router.navigateByUrl('/dashboard');
    await this.router.navigateByUrl('/enrollment/applications');
  }

  async cancel() {
    await this.router.navigateByUrl(this.returnUrl);
  }
}
