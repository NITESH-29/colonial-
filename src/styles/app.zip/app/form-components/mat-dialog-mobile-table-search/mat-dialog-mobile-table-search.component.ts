import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { GenericTableSearchFormGroup } from '../generic-table-search/generic-table-search-form-group';
import { SearchObject } from '../searchbox-with-dropdown/search-object';

export interface MobileTableSearchDialogData {
  formGroup: GenericTableSearchFormGroup;
  searchObjects: SearchObject[];
  statusList: string[];
}

@Component({
  selector: 'app-mat-dialog-mobile-table-search',
  templateUrl: './mat-dialog-mobile-table-search.component.html',
  styleUrls: ['./mat-dialog-mobile-table-search.component.scss'],
})
export class MatDialogMobileTableSearchComponent implements OnInit {

  @Output()
  applyFilters: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(public dialogRef: MatDialogRef<MatDialogMobileTableSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: MobileTableSearchDialogData) {
  }

  ngOnInit() {
  }

  applyFiltersEvent() {
    this.applyFilters.emit(true);
    this.close();
  }

  cancelFiltersEvent() {
    this.applyFilters.emit(false);
    this.close();
  }

  close() {
    this.dialogRef.close();
  }
}
