import { JsonConverter, JsonCustomConvert } from 'json2typescript';
import * as moment_ from 'moment';

@JsonConverter
export class CustomDateConverter implements JsonCustomConvert<Date> {
  moment = moment_;

  serialize(date: Date): any {
    if (date) {
      return this.moment(date).format('YYYY-MM-DD') + 'T12:00:00.000+0000';
    }
    return null;
  }
  deserialize(date: any): any {
    if (date) {
      // return new Date(this.moment(date).utcOffset('+0000').format('YYYY-MM-DD'));
      return this.moment(date).toDate();
    }
    return null;
  }
}
