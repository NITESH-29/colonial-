import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSelectChange } from '@angular/material';


@Component({
  selector: 'app-mobile-table-tabs',
  templateUrl: './mobile-table-tabs.component.html',
  styleUrls: ['./mobile-table-tabs.component.css'],
})
export class MobileTableTabsComponent implements OnInit {

  @Input()
  label: string;

  @Input()
  tabs: string[];

  @Output()
  updateListType: EventEmitter<string> = new EventEmitter<string>();

  control: FormControl;

  constructor() {
  }

  ngOnInit() {
    this.control = new FormControl(this.tabs[0]);
  }

  updateList(event: MatSelectChange) {
    this.updateListType.emit(event.value);
  }

}
