import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { PasswordOperationResponse, PasswordTokenValidity, SecurityService } from '../security.service';
import { ValueMatchValidator } from '../../common/validators/value-match-validator';
import { Validators } from '@angular/forms';
import { AlertService } from '../../common/alert.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { PatternValidators } from '../../common/validators/pattern-validators';


@Component({
  selector: 'app-reset-password',
  providers: [AlertService],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
})

export class ResetPasswordComponent implements OnInit {
  resetPasswordForm: FormGroup;
  token: string;
  passwordResetFailed = false;
  disableSubmit = false;

  constructor(public fb: FormBuilder,
    private router: Router,
    private snackbar: MatSnackBar,
    private securityService: SecurityService,
    private activatedRoute: ActivatedRoute,
    public serviceHandler: ServiceHandler) {
  }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(async (route: Params) => {
      this.token = route['token'];

      const response: PasswordTokenValidity = await this.securityService.checkResetPasswordTokenValidity(this.token);
      if (!response.passwordTokenValid) {
        this.serviceHandler.showErrorMessage('Password reset token has expired, please request another.');
        this.router.navigateByUrl('/secure/forgot-password');
      }
      this.resetPasswordForm = this.fb.group(
        {
          password: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(62), PatternValidators.alphanumeric()]],
          passwordConfirm: ['', [Validators.required, Validators.minLength(10)]],
        },
        {
          validator: ValueMatchValidator.matchingValues('password', 'passwordConfirm'),
        }
      );
    });
  }

  resetPassword() {
    if (this.resetPasswordForm.valid) {
      this.disableSubmit = true;
      const { password, passwordConfirm } = this.resetPasswordForm.value;
      this.securityService.resetPassword(this.token, password, passwordConfirm)
        .subscribe((response: PasswordOperationResponse) => {
          if (response.passwordOperationSuccessful) {
            // todo route to homepage
            this.snackbar.open('Your password has been successfully reset.', null, {
              duration: 6000,
              panelClass: ['confirmation_snack_bar'],
            });
            this.securityService
              .login(response.username, password)
              .then(() => this.router.navigate(['/enrollment']));
          } else {
            this.passwordResetFailed = true;
            this.disableSubmit = false;
          }
          this.resetPasswordForm.reset();
        });
    } else {
      CommonUtilities.markAllTouched(this.resetPasswordForm);
      this.serviceHandler.showErrorMessage('Please fix validation errors before submitting.');
    }

  }

  get password(): FormControl {
    return this.resetPasswordForm.get('password') as FormControl;
  }

  get passwordConfirm(): FormControl {
    return this.resetPasswordForm.get('passwordConfirm') as FormControl;
  }

  get confirmPasswordErrorMessage(): string {
    return this.passwordConfirm.hasError('required') ? 'Confirm New Password is required.' :
      this.passwordConfirm.hasError('minlength') ? 'Confirm New Password must have minimum length of 10.' :
        this.passwordConfirm.hasError('valueMatch') ? 'Passwords do not match.' : '';
  }

  get displayPasswordLengthError(): boolean {
    return (this.password.hasError('minlength') || this.password.hasError('maxlength'))
      || (this.password.touched && this.password.value === '');
  }

  get displayAlphanumericError(): boolean {
    return (this.password.touched && this.password.hasError('pattern')) || (this.password.touched && this.password.value === '');
  }

  // Conditions driving dynamic styles in template
  get validLengthCondition(): boolean {
    return !this.displayPasswordLengthError && this.password.touched;
  }

  get validPatternCondition(): boolean {
    return !this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }

  get invalidLengthCondition(): boolean {
    return this.displayPasswordLengthError && this.password.touched;
  }

  get invalidPatternCondition(): boolean {
    return (this.displayAlphanumericError && this.password.touched) ||
      (this.password.touched && this.password.value === '');
  }
}
