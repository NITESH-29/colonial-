import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeliveryMethodSelectionComponent } from './delivery-method-selection.component';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCheckboxModule, MatFormFieldModule, MatInputModule, MatSelectModule } from '@angular/material';
import { AddressComponent } from '../address/address.component';
import { FieldErrorsComponent } from '../field-errors/field-errors.component';
import { Component } from '@angular/core';
import { PatternValidators } from '../validators/pattern-validators';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// To provide DeliveryMethodSelectionComponent with a deliveryMethodFormGroup
@Component({
  selector: 'app-test-delivery-method-selection',
  template: '<app-delivery-method-selection [deliveryMethodFormGroup]="fakeDelivery"></app-delivery-method-selection>',
})
class TestDeliveryMethodSelectionComponent {
  get fakeDelivery(): FormGroup {
    return new FormGroup({
      deliveryMethod: new FormControl(null,
        [Validators.required]),
      copyViaEmail: new FormControl(null),
      deliveryName: new FormControl(null),
      deliveryPhone: new FormControl(null, PatternValidators.phoneNumber()),
      deliveryAddress: new FormGroup({
        street1: new FormControl(null, Validators.maxLength(60)),
        street2: new FormControl(null, Validators.maxLength(60)),
        city: new FormControl(null, Validators.maxLength(30)),
        state: new FormControl(null),
        zipCode: new FormControl(null, PatternValidators.zipCode()),
      }),
    });
  }
}

describe('DeliveryMethodSelectionComponent', () => {
  let component: DeliveryMethodSelectionComponent;
  let fixture: ComponentFixture<TestDeliveryMethodSelectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        HttpClientTestingModule,
        FormsModule,
        ReactiveFormsModule,
        MatInputModule,
        MatFormFieldModule,
        MatSelectModule,
        MatCheckboxModule,
      ],
      declarations: [DeliveryMethodSelectionComponent, TestDeliveryMethodSelectionComponent, AddressComponent, FieldErrorsComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestDeliveryMethodSelectionComponent);
    component = fixture.debugElement.children[0].componentInstance as DeliveryMethodSelectionComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
