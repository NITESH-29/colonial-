import { Component, HostListener, OnInit } from '@angular/core';
import { CompanyModel, CompanyModelImpl } from '../models/company-model';
import { AgencyModel, AgencyModelImpl } from '../models/agency-model';
import { PersonBusinessService } from '../providers/person-business.service';
import { SecurityService } from '../../security/security.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

type DisplayMode = 'LOADING' | 'EDITING_AGENCY' | 'EDITING_FIRM' | 'EDITING_COMPANY' | 'ADDING_COMPANY';

@Component({
  selector: 'app-business-with-single-office',
  templateUrl: './business-with-single-office.component.html',
})
export class BusinessWithSingleOfficeComponent implements OnInit {
  displayMode: DisplayMode;

  private business: AgencyModel | CompanyModel;

  constructor(
    private personBusinessService: PersonBusinessService,
    private securityService: SecurityService,
    private route: ActivatedRoute,
    private location: Location
  ) { this.displayMode = 'LOADING'; }

  @HostListener('window:beforeunload', ['$event'])
  refresh($event) {
    return (false);
  }

  ngOnInit() {
    this.loadBusiness(this.route.snapshot.data['business']);
  }

  loadBusiness(business: AgencyModel | CompanyModel) {
    const user = this.securityService.user;

    this.business = business;

    if (business instanceof AgencyModelImpl) {
      if (user.hasAgentRole) {
        this.displayMode = 'EDITING_AGENCY';
      } else if (user.hasAttorneyRole) {
        this.displayMode = 'EDITING_FIRM';
      }
    } else if (business instanceof CompanyModelImpl) {
      this.displayMode = 'EDITING_COMPANY';
    } else {
      this.displayMode = 'ADDING_COMPANY';
      this.business = new CompanyModelImpl();
    }
  }

  goBack() {
    this.securityService.refreshCurrentUser().subscribe(() => this.location.back());
  }

  get agency(): AgencyModel {
    return this.business as AgencyModel;
  }

  get firm(): AgencyModel {
    return this.business as AgencyModel;
  }

  get company(): CompanyModel {
    return this.business as CompanyModel;
  }
}
