import { UsernamePassword } from '../username-password/username-password-form-group';
import { ClientFormData } from './client-form-data';

export interface UserFormData extends ClientFormData {
  usernamePassword: UsernamePassword;
}
