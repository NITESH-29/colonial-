import { JsonObject, JsonProperty } from 'json2typescript';
import { ChildQuestion, ChildQuestionImpl } from './child-question';
import { AnswerSummary, AnswerSummaryImpl } from './answer-summary';

export interface Answer extends AnswerSummary {
  childQuestions: Array<ChildQuestion>;
}

@JsonObject('AnswerImpl')
export class AnswerImpl extends AnswerSummaryImpl implements Answer {
  @JsonProperty('childQuestions', [ChildQuestionImpl], true)
  childQuestions: Array<ChildQuestion> = new Array<ChildQuestionImpl>();
}
