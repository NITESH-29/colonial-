import { JsonObject, JsonProperty, } from 'json2typescript';
import { Person, PersonImpl, } from '../common/person';
import { DateConverter } from '../common/utils/date-converter';
import { Auditable, AuditableObject, } from '../common/auditable-object';
import { UserRole, UserRoleImpl, } from './user-role';
import { BillingProfile, BillingProfileImpl, } from '../common/billing-profile/billing-profile';
import { Agent, AgentImpl, } from '../common/agent';

export interface User extends Auditable {
  id: number;
  username: string;
  loginCount: number;
  lastLogon: Date;
  invalidLoginCount: number;
  passwordResetToken: string;
  passwordResetExpiration: Date;
  deactivated: boolean;
  person: Person;
  userRoles: UserRole[];
  billingProfile: BillingProfile;
  password: string;
  isSteward: boolean;
  isCompany: boolean;
  companyOrPersonal: string;
  agent: Agent;
  hasRole(roleName: string): boolean;
}

@JsonObject('UserImpl')
export class UserImpl extends AuditableObject implements User {
  private roleNames: string[];

  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('username', String, true)
  username: string = null;

  @JsonProperty('loginCount', Number, true)
  loginCount: number = null;

  @JsonProperty('lastLogon', DateConverter, true)
  lastLogon: Date = null;

  @JsonProperty('invalidLoginCount', Number, true)
  invalidLoginCount: number = null;

  @JsonProperty('passwordResetToken', String, true)
  passwordResetToken: string = null;

  @JsonProperty('passwordResetExpiration', DateConverter, true)
  passwordResetExpiration: Date = null;

  @JsonProperty('deactivated', Boolean, true)
  deactivated: boolean = null;

  @JsonProperty('person', PersonImpl, true)
  person: Person = new PersonImpl();

  @JsonProperty('userRoles', [UserRoleImpl], true)
  userRoles: UserRole[] = [];

  @JsonProperty('billingProfile', BillingProfileImpl, true)
  billingProfile: BillingProfile = null;

  // for sending the password on a new account creation, not for receiving
  // server needs to not send on read
  @JsonProperty('password', String, true)
  password: string = null;

  @JsonProperty('isSteward', Boolean, true)
  isSteward: boolean = null;

  @JsonProperty('agent', AgentImpl, true)
  agent: Agent = null;

  get isCompany(): boolean {
    return this.person.companyOfficePersons.length > 0;
  }

  get companyOrPersonal(): string {
    return this.isCompany ? 'C' : 'P';
  }

  get hasAgentRole(): boolean {
    return this.hasRole('agent');
  }

  get hasAttorneyRole(): boolean {
    return this.hasRole('attorney');
  }

  get hasSuperuserRole(): boolean {
    return this.hasRole('superuser');
  }

  get hasAdminRole(): boolean {
    return this.hasRole('admin');
  }

  get hasEmployeeDefaultRole(): boolean {
    return this.hasRole('employee default');
  }

  get hasEmployeePlusRole(): boolean {
    return this.hasRole('employee plus');
  }

  get hasSuperEmployeeRole(): boolean {
    return this.hasRole('super employee');
  }

  /**
   * The following permissions getters are to know if we can display certain things that are available to multiple roles.
   * Superusers can do everything an admin can.
   */

  get hasAdminPermissions(): boolean {
    return this.hasSuperuserRole || this.hasAdminRole;
  }

  get hasSuperEmployeePermissions(): boolean {
    return this.hasAdminPermissions || this.hasSuperEmployeeRole;
  }

  get hasEmployeePlusPermissions(): boolean {
    return this.hasSuperEmployeePermissions || this.hasEmployeePlusRole;
  }

  get hasEmployeePermissions(): boolean {
    return this.hasEmployeePlusPermissions || this.hasEmployeeDefaultRole;
  }

  public hasRole(roleName: string): boolean {
    if (!this.roleNames) {
      this.roleNames = this.userRoles.map(ur => ur.userRoleRef.role);
    }

    return this.roleNames.includes(roleName);
  }
}
