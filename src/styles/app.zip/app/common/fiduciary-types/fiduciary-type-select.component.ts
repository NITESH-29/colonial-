import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-fiduciary-type-select',
  templateUrl: './fiduciary-type-select.component.html',
})
export class FiduciaryTypeSelectComponent {
  @Input() fiduciaryTypeFormGroup: FormGroup;

  fiduciaryTypes = ['Administrator', 'Executor', 'Personal Representative', 'Other'];

  trackByFiduciaryType(index: number, fiduciaryType: string): string {
    return fiduciaryType;
  }

  get fiduciaryType(): FormControl {
    return this.fiduciaryTypeFormGroup.get('fiduciaryType') as FormControl;
  }

  get otherFiduciaryType(): FormControl {
    return this.fiduciaryTypeFormGroup.get('otherFiduciaryType') as FormControl;
  }
}
