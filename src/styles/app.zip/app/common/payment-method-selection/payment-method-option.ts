import { PaymentChannelCode } from './payment_channel_code';
import { BillingProfileModel } from './billing-profile-model';
import { PaymentChannelType } from './payment_channel_type';
import { JsonObject } from 'json2typescript';
import * as moment from 'moment';

enum PaymentMethodOptionType { // Not const enum so we preserve the 'mapping' code.
  PAYMENT_CHANNEL_CODE = 'PCC',
  BILLING_PROFILE = 'BP',
}

const PAYMENT_METHOD_OPTION_TYPE_PAYMENT_CHANNEL_CODE = `${PaymentMethodOptionType.PAYMENT_CHANNEL_CODE}`;
const PAYMENT_METHOD_OPTION_TYPE_BILLING_PROFILE = `${PaymentMethodOptionType.BILLING_PROFILE}`;

/**
 * PaymentMethodOption describes an option managed by the paymentMethod select control.
 * It currently manages options:
 * - that reference an existing Billing Profile
 * - that allow a creation of a new Billing Profile
 */
@JsonObject('PaymentMethodOption')
export class PaymentMethodOption {
  optionValue: string; // The unique value that identifies the option. Not to be displayed to a user.
  optionLabel: string; // The text to be displayed to a user for the option.
  paymentMethodOptionType: PaymentMethodOptionType; // The 'type' of option.
  paymentChannelCode: PaymentChannelCode;
  enabled = true;
  unacceptableOptionMessage?: string; // If set, explanation as to why option is not acceptable.

  public static createPaymentChannelCodePaymentMethodOption(paymentChannelCode: PaymentChannelCode): PaymentMethodOption {
    let paymentMethodOption: PaymentMethodOption;
    const unacceptableOptionMessage = undefined;
    paymentMethodOption = Object.assign<PaymentMethodOption, Partial<PaymentMethodOption>>(new PaymentMethodOption(), {
      optionValue: PaymentMethodOption.createPaymentChannelCodePaymentMethodOptionValue(paymentChannelCode),
      optionLabel: paymentChannelCode.defaultDisplayText,
      paymentMethodOptionType: PaymentMethodOptionType.PAYMENT_CHANNEL_CODE,
      paymentChannelCode: paymentChannelCode,
      enabled: !unacceptableOptionMessage,
      unacceptableOptionMessage: unacceptableOptionMessage,
    });
    return paymentMethodOption;
  }

  public static createPaymentChannelCodePaymentMethodOptionValue(paymentChannelCode: PaymentChannelCode): string {
    let optionValue: string;
    optionValue = `${PAYMENT_METHOD_OPTION_TYPE_PAYMENT_CHANNEL_CODE}`
      + '_' + `${paymentChannelCode.persistenceId}`;
    return optionValue;
  }

  public static createBillingProfilePaymentMethodOption(billingProfileModel: BillingProfileModel): PaymentMethodOption {
    let paymentMethodOption: PaymentMethodOption;
    const unacceptableOptionMessage = this.getBillingProfileUnacceptableOptionMessage(billingProfileModel);
    let optionLabel: string;
    if (billingProfileModel.paymentChannelCode.isACH()) {
      optionLabel = `${billingProfileModel.paymentChannelCode.defaultDisplayText} (${billingProfileModel.achAccountNumber})`;
    } else if (billingProfileModel.paymentChannelCode.isCreditCard()) {
      optionLabel = `${billingProfileModel.paymentChannelCode.defaultDisplayText} (${billingProfileModel.cardNumber})`;
    } else {
      optionLabel = `${billingProfileModel.paymentChannelCode.defaultDisplayText}`;
    }
    paymentMethodOption = Object.assign<PaymentMethodOption, Partial<PaymentMethodOption>>(new PaymentMethodOption(), {
      optionValue: PaymentMethodOption.createBillingProfilePaymentMethodOptionValue(billingProfileModel),
      optionLabel: optionLabel,
      paymentMethodOptionType: PaymentMethodOptionType.BILLING_PROFILE,
      paymentChannelCode: billingProfileModel.paymentChannelCode,
      enabled: !unacceptableOptionMessage,
      unacceptableOptionMessage: unacceptableOptionMessage,
    });
    return paymentMethodOption;
  }

  public static createBillingProfilePaymentMethodOptionValue(billingProfileModel: BillingProfileModel): string {
    let optionValue: string;
    optionValue = `${PAYMENT_METHOD_OPTION_TYPE_BILLING_PROFILE}` +
      '_' + `${billingProfileModel.billingProfileId}` +
      '_' + `${billingProfileModel.paymentChannelCode.persistenceId}`;
    return optionValue;
  }

  public static getBillingProfileUnacceptableOptionMessage(billingProfileModel): string | undefined {
    let unacceptableOptionMessage;
    if (!!billingProfileModel.deactivationTimestamp) {
      unacceptableOptionMessage = 'Payment method is no longer available.';
    } else {
      if (billingProfileModel.paymentChannelCode.isCreditCard()) {
        const parsedDate = moment(billingProfileModel.cardExpiration, 'MM/YY', true);
        if (parsedDate.endOf('month').isBefore(moment())) {
          unacceptableOptionMessage = 'Credit Card has expired.';
        }
      }
    }
    return unacceptableOptionMessage;
  }

  /**
   * Extracts the PaymentMethodOptionType of an option value ('create payment method' or 'use payment method').
   * @param optionValue
   */
  public static extractOptionType(optionValue: string): PaymentMethodOptionType | null {
    let optionType: PaymentMethodOptionType = null;
    if (!!optionValue) {
      const tokens = optionValue.split('_');
      if (tokens.length > 0) {
        const optionTypeId = tokens[0];
        if (optionTypeId === PAYMENT_METHOD_OPTION_TYPE_PAYMENT_CHANNEL_CODE) {
          optionType = PaymentMethodOptionType.PAYMENT_CHANNEL_CODE;
        } else if (optionTypeId === PAYMENT_METHOD_OPTION_TYPE_BILLING_PROFILE) {
          optionType = PaymentMethodOptionType.BILLING_PROFILE;
        }
      }
    }
    return optionType;
  }

  /**
   * Extract the 'option identifier' value from the option value.
   * Either the:
   * - PaymentChannelCode for a 'create payment method' option.
   * - BillingProfileId for a 'use payment method' option.
   * @param optionValue to be examined.
   */
  public static extractOptionId(optionValue: string): string | null {
    let optionId: string | null = null;
    if (!!optionValue) {
      const tokens = optionValue.split('_');
      if (tokens.length > 0) {
        optionId = tokens[1];
      }
    }
    return optionId;
  }

  /**
   * Extract the PaymentChannelCode value from a BillingProfile option value.
   * @param optionValue to be examined.
   */
  public static extractBillingProfilePaymentChannelCode(optionValue: string): PaymentChannelCode | null {
    let paymentChannelCode: PaymentChannelCode | null = null;
    if (PaymentMethodOption.isBillingProfileOption(optionValue)) {
      const tokens = optionValue.split('_');
      if (tokens.length > 1) {
        const paymentChannelCodeId = tokens[2];
        paymentChannelCode = PaymentChannelCode.valueOf(paymentChannelCodeId);
      }
    }
    return paymentChannelCode;
  }

  /**
   * Extracts the BillingProfileId of a 'use payment method' option value.
   * @param optionValue
   */
  public static getBillingProfileId(optionValue: string): number | null {
    let billingProfileId: number | null = null;
    if (PaymentMethodOption.isBillingProfileOption(optionValue)) {
      const optionId = PaymentMethodOption.extractOptionId(optionValue);
      if (!!optionId) {
        billingProfileId = +optionId;
      }
    }
    return billingProfileId;
  }

  /**
   * Extracts the PaymentChannelCode of a 'create payment method' option value.
   * @param optionValue
   */
  public static getCreatePaymentChannelCode(optionValue: string): PaymentChannelCode | null {
    let paymentChannelCode: PaymentChannelCode | null = null;
    const optionType = PaymentMethodOption.extractOptionType(optionValue);
    if (optionType === PaymentMethodOptionType.PAYMENT_CHANNEL_CODE) {
      const paymentChannelCodePersistenceId = PaymentMethodOption.extractOptionId(optionValue);
      paymentChannelCode = PaymentChannelCode.valueOf(paymentChannelCodePersistenceId);
    }
    return paymentChannelCode;
  }

  public static isCreatePaymentChannelCodeOption(optionValue: string): boolean {
    let isOption: boolean;
    const paymentChannelCode: PaymentChannelCode = PaymentMethodOption.getCreatePaymentChannelCode(optionValue);
    isOption = !!paymentChannelCode;
    return isOption;
  }

  public static getCreateCreditCardPaymentChannelCode(optionValue: string): PaymentChannelCode | null {
    let paymentChannelCode: PaymentChannelCode = PaymentMethodOption.getCreatePaymentChannelCode(optionValue);
    if (!!paymentChannelCode) {
      if (!paymentChannelCode.isCreditCard()) {
        paymentChannelCode = null;
      }
    }
    return paymentChannelCode;
  }

  public static isCreateCreditCardOption(optionValue: string): boolean {
    let isOption: boolean;
    const paymentChannelCode: PaymentChannelCode = PaymentMethodOption.getCreatePaymentChannelCode(optionValue);
    if (!!paymentChannelCode) {
      isOption = paymentChannelCode.paymentChannelType === PaymentChannelType.CREDIT;
    } else {
      isOption = false;
    }
    return isOption;
  }

  public static isCreateACHOption(optionValue: string): boolean {
    let isOption: boolean;
    const paymentChannelCode: PaymentChannelCode = PaymentMethodOption.getCreatePaymentChannelCode(optionValue);
    if (!!paymentChannelCode) {
      isOption = paymentChannelCode.paymentChannelType === PaymentChannelType.ACH;
    } else {
      isOption = false;
    }
    return isOption;
  }

  public static isBillingProfileOption(optionValue: string): boolean {
    let isOption: boolean;
    const optionType = PaymentMethodOption.extractOptionType(optionValue);
    isOption = optionType === PaymentMethodOptionType.BILLING_PROFILE;
    return isOption;
  }

  public static isAchBillingProfileOption(optionValue: string): boolean {
    let isOption = false;
    const billingProfilePaymentChannelCode = PaymentMethodOption.extractBillingProfilePaymentChannelCode(optionValue);
    if (!!billingProfilePaymentChannelCode) {
      isOption = billingProfilePaymentChannelCode === PaymentChannelCode.ACH;
    }
    return isOption;
  }

  public getOptionId(): string {
    return PaymentMethodOption.extractOptionId(this.optionValue);
  }

  public isPaymentChannelCodeOption(): boolean {
    return PaymentMethodOption.isCreatePaymentChannelCodeOption(this.optionValue);
  }

  public isBillingProfileOption(): boolean {
    return PaymentMethodOption.isBillingProfileOption(this.optionValue);
  }
}
