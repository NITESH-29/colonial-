import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SearchObject } from '../searchbox-with-dropdown/search-object';
import { GenericTableSearchFormGroup } from './generic-table-search-form-group';

@Component({
  selector: 'app-generic-table-search',
  templateUrl: './generic-table-search.component.html',
  styleUrls: ['./generic-table-search.component.scss'],
})
export class GenericTableSearchComponent implements OnInit {

  @Input()
  formGroup: GenericTableSearchFormGroup;

  @Input()
  searchObjects: SearchObject[];

  @Output()
  updateSearchEvent: EventEmitter<void> = new EventEmitter<void>();

  @Input()
  statusList: string[];

  constructor() {
  }

  updateList() {
    this.updateSearchEvent.emit();
  }

  ngOnInit() {
  }

}
