import { Person } from '../../common/person';

export interface BusinessOfficePersonInformation extends Person {
  title?: string;
}
