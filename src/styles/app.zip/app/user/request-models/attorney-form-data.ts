import { BusinessOfficePersonInformation } from '../business-office-person-information/business-office-person-information';
import { UsernamePassword } from '../username-password/username-password-form-group';
import { FirmAndOfficeInformation } from '../firm-and-office-information/firm-and-office-information';

export interface AttorneyFormData {
  personalInformation: BusinessOfficePersonInformation;
  firmAndOfficeInformation: FirmAndOfficeInformation;
  usernamePassword: UsernamePassword;
  statesPracticedIn: string[];
}
