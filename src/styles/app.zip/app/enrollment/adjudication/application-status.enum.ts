/**
 * We do a lot with status codes.
 */
export enum ApplicationStatus {
  SUBMITTED = 'Submitted',
  IN_PROGRESS = 'In Progress',
  COMPLETED = 'Completed',
  DECLINED = 'Declined',
  HOLD = 'Hold',
  SOFT_HOLD = 'Soft Hold',
  CLOSED = 'Closed',
}
