import { JsonObject, JsonProperty } from 'json2typescript';
import { CurrencyConverter } from '../../common/utils/currency-converter';
import { ApplicationData, ApplicationDataImpl } from './court/model/application-data';
import { DynamicQuestion, DynamicQuestionImpl } from './court/model/common/dynamic-question';

export interface PnlApplicationData extends ApplicationData {
  state: string;
  primaryService: string;
  businessDetails: Array<DynamicQuestion>;
  deductible: string;
  fraudWarning: string;

}

@JsonObject('PnlApplicationDataImpl')
export class PnlApplicationDataImpl extends ApplicationDataImpl implements PnlApplicationData {
  @JsonProperty('state', String, true)
  state: string = null;

  @JsonProperty('primaryService', String, true)
  primaryService: string = null;

  @JsonProperty('businessDetails', [DynamicQuestionImpl], true)
  businessDetails: Array<DynamicQuestion> = new Array<DynamicQuestionImpl>();

  @JsonProperty('deductible', CurrencyConverter, true)
  deductible: string = null;

  @JsonProperty('fraudWarning', String, true)
  fraudWarning: string = null;
}
