import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { SecurityService } from '../../security/security.service';
import { Client, ClientImpl } from '../../common/client';
import { CompanyOfficeImpl } from '../../common/company-office';
import { catchError, map } from 'rxjs/operators';
import { AbstractService } from '../../common/services/abstract-service';
import { JsonConvertService } from '../../common/utils/json-convert.service';
import { JsonConvert } from 'json2typescript';
import { PersonImpl } from '../../common/person';
import { Page, Pageable, PageableConverter, PageImpl } from '../../common/pagination';
import { ClientData, ClientDataImpl, ClientType } from './client-data';
import { UserImpl } from '../../security/user';
import { of } from 'rxjs';
import { ClientExtractor } from '../../common/utils/client-extractor';
import { CompanyClientOfPerson, CompanyClientOfPersonImpl } from './company-client-of-person';
import { ClientExistenceResponse, ClientExistenceResponseImpl } from './existence-details/client-existence-response';
import { API_URL } from 'src/app/ibond/constant/i-bond-constant';

@Injectable()
export class ClientService extends AbstractService {
  jsonConvert: JsonConvert;

  constructor(
    private http: HttpClient,
    private serviceHandler: ServiceHandler,
    private securityService: SecurityService,
    jsonConvertService: JsonConvertService
  ) {
    super();
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  requestURL(path: string = ''): string {
    return super.requestURL('/client' + path);
  }

  async getClients(pageable: Pageable, onlyPersons: boolean = false, onlyCompanyOffices: boolean = false, searchParams: any):
    Promise<Page<ClientData>> {
    const user = this.securityService.user;
    const pageableParams = PageableConverter.toPageableRequest(pageable);
    const params: ClientPageRequestParams = {
      agentId: user.agent && user.agent.id && user.agent.id.toString(),
      onlyPersons: onlyPersons.toString(),
      onlyCompanyOffices: onlyCompanyOffices.toString(),
      page: pageableParams.params.page,
      size: pageableParams.params.size,
    };
    if (user.hasEmployeePermissions) {
      delete params.agentId;
    }
    if (pageableParams.params.sort) {
      params.sort = pageableParams.params.sort;
    }
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam] && searchParam !== 'startDate' && searchParam !== 'endDate') {
        params[searchParam] = searchParams[searchParam];
      }
    }
    const clientPage = await this.http.get<Page<ClientData>>(this.requestURL(), { params } as any).toPromise();
    const deserializedPage = this.jsonConvert.deserialize(clientPage, PageImpl) as Page<ClientDataImpl>;
    deserializedPage.content = this.jsonConvert.deserializeArray(deserializedPage.content, ClientDataImpl) as ClientDataImpl[];
    return deserializedPage;
  }

  getAllClientsFor(user: UserImpl, skipCompanies: boolean = false): Observable<ClientData[]> {
    const agentId = user.agent && user.agent.id;
    return (agentId)
      ? this.http.get<ClientData[]>(this.requestURL(`/list/${agentId}`))
        .pipe(
          map(cds => this.jsonConvert.deserializeArray(cds, ClientDataImpl)))
      : of(ClientExtractor.getClientListFromUser(user, skipCompanies));
  }

  getClientById(clientType: ClientType, clientId: number): Observable<ClientImpl> {
    return this.http.get<ClientImpl>(`${this.requestURL()}/${clientType}/${clientId}`).pipe(
      catchError(this.serviceHandler.handleError.bind(this.serviceHandler)),
      map(this.deserializeClient.bind(this))
    );
  }

  companyClientOf(personId: number): Observable<CompanyClientOfPerson> {
    return this.http.get<CompanyClientOfPerson>(this.requestURL(`/${personId}/company-client`)).pipe(
      map(json => this.jsonConvert.deserializeObject(json, CompanyClientOfPersonImpl))
    );
  }

  private deserializeClient(data: Client): ClientImpl {
    const client = new ClientImpl();
    if (data.person) {
      client.person = this.jsonConvert.deserialize(data.person, PersonImpl) as PersonImpl;
    }
    if (data.companyOffice) {
      client.companyOffice = this.jsonConvert.deserialize(data.companyOffice, CompanyOfficeImpl) as CompanyOfficeImpl;
    }
    client.username = data.username;
    return client;
  }

  async saveClient(client: Client, agentId: number): Promise<Client> {
    if (client.isNew) {
      const json = this.jsonConvert.serialize(client);
      const createdClient = await this.http.post<ClientImpl>(`${this.requestURL()}/${agentId}`, json).toPromise();
      this.serviceHandler.handleConfirm('Client Record Created');
      return this.jsonConvert.deserialize(createdClient, ClientImpl) as ClientImpl;
    } else {
      const json = this.jsonConvert.serialize(client);
      const updatedClientResponse = await this.http.put<ClientImpl>(`${this.requestURL()}/${agentId}`, json).toPromise();
      this.serviceHandler.handleConfirm('Client Record Updated');
      return this.jsonConvert.deserialize(updatedClientResponse, ClientImpl) as ClientImpl;
    }
  }

  saveClientData(_payload, agentId: number): Observable<any> {
    return this.http.post(`${this.requestURL()}/${agentId}`, _payload);
  }

  updateClientData(_payload, agentId: number): Observable<any> {
    return this.http.put(`${this.requestURL()}/${agentId}`, _payload);
  }

  getClient(clientType: ClientType, clientId: number): Observable<any> {
    return this.http.get(`${this.requestURL()}/${clientType}/${clientId}`);
  }

  getClientInfoOnType(_accountType, _id: number): Observable<any> {
    const URL = `${API_URL.CLIENT_INFO}${_accountType}/${_id}`;
    return this.http.get(URL);
  }

  deleteClient(_clientType, _clientId): Observable<any> {
    if (_clientType === 'P') {
      const URL = `${API_URL.DELETE_PERSONAL}${_clientId}`;
      return this.http.delete(URL);
    } else if (_clientType === 'C') {
      const URL = `${API_URL.DELETE_COMPANY}${_clientId}`;
      return this.http.delete(URL);
    }
  }

  getZipCodeFromAddress(zipCode): Observable<any> {
    const URL = `${API_URL.ZIP_AVAILABILITY_CHECK}${zipCode}`;
    return this.http.get(URL);
  }

  async getClientExistenceDetails(agentId: number, personEmail?: string, companyOfficeEmail?: string): Promise<ClientExistenceResponse> {
    let params: HttpParams = new HttpParams();
    if (personEmail) {
      params = params.set('personEmail', personEmail);
    }
    if (companyOfficeEmail) {
      params = params.set('companyOfficeEmail', companyOfficeEmail);
    }
    const response = await this.http.get(`${this.requestURL()}/existence-details/${agentId}`, { params }).toPromise();
    return this.jsonConvert.deserialize(response, ClientExistenceResponseImpl) as ClientExistenceResponse;
  }
}

interface ClientPageRequestParams {
  agentId: string | string[];
  onlyPersons: string | string[];
  onlyCompanyOffices: string | string[];
  page: string | string[];
  size: string | string[];
  sort?: string | string[];
}
