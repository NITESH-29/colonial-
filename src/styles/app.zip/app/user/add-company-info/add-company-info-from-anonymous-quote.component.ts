import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BusinessOfficeInformationFormGroup } from '../business-office-information/business-office-information-form-group';
import { PersonBusinessService } from '../providers/person-business.service';
import { CompanyModel, CompanyModelImpl } from '../models/company-model';
import { CompanyOfficeModel } from '../models/company-office-model';
import { CourtBondFacilitationService } from '../../enrollment/facilitation/court-bond-facilitation.service';
import { SecurityService } from '../../security/security.service';

@Component({
  selector: 'app-add-company-info-from-anonymous-quote',
  templateUrl: './add-company-info-from-anonymous-quote.component.html',
  styleUrls: ['./add-company-info-from-anonymous-quote.component.css'],
})
export class AddCompanyInfoFromAnonymousQuoteComponent implements OnInit {
  @Input()
  personId: number;

  @Output()
  companyInfoAdded: EventEmitter<number> = new EventEmitter<number>();

  @Output()
  canceled: EventEmitter<void> = new EventEmitter<void>();

  companyInfoFormGroup: BusinessOfficeInformationFormGroup;

  firstName: string;
  lastName: string;
  titleLabel: string;

  constructor(
    private personBusinessService: PersonBusinessService,
    private courtBondFacilitationService: CourtBondFacilitationService,
    private securityService: SecurityService
  ) { }

  ngOnInit() {
    const anonymousQuote = this.courtBondFacilitationService.getAnonymousQuote();
    const { firstName, lastName, companyName } = anonymousQuote;
    this.firstName = firstName;
    this.lastName = lastName;
    this.titleLabel = `${firstName}'s Title at ${companyName}`;
    this.companyInfoFormGroup = new BusinessOfficeInformationFormGroup();
    this.companyInfoFormGroup.name.patchValue(companyName);
  }

  async save() {
    const companyOffice: CompanyOfficeModel = this.companyInfoFormGroup.getRawValue();
    const { agent } = this.securityService.user;
    if (agent) {
      companyOffice.agentId = agent.id;
    }
    const company: CompanyModel = new CompanyModelImpl();
    company.name = companyOffice.name;
    companyOffice.officeType = 'Main';
    company.companyOffices.push(companyOffice);
    const response: CompanyModel = await this.personBusinessService.createCompany(company, this.personId);
    this.companyInfoAdded.emit(response.companyOffices[0].id);
  }
}
