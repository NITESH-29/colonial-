export class AgreementConstants {
  public static VA_FIDUCIARY = [
    {
      text: `The maker of the foregoing statement hereby authorizes Colonial Surety Company (the “Surety”) to
             confirm credit and to investigate all other statements made but not limited to this application on/by
             any and all companies, stockholders, spouses and for listed indemnitors and hereby release and authorize
             the Surety to make such inquiries. The Undersigned and each of them hereby certifies that each statement
             contained herein is true and that this statement is made for the purpose of inducing the Surety to execute
             or continue certain bonds or undertakings. In consideration of the execution of certain bond or bonds before
             or after this date (collectively, the “Bonds”) by the Surety, the undersigned indemnitors (the “Indemnitors”)
             hereby agree to severally and jointly be liable for payment to the Surety of any defaults and expenses,
             including attorneys’ fees, incurred by the Surety as a result of any claim incurred under the Bonds.`,
    },
    {
      text: `To pay the Surety in advance the initial premium and thereafter pay in advance such additional premiums
             as may become due until the Surety is legally discharged and released of all liability under said bond and
             evidence of such discharge and release satisfactory to the Surety.`,
    },
    {
      text: `It is understood and agreed that the first year's premium is FULLY EARNED UPON issuance of the bond
             AND IS NOT REFUNDABLE. This application is subject to an underwriting credit and class review. We reserve
             the right to decline bond issuance for any reason.`,
    },
    {
      text: `Indemnitors shall immediately notify Surety in writing of any claim relating to any Bonds. Surety shall
             have the right to adjust, settle or compromise any claim.`,
    },
    {
      text: `Surety’s decision to adjust, settle or compromise any claim shall be final and binding upon the Indemnitors.
             Immediately upon demand by Surety, the Indemnitors shall deposit with Surety funds, as collateral security, in an
             amount Surety, in its sole and absolute discretion, deems necessary at the time of said demand to protect Surety
             from actual or anticipated loss. Surety shall be entitled to apply any collateral security held by it under this
             agreement (the “Agreement”) or any collateral security agreement between it and any of the Indemnitors to the
             satisfaction of or in reimbursement of Surety as a result of its satisfaction of any claim and to the direct payment
             of or reimbursement to itself of any loss or expense. The Indemnitors acknowledge and agree that their failure to
             immediately deposit with Surety any sums demanded under this section shall cause irreparable harm to Surety for which
             it has no adequate remedy at law. Indemnitors agree and shall stipulate in any legal proceeding that Surety is entitled
             to injunctive relief for specific performance of said collateral deposit obligation and do hereby expressly waive and
             relinquish any claims or defenses to the contrary.`,
    },
    {
      text: `This Agreement may only be modified by a written rider signed by an officer of Surety.`,
    },
    {
      text: `The Indemnitors submit to the jurisdiction of the state and federal courts situated in New York, waiving any
             defenses of lack of personal jurisdiction and waiving venue arguments, including forum non conveniens, in any action
             brought by Surety in the State of New York. Surety reserves the right to bring an action in any state where an Indemnitor
             has substantial contacts or where a project covered by a Bond subject to this Agreement is located or where a claimant
             brings suit against Surety on a Bond covered by this Agreement and Indemnitors agree to submit to the jurisdiction of
             the courts in such state. In any action by Surety against the Indemnitors, or any of them, each agrees that service of
             process may be made on any one of them and will be effective as to all of the Indemnitors. This Agreement shall be governed
             by the laws of the State of New York, without regard to conflicts of laws principles. Separate suits or proceedings may be
             brought by Surety on this Agreement as causes of action accrue.`,
    },
    {
      text: `THE INDEMNITORS HEREBY KNOWINGLY AND VOLUNTARILY WAIVE TRIAL BY JURY IN ANY ACTION OR PROCEEDING ARISING OUT OF THIS
             AGREEMENT.`,
    },
  ];

  public static PO = [
    {
      text: `The maker of the foregoing statement hereby authorizes Colonial Surety Company (the “Surety”) to confirm credit and to
             investigate all other statements made but not limited to this application on/by any and all companies, stockholders, spouses
             and for listed indemnitors and hereby release and authorize the Surety to make such inquiries. The Undersigned and each of
             them hereby certifies that each statement contained herein is true and that this statement is made for the purpose of inducing
             the Surety to execute or continue certain bonds or undertakings. In consideration of the execution of certain bond or bonds
             before or after this date (collectively, the “Bonds”) by the Surety, the undersigned indemnitors (the “Indemnitors”) hereby
             agree to severally and jointly be liable for payment to the Surety of any defaults and expenses, including attorneys’ fees,
             incurred by the Surety as a result of any claim incurred under the Bonds.`,
    },
    {
      text: `To pay the Surety in advance the initial premium and thereafter pay in advance such additional premiums as may become
             due until the Surety is legally discharged and released of all liability under said bond and evidence of such discharge and
             release satisfactory to the Surety.`,
    },
    {
      text: `It is understood and agreed that the first year's premium is FULLY EARNED UPON issuance of the bond AND IS NOT
             REFUNDABLE. This application is subject to an underwriting credit and class review. We reserve the right to decline bond
             issuance for any reason.`,
    },
    {
      text: `Indemnitors shall immediately notify Surety in writing of any claim relating to any Bonds. Surety shall have the right
             to adjust, settle or compromise any claim.`,
    },
    {
      text: `Surety’s decision to adjust, settle or compromise any claim shall be final and binding upon the Indemnitors.
             Immediately upon demand by Surety, the Indemnitors shall deposit with Surety funds, as collateral security, in an amount
             Surety, in its sole and absolute discretion, deems necessary at the time of said demand to protect Surety from actual or
             anticipated loss. Surety shall be entitled to apply any collateral security held by it under this agreement (the “Agreement”)
             or any collateral security agreement between it and any of the Indemnitors to the satisfaction of or in reimbursement of Surety
             as a result of its satisfaction of any claim and to the direct payment of or reimbursement to itself of any loss or expense.
             The Indemnitors acknowledge and agree that their failure to immediately deposit with Surety any sums demanded under this
             section shall cause irreparable harm to Surety for which it has no adequate remedy at law. Indemnitors agree and shall
             stipulate in any legal proceeding that Surety is entitled to injunctive relief for specific performance of said collateral
             deposit obligation and do hereby expressly waive and relinquish any claims or defenses to the contrary.`,
    },
    {
      text: `This Agreement may only be modified by a written rider signed by an officer of Surety.`,
    },
    {
      text: `The Indemnitors submit to the jurisdiction of the state and federal courts situated in New York, waiving any
             defenses of lack of personal jurisdiction and waiving venue arguments, including forum non conveniens, in any action
             brought by Surety in the State of New York. Surety reserves the right to bring an action in any state where an Indemnitor
             has substantial contacts or where a project covered by a Bond subject to this Agreement is located or where a claimant brings
             suit against Surety on a Bond covered by this Agreement and Indemnitors agree to submit to the jurisdiction of the courts in
             such state. In any action by Surety against the Indemnitors, or any of them, each agrees that service of process may be made
             on any one of them and will be effective as to all of the Indemnitors. This Agreement shall be governed by the laws of the
             State of New York, without regard to conflicts of laws principles. Separate suits or proceedings may be brought by Surety on
             this Agreement as causes of action accrue.`,
    },
    {
      text: `THE INDEMNITORS HEREBY KNOWINGLY AND VOLUNTARILY WAIVE TRIAL BY JURY IN ANY ACTION OR PROCEEDING ARISING OUT OF
             THIS AGREEMENT.`,
    },
  ];
  public static SHORT_FORM_AGREEMENT = [
    {
      text:
        `In consideration of the execution by Colonial Surety Company (“Colonial”) of the bond applied for in
         this application, including all renewals of the bond (collectively “the Bonds”), the undersigned
          indemnitor(s) agree, jointly and severally, to indemnify Colonial against all loss, liability, costs,
           damages, and attorneys’ fees which Colonial may sustain or incur by reason or in consequence of having executed the Bonds.`,
    },

  ];
  public static LONG_FORM_AGREEMENT = [
    {
      text:
        `The maker of the foregoing application hereby authorizes Colonial Surety Company
        (the "Surety") to confirm credit and to investigate all other statements made but not
         limited to this application on/by any and all companies and listed indemnitors, and hereby
          release and authorize the Surety to make such inquiries. The undersigned and each of them
           hereby certifies that each statement contained herein is true and that this statement is
            made for the purpose of inducing the Surety to execute or continue certain bonds or
             undertakings. In consideration of the execution of certain bond or bonds, including
              all renewals, before or after this date (collectively, the "Bonds") by the Surety, the
               undersigned indemnitors (the "Indemnitors") hereby agree to severally and jointly be
                liable for payment to the Surety of any losses, costs, and expenses, including attorneys’
                 fees, incurred by the Surety in connection with the Bonds and/or Surety’s enforcement
                  of this agreement (the “Agreement”).`,
    },
    {
      text: `Indemnitors agree to pay the Surety in advance the initial premium and thereafter pay in
       advance such additional premiums as may become due until the Surety is legally discharged and
        released of all liability under the Bonds  and evidence of such discharge and release satisfactory
         to the Surety.`,
    },
    {
      text: `It is understood and agreed that the first year's premium is FULLY EARNED UPON issuance of the
       Bonds AND IS NOT REFUNDABLE. This application is subject to an underwriting credit and class review.
        Surety reserves the right to decline bond issuance for any reason.`,
    },
    {
      text: `Indemnitors shall immediately notify Surety in writing of any claim relating to any Bonds.
       Surety shall have the right to adjust, settle or compromise any claim.`,
    },
    {
      text: `Surety's decision to adjust, settle or compromise any claim shall be final and binding
       upon the Indemnitors. Immediately upon demand by Surety, the Indemnitors shall deposit with
        Surety funds, as collateral security, in an amount Surety, in its sole and absolute discretion,
         deems necessary at the time of said demand to protect Surety from actual or anticipated loss.
          Surety shall be entitled to apply any collateral security held by it under this Agreement or
           any collateral security agreement between it and any of the Indemnitors to the satisfaction
            of or in reimbursement of Surety as a result of its satisfaction of any claim and to the
             direct payment of or reimbursement to itself of any loss or expense. The Indemnitors acknowledge
              and agree that their failure to immediately deposit with Surety any sums demanded under this
               section shall cause irreparable harm to Surety for which it has no adequate remedy at law.
                Indemnitors agree and shall stipulate in any legal proceeding that Surety is entitled to
                 injunctive relief for specific performance of said collateral deposit obligation and do
                  hereby expressly waive and relinquish any claims or defenses to the contrary.`,
    },
    {
      text: `This Agreement may only be modified by a written rider signed by an officer of Surety.`,
    },
    {
      text: `The Indemnitors submit to the jurisdiction of the state and federal courts situated in New York,
       waiving any defenses of lack of personal jurisdiction and waiving venue arguments, including forum non
        conveniens, in any action brought by Surety in the State of New York. Surety reserves the right to
         bring an action in any state where an Indemnitor has substantial contacts or where a project covered
          by a Bond subject to this Agreement is located or where a claimant brings suit against Surety on a
           Bond covered by this Agreement and Indemnitors agree to submit to the jurisdiction of the courts
            in such state. In any action by Surety against the Indemnitors, or any of them, each agrees that
             service of process may be made on any one of them and will be effective as to all of the
              Indemnitors. This Agreement shall be governed by the laws of the State of New York, without
               regard to conflicts of laws principles. Separate suits or proceedings may be brought by
                Surety on this Agreement as causes of action accrue.`,
    },
    {
      text: `THE INDEMNITORS HEREBY KNOWINGLY AND VOLUNTARILY WAIVE TRIAL BY JURY IN ANY ACTION OR PROCEEDING
       ARISING OUT OF THIS AGREEMENT.`,
    },
  ];
  public static NOTARY = [];
  public static EMPLOYEE_DISHONESTY = [
    {
      text: `IN ORDER TO PROTECT YOU AND YOUR EMPLOYEES AGAINST UNJUSTIFIED ALLEGATIONS OF DISHONESTY, THE EMPLOYEE MUST BE
             CONVICTED BEFORE COVERAGE WILL APPLY.  The undersigned warrants no previous bond losses, the truth and accuracy of all
             the above information.`,
    },
  ];
  public static JANITORIAL = [
    {
      text: `IN ORDER TO PROTECT YOU AND YOUR EMPLOYEES AGAINST UNJUSTIFIED ALLEGATIONS OF DISHONESTY, THE EMPLOYEE MUST BE
             CONVICTED BEFORE COVERAGE WILL APPLY.  The undersigned warrants no previous bond losses, the truth and accuracy of all
             the above information.`,
    },
  ];
  public static LOST_INSTRUMENT = [
    {
      text: `The maker of the foregoing statement hereby authorizes Colonial Surety Company (the “Surety”) to confirm credit
             and to investigate all other statements made but not limited to this application on/by any and all companies, stockholders,
             spouses and for listed indemnitors and hereby release and authorize the Surety to make such inquiries. The Undersigned and
             each of them hereby certifies that each statement contained herein is true and that this statement is made for the purpose
             of inducing the Surety to execute or continue certain bonds or undertakings. In consideration of the execution of certain
             bond or bonds before or after this date (collectively, the “Bonds”) by the Surety, the undersigned indemnitors
             (the “Indemnitors”) hereby agree to severally and jointly be liable for payment to the Surety of any defaults and expenses,
             including attorneys’ fees, incurred by the Surety as a result of any claim incurred under the Bonds.`,
    },
    {
      text: `To pay the Surety in advance the initial premium and thereafter pay in advance such additional premiums as may become
             due until the Surety is legally discharged and released of all liability under said bond and evidence of such discharge and
             release satisfactory to the Surety.`,
    },
    {
      text: `It is understood and agreed that the first year's premium is FULLY EARNED UPON issuance of the bond AND IS NOT
             REFUNDABLE. This application is subject to an underwriting credit and class review. We reserve the right to decline bond
             issuance for any reason.`,
    },
    {
      text: `Indemnitors shall immediately notify Surety in writing of any claim relating to any Bonds. Surety shall have the
             right to adjust, settle or compromise any claim.`,
    },
    {
      text: `Surety’s decision to adjust, settle or compromise any claim shall be final and binding upon the Indemnitors.
             Immediately upon demand by Surety, the Indemnitors shall deposit with Surety funds, as collateral security, in an amount
             Surety, in its sole and absolute discretion, deems necessary at the time of said demand to protect Surety from actual or
             anticipated loss. Surety shall be entitled to apply any collateral security held by it under this agreement
             (the “Agreement”) or any collateral security agreement between it and any of the Indemnitors to the satisfaction of or in
             reimbursement of Surety as a result of its satisfaction of any claim and to the direct payment of or reimbursement to
             itself of any loss or expense. The Indemnitors acknowledge and agree that their failure to immediately deposit with Surety
             any sums demanded under this section shall cause irreparable harm to Surety for which it has no adequate remedy at law.
             Indemnitors agree and shall stipulate in any legal proceeding that Surety is entitled to injunctive relief for specific
             performance of said collateral deposit obligation and do hereby expressly waive and relinquish any claims or defenses to
             the contrary.`,
    },
    {
      text: `This Agreement may only be modified by a written rider signed by an officer of Surety.`,
    },
    {
      text: `The Indemnitors submit to the jurisdiction of the state and federal courts situated in New York, waiving any defenses
             of lack of personal jurisdiction and waiving venue arguments, including forum non conveniens, in any action brought by
             Surety in the State of New York. Surety reserves the right to bring an action in any state where an Indemnitor has
             substantial contacts or where a project covered by a Bond subject to this Agreement is located or where a claimant brings
             suit against Surety on a Bond covered by this Agreement and Indemnitors agree to submit to the jurisdiction of the courts
             in such state. In any action by Surety against the Indemnitors, or any of them, each agrees that service of process may be
             made on any one of them and will be effective as to all of the Indemnitors. This Agreement shall be governed by the laws
             of the State of New York, without regard to conflicts of laws principles. Separate suits or proceedings may be brought by
             Surety on this Agreement as causes of action accrue.`,
    },
    {
      text: `THE INDEMNITORS HEREBY KNOWINGLY AND VOLUNTARILY WAIVE TRIAL BY JURY IN ANY ACTION OR PROCEEDING ARISING OUT OF
             THIS AGREEMENT.`,
    },
  ];
  public static RIA = [
    {
      text: `The maker of the foregoing statement hereby authorizes Colonial Surety Company (the “Surety”) to confirm credit and
             to investigate all other statements made but not limited to this application on/by any and all companies, stockholders,
             spouses and for listed indemnitors and hereby release and authorize the Surety to make such inquiries. The Undersigned and
             each of them hereby certifies that each statement contained herein is true and that this statement is made for the purpose
             of inducing the Surety to execute or continue certain bonds or undertakings. In consideration of the execution of certain
             bond or bonds before or after this date (collectively, the “Bonds”) by the Surety, the undersigned indemnitors
             (the “Indemnitors”)hereby agree to severally and jointly be liable for payment to the Surety of any defaults and expenses,
             including attorneys’ fees, incurred by the Surety as a result of any claim incurred under the Bonds.`,
    },
    {
      text: `To pay the Surety in advance the initial premium and thereafter pay in advance such additional premiums as may become
             due until the Surety is legally discharged and released of all liability under said bond and evidence of such discharge and
             release satisfactory to the Surety.`,
    },
    {
      text: `It is understood and agreed that the first year's premium is FULLY EARNED UPON issuance of the bond AND IS NOT
             REFUNDABLE. This application is subject to an underwriting credit and class review. We reserve the right to decline bond
             issuance for any reason.`,
    },
    {
      text: `Indemnitors shall immediately notify Surety in writing of any claim relating to any Bonds. Surety shall have the right
             to adjust, settle or compromise any claim.`,
    },
    {
      text: `Surety’s decision to adjust, settle or compromise any claim shall be final and binding upon the Indemnitors.
             Immediately upon demand by Surety, the Indemnitors shall deposit with Surety funds, as collateral security, in an amount
             Surety, in its sole and absolute discretion, deems necessary at the time of said demand to protect Surety from actual or
             anticipated loss.Surety shall be entitled to apply any collateral security held by it under this agreement (the “Agreement”)
             or any collateral security agreement between it and any of the Indemnitors to the satisfaction of or in reimbursement of
             Surety as a result of its satisfaction of any claim and to the direct payment of or reimbursement to itself of any loss or
             expense. The Indemnitors acknowledge and agree that their failure to immediately deposit with Surety any sums demanded under
             this section shall cause irreparable harm to Surety for which it has no adequate remedy at law. Indemnitors agree and shall
             stipulate in any legal proceeding that Surety is entitled to injunctive relief for specific performance of said collateral
             deposit obligation and do hereby expressly waive and relinquish any claims or defenses to the contrary.`,
    },
    {
      text: `This Agreement may only be modified by a written rider signed by an officer of Surety.`,
    },
    {
      text: `The Indemnitors submit to the jurisdiction of the state and federal courts situated in New York, waiving any defenses
             of lack of personal jurisdiction and waiving venue arguments, including forum non conveniens, in any action brought by Surety
             in the State of New York. Surety reserves the right to bring an action in any state where an Indemnitor has substantial
             contacts or where a project covered by a Bond subject to this Agreement is located or where a claimant brings suit against
             Surety on a Bond covered by this Agreement and Indemnitors agree to submit to the jurisdiction of the courts in such state.
             In any action by Surety against the Indemnitors, or any of them, each agrees that service of process may be made on any one
             of them and will be effective as to all of the Indemnitors. This Agreement shall be governed by the laws of the State of
             New York, without regard to conflicts of laws principles. Separate suits or proceedings may be brought by Surety on this
             Agreement as causes of action accrue.`,
    },
    {
      text: `THE INDEMNITORS HEREBY KNOWINGLY AND VOLUNTARILY WAIVE TRIAL BY JURY IN ANY ACTION OR PROCEEDING ARISING OUT OF
             THIS AGREEMENT.`,
    },
  ];
  public static AIRPORT_SECURITY = [
    {
      text: `The maker of the foregoing statement hereby authorizes Colonial Surety Company (the "Surety") to confirm
             credit and to investigate all other statements made but not limited to this application on/by any and all companies,
             stockholders, spouses and for listed indemnitors and hereby release and authorize the Surety to make such inquiries.`,
    },
    {
      text: `In consideration of the execution by Colonial Surety Company (“Colonial”) of the bond applied for in this
             application, the undersigned indemnitor(s) agree, jointly and severally, to indemnify Colonial against all loss, liability,
             costs, damages, and attorneys’ fees which Colonial may sustain or incur by reason or in consequence of having executed the
             bond.`,
    },
  ];
  public static LOST_CAR_TITLE = [
    {
      text: `The maker of the foregoing statement hereby authorizes Colonial Surety Company (the “Surety”) to confirm credit and to
       investigate all other statements made but not limited to this application on/by any and all companies, stockholders, spouses
       and for listed indemnitors and hereby release and authorize the Surety to make such inquiries. The Undersigned and each of them
       hereby certifies that each statement contained herein is true and that this statement is made for the purpose of inducing the
       Surety to execute or continue certain bonds or undertakings. In consideration of the execution of certain bond or bonds before
       or after this date (collectively, the “Bonds”) by the Surety, the undersigned indemnitors (the “Indemnitors”) hereby agree
       to severally and jointly be liable for payment to the Surety of any defaults and expenses, including attorneys’ fees, incurred
       by the Surety as a result of any claim incurred under the Bonds.`,
    },
    {
      text: `To pay the Surety in advance the initial premium and thereafter pay in advance such additional premiums as may become
       due until the Surety is legally discharged and released of all liability under said bond and evidence of such discharge and
       release satisfactory to the Surety.`,
    },
    {
      text: `It is understood and agreed that the first year's premium is FULLY EARNED UPON issuance of the bond AND IS NOT
       REFUNDABLE. This application is subject to an underwriting credit and class review. We reserve the right to decline
       bond issuance for any reason.`,
    },
    {
      text: `Indemnitors shall immediately notify Surety in writing of any claim relating to any Bonds. Surety shall have the right
       to adjust, settle or compromise any claim.`,
    },
    {
      text: `Surety’s decision to adjust, settle or compromise any claim shall be final and binding upon the Indemnitors.
       Immediately upon demand by Surety, the Indemnitors shall deposit with Surety funds, as collateral security, in an amount
       Surety, in its sole and absolute discretion, deems necessary at the time of said demand to protect Surety from actual or
       anticipated loss. Surety shall be entitled to apply any collateral security held by it under this agreement (the “Agreement”)
       or any collateral security agreement between it and any of the Indemnitors to the satisfaction of or in reimbursement of
       Surety as a result of its satisfaction of any claim and to the direct payment of or reimbursement to itself of any loss or
       expense. The Indemnitors acknowledge and agree that their failure to immediately deposit with Surety any sums demanded
       under this section shall cause irreparable harm to Surety for which it has no adequate remedy at law. Indemnitors agree
       and shall stipulate in any legal proceeding that Surety is entitled to injunctive relief for specific performance of said
       collateral deposit obligation and do hereby expressly waive and relinquish any claims or defenses to the contrary.`,
    },
    {
      text: `This Agreement may only be modified by a written rider signed by an officer of Surety.`,
    },
    {
      text: `The Indemnitors submit to the jurisdiction of the state and federal courts situated in New York, waiving any defenses
       of lack of personal jurisdiction and waiving venue arguments, including forum non conveniens, in any action brought by Surety
       in the State of New York. Surety reserves the right to bring an action in any state where an Indemnitor has substantial
       contacts or where a project covered by a Bond subject to this Agreement is located or where a claimant brings suit against
       Surety on a Bond covered by this Agreement and Indemnitors agree to submit to the jurisdiction of the courts in such state.
       In any action by Surety against the Indemnitors, or any of them, each agrees that service of process may be made on any one
       of them and will be effective as to all of the Indemnitors. This Agreement shall be governed by the laws of the State of New York,
       without regard to conflicts of laws principles. Separate suits or proceedings may be brought by Surety on this Agreement as
       causes of action accrue.`,
    },
    {
      text: `THE INDEMNITORS HEREBY KNOWINGLY AND VOLUNTARILY WAIVE TRIAL BY JURY IN ANY ACTION OR PROCEEDING ARISING OUT
       OF THIS AGREEMENT.`,
    },
  ];
  public static AUTO_RENEWAL_TEXT = [`By Signing I understand that the bond issued by Colonial
  will automatically renew upon the expiration date unless otherwise canceled by Colonial.
  Prior to expiration, I will be offered the opportunity to change or elect not to renew the bond.`,
    `I authorize Colonial to automatically charge the credit card account I have provided for all  renewal bond  premium.
   I represent that I am the owner and/or authorized signer on the account.`];
}

export class AgreementTerms {
  public static READ_AND_AGREE_TERMS_INDEMNITOR =
    `Yes, I have read, understood, and agreed to the terms and conditions of this agreement.`;

  public static READ_AND_AGREE_TERMS = `Yes, I have read & understood the
      terms.`;

}
