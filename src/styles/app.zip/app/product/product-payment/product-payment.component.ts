import { PaymentChannelCode } from '../../common/payment-method-selection/payment_channel_code';
import { PaymentPlanTypeModel } from '../../common/payment-method-selection/payment-plan-type-model';
import { PaymentFrequencyType } from '../../common/payment-method-selection/payment_frequency_type';
import { BillingProfileModel } from '../../common/payment-method-selection/billing-profile-model';
import { Component, Input, OnInit } from '@angular/core';
import { PaymentPlanModel } from '../../common/payment-method-selection/payment-plan-model';


@Component({
  selector: 'app-product-payment',
  templateUrl: './product-payment.component.html',
  styleUrls: ['./product-payment.component.scss'],
})

export class ProductPaymentComponent implements OnInit {

  @Input()
  paymentPlanModel: PaymentPlanModel = null;

  ngOnInit(): void {
  }

  get paymentChannelCode(): PaymentChannelCode {
    let paymentChannelCode: PaymentChannelCode;
    if (!!this.billingProfile) {
      paymentChannelCode = this.billingProfile.paymentChannelCode;
    } else {
      paymentChannelCode = PaymentChannelCode.CHECK;
    }
    return paymentChannelCode;
  }

  get paymentPlanTypeModel(): PaymentPlanTypeModel {
    return this.paymentPlanModel.paymentPlanTypeModel;
  }

  get paymentFrequencyType(): PaymentFrequencyType {
    return this.paymentPlanTypeModel.paymentFrequencyType;
  }

  get billingProfile(): BillingProfileModel | null {
    return this.paymentPlanModel.billingProfileModel;
  }
}
