import { Component, OnChanges, SimpleChanges, OnInit } from '@angular/core';
import { ComplexSelectFormFieldComponent } from './complex-select-form-field.component';
import { SicCode, UtilService } from '../../common/utils/util.service';
import { startWith, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { CompanyAndOfficeInformationFormGroup } from 'src/app/user/company-and-office-information/company-and-office-information-form-group';
import { Validators } from '@angular/forms';
import { FirmAndOfficeInformationFormGroup } from 'src/app/user/firm-and-office-information/firm-and-office-information-form-group';

@Component({
  selector: 'app-siccode-select-form-field',
  templateUrl: './siccode-select-form-field.component.html',
})
export class SiccodeSelectFormFieldComponent extends ComplexSelectFormFieldComponent<SicCode> implements OnChanges, OnInit {
  filteredOptions: Observable<any[]>;
  list: any[];
  constructor(private utilService: UtilService) {
    super();
    this.label = 'Select primary service';
  }
  ngOnInit(): void {
    this.utilService.getSicCodes().subscribe(scs => {
      this.filteredOptions = new Observable((subscribe) => {
        subscribe.next(scs);
      });
      this.assignFilter();
      return this.list = scs;
    });
    if (this.control.parent instanceof CompanyAndOfficeInformationFormGroup) {
      // this.control.setValidators(Validators.required);
    } else if (this.control.parent instanceof FirmAndOfficeInformationFormGroup) {
      this.control.clearValidators();
      this.control.setValidators(Validators.maxLength(8));
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    this.assignFilter();
    this.checkCorrectValue();
  }

  onValueSelect(value) {
    this.control.setValue(value);
    this.filteredOptions = new Observable((subscribe) => {
      subscribe.next(this.list);
    });
    this.assignFilter();
  }

  checkCorrectValue() {
    if (this.control) {
      this.control.valueChanges.subscribe((value) => {
        if (isNaN(Number(value))) {
          this.control.setErrors({ 'required': true });
        }
      });
    }
  }

  assignFilter() {
    if (this.control) {
      this.filteredOptions = this.control.valueChanges
        .pipe(
          startWith(''),
          map(value => value ? (typeof value === 'string' ? value : value.sic_code_description) : null),
          map(value => value ? this._filter(value) : (this.list ? this.list.slice() : []))
        );
    }
  }

  sicCodeValue({ sic_code }: SicCode): string {
    return sic_code;
  }

  sicCodeDisplay({ sic_code, sic_code_description }: SicCode): string {
    return `${sic_code_description} (${sic_code})`;
  }

  private _filter(value: string) {
    const filterValue = value ? value.toLowerCase() : '';
    return this.list.filter(obj => obj.sic_code_description.toLowerCase().includes(filterValue));
  }

  displayFn(object): string {
    if (this['template']._parentView.parent.component.list) {
      const selectedObject = this['template']._parentView.parent.component.list.filter((value) => value.sic_code === object);
      return selectedObject[0] ? selectedObject[0].sic_code_description : '';
    }
  }
}
