import {
  Component, EventEmitter,
  Input,
  OnInit, Output
} from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../products.service';
import { Product } from '../product';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit {

  adjudicationUrl = '/enrollment/adjudicate?formId=';
  overviewUrl = '/product/product-overview?formId=';
  initialized: boolean;
  applicant: string;
  applicationInfo: object;

  constructor(public router: Router) {
  }

  @Input() cols: any[];
  @Input() rows: number;
  @Input() paginator: boolean;
  @Input() products: Product[];
  @Input() sort: boolean;
  @Input() isColonialEmployee: boolean;

  @Output()
  routeToApplicationEvent: EventEmitter<any> = new EventEmitter<any>();

  async ngOnInit() {
  }

  OnDestroy(): void {
    this.products = [];
  }

  showProduct(bondId: number) {
    this.router.navigateByUrl(this.overviewUrl + bondId);
  }

  showAdjudicationPage(productId: number) {
    this.router.navigateByUrl(this.adjudicationUrl + productId);
  }

  emitApplicationInfo(bondId: number, type: string, status: string) {
    this.applicationInfo = {
      bondId: bondId,
      type: type,
      status: status,
    };
    this.routeToApplicationEvent.emit(this.applicationInfo);
  }
}
