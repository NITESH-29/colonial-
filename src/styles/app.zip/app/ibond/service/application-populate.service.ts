import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ApplicationPopulateService {
  createdUser;
  formData;
  isPendingApplication;
  bondClassification;
  incomingFrom;
  isLoggedInFromSignUp;
  anonymousApplication;
  paymentStackData;
  companySignatureValid;
  emailSignatureValid;
  private _isFormSavedForLater = false;

  constructor() {
    this.createdUser = null;
    this.isLoggedInFromSignUp = false;
    this.incomingFrom = null;
    this.formData = {};
    this.isPendingApplication = false;
    this.bondClassification = null;
    this.paymentStackData = null;
    this.companySignatureValid = false;
    this.emailSignatureValid = false;
  }
  setCreatedUser(val) {
    this.createdUser = val;
  }
  getCreatedUser() {
    return this.createdUser;
  }
  setFormData(key, val) {
    this.formData[key] = val;
  }
  getFormData(key) {
    return this.formData && this.formData[key] ? this.formData[key] : null;
  }
  setIsPendingApplication(val) {
    this.isPendingApplication = val;
  }
  getIsPendingApplication() {
    return this.isPendingApplication;
  }
  setBondClassification(val) {
    this.bondClassification = val;
  }
  getBondClassification() {
    return this.bondClassification;
  }
  resetData() {
    this.createdUser = null;
    this.formData = {};
    this.isPendingApplication = false;
  }
  setAnonymousApplication(data) {
    this.anonymousApplication = data;
  }
  getAnonymousApplication() {
    return this.anonymousApplication;
  }
  resetAnonymousApplication() {
    this.anonymousApplication = null;
  }
  resetApplicationData() {
    this.anonymousApplication = null;
    this.resetData();
    localStorage.removeItem('temp_application');
    localStorage.removeItem('quote_id');
    this.paymentStackData = null;
  }
  resetSignatureValidation() {
    this.emailSignatureValid = false;
    this.companySignatureValid = false;
  }
  setPaymentStackData(paymentStackData): void {
    this.paymentStackData = paymentStackData;
  }

  getPaymentStackData(): any {
    return this.paymentStackData;
  }

  resetPaymentStackData(): void {
    this.paymentStackData = null;
  }

  get isFormSavedForLater(): boolean {
    return this._isFormSavedForLater;
  }

  set isFormSavedForLater(value: boolean) {
    this._isFormSavedForLater = value;
  }
}
