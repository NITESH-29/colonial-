import { TestBed, inject } from '@angular/core/testing';

import { JsonConvertService } from './json-convert.service';
import { JsonConvert, OperationMode, ValueCheckingMode } from 'json2typescript';

describe('JsonConvertService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [JsonConvertService],
    });
  });

  it('should be injectable as a service', inject([JsonConvertService], (svc: JsonConvertService) => {
    expect(svc).toBeTruthy();
  }));

  describe('.getJsonConvert()', () => {
    it('should return a JsonConvert object', inject([JsonConvertService], (svc: JsonConvertService) => {
      expect(svc.getJsonConvert()).toEqual(jasmine.any(JsonConvert));
    }));

    it('should return a properly configured JsonConvert object', inject([JsonConvertService], (svc: JsonConvertService) => {
      const convert = svc.getJsonConvert();

      expect(convert.operationMode).toEqual(OperationMode.ENABLE);
      expect(convert.ignorePrimitiveChecks).toEqual(false);
      expect(convert.valueCheckingMode).toEqual(ValueCheckingMode.ALLOW_NULL);
    }));

    it('should return the same JsonConvert instance each time you call it', inject([JsonConvertService], (svc: JsonConvertService) => {
      const first = svc.getJsonConvert();
      const second = svc.getJsonConvert();

      expect(first === second).toBe(true);
    }));
  });
});
