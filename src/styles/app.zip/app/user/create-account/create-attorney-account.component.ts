import { AccountCreator, AccountService } from '../account.service';
import { Component, ViewChild } from '@angular/core';
import { CreateAccountComponent } from './create-account.component';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { AttorneyReferralListEntryComponent } from '../attorney-referral-list/attorney-referral-list-entry.component';
import { UsernamePasswordFormGroup } from '../username-password/username-password-form-group';
import { FirmAndOfficeInformationFormGroup } from '../firm-and-office-information/firm-and-office-information-form-group';
import { BusinessOfficePersonInformationFormGroup } from '../business-office-person-information/business-office-person-information-form-group';
import { FormControl, FormGroup } from '@angular/forms';
import { convertToAttorneyAccountCreationRequest, CreateAttorneyAccountRequest } from '../request-models/create-account-request';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { CourtBondFacilitationService } from 'src/app/enrollment/facilitation/court-bond-facilitation.service';
import { ApplicationService } from 'src/app/enrollment/application/application.service';

@Component({
  selector: 'app-create-attorney-account',
  templateUrl: './create-attorney-account.component.html',
})
export class CreateAttorneyAccountComponent extends CreateAccountComponent {
  @ViewChild('referralListComponent') referralListComponent: AttorneyReferralListEntryComponent;

  private isAddingStates: boolean;

  constructor(
    accountService: AccountService,
    securityService: SecurityService,
    serviceHandler: ServiceHandler,
    router: Router,
    activatedRoute: ActivatedRoute,
    location: Location,
    public gtmService: GoogleTagManagerService,
    private courtBondFacilitationService: CourtBondFacilitationService,
    private applicationService: ApplicationService
  ) {
    super(accountService, securityService, serviceHandler, router, activatedRoute, location);
    this.isAddingStates = false;
    if (this.courtBondFacilitationService['applicationDetails'].quoteId) {
      const gtmBondType = this.applicationService.setBondType(
        this.courtBondFacilitationService['applicationDetails'].type);
      this.createAttorneyPageGtmEvent(
        'court-bond-app-register',
        `${gtmBondType}`,
        `${this.courtBondFacilitationService['applicationDetails'].premium}`,
        'attorney',
        `${this.courtBondFacilitationService['applicationDetails'].quoteId}`
      );
    }
  }

  formIsValid(): boolean {
    return this.formGroup.valid && this.referralListComponent.valid;
  }

  save() {
    super.save();
    if (!this.referralListComponent.valid) {
      this.referralListComponent.checkErrorState();
    }
  }

  protected accountCreationFunction(): AccountCreator {
    return this.accountService.createAttorneyAccount;
  }

  protected configureFormGroup(): void {
    const self = this;
    this.formGroup = new FormGroup({
      personalInformation: new BusinessOfficePersonInformationFormGroup({
        isRequired: true,
        includeEmail: true,
        includePhone: true,
        includeAddress: true,
        includeProfession: false,
        includeTitle: true,
        isTitleRequired: false,
        isAddressRequired: true,
      }),
      firmAndOfficeInformation: new FirmAndOfficeInformationFormGroup(),
      usernamePassword: new UsernamePasswordFormGroup(),
      statesPracticedIn: new FormControl(
        [],
        (ctl) => self.isAddingStates && ctl.value.length < 1 ? { required: true } : null
      ),
    });

    // Legal Counsel and Prosecution
    this.formGroup.patchValue({ firmAndOfficeInformation: { sicCode: '9222' } });
  }

  statesChanged(states: string[]): void {
    this.formGroup.get('statesPracticedIn').setValue(states);
  }

  isAddingStatesChanged(value: boolean): void {
    this.isAddingStates = value;
    this.formGroup.get('statesPracticedIn').updateValueAndValidity();
  }

  get personalInformation(): BusinessOfficePersonInformationFormGroup {
    return this.formGroup.get('personalInformation') as BusinessOfficePersonInformationFormGroup;
  }

  get firmAndOfficeInformation(): FirmAndOfficeInformationFormGroup {
    return this.formGroup.get('firmAndOfficeInformation') as FirmAndOfficeInformationFormGroup;
  }

  protected prepareAccountCreationRequest(rawValue: any): CreateAttorneyAccountRequest {
    return convertToAttorneyAccountCreationRequest(rawValue);
  }

  createAttorneyPageGtmEvent(event, bondType, bondPremium, userType, quoteId?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${quoteId}`
    );
  }
}
