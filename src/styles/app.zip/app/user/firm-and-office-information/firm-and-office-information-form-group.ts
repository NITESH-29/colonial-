import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { FirmAndOfficeInformation } from './firm-and-office-information';
import { PatternValidators } from '../../common/validators/pattern-validators';
import { AddressFormGroup } from '../../common/address/address-form-group';

type IsRequiredFn = () => boolean;
export type FormGroupOptions<T> = { [P in keyof T]?: IsRequiredFn };
export type AgencyAndOfficeInformationFormGroupOptions = FormGroupOptions<FirmAndOfficeInformation>;

const defaultAgencyAndOfficeInformationFormGroupOptions = {
  name: () => true,
  phone: () => true,
  email: () => true,
  sicCode: () => true,
  address: () => true,
};

export class FirmAndOfficeInformationFormGroup extends FormGroup {
  constructor(opts: AgencyAndOfficeInformationFormGroupOptions = defaultAgencyAndOfficeInformationFormGroupOptions) {
    super({
      id: new FormControl(),
      name: new ConditionalRequireFormControl(null, opts.name),
      website: new FormControl(null, Validators.maxLength(50)),
      phone: new ConditionalRequireFormControl(null, opts.phone, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      fax: new FormControl(null, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      email: new ConditionalRequireFormControl(null, opts.email, [PatternValidators.email(), Validators.maxLength(75)]),
      sicCode: new ConditionalRequireFormControl(null, opts.sicCode, Validators.maxLength(8)),
      address: new AddressFormGroup(opts.address),
    });
  }

  get id(): FormControl {
    return this.get('id') as FormControl;
  }

  get name(): FormControl {
    return this.get('name') as FormControl;
  }

  get website(): FormControl {
    return this.get('website') as FormControl;
  }

  get phone(): FormControl {
    return this.get('phone') as FormControl;
  }

  get fax(): FormControl {
    return this.get('fax') as FormControl;
  }

  get email(): FormControl {
    return this.get('email') as FormControl;
  }

  get sicCode(): FormControl {
    return this.get('sicCode') as FormControl;
  }

  get address(): AddressFormGroup {
    return this.get('address') as AddressFormGroup;
  }
}
