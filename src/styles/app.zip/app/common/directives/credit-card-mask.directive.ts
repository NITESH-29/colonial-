import { Directive, HostListener, ElementRef, OnInit, EventEmitter, Output } from '@angular/core';

const keys = ['Backspace', 'Delete', 'ArrowRight', 'ArrowLeft'];

@Directive({
  selector: '[appCreditCardInputMask]',
})

export class CreditCardMaskDirective implements OnInit {

  @Output() ngModelChange = new EventEmitter();

  constructor(private element: ElementRef) {
  }

  @HostListener('input')
  public onChange(): void {
    this.applyMask(this.getValue());
  }

  public ngOnInit(): void {
  }

  @HostListener('keydown', ['$event'])
  public onKeyDown(event): void {

    if (!Number.isInteger(parseInt(event.key, 10)) && (keys.indexOf(event.key) === -1)) {
      event.preventDefault();
    }
  }

  private getCursorPosition(): number {
    return this.element.nativeElement.selectionStart;
  }

  private applyMask(value): void {
    if (!Number.isInteger(parseInt(value.replace(/\s/g, ''), 10))) {
      this.setValue(this.spliceSplit(value, this.getCursorPosition(), 1, ''));
    } else if (value.length % 5 === 0) {
      this.setValue(this.spliceSplit(value, value.length - 1, 0, ' '));
    }
  }

  private spliceSplit(str, index, count, add) {
    const ar = str.split('');
    ar.splice(index, count, add);
    return ar.join('');
  }

  private getValue(): string {
    return this.element.nativeElement.value;
  }

  private setValue(value: string): void {
    this.element.nativeElement.value = value.trim();
  }
}

