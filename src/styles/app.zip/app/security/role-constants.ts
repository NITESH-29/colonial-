export class RoleConstants {

  static readonly SUPERUSER_AUTHORITY = 'ROLE_SUPERUSER';
  static readonly OWNER_AUTHORITY = 'ROLE_OWNER';
  static readonly ADMIN_AUTHORITY = 'ROLE_ADMIN';
  static readonly CLERK_AUTHORITY = 'ROLE_CLERK';
  static readonly TPA_AUTHORITY = 'ROLE_TPA';
  static readonly ATTORNEY_AUTHORITY = 'ROLE_ATTORNEY';
  static readonly AGENT_AUTHORITY = 'ROLE_AGENT';
  static readonly INDIVIDUAL_AUTHORITY = 'ROLE_INDIVIDUAL';
  static readonly SUPER_EMPLOYEE_AUTHORITY = 'ROLE_SUPER_EMPLOYEE';
  static readonly EMPLOYEE_PLUS_AUTHORITY = 'ROLE_EMPLOYEE_PLUS';
  static readonly EMPLOYEE_DEFAULT_AUTHORITY = 'ROLE_EMPLOYEE_DEFAULT';

  static readonly AGENT_AUTHORITIES = [
    RoleConstants.ATTORNEY_AUTHORITY,
    RoleConstants.AGENT_AUTHORITY,
    RoleConstants.TPA_AUTHORITY,
  ];
}
