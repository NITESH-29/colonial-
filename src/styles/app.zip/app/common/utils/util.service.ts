import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ServiceHandler } from './service-handler.service';

import { Observable } from 'rxjs/Observable';
import { JsonConvert, OperationMode, ValueCheckingMode } from 'json2typescript';
import { catchError, tap } from 'rxjs/operators';
import { of } from 'rxjs';

export interface SicCode {
  id: number;
  division: string;
  major_group: number;
  industry_group: number;
  sic_code: string;
  sic_code_description: string;
}

@Injectable()
export class UtilService {
  private sicCodes: SicCode[];
  private airportList: any[];

  // Deprecated: change your code to use JsonConvertService to get JsonConvert instances instead
  static getJsonConvert(): JsonConvert {
    const jsonConvert = new JsonConvert();
    jsonConvert.operationMode = OperationMode.LOGGING;
    jsonConvert.operationMode = OperationMode.ENABLE;
    jsonConvert.ignorePrimitiveChecks = false;
    jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;

    return jsonConvert;
  }

  constructor(private http: HttpClient, private serviceHandler: ServiceHandler) {
  }

  public getSicCodes(): Observable<SicCode[]> {
    if (this.sicCodes) {
      return of(this.sicCodes);
    } else {
      return this.http.get<SicCode[]>('assets/sicCodes.json').pipe(
        tap(codes => this.sicCodes = codes),
        catchError(this.serviceHandler.handleError)
      );
    }
  }

  public getAirportList(): Observable<any[]> {
    if (this.sicCodes) {
      return of(this.sicCodes);
    } else {
      return this.http.get<any[]>('assets/USA_Airport.json').pipe(
        tap(obj => this.airportList = obj),
        catchError(this.serviceHandler.handleError)
      );
    }
  }
}
