import { Component, Input } from '@angular/core';
import { AgencyAndOfficeInformationFormGroup } from './agency-and-office-information-form-group';

@Component({
  selector: 'app-agency-and-office-information',
  templateUrl: './agency-and-office-information.component.html',
})
export class AgencyAndOfficeInformationComponent {
  @Input() formGroup: AgencyAndOfficeInformationFormGroup;
}
