import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { UserModule } from '../user.module';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/primeng';
import { EmployeeComponent } from './employee/employee.component';
import {
  MatButtonModule,
  MatCardModule,
  MatDialogModule,
  MatIconModule,
  MatInputModule,
  MatSelectModule,
  MatSnackBarModule,
  MatTooltipModule
} from '@angular/material';
import { EmployeeService } from './employee/employee.service';
import { FormComponentsModule } from '../../form-components/form-components.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminService } from './admin.service';
import { ConfirmRemoveEmployeeDialogComponent } from './employee/confirm-remove-employee-dialog.component';
import { AttorneyReferralListComponent } from './attorney/attorney-referral-list.component';
import { AttorneyReferralListService } from './attorney/attorney-referral-list.service';
import {
  AttorneyReferralListEmailSearchResultsDialogComponent
} from './attorney/attorney-referral-list-email-search-results-dialog.component';

@NgModule({
  declarations: [
    EmployeeListComponent,
    AdminHomeComponent,
    EmployeeComponent,
    ConfirmRemoveEmployeeDialogComponent,
    AttorneyReferralListComponent,
    AttorneyReferralListEmailSearchResultsDialogComponent,
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    UserModule,
    TableModule,
    PaginatorModule,
    MatCardModule,
    FormComponentsModule,
    MatTooltipModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatIconModule,
    MatSnackBarModule,
    MatDialogModule,
    MatInputModule,
    MatSelectModule,
  ],
  providers: [
    EmployeeService,
    AdminService,
    AttorneyReferralListService,
  ],
  entryComponents: [
    ConfirmRemoveEmployeeDialogComponent,
    AttorneyReferralListEmailSearchResultsDialogComponent,
  ],
})
export class AdminModule { }
