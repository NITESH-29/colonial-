import { Component } from '@angular/core';
import { ComplexSelectFormFieldComponent } from './complex-select-form-field.component';

@Component({
  selector: 'app-basic-select-form-field',
  templateUrl: './basic-select-form-field.component.html',
})
export class BasicSelectFormFieldComponent extends ComplexSelectFormFieldComponent<any> {
  constructor() {
    super();
    this.value = x => x;
    this.display = x => x;
  }
}
