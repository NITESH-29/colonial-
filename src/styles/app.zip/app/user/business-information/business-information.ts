export interface BusinessInformation {
  id?: number;
  name: string;
}

export interface AgencyInformation extends BusinessInformation {
  memberOfNasbp: boolean;
  einNumber: string;
}
