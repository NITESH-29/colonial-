import { RouterModule, Routes } from '@angular/router';
import { LoggedInResolver } from '../enrollment/application/providers/logged-in.resolver';
import { NgModule } from '@angular/core';
import { InsuranceComponent } from './component/insurance.component';
import { InsuranceGetQuotesComponent } from './component/screens/get-quotes/get-quotes.component';
import { InsuranceDetailsComponent } from './component/screens/insurance-details/insurance-details.component';
import { InsurancePaymentComponent } from './component/screens/payment/payment.component';
import { ConfirmationComponent } from './component/screens/confirmation/confirmation.component';
import { InsuranceYourQuotesComponent } from './component/screens/your-quotes/your-quotes.component';
import { InsuranceAgreementComponent } from './component/screens/agreement/agreement.component';
import { AuthGuardLoginService as LoginAccessGuard } from './security/auth-guard-login.service';
import { AuthGuardInsuranceDetailsService as InsuranceDetailsAccessGuard } from './security/auth-guard-insurance-details.service';
import { AuthGuardInsuranceConfirmationService as ConfirmationAccessGuard } from './security/auth-guard-insurance-confirmation.service';
import { AuthGuardInsuranceYourQuotesService as YourQuotesAccessGuard } from './security/auth-guard-insurance-your-quotes.service';
import { AuthGuardInsuranceAgreementService as AgreementAccessGuard } from './security/auth-guard-insurance-agreement.service';
import { AuthGuardInsuranceCreateUserService as CreateUserAccessGuard } from './security/auth-guard-insurance-create-user.service';
import { EvaluatorComponent } from './component/common/evaluator/evaluator.component';
import { AuthGuardPageRefreshService as PageRefreshAccessGuard } from './security/auth-guard-page-refresh.service';
import { InsuranceSignUpComponent } from './component/screens/sign-up/sign-up.component';
import { AuthGuardLoadUserService as LoadUserAccessGuard } from './security/auth-guard-load-user';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'evaluator',
    pathMatch: 'full',
  },
  {
    path: 'evaluator',
    component: EvaluatorComponent,
    canActivate: [LoadUserAccessGuard],
  },
  {
    path: 'insurance',
    component: InsuranceComponent,
  },
  {
    path: 'getquotes',
    component: InsuranceGetQuotesComponent,
    canActivate: [PageRefreshAccessGuard],
  },
  {
    path: 'insuranceDetails',
    component: InsuranceDetailsComponent,
    canActivate: [InsuranceDetailsAccessGuard],
  },
  {
    path: 'insurancePayment',
    component: InsurancePaymentComponent,
    canActivate: [LoginAccessGuard],
  },
  {
    path: 'insuranceConfirmation',
    component: ConfirmationComponent,
    canActivate: [ConfirmationAccessGuard],
  },
  {
    path: 'yourquotes',
    component: InsuranceYourQuotesComponent,
    canActivate: [YourQuotesAccessGuard],
  },
  {
    path: 'agreement',
    component: InsuranceAgreementComponent,
    canActivate: [AgreementAccessGuard],
  },
  {
    path: 'create-user',
    component: InsuranceSignUpComponent,
    canActivate: [CreateUserAccessGuard],
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InsuranceRoutingModule { }
