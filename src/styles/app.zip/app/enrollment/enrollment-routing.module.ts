import { NgModule } from '@angular/core';
import {
  RouterModule,
  Routes
} from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { AuthGuard } from '../security/app.auth.guard';
import { ApplicationOverviewComponent } from './application-overview/application-overview.component';
import { AgentHandoffComponent } from './agent-handoff/agent-handoff.component';
import { AdjudicationComponent } from './adjudication/adjudication.component';
import { CourtBondFacilitationPostLoginGuard } from './facilitation/court-bond-facilitation-post-login-guard.service';
import { ApplicationListComponent } from './application-list/application-list.component';

const routes: Routes = [
  { path: '', component: DashboardComponent, canActivate: [AuthGuard, CourtBondFacilitationPostLoginGuard] }, // default route of module
  { path: 'applications', component: ApplicationListComponent, canActivate: [AuthGuard] },
  { path: 'applications/:status', component: ApplicationListComponent, canActivate: [AuthGuard] },

  { path: 'application', loadChildren: './application/application.module#ApplicationModule' },
  { path: 'application-overview', component: ApplicationOverviewComponent, canActivate: [AuthGuard] },
  { path: 'agent-handoff/:id', component: AgentHandoffComponent, canActivate: [AuthGuard] },
  // { path: 'adjudicate', component: AdjudicationComponent, canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EnrollmentRoutingModule { }
