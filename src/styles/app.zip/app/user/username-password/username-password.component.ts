import { Component, Input } from '@angular/core';
import { UsernamePasswordFormGroup } from './username-password-form-group';

@Component({
  selector: 'app-username-password',
  templateUrl: './username-password.component.html',
  styleUrls: ['./username-password.component.css'],
})
export class UsernamePasswordComponent {

  @Input()
  formGroup: UsernamePasswordFormGroup;

  @Input()
  disableUsernamePassword: boolean;

  @Input()
  hideLabel = false;

  @Input()
  hidePassword = false;

  constructor() { }
}
