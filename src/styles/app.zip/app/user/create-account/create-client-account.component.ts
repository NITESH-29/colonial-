import { AccountCreator, AccountService } from '../account.service';
import { Component, OnInit } from '@angular/core';
import { CreateAccountComponent } from './create-account.component';
import { convertToAccountCreationRequest, CreateAccountRequest } from '../request-models/create-account-request';
import { Location } from '@angular/common';
import { PersonalInformationFormGroup } from '../personal-information/personal-information-form-group';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsernamePasswordFormGroup } from '../username-password/username-password-form-group';
import { InputValidators } from '../../form-components/validators/input-validators';
import { PatternValidators } from '../../common/validators/pattern-validators';
import { CompanyAndOfficeInformationFormGroup } from '../company-and-office-information/company-and-office-information-form-group';
import { CourtBondFacilitationService } from '../../enrollment/facilitation/court-bond-facilitation.service';
import { CourtBondTypesPurchasableByCompanies } from '../../enrollment/application/common/bond-types';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { MatDialog } from '@angular/material';
import { ApplicationPopulateService } from '../../ibond/service/application-populate.service';
import { ApplicationService } from 'src/app/enrollment/application/application.service';

@Component({
  selector: 'app-create-client-account',
  templateUrl: './create-client-account.component.html',
})
export class CreateClientAccountComponent extends CreateAccountComponent implements OnInit {
  companyInformationEntryDesired = new FormControl(false, Validators.required);
  hideCompanyInformationEntryOption = false;
  private returnUrl: string;

  constructor(
    private courtBondFacilitationService: CourtBondFacilitationService,
    accountService: AccountService,
    securityService: SecurityService,
    serviceHandler: ServiceHandler,
    router: Router,
    activatedRoute: ActivatedRoute,
    private matDialog: MatDialog,
    location: Location,
    private applicationPopulateService: ApplicationPopulateService,
    public gtmService: GoogleTagManagerService,
    private applicationService: ApplicationService

  ) {
    super(accountService, securityService, serviceHandler, router, activatedRoute, location);
    if (this.courtBondFacilitationService['applicationDetails'].quoteId) {
      const gtmBondType = this.applicationService.setBondType(
        this.courtBondFacilitationService['applicationDetails'].type);
      this.createClientPageGtmEvent(
        'court-bond-app-register',
        `${gtmBondType}`,
        `${this.courtBondFacilitationService['applicationDetails'].premium}`,
        'individual',
        `${this.courtBondFacilitationService['applicationDetails'].quoteId}`
      );
    }
  }

  protected configureFormGroup(): void {
    const anonymousQuote = this.courtBondFacilitationService.getAnonymousQuote();
    const applicationDetails = this.courtBondFacilitationService.getApplicationDetails();

    const bondTypeAllowsCompanyApplicants = applicationDetails && CourtBondTypesPurchasableByCompanies.includes(applicationDetails.type);
    const anonymousQuoteIsForCompany = anonymousQuote && anonymousQuote.isCompany;
    const includeAddress = !(bondTypeAllowsCompanyApplicants && anonymousQuoteIsForCompany);

    this.formGroup = new FormGroup({
      personalInformation: new PersonalInformationFormGroup({
        isRequired: true,
        includeEmail: true,
        includePhone: true,
        includeAddress: true,
        includeProfession: true,
      }),
      companyAndOfficeInformation: new CompanyAndOfficeInformationFormGroup({
        name: this.requiredIfAddingCompanyInformation(),
        title: this.requiredIfAddingCompanyInformation(),
        email: this.requiredIfAddingCompanyInformation(),
        phone: this.requiredIfAddingCompanyInformation(),
        sicCode: this.requiredIfAddingCompanyInformation(),
        address: this.requiredIfAddingCompanyInformation(),
      }),
      usernamePassword: new UsernamePasswordFormGroup(),
      referralCode: new FormControl('', [InputValidators.noSpaces, PatternValidators.referralCode()]),
    });

    if (this.courtBondFacilitationService.isEnrollmentInProgress() && anonymousQuote) {
      const { firstName, lastName, email, phone, isCompany, companyName: name } = anonymousQuote;
      this.personalInformation.patchValue({ firstName, lastName, email, phone });

      if (isCompany) {
        this.hideCompanyInformationEntryOption = true;
        this.companyInformationEntryDesired.setValue(true);
        this.companyAndOfficeInformation.patchValue({ name });
      }
    }
    if (this.applicationPopulateService.getIsPendingApplication() && this.applicationPopulateService.formData) {
      const productFor = this.applicationPopulateService.getFormData('productFor');
      if (productFor && productFor === 'company') {
        this.setCompanyInformationFormDetails();
      } else {
        this.setIndividualFormDetails();
      }
    }
    // this.personalInformation.get('email').markAsTouched();
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.activatedRoute.queryParams.subscribe((route: Params) => {
      if (!this.returnUrl) {
        this.returnUrl = route['returnUrl'];
      }
    });

    this.companyInformationEntryDesired.valueChanges.subscribe(
      (value: boolean) => {
        if (!value) {
          this.companyAndOfficeInformation.reset();
        }
      }
    );
  }
  login() {
    this.router.navigateByUrl('/');
  }
  setIndividualFormDetails() {
    if (this.applicationPopulateService.getFormData('applicantDetailForm')) {
      const applicantInformation = this.applicationPopulateService.getFormData('applicantDetailForm').getRawValue();
      this.personalInformation.patchValue({
        firstName: applicantInformation['firstName'],
        lastName: applicantInformation['lastName'],
        phone: applicantInformation['applicantPhone'],
        email: applicantInformation['applicantEmail'],
      });
      this.personalInformation.controls['address'].patchValue({
        street1: applicantInformation['applicantStreet1'],
        street2: applicantInformation['applicantStreet2'],
        city: applicantInformation['applicantCity'],
        state: applicantInformation['applicantState'],
        zipCode: applicantInformation['applicantZipCode'],
      });
      this.personalInformation.updateValueAndValidity();
    } else {
      const applicantInformation = this.applicationPopulateService.getFormData('businessDetailForm').getRawValue();
      this.companyInformationEntryDesired.setValue(true);
      this.hideCompanyInformationEntryOption = false;
      if (applicantInformation) {
        this.companyAndOfficeInformation.patchValue({
          name: applicantInformation['individualName'],
          phone: applicantInformation['individualPhone'],
          fax: applicantInformation['individualfax'],
        });
        this.companyAndOfficeInformation.controls['address'].patchValue({
          street1: applicantInformation['individualAddress'],
          street2: applicantInformation['individualAddress2'],
          city: applicantInformation['individualCity'],
          state: applicantInformation['individualState'],
          zipCode: applicantInformation['individualZip'],
        });
        this.personalInformation.updateValueAndValidity();
      }
    }
  }

  setCompanyInformationFormDetails() {
    this.companyInformationEntryDesired.setValue(true);
    this.hideCompanyInformationEntryOption = false;
    const bondClassification = this.applicationPopulateService.getBondClassification();
    const companyInformation = this.applicationPopulateService.getFormData('applicantDetailForm');
    if (companyInformation) {
      const companyInformationData = companyInformation.getRawValue();
      this.companyAndOfficeInformation.patchValue({
        name: companyInformationData.applicantName,
        title: companyInformationData.applicantContactTitle,
        email: companyInformationData.applicantEmail,
        phone: companyInformationData.applicantPhone,
        fax: companyInformationData.applicantFax,
      });
      this.companyAndOfficeInformation.controls['address'].patchValue({
        street1: companyInformationData.applicantStreet1,
        street2: companyInformationData.applicantStreet2,
        city: companyInformationData.applicantCity,
        state: companyInformationData.applicantState,
        zipCode: companyInformationData.applicantZipCode,
      });
    }
    if (bondClassification === 'lost_instrument') {
      const applicantInformationData = this.applicationPopulateService.getFormData('ownerDetailsArray');
      if (applicantInformationData) {
        this.personalInformation.patchValue({
          firstName: applicantInformationData['ownerName'],
        });
        this.personalInformation.controls['address'].patchValue({
          street1: applicantInformationData['ownerAddress'].street1,
          street2: applicantInformationData['ownerAddress'].street2,
          city: applicantInformationData['ownerAddress'].city,
          state: applicantInformationData['ownerAddress'].state,
          zipCode: applicantInformationData['ownerAddress'].zipCode,
        });
      }
    } else {
      const applicantInformation = this.applicationPopulateService.getFormData('ownerInformationForm');
      let applicantInformationData;
      if (applicantInformation) {
        applicantInformationData = applicantInformation.getRawValue();
      }
      if (applicantInformation) {
        this.personalInformation.patchValue({
          firstName: applicantInformationData['ownerFirstName'],
          lastName: applicantInformationData['ownerLastName'],
          phone: applicantInformationData['ownerPhone'],
          email: applicantInformationData['ownerEmail'],
        });
        this.personalInformation.controls['address'].patchValue({
          street1: applicantInformationData['ownerStreet1'],
          street2: applicantInformationData['ownerStreet2'],
          city: applicantInformationData['ownerCity'],
          state: applicantInformationData['ownerState'],
          zipCode: applicantInformationData['ownerZipCode'],
        });
      }
    }
    this.personalInformation.updateValueAndValidity();
  }

  get referralCode(): FormControl {
    return this.formGroup.get('referralCode') as FormControl;
  }

  get personalInformation(): PersonalInformationFormGroup {
    return this.formGroup.get('personalInformation') as PersonalInformationFormGroup;
  }

  get companyAndOfficeInformation(): CompanyAndOfficeInformationFormGroup {
    return this.formGroup.get('companyAndOfficeInformation') as CompanyAndOfficeInformationFormGroup;
  }

  protected prepareAccountCreationRequest(rawValue: any): CreateAccountRequest {
    const request: CreateAccountRequest = convertToAccountCreationRequest(rawValue);

    if (!this.companyInformationEntryDesired.value) {
      delete request.businessInformation;
      delete request.businessOfficeInformation;
    }
    return request;
  }

  protected accountCreationFunction(): AccountCreator {
    return this.accountService.createClientAccount;
  }

  private requiredIfAddingCompanyInformation(): () => boolean {
    return () => this.companyInformationEntryDesired.value;
  }

  redirectUrl(): string {
    return this.returnUrl;
  }

  createClientPageGtmEvent(event, bondType, bondPremium, userType, quoteId?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${quoteId}`
    );
  }
}
