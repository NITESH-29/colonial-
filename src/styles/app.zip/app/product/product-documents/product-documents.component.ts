import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ProductService } from '../products.service';
import { ProductDocument } from './product-document';
import { Product } from '../product';

@Component({
  selector: 'app-product-documents',
  templateUrl: './product-documents.component.html',
  styleUrls: ['./product-documents.component.scss'],
})

export class ProductDocumentsComponent implements OnInit, OnChanges {

  @Input()
  product: Product;

  productDocuments: ProductDocument[] = [];
  initialized = false;

  constructor(private productService: ProductService) {

  }

  async ngOnInit(): Promise<void> {
    this.productDocuments = await this.productService.getProductDocuments(this.product.id).toPromise();
    this.initialized = true;
  }

  async ngOnChanges(changes: SimpleChanges): Promise<void> {
    this.productDocuments = await this.productService.getProductDocuments(this.product.id).toPromise();
  }

}
