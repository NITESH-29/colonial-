import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidatePDFComponent } from './validate-pdf/validate-pdf.component';
import { GeneratePDFComponent } from './generate-pdf/generate-pdf.component';
import { ManagePDFComponent } from './manage-pdf/manage-pdf.component';
import { SpecialFormComponent } from './special-form.component';
import { MatCardModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { SpecialFormModuleRouting } from './special-form-module.routing';
import { FileUploadComponent } from './common/file-upload/file-upload.component';
import { SelectDropdownFormFieldComponent } from './common/select-dropdown-form-field/select-dropdown-form-field.component';
import { MaterialModule } from '../material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AddNewPdfComponent } from './manage-pdf/add-new-pdf/add-new-pdf.component';
import { PDFFileRecordComponent } from './manage-pdf/pdf-file-record/pdf-file-record.component';
import { EditPdfComponent } from './manage-pdf/edit-pdf/edit-pdf.component';

@NgModule({
  declarations: [
    ValidatePDFComponent,
    GeneratePDFComponent,
    ManagePDFComponent,
    SpecialFormComponent,
    FileUploadComponent,
    SelectDropdownFormFieldComponent,
    AddNewPdfComponent,
    PDFFileRecordComponent,
    EditPdfComponent,
  ],
  imports: [
    CommonModule,
    MatCardModule,
    FlexLayoutModule,
    RouterModule,
    SpecialFormModuleRouting,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
  ],
  exports: [
    SpecialFormComponent,
  ],
  entryComponents: [
    AddNewPdfComponent,
    EditPdfComponent,
  ],
})
export class SpecialFormModule { }
