import { Injectable } from '@angular/core';
import { RoleGuard } from './role.guard';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';

@Injectable()
export class AdminGuard extends RoleGuard {
  constructor(securityService: SecurityService) {
    super(securityService);
  }

  protected hasPermission(user: UserImpl): boolean {
    return user.hasAdminPermissions;
  }
}
