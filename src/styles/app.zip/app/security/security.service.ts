import {
  HttpClient,
  HttpHeaders,
  HttpParams
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ServiceHandler } from '../common/utils/service-handler.service';
import { UserImpl } from './user';
import { AbstractService } from '../common/services/abstract-service';
import { JsonConvertService } from '../common/utils/json-convert.service';
import { JsonConvert } from 'json2typescript';
import { AppConfigService } from '../app-config-service';
import { Router } from '@angular/router';
import { Observable, of, Subject } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { IBondSignUpWithSource } from '../ibond/login/i-bond-sign-up-with-source';
import { ApplicationPopulateService } from '../ibond/service/application-populate.service';
import { UserIdleService } from 'angular-user-idle';

export interface PasswordOperationResponse {
  username: string;
  message: string;
  passwordOperationSuccessful: boolean;
}

export interface PasswordTokenValidity {
  passwordTokenValid: boolean;
}

export interface CustomError {
  timestamp: string;
  status: string;
  message: string;
}

@Injectable({
  providedIn: 'root',
})

export class SecurityService extends AbstractService {

  private loginRequestURL = '/login';
  private tokenRequestUrl = '/account/access-token';
  private ssoLoginUrl = '/account/sso-login';
  private logoutRequestURL = '/api/logout';
  private _user: UserImpl;
  private cookieName: string;
  private jsonConvert: JsonConvert;
  public _loggedIn$ = new BehaviorSubject<boolean>(false);
  public _userFromThirdPartyApplication = new BehaviorSubject<boolean>(false);
  // private loggedInAfterSignupSubject = new BehaviorSubject<IBondSignUpWithSource>({ incomingFrom: '' });
  // loggedInAfterSignup = this.loggedInAfterSignupSubject.asObservable();
  // isLoggedInAfterSignUp = false;
  // incomingFrom: string;

  // We need this flag to avoid multiple calls to the server while still waiting for result
  constructor(
    private http: HttpClient,
    private serviceHandler: ServiceHandler,
    private router: Router,
    private userIdle: UserIdleService,
    private applicationPopulate: ApplicationPopulateService,
    appConfigService: AppConfigService,
    jsonConvertService: JsonConvertService) {

    super();
    this.jsonConvert = jsonConvertService.getJsonConvert();
    const token = sessionStorage.getItem('token');
    const tokenName = localStorage.getItem('tokenName');
    if (token) {
      this.cookieName = token;
    } else if (tokenName) {
      this.cookieName = tokenName;
    } else {
      appConfigService.getConfig().subscribe(config => this.cookieName = config.cookieName);
    }
    this._loggedIn$ = new BehaviorSubject<boolean>(false);
    this._userFromThirdPartyApplication = new BehaviorSubject<boolean>(false);
  }

  get loggedIn$(): Observable<boolean> {
    return this._loggedIn$.asObservable().pipe(
      // Call mergeMap here because we might need to invoke another observable and merge it into this one…
      mergeMap(loggedIn => {
        // Either someone is already logged in…
        if (loggedIn) {
          return of(loggedIn);
        } else if (!!document.cookie && document.cookie.includes(this.cookieName)) {
          // …Or we can try to refresh the current user from an existing login cookie
          return this.refreshCurrentUser().pipe(
            // Refresh the current user and switch back to this.loggedIn$
            switchMap(() => this.loggedIn$),
            // If we got here, refreshing the current user failed for whatever reason, so… we're probably not logged in
            catchError(() => of(false))
          );
        } else {
          // …Or there is no login cookie, so don't even bother trying to refresh the current user
          return of(false);
        }
      })
    );
  }

  async loginFromSignup(username, password, incomingFrom) {
    this.applicationPopulate.isLoggedInFromSignUp = true;
    this.applicationPopulate.incomingFrom = incomingFrom;
    return await this.login(username, password);
  }

  async verifyToken(token: string) {
    return this.http.post(this.requestURL(this.ssoLoginUrl),
      {
        accessToken: token,
      },
      {
        observe: 'body',
        responseType: 'json',
      }
    ).toPromise();

  }

  async getAccessToken() {
    return this.http.get(this.requestURL(this.tokenRequestUrl),
      {
        observe: 'body',
        responseType: 'text',
      }
    ).toPromise();
  }

  async login(username: string, password: string) {
    const self = this; // Gotta hold on to this object, otherwise Promise might loose it
    const userObj = await this.http.post(this.requestURL(this.loginRequestURL),
      {
        username,
        password,
      },
      {
        observe: 'body',
        responseType: 'json',
        withCredentials: true,
      }).toPromise();

    // must deserialize so computed properties are properly realized
    this._user = await self.jsonConvert.deserialize(userObj, UserImpl) as UserImpl;
    this._loggedIn$.next(true);
    this.userIdle.startWatching();
    // if (this.isLoggedInAfterSignUp) {
    //   this.loggedInAfterSignupSubject.next({ incomingFrom: this.incomingFrom });
    // }
    return this._user;
  }

  refreshCurrentUser(): Observable<UserImpl> {
    return this.http.get<UserImpl>(
      this.requestURL('/currentUser'), { observe: 'body', responseType: 'json' }
    ).pipe(
      map(json => {
        const user = this.jsonConvert.deserialize(json, UserImpl) as UserImpl;
        this._user = user;
        this._loggedIn$.next(!!user.id); // Use the presence of a truthy user.id as a proxy for loggedIn
        return this._user;
      })
    );
  }

  updateUser(user: UserImpl) {
    this._user = user;
  }

  get user(): UserImpl | null {
    if (this._loggedIn$.getValue()) {
      return this._user;
    } else {
      return null;
    }
  }

  async logout() {
    this._user = null;
    this.deleteCookie();
    localStorage.removeItem('productCode');
    // Call server to invalidate the jwt cookie
    await this.http.get(this.logoutRequestURL).toPromise();
    this._loggedIn$.next(false);
  }

  requestPasswordReset(username: string) {
    // set username as a query param
    const params = new HttpParams().set('userName', username);
    const url = this.requestURL('/user/request-password-reset');
    // call the endpoint that will send the email to the user
    return this.http.get(url, { params: params })
      .catch((error) => this.serviceHandler.handleError(error));
  }

  changePassword(userName: string, newPassword: string, newPasswordConfirm: string) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    const body = {
      newPassword,
      userName,
    };
    const url = this.requestURL('/user/change-password');

    return this.http.put(url, body, {
      headers: headers,
      observe: 'response',
    });
  }

  resetPassword(token: string, newPassword: string, newPasswordConfirm: string): Observable<PasswordOperationResponse> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    const body = {
      newPassword,
      token,
    };
    const url = this.requestURL('/user/reset-password');

    return this.http.put<PasswordOperationResponse>(url, body, {
      headers: headers,
      observe: 'body',
    });
  }

  setInitialPassword(token: string, username: string, newPassword: string, applicationId: string): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    const body = {
      token,
      username,
      newPassword,
      applicationId,
    };
    const url = this.requestURL('/user/set-initial-password');
    return this.http.put<any>(url, body, {
      headers: headers,
      observe: 'body',
    });
  }

  checkResetPasswordTokenValidity(token: string): Promise<PasswordTokenValidity> {
    const url = this.requestURL('/user/token-valid');
    return this.http.get<PasswordTokenValidity>(url, { params: { token: token } }).toPromise();
  }

  deleteCookie() {
    // Set it to expire in the past - this invalidates the cookie, effectively deleting it
    document.cookie = `${this.cookieName}=; expires=Thu, 01 Jan 1970 00:00:01 GMT; Path=/`;
  }

  retrieveUsername(req_body) {
    const url = this.requestURL('/user/forgot-username');
    return this.http.post(url, req_body).toPromise();
  }
  setUserFromThirdPartyApplication(data) {
    this._userFromThirdPartyApplication.next(data);
  }

  isUserFromThirdPartyApplication() {
    return this._userFromThirdPartyApplication.asObservable();
  }
}
