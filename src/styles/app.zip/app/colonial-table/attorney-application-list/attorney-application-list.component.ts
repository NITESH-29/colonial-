import { Component, Input } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';
import { TableDefaultDetails } from '../../form-components/generic-table-search/table-default-details';
import { Subject } from 'rxjs/index';

@Component({
  selector: 'app-attorney-application-list',
  templateUrl: './attorney-application-list.component.html',
  styleUrls: ['./attorney-application-list.component.scss'],
})
export class AttorneyApplicationListComponent {

  @Input()
  tableDefaultDetails: TableDefaultDetails;

  mode = 'Court';

  tabs: string[] = [
    'Court',
    'Professional Liability',
  ];

  filtersEventSubject: Subject<any> = new Subject();

  constructor() {
  }

  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {
    this.switchMode(tabChangeEvent.tab.textLabel.toLocaleLowerCase());
  }

  switchMode(modeVal) {
    this.mode = modeVal;
  }

  emitFiltersSubject() {
    this.filtersEventSubject.next();
  }

}
