

export interface ListLinkClickEvent {
  columnFieldName?: string;
  data: any;
}

export interface IconActionListEvent {
  data?: any;
  action?: string;
}
