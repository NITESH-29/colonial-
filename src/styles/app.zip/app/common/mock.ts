import { Observable, of } from 'rxjs';
export const agreementJson = [
  {
    'name': 'Personal Details',
    'label': '',
    'section_type': 'BLOCK',
    'questions_per_row': 3,
    'questions_alignment': null,
    'visible_by_default': 1,
    'fields': [
      {
        'question_reference_id': 1,
        'sequence_number': 0,
        'label': '',
        'name': 'aggrementTermsYes',
        'type': 'checkbox',
        'value': '',
        'visible_by_default': 1,
        'options': [
          {
            'id': 1,
            'code': 'yes',
            'label': '',
          },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': '',
        'name': 'aggrementYes',
        'type': 'checkbox',
        'value': '',
        'visible_by_default': 1,
        'options': [
          {
            'id': 1,
            'code': 'yes',
            'label': 'Yes, I have read & agree with the terms and conditions of this agreement.*',
          },
        ],
      },
      {
        'id': 68,
        'name': 'readAndAgreeToTerms',
        'label': 'Yes, I have read & agree with the terms and conditions of this agreement.',
        'type': 'singlecheckbox',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
        'sequence_number': 2,
      },
      {
        'id': 64,
        'name': 'acknowledgeFraudWarning',
        'label': 'Yes, I have read & I agree',
        'type': 'singlecheckbox',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
        'sequence_number': 3,
      },
      {
        'id': 63,
        'name': 'acknowledgeTerms',
        'label': 'Yes, I acknowledge the above.',
        'type': 'singlecheckbox',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
        'sequence_number': 4,
      },
      {
        'id': 98,
        'name': 'agreeToRenewPolicy',
        'label': '-',
        'type': 'radio',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 68,
            'name': 'yes',
            // tslint:disable-next-line: max-line-length
            'label': 'YES, I want to sign up for automatic renewal to ensure that there will not be a lapse in coverage. I, {APPLICANT_NAME} understand that Colonial will automatically renew upon the expiration date unless otherwise cancelled by Colonial. Prior to expiration, I will be offered the opportunity to change or elect not to renew the policy. I, {APPLICANT_NAME}, authorize Colonial to automatically charge the credit card account I have provided for all renewal policy premium. I represent that I am the owner and/or authorized signer of the account.',
          },
          {
            'id': 69,
            'name': 'no',
            'label': 'NO, I do not want to sign up for automatic renewal to ensure that there will not be a lapse in coverage.',
          },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 5,
        'label': '',
        'name': 'emailSignature',
        'type': 'textbasic',
        'value': 'john@colonialsurety.com',
        'visible_by_default': 1,
        'placeholder': 'example@email.com',
      },
    ],
  },
];

export class MockPreloadService {
  startPreloading(callback?: Function) {
    console.log('Called from MOCK start Preloading');
    callback();
  }
}

export class MockInsuranceStaticService {

  getStates(): Observable<any> {
    return of(
      {
        'list': [
          {
            'id': 1,
            'name': 'AL',
            'label': 'Alabama',
          },
          {
            'id': 54,
            'name': 'AK',
            'label': 'Alaska',
          },
          {
            'id': 61,
            'name': 'AS',
            'label': 'American Samoa',
          },
          {
            'id': 2,
            'name': 'AZ',
            'label': 'Arizona',
          },
        ],
      }
    );
  }

  getSanctionedStates(): Observable<any> {
    return of(
      {
        'list': [
          'AS',
          'CA',
        ],
      }
    );
  }

  getProfession(): Observable<any> {
    return of(
      {
        'list': [
          {
            'id': 1,
            'name': 'accountants',
            'label': 'Accountants',
          },
          {
            'id': 2,
            'name': 'acupressureServices',
            'label': 'Acupressure services',
          },
          {
            'id': 3,
            'name': 'acupunctureServices',
            'label': 'Acupuncture services',
          },
          {
            'id': 4,
            'name': 'advertising',
            'label': 'Advertising',
          },
          {
            'id': 5,
            'name': 'answeringPagingServices',
            'label': 'Answering/paging services',
          },
        ],
      }
    );
  }

  getStaticQuestion(): Observable<any> {
    return of(
      {
        'questions': [
          {
            'id': 1,
            'name': 'application_firstName',
            'label': 'First Name',
            'type': 'textbasic',
            'validations': [],
          },
          {
            'id': 2,
            'name': 'application_lastName',
            'label': 'Last Name',
            'type': 'textbasic',
            'validations': [],
          },
        ],
      }
    );
  }

  getInsuranceSectionFormJson(): Observable<any> {
    return of(
      {
        'questions': [
          {
            'id': 43911,
            'name': 'PNL_activeRetiredPractitioner_AZ_acupressureServices',
            // tslint:disable-next-line:max-line-length
            'label': 'Are you are an active or retired Medical Doctor, Registered Nurse, Nurse Practitioner, Licensed Practical Nurse, Physician??s Assistant or Naturopathic Doctor?',
            'type': 'radio',
            'validations': [
              {
                'name': 'required',
                'value': 'true',
                'message': 'Field is Required',
              },
            ],
            'options': [
              {
                'id': 20,
                'name': 'yes',
                'label': 'Yes',
              },
              {
                'id': 21,
                'name': 'no',
                'label': 'No',
              },
            ],
          },
          {
            'id': 29813,
            'name': 'PNL_acupunctureServices_AZ_acupressureServices',
            'label': 'Does your business provide any acupuncture services?',
            'type': 'radio',
            'validations': [
              {
                'name': 'required',
                'value': 'true',
                'message': 'Field is Required',
              },
            ],
            'options': [
              {
                'id': 20,
                'name': 'yes',
                'label': 'Yes',
              },
              {
                'id': 21,
                'name': 'no',
                'label': 'No',
              },
            ],
          },
        ],
      }
    );
  }

  getZipCodeFromAddress(zipCode): Observable<any> {
    let _obj = {};
    if (zipCode === '08817') {
      _obj = { 'zip': '08817', 'city': 'Edison', 'state': 'NJ', 'invalidZipCodeMessage': null, 'countyName': 'Middlesex' };
    }

    if (zipCode === '44444') {
      _obj = { 'zip': '44444', 'city': 'New York', 'state': 'NY', 'invalidZipCodeMessage': null, 'countyName': 'Middlesex' };
    }

    if (zipCode === '12345') {
      _obj = {};
    }
    return of(_obj);
  }

  getInsuranceDetailFormJson() {
    return {
      'data': [{
        'name': 'Personal Details',
        'label': '',
        'section_type': 'BLOCK',
        'questions_per_row': 3,
        'questions_alignment': null,
        'visible_by_default': 1,
        'fields': [{
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'First Name',
          'name': 'firstName',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Your First Name',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            // tslint:disable-next-line:quotemark
            'value': "^[a-zA-Z0-9 '-]*$",
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxlength',
            'value': 100,
            'message': '',
          },
          ],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Last Name',
          'name': 'lastName',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Your Last Name',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            // tslint:disable-next-line:quotemark
            'value': "^[a-zA-Z0-9 '-]*$",
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxlength',
            'value': 100,
            'message': '',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Applicant/Business Name',
          'name': 'applicantName',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Your Business Name',
          'validations': [{
            'name': 'required',
            // tslint:disable-next-line:quotemark
            'value': "^[a-zA-Z0-9 '-]*$",
            'message': 'This field is required',
          },
          {
            'name': 'maxlength',
            'value': 450,
            'message': '',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Profession',
          'name': 'profession',
          'optionReference': 'profession',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Select',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'maxlength',
            'value': 35,
            'message': '',
          }],
          'options': [],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': '',
          'name': 'setApplicantName',
          'type': 'checkbox',
          'value': '',
          'visible_by_default': 1,
          'validations': [],
          'options': [{
            'id': 101,
            'name': 'Use First/Last name as applicant name',
            'label': 'Use First/Last name as applicant name',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Address line 1',
          'name': 'street1',
          'type': 'textgoogle',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Address Line 1',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Address line 2',
          'name': 'street2',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Address Line 2',
          'validations': [],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Email Address',
          'name': 'applicantEmail',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'example@email.com',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'value': '[a-zA-Z0-9.@,_&-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{3,}',
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxlength',
            'value': 45,
            'message': '',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'City',
          'name': 'city',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'City',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            // tslint:disable-next-line:quotemark
            'value': "^[a-zA-Z '-]*$",
            'message': 'Please enter valid values',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'State',
          'name': 'state',
          'type': 'selectwithsearch',
          'optionReference': 'state',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Select',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'maxlength',
            'value': 2,
            'message': '',
          }],
          'options': [],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Zip Code',
          'name': 'zipCode',
          'type': 'textnumber',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Enter ZipCode',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'maxlength',
            'value': 5,
            'message': '',
          }],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Phone',
          'name': 'applicantPhone',
          'type': 'textphone',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Phone Number',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'value': '^[0-9-]{12}',
            'message': 'Please enter valid values',
          },
          ],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'What best describes your business structure?',
          'name': 'businessStructure',
          'type': 'selectbox',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Select',
          'options': [
            {
              'id': 1,
              'name': 'Individual/Sole Proprietor',
              'label': 'Individual/Sole Proprietor',
            },
            {
              'id': 2,
              'name': 'Joint Venture',
              'label': 'Joint Venture',
            },
            {
              'id': 3,
              'name': 'Limited Liability Company',
              'label': 'Limited Liability Company',
            },
            {
              'id': 4,
              'name': 'Partnership',
              'label': 'Partnership',
            },
            {
              'id': 5,
              'name': 'Trust',
              'label': 'Trust',
            },
            {
              'id': 6,
              'name': 'Corporation or other Organization (other than the above)',
              'label': 'Corporation or other Organization (other than the above)',
            },
          ],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Other than the business address provided above, how many additional locations does your business own or rent?',
          'name': 'businessLocations',
          'type': 'selectbox',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'Select',
          'options': [
            {
              'id': 1,
              'name': '1',
              'label': '1',
            },
            {
              'id': 2,
              'name': '2',
              'label': '2',
            },
            {
              'id': 3,
              'name': '3',
              'label': '3',
            },
            {
              'id': 4,
              'name': '4',
              'label': '4',
            },
            {
              'id': 5,
              'name': '5',
              'label': '5+',
            },
          ],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'If you purchase a policy, when would you like your coverage to start?',
          'name': 'policyStartDate',
          'type': 'date',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'mm/dd/yyyy',
          'validations': [],
        },
        ],
      },
      ],
      // tslint:disable-next-line:semicolon
    }
  }

  premiumCalculator(): Observable<any> {
    return of({ premium: 2300 });
  }

  getClientInfoOnType(_clientType, client_id: number): Observable<any> {
    return of({});
  }

  updateApplication(): Observable<any> {
    return of({ premium: 2300 });
  }

  saveApplication(): Observable<any> {
    return of({ premium: 2300 });
  }

  createApplication(): Observable<any> {
    return of({ id: '20501' });
  }

  getInsuranceLimit(_professionCode): Observable<any> {
    const LIMIT = {
      'list': [
        {
          'id': 99,
          'name': '250000',
          'label': '$250,000',
        },
        {
          'id': 211,
          'name': '500000',
          'label': '$500,000',
        },
        {
          'id': 323,
          'name': '1000000',
          'label': '$1,000,000',
        },
      ],
    };
    return of(LIMIT);
  }

  sendToclientMailDetails(_appId): Observable<any> {
    return of({ id: '20502' });
  }

  getAgreementTerms(): Observable<any> {
    return of({ fraudAndWarning: 'Fraud Warning', tnc: '' });
  }

  getAgreementFormJson() {
    return { data: agreementJson };
  }

  getAddressGridFromJson() {
    return of({
      'data': [{
        'name': 'Address grid',
        'label': '',
        'section_type': 'BLOCK',
        'questions_per_row': 3,
        'questions_alignment': null,
        'visible_by_default': 1,
        'fields': [{
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': 'Address',
          'name': 'street',
          'type': 'textgoogle',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'street..',
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
          {
            'name': 'maxlength',
            'value': 250,
            'message': '',
          }],
        },
        ],
      }],
    });
  }
}

export class MockTransactionalService {
  encryptPayload(flag?) {
    const payloadData = {
      'person': {
        'id': 513,
      },
      'data': {
        'applicantId': '20608',
        'applicantAddress': {
          'city': 'Arlington',
          'state': 'VA',
          'street1': '3833 Fairfax Drive',
          'zipCode': '22203',
        },
        'dynamicQuestions': [
          {
            'question': {
              'name': 'PNL_insuranceLimitToPurchase',
            },
            'value': '2000000',
          },
          {
            'question': {
              'name': 'PNL_deductibleToPurchase',
            },
            'value': '5000',
          },
          {
            'question': {
              'name': 'PNL_estimatedGrossSalesInNextTwelveMonths',
            },
            'value': '11.00',
          },
          {
            'question': {
              'name': 'PNL_whenWouldCoverageStart',
            },
            'value': '2020-09-09',
          },
          {
            'question': {
              'name': 'PNL_acupunctureServices',
            },
            'value': 'yes',
          },
          {
            'question': {
              'name': 'PNL_homeopathyCupping',
            },
            'value': 'yes',
          },
          {
            'question': {
              'name': 'PNL_workHospital',
            },
            'value': 'yes',
          },
          {
            'question': {
              'name': 'PNL_activeRetiredPractitioner',
            },
            'value': 'yes',
          },
          {
            'question': {
              'name': 'PNL_whenBusinessBegan',
            },
            'value': '2020-09-03',
          },
        ],
        'deliveryMethod': {
          'deliveryMethod': 'Email',
        },
        'applicantPhone': '123-232-3232',
        'applicantEmail': 'sfdf@gmail.com',
        'bondClassification': 'pnl',
        'firstName': 'sdsd',
        'lastName': 'qwsd',
        'pageReference': 'getQuote',
        'profession': 'acupressureServices',
        'buttonReference': 'continue',
        'ownerName': 'sdsd qwsd',
        'businessLocations': '4',
        'businessStructure': 'partnership',
        'setApplicantName': true,
        'applicantName': 'sdsd qwsd',
      },
      'id': '20608',
    };
    return payloadData;
  }

  isUserLogIn(): boolean {
    return true;
  }

  getPersonalProfileTypeAndProfileId() {
    return [513, 'P'];
  }
  isAgent(): boolean {
    return false;
  }

  // tslint:disable-next-line:max-line-length
  prePopulateUserDetails(_spinner, _clientId?, clientType?, _isJumpOnGetQuote?, _form?, isCompanyExistForPersonProfile?, _isCheckBoxCheked?, _callbackFn?) {

  }

  isClientAssociatedWithAgent(): boolean {
    return true;
  }
  isMandatoryAddressFieldsProvided(): Observable<boolean> {
    return of(true);
  }

  setControlState(spinner, form) {
  }

  decryptPayload(appData, premiumAmount) {
  }

  debounce(func, wait, immediate?) {
    let timeout;
    return function() {
      const context = this, args = arguments;
      const later = function() {
        timeout = null;
        if (!immediate) {
          func.apply(context, args);
        }
      };
      const callNow = (immediate && !timeout);
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) {
        func.apply(context, args);
      }
    };
  }
}
import { BehaviorSubject } from 'rxjs';
export const MockStateService = {
  isConfirmationPageLoad: BehaviorSubject,
  quoteId: '20622',
  SECTIONS: {
    'getQuote': {
      'istouched': true,
      'status': 'complete',
      'errors': 0,
      'getQuote': {
        'errors': 0,
        'requiredFields': 0,
        'istouched': true,
        'invalidFields': [],
      },
    },
    'productInformation': {
      'istouched': false,
      'status': 'inProgress',
      'errors': 4,
      'applicantDetails': {
        'errors': 4,
        'requiredFields': 0,
        'istouched': true,
        'invalidFields': [],
      },
      'pnl': {
        'errors': 0,
        'requiredFields': 0,
        'istouched': false,
        'invalidFields': [],
      },
    },
    'yourQuote': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
    },
    'agreement': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
    },
    'payment': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
    },
    'createUser': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
    },
  },
  insuranceDetails: {
    'applicationId': '20622',
    'questionAnswers': {
      'dynamicQuestions': {},
      'paymentMethod': {},
      'premiumCalculation': {},
      'applicantId': 513,
      'applicantPhone': '121-212-1212',
      'applicantEmail': 'fdfd@gmail.com',
      'state': 'AZ',
      'bondClassification': 'pnl',
      'firstName': 'sdsd',
      'lastName': 'sdsd',
      'deliveryMethod': 'Email',
      'pageReference': 'getQuote',
      'profession': 'acupressureServices',
      'buttonReference': 'continue',
      'ownerName': 'sdsd sdsd',
    },
    'insuranceLimit': {
      'list': [
        {
          'id': 99,
          'name': '250000',
          'label': '$250,000',
        },
        {
          'id': 211,
          'name': '500000',
          'label': '$500,000',
        },
        {
          'id': 323,
          'name': '1000000',
          'label': '$1,000,000',
        },
      ],
    },
  },
  preloadData: {
    'state': [
      {
        'id': 1,
        'name': 'AL',
        'label': 'Alabama',
      },
      {
        'id': 54,
        'name': 'AK',
        'label': 'Alaska',
      },
      {
        'id': 61,
        'name': 'AS',
        'label': 'American Samoa',
      },
      {
        'id': 2,
        'name': 'AZ',
        'label': 'Arizona',
      },
      {
        'id': 3,
        'name': 'AR',
        'label': 'Arkansas',
      },
      {
        'id': 4,
        'name': 'CA',
        'label': 'California',
      },
      {
        'id': 5,
        'name': 'CO',
        'label': 'Colorado',
      },
      {
        'id': 6,
        'name': 'CT',
        'label': 'Connecticut',
      },
      {
        'id': 8,
        'name': 'DC',
        'label': 'D.C.',
      },
      {
        'id': 7,
        'name': 'DE',
        'label': 'Delaware',
      },
      {
        'id': 9,
        'name': 'FL',
        'label': 'Florida',
      },
      {
        'id': 10,
        'name': 'GA',
        'label': 'Georgia',
      },
      {
        'id': 53,
        'name': 'GU',
        'label': 'Guam',
      },
      {
        'id': 52,
        'name': 'HI',
        'label': 'Hawaii',
      },
      {
        'id': 11,
        'name': 'ID',
        'label': 'Idaho',
      },
      {
        'id': 12,
        'name': 'IL',
        'label': 'Illinois',
      },
      {
        'id': 13,
        'name': 'IN',
        'label': 'Indiana',
      },
      {
        'id': 14,
        'name': 'IA',
        'label': 'Iowa',
      },
      {
        'id': 15,
        'name': 'KS',
        'label': 'Kansas',
      },
      {
        'id': 16,
        'name': 'KY',
        'label': 'Kentucky',
      },
      {
        'id': 17,
        'name': 'LA',
        'label': 'Louisiana',
      },
      {
        'id': 18,
        'name': 'ME',
        'label': 'Maine',
      },
      {
        'id': 19,
        'name': 'MD',
        'label': 'Maryland',
      },
      {
        'id': 20,
        'name': 'MA',
        'label': 'Massachusetts',
      },
      {
        'id': 21,
        'name': 'MI',
        'label': 'Michigan',
      },
      {
        'id': 22,
        'name': 'MN',
        'label': 'Minnesota',
      },
      {
        'id': 23,
        'name': 'MS',
        'label': 'Mississippi',
      },
      {
        'id': 24,
        'name': 'MO',
        'label': 'Missouri',
      },
      {
        'id': 25,
        'name': 'MT',
        'label': 'Montana',
      },
      {
        'id': 26,
        'name': 'NE',
        'label': 'Nebraska',
      },
      {
        'id': 27,
        'name': 'NV',
        'label': 'Nevada',
      },
      {
        'id': 28,
        'name': 'NH',
        'label': 'New Hampshire',
      },
      {
        'id': 29,
        'name': 'NJ',
        'label': 'New Jersey',
      },
      {
        'id': 30,
        'name': 'NM',
        'label': 'New Mexico',
      },
      {
        'id': 32,
        'name': 'NC',
        'label': 'North Carolina',
      },
      {
        'id': 33,
        'name': 'ND',
        'label': 'North Dakota',
      },
      {
        'id': 34,
        'name': 'OH',
        'label': 'Ohio',
      },
      {
        'id': 35,
        'name': 'OK',
        'label': 'Oklahoma',
      },
      {
        'id': 36,
        'name': 'OR',
        'label': 'Oregon',
      },
      {
        'id': 37,
        'name': 'PA',
        'label': 'Pennsylvania',
      },
      {
        'id': 58,
        'name': 'PR',
        'label': 'Puerto Rico',
      },
      {
        'id': 38,
        'name': 'RI',
        'label': 'Rhode Island',
      },
      {
        'id': 39,
        'name': 'SC',
        'label': 'South Carolina',
      },
      {
        'id': 40,
        'name': 'SD',
        'label': 'South Dakota',
      },
      {
        'id': 41,
        'name': 'TN',
        'label': 'Tennessee',
      },
      {
        'id': 42,
        'name': 'TX',
        'label': 'Texas',
      },
      {
        'id': 43,
        'name': 'UT',
        'label': 'Utah',
      },
      {
        'id': 44,
        'name': 'VT',
        'label': 'Vermont',
      },
      {
        'id': 59,
        'name': 'VI',
        'label': 'Virgin Islands',
      },
      {
        'id': 45,
        'name': 'VA',
        'label': 'Virginia',
      },
      {
        'id': 46,
        'name': 'WA',
        'label': 'Washington',
      },
      {
        'id': 47,
        'name': 'WV',
        'label': 'West Virginia',
      },
      {
        'id': 48,
        'name': 'WI',
        'label': 'Wisconsin',
      },
      {
        'id': 49,
        'name': 'WY',
        'label': 'Wyoming',
      },
    ],
    'profession': [
      {
        'id': 1,
        'name': 'accountants',
        'label': 'Accountants',
      },
      {
        'id': 2,
        'name': 'acupressureServices',
        'label': 'Acupressure services',
      },
      {
        'id': 3,
        'name': 'acupunctureServices',
        'label': 'Acupuncture services',
      },
      {
        'id': 4,
        'name': 'advertising',
        'label': 'Advertising',
      },
      {
        'id': 5,
        'name': 'answeringPagingServices',
        'label': 'Answering/paging services',
      },
      {
        'id': 6,
        'name': 'applicationDevelopment',
        'label': 'Application development',
      },
      {
        'id': 7,
        'name': 'applicationServiceProvider',
        'label': 'Application service provider',
      },
      {
        'id': 8,
        'name': 'architecture',
        'label': 'Architecture',
      },
      {
        'id': 9,
        'name': 'artTherapy',
        'label': 'Art therapy',
      },
      {
        'id': 10,
        'name': 'auctioneering',
        'label': 'Auctioneering',
      },
      {
        'id': 11,
        'name': 'audiology',
        'label': 'Audiology',
      },
      {
        'id': 12,
        'name': 'barberStylistServices',
        'label': 'Barber/hair stylist services',
      },
      {
        'id': 13,
        'name': 'beauticianServices',
        'label': 'Beautician/cosmetology services',
      },
      {
        'id': 14,
        'name': 'bookkeeping',
        'label': 'Bookkeeping',
      },
      {
        'id': 15,
        'name': 'brandConsulting',
        'label': 'Brand Consulting',
      },
      {
        'id': 16,
        'name': 'buildingInspection',
        'label': 'Building inspection',
      },
      {
        'id': 17,
        'name': 'businessConsulting',
        'label': 'Business consulting',
      },
      {
        'id': 18,
        'name': 'businessManagerServices',
        'label': 'Business Manager Services',
      },
      {
        'id': 19,
        'name': 'civilEngineering',
        'label': 'Civil engineering',
      },
      {
        'id': 20,
        'name': 'claimsAdjusting',
        'label': 'Claims adjusting',
      },
      {
        'id': 21,
        'name': 'computerConsulting',
        'label': 'Computer consulting',
      },
      {
        'id': 22,
        'name': 'computerProgrammingServices',
        'label': 'Computer programming services',
      },
      {
        'id': 23,
        'name': 'computerSystemNetworkDeveloper',
        'label': 'Computer system/network developer',
      },
      {
        'id': 24,
        'name': 'controlSystemsIntegrationAutomation',
        'label': 'Control systems integration/automation',
      },
      {
        'id': 25,
        'name': 'courtReporting',
        'label': 'Court reporting',
      },
      {
        'id': 26,
        'name': 'danceTherapy',
        'label': 'Dance therapy',
      },
      {
        'id': 27,
        'name': 'dataProcessing',
        'label': 'Data processing',
      },
      {
        'id': 28,
        'name': 'databaseDesigner',
        'label': 'Database designer',
      },
      {
        'id': 29,
        'name': 'dietNutritionServices',
        'label': 'Diet/nutrition services',
      },
      {
        'id': 30,
        'name': 'digitalMarketing',
        'label': 'Digital marketing',
      },
      {
        'id': 31,
        'name': 'directMarketing',
        'label': 'Direct marketing',
      },
      {
        'id': 32,
        'name': 'documentPreparation',
        'label': 'Document preparation',
      },
      {
        'id': 33,
        'name': 'draftsman',
        'label': 'Draftsman (including CAD/CAM)',
      },
      {
        'id': 34,
        'name': 'dramaTherapy',
        'label': 'Drama therapy',
      },
      {
        'id': 35,
        'name': 'educationConsulting',
        'label': 'Education consulting',
      },
      {
        'id': 36,
        'name': 'electricalEngineering',
        'label': 'Electrical engineering',
      },
      {
        'id': 37,
        'name': 'engineering',
        'label': 'Engineering',
      },
      {
        'id': 38,
        'name': 'environmentalEngineering',
        'label': 'Environmental engineering',
      },
      {
        'id': 39,
        'name': 'estheticianServices',
        'label': 'Esthetician services',
      },
      {
        'id': 40,
        'name': 'eventPlanningPromotion',
        'label': 'Event planning/Promotion',
      },
      {
        'id': 41,
        'name': 'executivePlacement',
        'label': 'Executive placement',
      },
      {
        'id': 42,
        'name': 'expertWitnessServices',
        'label': 'Expert witness services',
      },
      {
        'id': 43,
        'name': 'firstAidCPRTraining',
        'label': 'First aid & CPR training',
      },
      {
        'id': 44,
        'name': 'graphicDesign',
        'label': 'Graphic design',
      },
      {
        'id': 45,
        'name': 'homeHealthAides',
        'label': 'Home health aides',
      },
      {
        'id': 46,
        'name': 'humanResourcesConsulting',
        'label': 'Human Resources (HR) consulting',
      },
      {
        'id': 47,
        'name': 'hypnosis',
        'label': 'Hypnosis',
      },
      {
        'id': 48,
        'name': 'industrialEngineering',
        'label': 'Industrial engineering',
      },
      {
        'id': 49,
        'name': 'insuranceAgents',
        'label': 'Insurance agents',
      },
      {
        'id': 50,
        'name': 'insuranceInspectors',
        'label': 'Insurance Inspectors',
      },
      {
        'id': 51,
        'name': 'interiorDesign',
        'label': 'Interior Design',
      },
      {
        'id': 52,
        'name': 'ITConsulting',
        'label': 'IT consulting',
      },
      {
        'id': 53,
        'name': 'ITProjectManagement',
        'label': 'IT project management',
      },
      {
        'id': 54,
        'name': 'ITSoftwareHardwareTrainingServices',
        'label': 'IT software/hardware training services',
      },
      {
        'id': 55,
        'name': 'landSurveyors',
        'label': 'Land surveyors',
      },
      {
        'id': 56,
        'name': 'landscape',
        'label': 'Landscape',
      },
      {
        'id': 57,
        'name': 'landscapeArchitect',
        'label': 'Landscape architect',
      },
      {
        'id': 58,
        'name': 'lifeCoaching',
        'label': 'Life/career/executive coaching',
      },
      {
        'id': 59,
        'name': 'managementconsulting',
        'label': 'Management consulting',
      },
      {
        'id': 60,
        'name': 'marketResearch',
        'label': 'Market research',
      },
      {
        'id': 61,
        'name': 'marketingMediaConsulting',
        'label': 'Marketing/Media Consulting',
      },
      {
        'id': 62,
        'name': 'marriageFamilyTherapy',
        'label': 'Marriage and family therapy',
      },
      {
        'id': 63,
        'name': 'massageTherapy',
        'label': 'Massage therapy',
      },
      {
        'id': 64,
        'name': 'medicalBilling',
        'label': 'Medical billing',
      },
      {
        'id': 65,
        'name': 'mentalHealthCounseling',
        'label': 'Mental health counseling',
      },
      {
        'id': 66,
        'name': 'mentalHealthCounselor',
        'label': 'Mental health counselor',
      },
      {
        'id': 67,
        'name': 'musicTherapy',
        'label': 'Music therapy',
      },
      {
        'id': 68,
        'name': 'nailTechnician',
        'label': 'Nail technician',
      },
      {
        'id': 69,
        'name': 'notaryServices',
        'label': 'Notary services',
      },
      {
        'id': 70,
        'name': 'occupationalTherapy',
        'label': 'Occupational therapy',
      },
      {
        'id': 71,
        'name': 'otherConsultingServices',
        'label': 'Other Consulting services',
      },
      {
        'id': 73,
        'name': 'otherMarketingServices',
        'label': 'Other marketing/PR Services',
      },
      {
        'id': 74,
        'name': 'otherTechnologyServices',
        'label': 'Other technology services',
      },
      {
        'id': 75,
        'name': 'personalAides',
        'label': 'Personal aides',
      },
      {
        'id': 76,
        'name': 'personalCareAides',
        'label': 'Personal care aides',
      },
      {
        'id': 77,
        'name': 'personalConciergeAssistant',
        'label': 'Personal concierge/Assistant',
      },
      {
        'id': 78,
        'name': 'personalTrainerHealthFitness)',
        'label': 'Personal trainer (health and fitness)',
      },
      {
        'id': 79,
        'name': 'photography',
        'label': 'Photography',
      },
      {
        'id': 80,
        'name': 'processEngineering',
        'label': 'Process engineering',
      },
      {
        'id': 81,
        'name': 'processServer',
        'label': 'Process Server',
      },
      {
        'id': 82,
        'name': 'projectManagement',
        'label': 'Project management',
      },
      {
        'id': 83,
        'name': 'projectManager',
        'label': 'Project manager (architecture or engineering)',
      },
      {
        'id': 84,
        'name': 'propertyManagement',
        'label': 'Property management',
      },
      {
        'id': 85,
        'name': 'psychology',
        'label': 'Psychology',
      },
      {
        'id': 86,
        'name': 'publicRelations',
        'label': 'Public relations',
      },
      {
        'id': 88,
        'name': 'realEstateAgentsBrokers',
        'label': 'Real Estate Agents/Brokers',
      },
      {
        'id': 89,
        'name': 'recruiting',
        'label': 'Recruiting (employment placements)',
      },
      {
        'id': 90,
        'name': 'researchConsulting',
        'label': 'Research consulting',
      },
      {
        'id': 91,
        'name': 'resumeConsulting',
        'label': 'Resume consulting',
      },
      {
        'id': 92,
        'name': 'safetyConsultants',
        'label': 'Safety consultants',
      },
      {
        'id': 93,
        'name': 'safetyConsulting',
        'label': 'Safety consulting',
      },
      {
        'id': 94,
        'name': 'salesRepresentatives',
        'label': 'Sales representatives',
      },
      {
        'id': 95,
        'name': 'searchEngineServices',
        'label': 'Search engine services (SEO/SEM)',
      },
      {
        'id': 96,
        'name': 'socialMediaConsulting',
        'label': 'Social media consulting',
      },
      {
        'id': 97,
        'name': 'socialWorkServices',
        'label': 'Social work services',
      },
      {
        'id': 98,
        'name': 'softwareDevelopment',
        'label': 'Software development',
      },
      {
        'id': 99,
        'name': 'speechTherapy',
        'label': 'Speech therapy',
      },
      {
        'id': 100,
        'name': 'strategyConsultant',
        'label': 'Strategy consultant',
      },
      {
        'id': 101,
        'name': 'substanceAbuseCounseling',
        'label': 'Substance abuse counseling',
      },
      {
        'id': 102,
        'name': 'substanceAbuseCounselor',
        'label': 'Substance abuse counselor',
      },
      {
        'id': 103,
        'name': 'taxPreparation',
        'label': 'Tax preparation',
      },
      {
        'id': 104,
        'name': 'technologyServices',
        'label': 'Technology services',
      },
      {
        'id': 105,
        'name': 'trainingBusinessVocational',
        'label': 'Training (business, vocational or life skills)',
      },
      {
        'id': 106,
        'name': 'translatingInterpreting',
        'label': 'Translating/interpreting',
      },
      {
        'id': 107,
        'name': 'transportationEngineering',
        'label': 'Transportation engineering',
      },
      {
        'id': 108,
        'name': 'travelAgency',
        'label': 'Travel agency',
      },
      {
        'id': 109,
        'name': 'tutoring',
        'label': 'Tutoring',
      },
      {
        'id': 110,
        'name': 'valueAddedResellerComputerHardware',
        'label': 'Value added reseller of computer hardware',
      },
      {
        'id': 111,
        'name': 'websiteDesign',
        'label': 'Website design',
      },
      {
        'id': 112,
        'name': 'yogaPilatesInstruction',
        'label': 'Yoga/Pilates instruction',
      },
    ],
    'sanctionStates': [
      'MP',
      'NY',
    ],
    'allowedStates': [
      {
        'id': 1,
        'name': 'AL',
        'label': 'Alabama',
      },
      {
        'id': 54,
        'name': 'AK',
        'label': 'Alaska',
      },
      {
        'id': 61,
        'name': 'AS',
        'label': 'American Samoa',
      },
      {
        'id': 2,
        'name': 'AZ',
        'label': 'Arizona',
      },
      {
        'id': 3,
        'name': 'AR',
        'label': 'Arkansas',
      },
      {
        'id': 4,
        'name': 'CA',
        'label': 'California',
      },
      {
        'id': 5,
        'name': 'CO',
        'label': 'Colorado',
      },
      {
        'id': 6,
        'name': 'CT',
        'label': 'Connecticut',
      },
      {
        'id': 8,
        'name': 'DC',
        'label': 'D.C.',
      },
      {
        'id': 7,
        'name': 'DE',
        'label': 'Delaware',
      },
      {
        'id': 9,
        'name': 'FL',
        'label': 'Florida',
      },
      {
        'id': 10,
        'name': 'GA',
        'label': 'Georgia',
      },
      {
        'id': 53,
        'name': 'GU',
        'label': 'Guam',
      },
      {
        'id': 52,
        'name': 'HI',
        'label': 'Hawaii',
      },
      {
        'id': 11,
        'name': 'ID',
        'label': 'Idaho',
      },
      {
        'id': 12,
        'name': 'IL',
        'label': 'Illinois',
      },
      {
        'id': 13,
        'name': 'IN',
        'label': 'Indiana',
      },
      {
        'id': 14,
        'name': 'IA',
        'label': 'Iowa',
      },
      {
        'id': 15,
        'name': 'KS',
        'label': 'Kansas',
      },
      {
        'id': 16,
        'name': 'KY',
        'label': 'Kentucky',
      },
      {
        'id': 17,
        'name': 'LA',
        'label': 'Louisiana',
      },
      {
        'id': 18,
        'name': 'ME',
        'label': 'Maine',
      },
      {
        'id': 19,
        'name': 'MD',
        'label': 'Maryland',
      },
      {
        'id': 20,
        'name': 'MA',
        'label': 'Massachusetts',
      },
      {
        'id': 21,
        'name': 'MI',
        'label': 'Michigan',
      },
      {
        'id': 22,
        'name': 'MN',
        'label': 'Minnesota',
      },
      {
        'id': 23,
        'name': 'MS',
        'label': 'Mississippi',
      },
      {
        'id': 24,
        'name': 'MO',
        'label': 'Missouri',
      },
      {
        'id': 25,
        'name': 'MT',
        'label': 'Montana',
      },
      {
        'id': 26,
        'name': 'NE',
        'label': 'Nebraska',
      },
      {
        'id': 27,
        'name': 'NV',
        'label': 'Nevada',
      },
      {
        'id': 28,
        'name': 'NH',
        'label': 'New Hampshire',
      },
      {
        'id': 29,
        'name': 'NJ',
        'label': 'New Jersey',
      },
      {
        'id': 30,
        'name': 'NM',
        'label': 'New Mexico',
      },
      {
        'id': 32,
        'name': 'NC',
        'label': 'North Carolina',
      },
      {
        'id': 33,
        'name': 'ND',
        'label': 'North Dakota',
      },
      {
        'id': 34,
        'name': 'OH',
        'label': 'Ohio',
      },
      {
        'id': 35,
        'name': 'OK',
        'label': 'Oklahoma',
      },
      {
        'id': 36,
        'name': 'OR',
        'label': 'Oregon',
      },
      {
        'id': 37,
        'name': 'PA',
        'label': 'Pennsylvania',
      },
      {
        'id': 58,
        'name': 'PR',
        'label': 'Puerto Rico',
      },
      {
        'id': 38,
        'name': 'RI',
        'label': 'Rhode Island',
      },
      {
        'id': 39,
        'name': 'SC',
        'label': 'South Carolina',
      },
      {
        'id': 40,
        'name': 'SD',
        'label': 'South Dakota',
      },
      {
        'id': 41,
        'name': 'TN',
        'label': 'Tennessee',
      },
      {
        'id': 42,
        'name': 'TX',
        'label': 'Texas',
      },
      {
        'id': 43,
        'name': 'UT',
        'label': 'Utah',
      },
      {
        'id': 44,
        'name': 'VT',
        'label': 'Vermont',
      },
      {
        'id': 59,
        'name': 'VI',
        'label': 'Virgin Islands',
      },
      {
        'id': 45,
        'name': 'VA',
        'label': 'Virginia',
      },
      {
        'id': 46,
        'name': 'WA',
        'label': 'Washington',
      },
      {
        'id': 47,
        'name': 'WV',
        'label': 'West Virginia',
      },
      {
        'id': 48,
        'name': 'WI',
        'label': 'Wisconsin',
      },
      {
        'id': 49,
        'name': 'WY',
        'label': 'Wyoming',
      },
    ],
    'allStates': [
      {
        'id': 1,
        'name': 'AL',
        'label': 'Alabama',
      },
      {
        'id': 54,
        'name': 'AK',
        'label': 'Alaska',
      },
      {
        'id': 61,
        'name': 'AS',
        'label': 'American Samoa',
      },
      {
        'id': 2,
        'name': 'AZ',
        'label': 'Arizona',
      },
      {
        'id': 3,
        'name': 'AR',
        'label': 'Arkansas',
      },
      {
        'id': 4,
        'name': 'CA',
        'label': 'California',
      },
      {
        'id': 5,
        'name': 'CO',
        'label': 'Colorado',
      },
      {
        'id': 6,
        'name': 'CT',
        'label': 'Connecticut',
      },
      {
        'id': 8,
        'name': 'DC',
        'label': 'D.C.',
      },
      {
        'id': 7,
        'name': 'DE',
        'label': 'Delaware',
      },
      {
        'id': 9,
        'name': 'FL',
        'label': 'Florida',
      },
      {
        'id': 10,
        'name': 'GA',
        'label': 'Georgia',
      },
      {
        'id': 53,
        'name': 'GU',
        'label': 'Guam',
      },
      {
        'id': 52,
        'name': 'HI',
        'label': 'Hawaii',
      },
      {
        'id': 11,
        'name': 'ID',
        'label': 'Idaho',
      },
      {
        'id': 12,
        'name': 'IL',
        'label': 'Illinois',
      },
      {
        'id': 13,
        'name': 'IN',
        'label': 'Indiana',
      },
      {
        'id': 14,
        'name': 'IA',
        'label': 'Iowa',
      },
      {
        'id': 15,
        'name': 'KS',
        'label': 'Kansas',
      },
      {
        'id': 16,
        'name': 'KY',
        'label': 'Kentucky',
      },
      {
        'id': 17,
        'name': 'LA',
        'label': 'Louisiana',
      },
      {
        'id': 18,
        'name': 'ME',
        'label': 'Maine',
      },
      {
        'id': 60,
        'name': 'MP',
        'label': 'Mariana Islands',
      },
      {
        'id': 19,
        'name': 'MD',
        'label': 'Maryland',
      },
      {
        'id': 20,
        'name': 'MA',
        'label': 'Massachusetts',
      },
      {
        'id': 21,
        'name': 'MI',
        'label': 'Michigan',
      },
      {
        'id': 22,
        'name': 'MN',
        'label': 'Minnesota',
      },
      {
        'id': 23,
        'name': 'MS',
        'label': 'Mississippi',
      },
      {
        'id': 24,
        'name': 'MO',
        'label': 'Missouri',
      },
      {
        'id': 25,
        'name': 'MT',
        'label': 'Montana',
      },
      {
        'id': 26,
        'name': 'NE',
        'label': 'Nebraska',
      },
      {
        'id': 27,
        'name': 'NV',
        'label': 'Nevada',
      },
      {
        'id': 28,
        'name': 'NH',
        'label': 'New Hampshire',
      },
      {
        'id': 29,
        'name': 'NJ',
        'label': 'New Jersey',
      },
      {
        'id': 30,
        'name': 'NM',
        'label': 'New Mexico',
      },
      {
        'id': 31,
        'name': 'NY',
        'label': 'New York',
      },
      {
        'id': 32,
        'name': 'NC',
        'label': 'North Carolina',
      },
      {
        'id': 33,
        'name': 'ND',
        'label': 'North Dakota',
      },
      {
        'id': 34,
        'name': 'OH',
        'label': 'Ohio',
      },
      {
        'id': 35,
        'name': 'OK',
        'label': 'Oklahoma',
      },
      {
        'id': 36,
        'name': 'OR',
        'label': 'Oregon',
      },
      {
        'id': 37,
        'name': 'PA',
        'label': 'Pennsylvania',
      },
      {
        'id': 58,
        'name': 'PR',
        'label': 'Puerto Rico',
      },
      {
        'id': 38,
        'name': 'RI',
        'label': 'Rhode Island',
      },
      {
        'id': 39,
        'name': 'SC',
        'label': 'South Carolina',
      },
      {
        'id': 40,
        'name': 'SD',
        'label': 'South Dakota',
      },
      {
        'id': 41,
        'name': 'TN',
        'label': 'Tennessee',
      },
      {
        'id': 42,
        'name': 'TX',
        'label': 'Texas',
      },
      {
        'id': 43,
        'name': 'UT',
        'label': 'Utah',
      },
      {
        'id': 44,
        'name': 'VT',
        'label': 'Vermont',
      },
      {
        'id': 59,
        'name': 'VI',
        'label': 'Virgin Islands',
      },
      {
        'id': 45,
        'name': 'VA',
        'label': 'Virginia',
      },
      {
        'id': 46,
        'name': 'WA',
        'label': 'Washington',
      },
      {
        'id': 47,
        'name': 'WV',
        'label': 'West Virginia',
      },
      {
        'id': 48,
        'name': 'WI',
        'label': 'Wisconsin',
      },
      {
        'id': 49,
        'name': 'WY',
        'label': 'Wyoming',
      },
    ],
    'APIstaticQuestionStack': {
      'firstName': {
        'id': 1,
        'name': 'firstName',
        'label': 'First Name',
        'type': 'textbasic',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'minLength',
            'value': '1',
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxLength',
            'value': '100',
            'message': 'Please enter valid values',
          },
          {
            'name': 'pattern',
            'value': '^[a-zA-Z0-9 \'-]*$',
            'message': 'Please enter valid values',
          },
        ],
      },
      'lastName': {
        'id': 2,
        'name': 'lastName',
        'label': 'Last Name',
        'type': 'textbasic',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'minLength',
            'value': '1',
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxLength',
            'value': '100',
            'message': 'Please enter valid values',
          },
          {
            'name': 'pattern',
            'value': '^[a-zA-Z0-9 \'-]*$',
            'message': 'Please enter valid values',
          },
        ],
      },
      'applicantPhone': {
        'id': 3,
        'name': 'applicantPhone',
        'label': 'Phone',
        'type': 'textphone',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'minLength',
            'value': '1',
            'message': 'Please enter valid values',
          },
          {
            'name': 'pattern',
            'value': '^[0-9-]{12}',
            'message': 'Please enter valid values',
          },
        ],
      },
      'applicantEmail': {
        'id': 4,
        'name': 'applicantEmail',
        'label': 'Email Address',
        'type': 'email',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'value': '^([A-Za-z0-9@,_&-])+\\@([A-Za-z0-9])+([\\.]{1})([A-Za-z]{3})$',
            'message': 'Please enter valid email address',
          },
          {
            'name': 'maxLength',
            'value': '45',
            'message': 'Please enter valid values',
          },
        ],
      },
      'state': {
        'id': 5,
        'name': 'state',
        'label': 'State',
        'type': 'select',
        'optionReference': 'state',
        'parentObject': 'data.applicantAddress',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
      },
      'profession': {
        'id': 6,
        'name': 'profession',
        'label': 'Profession',
        'type': 'select',
        'optionReference': 'profession',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
      },
      'applicantName': {
        'id': 7,
        'name': 'applicantName',
        'label': 'Applicant/Business Name',
        'type': 'textbasic',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'minLength',
            'value': '1',
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxLength',
            'value': '450',
            'message': 'Please enter valid values',
          },
          {
            'name': 'pattern',
            'value': '^[a-zA-Z0-9 \'-]*$',
            'message': 'Please enter valid values',
          },
        ],
      },
      'ownerName': {
        'id': 8,
        'name': 'ownerName',
        'label': 'Owner Name',
        'type': 'textbasic',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'minLength',
            'value': '1',
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxLength',
            'value': '35',
            'message': 'Please enter valid values',
          },
        ],
      },
      'street1': {
        'id': 9,
        'name': 'street1',
        'label': 'Address Line 1',
        'type': 'textgoogle',
        'parentObject': 'data.applicantAddress',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'minLength',
            'value': '1',
            'message': 'Please enter valid values',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
      },
      'street2': {
        'id': 10,
        'name': 'street2',
        'label': 'Address Line 2',
        'type': 'textgoogle',
        'parentObject': 'data.applicantAddress',
      },
      'zipCode': {
        'id': 11,
        'name': 'zipCode',
        'label': 'Zip Code',
        'type': 'textnumber',
        'parentObject': 'data.applicantAddress',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'maxLength',
            'value': '5',
            'message': 'Please enter valid values',
          },
          {
            'name': 'pattern',
            'pattern': {},
            'message': 'This field is required',
          },
        ],
      },
      'city': {
        'id': 12,
        'name': 'city',
        'label': 'City',
        'type': 'textbasic',
        'parentObject': 'data.applicantAddress',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            'value': '^[a-zA-Z \'-]*$',
            'message': 'Please enter valid values',
          },
          {
            'name': 'maxLength',
            'value': '30',
            'message': 'Please enter valid values',
          },
        ],
      },
      'businessLocations': {
        'id': 13,
        'name': 'businessLocations',
        'label': 'Other than the business address provided above, how many additional locations does your business own or rent?',
        'type': 'select',
        'parentObject': 'data',
        'options': [
          {
            'id': 1,
            'name': '1',
            'label': '1',
          },
          {
            'id': 2,
            'name': '2',
            'label': '2',
          },
          {
            'id': 3,
            'name': '3',
            'label': '3',
          },
          {
            'id': 4,
            'name': '4',
            'label': '4',
          },
          {
            'id': 5,
            'name': '5+',
            'label': '5+',
          },
        ],
      },
      'businessStructure': {
        'id': 14,
        'name': 'businessStructure',
        'label': 'What best describes your business structure?',
        'type': 'select',
        'parentObject': 'data',
        'options': [
          {
            'id': 6,
            'name': 'individual',
            'label': 'Individual /Sole Proprietor',
          },
          {
            'id': 7,
            'name': 'jointVenture',
            'label': 'Joint Venture',
          },
          {
            'id': 8,
            'name': 'limitedLiabilityCompany',
            'label': 'Limited Liability Company',
          },
          {
            'id': 9,
            'name': 'partnership',
            'label': 'Partnership',
          },
          {
            'id': 10,
            'name': 'trust',
            'label': 'Trust',
          },
          {
            'id': 11,
            'name': 'corporation',
            'label': 'Corporation or Other Organization',
          },
        ],
      },
      'policyStartDate': {
        'id': 15,
        'name': 'policyStartDate',
        'label': 'If you purchase a policy, when would you like your coverage to start?',
        'type': 'date',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'maxDate',
            'value': '15',
            'message': 'Please enter valid values',
          },
        ],
      },
      'premiumOption': {
        'id': 16,
        'name': 'premiumOption',
        'label': 'Premium Option',
        'type': 'radio',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 12,
            'name': 'annualPay',
            'label': 'Annual Pay',
          },
          {
            'id': 13,
            'name': 'monthlyPay',
            'label': 'Monthly Pay',
          },
        ],
      },
      'amount': {
        'id': 17,
        'name': 'amount',
        'label': 'Aggregate Limit',
        'type': 'select',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 18,
            'name': '250000',
            'label': '$250,000',
          },
          {
            'id': 19,
            'name': '500000',
            'label': '$500,000',
          },
          {
            'id': 20,
            'name': '1000000',
            'label': '$1,000,000',
          },
          {
            'id': 21,
            'name': '2000000',
            'label': '$2,000,000',
          },
          {
            'id': 22,
            'name': '3000000',
            'label': '$3,000,000',
          },
        ],
      },
      'deductible': {
        'id': 18,
        'name': 'deductible',
        'label': 'Deductible',
        'type': 'select',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 23,
            'name': '500',
            'label': '$500',
          },
          {
            'id': 24,
            'name': '2500',
            'label': '$2,500',
          },
          {
            'id': 25,
            'name': '5000',
            'label': '$5,000',
          },
        ],
      },
      'readAndAgreeToTerms': {
        'id': 29,
        'name': 'readAndAgreeToTerms',
        'label': 'Yes, I have read & agree with the terms and conditions of this agreement.',
        'type': 'singlecheckbox',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
      },
      'emailSignature': {
        'id': 30,
        'name': 'emailSignature',
        'label': 'Signed by',
        'type': 'email',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
      },
      'setApplicantName': {
        'id': 67,
        'name': 'setApplicantName',
        'label': 'Use First/Last name as applicant name',
        'type': 'singlecheckbox',
        'parentObject': 'data',
      },
    },
  },
  fieldError: {},
  screenMapObject: {
    'applicantPhone': '121-212-1212',
    'applicantEmail': 'fdfd@gmail.com',
    'state': 'AZ',
    'firstName': 'sdsd',
    'lastName': 'sdsd',
    'profession': 'acupressureServices',
  },
  insuranceSelected: ['cyber'],
};

export const MockDialog = {
  open: function() {
    return {
      afterClosed: function() { return of({ 'status': 'closed' }); },
    };
  },
};

export const questionList = [
  {
    'id': 51421,
    'name': 'CYBER_stateOfIncorporation',
    'label': 'State of Incorporation',
    'type': 'select',
    'optionReference': 'state',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
  },
  {
    'id': 51422,
    'name': 'CYBER_dateEstablished',
    'label': 'Date Established',
    'type': 'date',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
  },
  {
    'id': 51423,
    'name': 'CYBER_websiteUrl',
    'label': 'Website URLs',
    'type': 'textbasic',
    'sectionName': 'CYBER_businessActivities',
  },
  {
    'id': 51424,
    'name': 'CYBER_noOfEmployee',
    'label': 'No. of Employees',
    'type': 'textnumber',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'maxLength',
        'value': '3',
        'message': 'Please enter valid values',
      },
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
  },
  {
    'id': 51425,
    'name': 'CYBER_authorizedOfficer',
    'label': 'Authorized Officer',
    'type': 'textbasic',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
  },
  {
    'id': 51426,
    'name': 'CYBER_breachResponseContract',
    'label': 'Breach response Contact',
    'type': 'textbasic',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
  },
  {
    'id': 55636,
    'name': 'CYBER_breachResponseContractSeparator',
    'label': 'Separator',
    'type': 'sectionSeparator',
    'sectionName': 'CYBER_businessActivities',
  },
  {
    'id': 51365,
    'name': 'CYBER_businessActivities',
    'label': '<strong>Applicant Business Activities</strong>',
    'type': 'label',
    'sectionName': 'CYBER_businessActivities',
  },
  {
    'id': 51366,
    'name': 'CYBER_providDataService',
    'label': 'Does the Applicant provide data processing, data storage, or data hosting services to third parties?',
    'type': 'radio',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
    'options': [
      {
        'id': 20,
        'name': 'yes',
        'label': 'Yes',
      },
      {
        'id': 21,
        'name': 'no',
        'label': 'No',
      },
    ],
  },
  {
    'id': 51367,
    'name': 'CYBER_businessDescription',
    'label': 'Business Description:',
    'type': 'textbasic',
    'sectionName': 'CYBER_businessActivities',
    'validations': [
      {
        'name': 'required',
        'message': 'This field is required',
      },
    ],
    'displayCriteria': '({CYBER_providDataService} == \'yes\')',
  },
];

export const MockProductConfigService = {
  INSURANCE_LIMIT_ALLOW_PRODUCT: { allowed_products: ['pnl'] },
};
