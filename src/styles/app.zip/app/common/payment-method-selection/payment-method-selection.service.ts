import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ServiceHandler } from '../utils/service-handler.service';
import {
  AppliedPaymentPlanTypeModel,
  AppliedPaymentPlanTypeModelImpl,
  PaymentPlanTypeModel, PaymentPlanTypeModelImpl,
} from './payment-plan-type-model';
import { map, catchError } from 'rxjs/operators';
import { BillingProfileModel, BillingProfileModelImpl } from './billing-profile-model';
import { PaymentPlanModel, PaymentPlanModelImpl } from './payment-plan-model';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../utils/util.service';

@Injectable({
  providedIn: 'root',
})

export class PaymentMethodSelectionService {
  private static readonly paymentPlanTypesRequestURL
    = 'api/payment-plan-type';
  private static readonly applicationApliedPaymentPlanTypesRequestURL
    = 'api/payment-plan-type/calculated/list/application/{applicationId}';
  private static readonly productAppliedPaymentPlanTypesRequestURL
    = 'api/payment-plan-type/calculated/list/product/{productId}';

  private static readonly personBillingProfileRequestURL
    = 'api/billing-profile/person/{personId}';
  private static readonly billingProfileRequestURL
    = 'api/billing-profile/{billingProfileId}';
  private static readonly applicationBillingProfileRequestURL
    = 'api/billing-profile/{billingProfileId}/application/{applicationId}';
  private static readonly uiBillingProfileUpdateURL
    = 'api/billing-profile/ui/{billingProfileId}';

  private static readonly paymentPlanModelsForProductRequestURL
    = '/api/payment-plan/list/product/{productId}';

  private jsonConvert: JsonConvert;

  constructor(private http: HttpClient, private serviceHandler: ServiceHandler) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  getPaymentPlanTypes(criterionDate: Date): Observable<PaymentPlanTypeModel[]> {
    const url = PaymentMethodSelectionService.paymentPlanTypesRequestURL;
    let params: HttpParams = new HttpParams();
    if (criterionDate) {
      params = params.set('criterionDate', criterionDate.toISOString());
    }
    return this.http.get(url, { params })
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((paymentPlanTypes: any) => this.jsonConvert.deserialize(paymentPlanTypes, PaymentPlanTypeModelImpl) as PaymentPlanTypeModel[])
      );
  }

  getApplicationAppliedPaymentPlanTypes(applicationId: number): Observable<AppliedPaymentPlanTypeModel[]> {
    const url = PaymentMethodSelectionService.applicationApliedPaymentPlanTypesRequestURL
      .replace('{applicationId}', applicationId.toString());
    return this.http.get(url)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((paymentPlanTypes: any[]) => this.jsonConvert
          .deserialize(paymentPlanTypes, AppliedPaymentPlanTypeModelImpl) as AppliedPaymentPlanTypeModel[])
      );
  }

  getProductAppliedPaymentPlanTypes(productId: number): Observable<AppliedPaymentPlanTypeModel[]> {
    const url = PaymentMethodSelectionService.productAppliedPaymentPlanTypesRequestURL
      .replace('{productId}', productId.toString());
    return this.http.get(url)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((paymentPlanTypes: any[]) => this.jsonConvert
          .deserialize(paymentPlanTypes, AppliedPaymentPlanTypeModelImpl) as AppliedPaymentPlanTypeModel[])
      );
  }

  getBillingProfilesForPerson(personId: number): Observable<BillingProfileModel[]> {
    const url = PaymentMethodSelectionService.personBillingProfileRequestURL
      .replace('{personId}', personId.toString());
    return this.http.get(url)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((profiles: any[]) => this.jsonConvert.deserialize(profiles, BillingProfileModelImpl) as BillingProfileModel[])
      );
  }

  getOptionBillingProfilesForPerson(personId: number): Observable<BillingProfileModel[]> {
    const url = PaymentMethodSelectionService.personBillingProfileRequestURL
      .replace('{personId}', personId.toString());
    let params: HttpParams = new HttpParams();
    // Get 'valid' and non-deactivated BillingProfiles.
    params = params.set('validFilterValue', 'true');
    params = params.set('deactivatedFilterValue', 'false');
    return this.http.get(url, { params })
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((profiles: any[]) => this.jsonConvert.deserialize(profiles, BillingProfileModelImpl) as BillingProfileModel[])
      );
  }

  /**
   * Return a BillingProfileModel by billingProfileId.
   * Note that the BillingProfile may 'belong' to another user and thus result in a permissions error.
   * @param billingProfileId
   */
  getBillingProfile(billingProfileId: number): Observable<BillingProfileModel> {
    const url = PaymentMethodSelectionService.billingProfileRequestURL
      .replace('{billingProfileId}', billingProfileId.toString());
    return this.http.get(url)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((profile: any) => this.jsonConvert.deserialize(profile, BillingProfileModelImpl) as BillingProfileModel)
      );
  }

  /**
   * Retrieve a BillingProfile available to an application, either because:
   * it belongs to the applicant person
   * it belongs to a person other than the applicant but has been 'loaned' for this application.
   * @param applicationId
   * @param billingProfileId
   */
  getApplicationPaymentBillingProfile(applicationId: number, billingProfileId: number): Observable<BillingProfileModel> {
    const url = PaymentMethodSelectionService.applicationBillingProfileRequestURL
      .replace('{billingProfileId}', billingProfileId.toString())
      .replace('{applicationId}', applicationId.toString());
    return this.http.get(url)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((profile: any) => this.jsonConvert.deserialize(profile, BillingProfileModelImpl) as BillingProfileModel)
      );
  }

  updateBillingProfile(billingProfileId: number, billingProfileData: BillingProfileModel): Observable<BillingProfileModel> {
    const url = PaymentMethodSelectionService.uiBillingProfileUpdateURL
      .replace('{billingProfileId}', billingProfileId.toString());
    return this.http.put(url, billingProfileData)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((profile: any) => this.jsonConvert.deserialize(profile, BillingProfileModelImpl) as BillingProfileModel)
      );
  }

  getPaymentPlanModelsForProduct(productId: number): Observable<PaymentPlanModel[]> {
    const url = PaymentMethodSelectionService.paymentPlanModelsForProductRequestURL
      .replace('{productId}', productId.toString());
    return this.http.get(url)
      .pipe(
        catchError((error) => this.serviceHandler.handleError(error)),
        map((responseModels: any[]) => this.jsonConvert.deserialize(responseModels, PaymentPlanModelImpl) as PaymentPlanModel[])
      );
  }
}
