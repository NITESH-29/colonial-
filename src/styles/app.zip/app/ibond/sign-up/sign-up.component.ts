import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { LoginComponent } from 'src/app/ibond/login/login.component';
import { MatDialog } from '@angular/material';
import { IbondBaseService } from '../service/ibond-base.service';
import { AccountService } from 'src/app/user/account.service';
import { InputValidators } from 'src/app/form-components/validators/input-validators';
import { PatternValidators } from 'src/app/common/validators/pattern-validators';
import { ValueMatchValidator } from 'src/app/common/validators/value-match-validator';
import { SecurityService } from 'src/app/security/security.service';
import { SpinnerService } from '../service/spinner.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { ISignUpIndividual, ISignUpCompany } from './sign-up';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { RequestService } from '../service/request.service';
import { ActivatedRoute } from '@angular/router';
import { NoopScrollStrategy } from '@angular/cdk/overlay';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss'],
})
export class SignUpComponent implements OnInit {
  signUpForm: FormGroup;
  @Input() applicantInfo: any;
  @Input() set showSignUp(val) {
    if (val) {
      this.viewInit();
    }
  }
  isCompanySignup = false;
  isEmailAlreadyRegister = false;
  gtmBondType: string;
  sudoBond: string;
  constructor(
    protected accountService: AccountService,
    public fb: FormBuilder,
    public baseService: IbondBaseService,
    public matDialog: MatDialog,
    protected securityService: SecurityService,
    public spinnerService: SpinnerService,
    public serviceHandlerSnackbar: ServiceHandler,
    private gtmService: GoogleTagManagerService,
    private requestService: RequestService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.initialize();
    this.activatedRoute.params.subscribe(parms => {
      this.gtmBondType = parms.bondType;
      this.sudoBond = this.requestService.setBondType(this.gtmBondType);
    });
  }
  viewInit(): void {
    this.signUpForm.get('username').setAsyncValidators(
      this.accountService.getUsernameAvailabilityAsyncValidator()
    );
    const request_email_check = {
      requestedEmail: this.applicantInfo.applicantEmail,
    };
    this.accountService.checkEmailAvailability(request_email_check).subscribe(res => {
      this.isEmailAlreadyRegister = !res.available;
    });
    // const sudoBond = this.requestService.setBondType(this.gtmBondType);
    const quoteId = localStorage.getItem('quote_id');
    const gtmData = JSON.parse(localStorage.getItem('temp_application'));
    const classification = gtmData.data.classificationName ? gtmData.data.classificationName : '';
    const IPgroup = this.requestService.ipGroup;
    this.registerGtmEvent('bond-app-register', `${this.sudoBond}`, gtmData.premium,
      'anonymous', IPgroup, classification, quoteId, 'new', ''
    );
  }
  initialize(): void {
    this.signUpForm = this.fb.group({
      username: this.fb.control(null, [Validators.required, InputValidators.noSpaces, Validators.maxLength(50)]),
      password: this.fb.control(null, [Validators.required, Validators.minLength(10),
      Validators.maxLength(62), PatternValidators.alphanumeric()]),
      confirmPassword: this.fb.control(null, [Validators.required, Validators.minLength(10), Validators.maxLength(62)]),
    },
      {
        validator: ValueMatchValidator.matchingValues('password', 'confirmPassword'),
      });
  }
  login(): void {
    const dialogRef = this.matDialog.open(LoginComponent, {
      data: { clickFrom: 'signup', url: '' },
      scrollStrategy: new NoopScrollStrategy(),
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.baseService.setSignUpValue(false);
      }
    }, error => {
    });
  }
  checkPasswords(control: FormGroup) {
    const pass = control.get('password').value;
    const confirmPass = control.get('confirmPass').value;

    return pass === confirmPass ? null : { match: true };
  }
  returnBack(): void {
    this.baseService.setSignUpValue(false);
  }
  get password() {
    return this.signUpForm.get('password');
  }
  get username() {
    return this.signUpForm.get('username');
  }
  get confirmPassword() {
    return this.signUpForm.get('confirmPassword');
  }
  get invalidPatternCondition(): boolean {
    return (this.displayAlphanumericError && this.password.touched) ||
      (this.password.touched && this.password.value === '');
  }
  get displayAlphanumericError(): boolean {
    return (this.password.touched && this.password.hasError('pattern')) ||
      (this.password.touched && (this.password.value === '' || this.password.value === null));
  }
  get displayPasswordLengthError(): boolean {
    return (this.password.hasError('minlength') || this.password.hasError('maxlength'))
      || (this.password.touched && (this.password.value === '' || this.password.value === null));
  }
  get validLengthCondition(): boolean {
    return !this.displayPasswordLengthError && this.password.touched;
  }
  get invalidLengthCondition(): boolean {
    return this.displayPasswordLengthError && this.password.touched;
  }

  get validPatternCondition(): boolean {
    return !this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }

  get confirmPasswordErrorMessage(): string {
    return this.confirmPassword.hasError('required') ? 'Confirm New Password is required.' :
      this.confirmPassword.hasError('minlength') ? 'Confirm New Password must have minimum length of 10.' :
        this.confirmPassword.hasError('valueMatch') ? 'Passwords do not match.' : '';
  }

  signUp() {
    this.spinnerService.show();
    if (this.signUpForm.valid) {
      // const funcatioName = this.applicantInfo.applicantNameCheck ? 'signIndividual' : 'signCompany';
      this.baseService.signUpStandardUser(this.requestObject()).subscribe((response) => {
        if (response) {
          const username = this.signUpForm.value.username;
          const password = this.signUpForm.value.password;
          this.securityService.loginFromSignup(username, password, this.applicantInfo.incomingFrom).then((res) => {
            if (res) {
              this.baseService.setSignUpValue(false);
              this.spinnerService.hide();
            } else {
              this.spinnerService.hide();
            }
          });

        }
      }, (err) => {
        this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
        this.spinnerService.hide();
      });
    }
  }

  requestObject(): ISignUpIndividual | ISignUpCompany {
    if (this.applicantInfo.productFor === 'individual') {
      return this.requestObjectIndividual();
    } else {
      return this.requestObjectCompany();
    }
  }
  requestObjectIndividual(): ISignUpIndividual {
    return {
      personalInformation: {
        firstName: this.applicantInfo.firstName || null,
        initial: null,
        lastName: this.applicantInfo.lastName || null,
        suffix: this.applicantInfo.suffix || null,
        salutation: null,
        phone: this.serializePhoneNumber(this.applicantInfo.applicantPhone) || null,
        email: this.applicantInfo.applicantEmail || null,
        profession: null,
        address: {
          street1: this.applicantInfo.applicantStreet1 || null,
          street2: this.applicantInfo.applicantStreet2 || null,
          city: this.applicantInfo.applicantCity || null,
          state: this.applicantInfo.applicantState || null,
          zipCode: this.applicantInfo.applicantZipCode || null,
        },
      },
      usernamePassword: {
        username: this.signUpForm.value.username,
        password: this.signUpForm.value.password,
        confirmPassword: this.signUpForm.value.confirmPassword,
        referralCode: null,
      },
    };
  }

  requestObjectCompany(): ISignUpCompany {
    return {
      personalInformation: {
        firstName: this.applicantInfo.firstName,
        initial: null,
        lastName: this.applicantInfo.lastName,
        suffix: null,
        salutation: null,
        phone: this.serializePhoneNumber(this.applicantInfo.applicantPhone),
        email: this.applicantInfo.applicantEmail,
        profession: null,
        address: null,
      },
      businessInformation: {
        name: this.applicantInfo.companyName,
      },
      businessOfficeInformation: {
        name: this.applicantInfo.companyName,
        // website: null,
        email: this.applicantInfo.applicantEmail,
        phone: this.serializePhoneNumber(this.applicantInfo.applicantPhone),
        fax: null,
        // 'sicCode': '3291',
        // 'officeType': 'Main',
        address: {
          street1: this.applicantInfo.applicantStreet1 || null,
          street2: this.applicantInfo.applicantStreet2 || null,
          city: this.applicantInfo.applicantCity || null,
          state: this.applicantInfo.applicantState || null,
          zipCode: this.applicantInfo.applicantZipCode || null,
        },
        // 'title': 'admin',
      },
      usernamePassword: {
        username: this.signUpForm.value.username,
        password: this.signUpForm.value.password,
        confirmPassword: this.signUpForm.value.confirmPassword,
        referralCode: null,
      },
    };
  }
  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  registerGtmEvent(event, bondType, bondPremium, userType, lpGroup, lpBond, quoteId, bondClass?, applicationID?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }
}
