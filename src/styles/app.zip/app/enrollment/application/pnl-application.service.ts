import { JsonConvert } from 'json2typescript';
import { SecurityService } from '../../security/security.service';
import { HttpClient } from '@angular/common/http';
import { UtilService } from '../../common/utils/util.service';
import { ClassOfBusiness, ClassOfBusinessImpl } from './class-of-business';
import { CompanyOfficeImpl } from '../../common/company-office';
import { ApplicationDataImpl } from './court/model/application-data';
import { AgentImpl } from '../../common/agent';
import { Application, ApplicationImpl } from './application';
import { UserImpl } from '../../security/user';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})

export class PnlApplicationService {
  private requestURL = 'api/application';
  private jsonConvert: JsonConvert;

  constructor(private http: HttpClient, private securityService: SecurityService) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async create(bondType: string, data: ApplicationDataImpl, companyOfficeId?: number, agentId?: number): Promise<ApplicationImpl> {
    const user: UserImpl = this.securityService.user;
    if (!user.isSteward && !companyOfficeId) {
      throw new Error('User or Company Office is required');
    }
    data.bondClassification = bondType;
    const requestBody: ApplicationImpl = new ApplicationImpl();
    requestBody.data = data;

    if (companyOfficeId) {
      const companyOffice = new CompanyOfficeImpl();
      companyOffice.id = companyOfficeId;
      requestBody.companyOffice = companyOffice;
    }
    if (agentId) {
      const agent = new AgentImpl();
      agent.id = agentId;
      requestBody.agent = agent;
    }
    delete requestBody.person;
    const application: any = await this.http.post(`${this.requestURL}/${bondType}`, this.jsonConvert.serialize(requestBody)).toPromise();
    return this.jsonConvert.deserialize(application, ApplicationImpl) as ApplicationImpl;
  }

  async update(id: number, bondType: string, application: ApplicationImpl): Promise<ApplicationImpl> {
    application.data.bondClassification = bondType;
    const formattedData = this.jsonConvert.serialize(application);
    const returnData: any = await this.http.put(`${this.requestURL}/${bondType}/${id}`, formattedData).toPromise();
    return this.jsonConvert.deserialize(returnData, ApplicationImpl) as ApplicationImpl;
  }

  async getById(id: number): Promise<ApplicationImpl> {
    const application: any = await this.http.get(`${this.requestURL}/${id}`).toPromise();
    return this.jsonConvert.deserialize(application, ApplicationImpl) as ApplicationImpl;
  }

  async getListForUser(): Promise<Array<Application>> {
    const user: UserImpl = this.securityService.user;
    let applicationList: any;
    if (user.isSteward) {
      applicationList = await this.http.get(`${this.requestURL}/list/agent/${user.person.id}`).toPromise();
    } else {
      applicationList = await this.http.get(`${this.requestURL}/list/person/${user.person.id}`).toPromise();
    }
    return this.jsonConvert.deserialize(applicationList, ApplicationImpl) as ApplicationImpl[];
  }

  async getClassOfBusinessList(): Promise<Array<ClassOfBusiness>> {
    const classOfBusinessList = await this.http.get<ClassOfBusiness[]>(`api/class-of-business`).toPromise();

    // TODO: REMOVE THIS FILTER ONCE WE GET HAZARD CLASSES FOR ALL CLASSES OF BUSINESS
    const withHazardClasses = classOfBusinessList.filter(cob => !!cob.hazardClass);

    return this.jsonConvert.deserialize(withHazardClasses, ClassOfBusinessImpl) as ClassOfBusinessImpl[];
  }
}
