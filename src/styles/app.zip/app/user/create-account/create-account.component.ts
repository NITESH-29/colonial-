import { AccountCreator, AccountService } from '../account.service';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { convertToAccountCreationRequest, CreateAccountRequest } from '../request-models/create-account-request';
import { FormGroup } from '@angular/forms';
import { HostListener, OnInit } from '@angular/core';
import { PersonalInformationFormGroup } from '../personal-information/personal-information-form-group';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { UsernamePasswordFormGroup } from '../username-password/username-password-form-group';
import { Location } from '@angular/common';

export abstract class CreateAccountComponent implements OnInit {
  formGroup: FormGroup;
  disableSubmit = false;

  protected constructor(
    protected accountService: AccountService,
    protected securityService: SecurityService,
    protected serviceHandler: ServiceHandler,
    protected router: Router,
    protected activatedRoute: ActivatedRoute,
    protected location: Location
  ) { }

  ngOnInit(): void {
    this.configureFormGroup();

    this.personalInformation.get('email').setAsyncValidators(
      this.accountService.getEmailAvailabilityAsyncValidator()
    );

    this.usernamePassword.get('username').setAsyncValidators(
      this.accountService.getUsernameAvailabilityAsyncValidator()
    );
  }

  @HostListener('window:beforeunload', ['$event'])
  refresh($event) {
    return (false);
  }

  protected abstract configureFormGroup(): void;

  protected abstract accountCreationFunction(): AccountCreator;

  protected prepareAccountCreationRequest(rawValue: any): CreateAccountRequest {
    return convertToAccountCreationRequest(rawValue);
  }

  goBack(): void {
    this.location.back();
  }

  protected formIsValid(): boolean {
    return this.formGroup.valid;
  }

  save(): void {
    CommonUtilities.markAllTouched(this.formGroup);
    if (this.formIsValid()) {
      this.disableSubmit = true;
      const formData = this.formGroup.getRawValue();

      const request: CreateAccountRequest = this.prepareAccountCreationRequest(formData);

      const accountCreator = this.accountCreationFunction().bind(this.accountService);

      try {
        accountCreator(request)
          .then(() => {
            const { username, password } = request.usernamePassword;
            return this.securityService.login(username, password);
          })
          .then(() => this.router.navigateByUrl(this.redirectUrl()));
      } catch (err) {
        this.disableSubmit = false;
      }
    } else {
      CommonUtilities.markAllTouched(this.formGroup);
      this.serviceHandler.showErrorMessage('Please fix validation errors before saving.');
    }
  }

  abstract get personalInformation(): PersonalInformationFormGroup;

  get usernamePassword(): UsernamePasswordFormGroup {
    return this.formGroup.get('usernamePassword') as UsernamePasswordFormGroup;
  }

  redirectUrl(): string {
    return '';
  }
}
