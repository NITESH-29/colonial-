import { FormGroup } from '@angular/forms';
import { BusinessInformationFormGroup } from '../business-information/business-information-form-group';
import { BusinessOfficeFormArray } from '../business-office-information/business-office-list/business-office-form-array';
import { CompanyModel } from '../models/company-model';

export class CompanyWithOfficeListFormGroup extends FormGroup {
  constructor() {
    super({
      companyInformation: new BusinessInformationFormGroup(),
      companyOfficeList: new BusinessOfficeFormArray(),
    });
  }

  get companyInformation(): BusinessInformationFormGroup {
    return this.get('companyInformation') as BusinessInformationFormGroup;
  }

  get companyOfficeList(): BusinessOfficeFormArray {
    return this.get('companyOfficeList') as BusinessOfficeFormArray;
  }

  // noinspection JSAnnotator
  patchValue(value: Partial<CompanyModel>): void {
    this.companyInformation.patchValue(value);
    this.companyOfficeList.patchValue(value.companyOffices);
  }

  getRawValue(): CompanyModel {
    const companyModel: CompanyModel = this.companyInformation.getRawValue();
    companyModel.companyOffices = this.companyOfficeList.getRawValue();
    return companyModel;
  }
}
