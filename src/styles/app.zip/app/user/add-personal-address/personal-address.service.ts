import { Injectable } from '@angular/core';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../../common/utils/util.service';
import { HttpClient } from '@angular/common/http';
import { AddressModel } from '../../common/address/address';
import { PersonAddress, PersonAddressImpl } from '../../common/person-address';
import { PersonalAddress, PersonalAddressImpl } from './personal-address';


@Injectable()
export class PersonalAddressService {
  requestUrl = '/api/person-address';

  private jsonConvert: JsonConvert;

  constructor(private http: HttpClient) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async existsByPersonId(personId: number): Promise<Boolean> {
    return (await this.http.get(`${this.requestUrl}/${personId}`).toPromise()) as Boolean;
  }

  async save(personId: number, address: AddressModel): Promise<PersonalAddress> {
    const personalAddress: PersonalAddress = new PersonalAddressImpl();
    personalAddress.address = address;
    const response = await this.http.post(`${this.requestUrl}/${personId}`, this.jsonConvert.serialize(personalAddress)).toPromise();
    return this.jsonConvert.deserialize(response, PersonalAddressImpl) as PersonalAddress;
  }

}
