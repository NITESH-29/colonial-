import { JsonObject, JsonProperty } from 'json2typescript';
import { Answer, AnswerImpl } from './answer';
import { QuestionSummary, QuestionSummaryImpl } from './question-summary';

export interface Question extends QuestionSummary {
  answers: Array<Answer>;
}

@JsonObject('QuestionImpl')
export class QuestionImpl extends QuestionSummaryImpl implements Question {
  @JsonProperty('answers', [AnswerImpl], true)
  answers: Array<Answer> = new Array<AnswerImpl>();
}
