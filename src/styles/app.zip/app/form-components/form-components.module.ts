import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BasicInputFormFieldComponent } from './input-form-fields/basic/basic-input-form-field.component';
import { FormErrorComponent } from './form-error/form-error.component';
import { MatFormFieldModule, MatIconModule, MatInputModule, MatRadioModule, MatSelectModule, MatButtonModule } from '@angular/material';
import { PasswordInputFormFieldComponent } from './input-form-fields/password/password-input-form-field.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PhoneInputFormFieldComponent } from './input-form-fields/phone/phone-input-form-field.component';
import { BasicSelectFormFieldComponent } from './form-select/basic-select-form-field.component';
import { ControlModule } from '../control/control.module';
import { CommonComponentsModule } from '../common/common-components.module';
import { ComplexSelectFormFieldComponent } from './form-select/complex-select-form-field.component';
import { SiccodeSelectFormFieldComponent } from './form-select/siccode-select-form-field.component';
import { GenericPageableListComponent } from './generic-pageable-list/generic-pageable-list.component';
import { TableModule } from 'primeng/table';
import { DateRangeComponent } from './date-range/date-range.component';
import { CalendarModule } from 'primeng/calendar';
import { SearchboxWithDropdownComponent } from './searchbox-with-dropdown/searchbox-with-dropdown.component';
import { SharedModule } from 'primeng/shared';
import { GenericTableSearchComponent } from './generic-table-search/generic-table-search.component';
import { ConsiderDotNotationPipe } from './generic-pageable-list/consider-dot-notation.pipe';
import { MobileTableTabsComponent } from './mobile-table-tabs/mobile-table-tabs.component';
import { MatDialogMobileTableSearchComponent } from './mat-dialog-mobile-table-search/mat-dialog-mobile-table-search.component';
import { MoneyInputFormFieldComponent } from './input-form-fields/money/money-input-form-field.component';
import { TextareaInputFormFieldComponent } from './input-form-fields/textarea/textarea-input-form-field.component';
import { MaterialModule } from '../material.module';

/**
 * FormComponentsModule
 * A place to start putting any sort of form field we use that can be used simply.
 * This one day may be combined with the questions that are in dynamic questions, but for now I think we should just start migrating
 * over commonly used form fields into easy to use modules.
 *
 */

@NgModule({
  declarations: [
    BasicInputFormFieldComponent,
    FormErrorComponent,
    PasswordInputFormFieldComponent,
    PhoneInputFormFieldComponent,
    BasicSelectFormFieldComponent,
    ComplexSelectFormFieldComponent,
    SiccodeSelectFormFieldComponent,
    GenericPageableListComponent,
    DateRangeComponent,
    SearchboxWithDropdownComponent,
    GenericTableSearchComponent,
    ConsiderDotNotationPipe,
    MobileTableTabsComponent,
    MatDialogMobileTableSearchComponent,
    MoneyInputFormFieldComponent,
    TextareaInputFormFieldComponent,
  ],
  imports: [
    CommonModule,
    CommonComponentsModule,
    ReactiveFormsModule,
    FormsModule,
    ControlModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatButtonModule,
    TableModule,
    CalendarModule,
    SharedModule,
    MaterialModule,
  ],
  exports: [
    BasicInputFormFieldComponent,
    PasswordInputFormFieldComponent,
    PhoneInputFormFieldComponent,
    BasicSelectFormFieldComponent,
    ComplexSelectFormFieldComponent,
    SiccodeSelectFormFieldComponent,
    FormErrorComponent,
    GenericPageableListComponent,
    DateRangeComponent,
    SearchboxWithDropdownComponent,
    GenericTableSearchComponent,
    MobileTableTabsComponent,
    MatDialogMobileTableSearchComponent,
    MoneyInputFormFieldComponent,
    TextareaInputFormFieldComponent,
  ],
})
export class FormComponentsModule {
}
