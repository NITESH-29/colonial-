import { Injectable, EventEmitter } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { throwError } from 'rxjs';

@Injectable()
export class ServiceHandler {
  returnUrl: string;
  blockMessageEvent = new EventEmitter();

  constructor(private snackBar: MatSnackBar, private authRouter: Router, private _route: ActivatedRoute) {
  }

  openSnackBar(message: string, action: string, millis: number, extra: string) {

    this.snackBar.open(message, action, {
      duration: millis,
      panelClass: extra,
    });
  }

  handleErrorNoException(error: any): any {
    this.returnUrl = this._route.snapshot.queryParams['returnUrl'];

    if (!error || !error.status || error.status >= 500) {
      this.openSnackBar('Unexpected Server Error. Please try again later.', null, 10000, 'alert_snack_bar');
    } else if (error.status === 404) {
      this.authRouter.navigateByUrl('/not-found');
    } else if (error.status === 401 || error.status === 403) {
      this.authRouter.navigateByUrl('/secure/logout');
    } else {
      if (error.error) {
        this.openSnackBar(error.error.message, null, 5000, 'alert_snack_bar');
      } else {
        this.openSnackBar(error.message, null, 5000, 'alert_snack_bar');
      }
    }

    return error;
  }

  handleError(error: any) {
    return throwError(this.handleErrorNoException(error));
  }

  handleConfirm(message: any) {
    this.openSnackBar(message, null, 2000, 'confirmation_snack_bar');
  }

  showErrorMessage(message: string) {
    this.openSnackBar(message, null, 5000, 'alert_snack_bar');
  }

  setErrorBlock(error) {
    this.blockMessageEvent.emit(error);
  }

  getErrorBlock() {
    return this.blockMessageEvent;
  }

}
