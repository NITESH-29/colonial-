import { Directive, ElementRef, OnInit, EventEmitter, Output, AfterViewInit } from '@angular/core';
// const google = require('@types/googlemaps');
import { } from 'googlemaps';

@Directive({
  selector: '[appGooglePlace]',
})
export class GooglePlacesDirective implements OnInit, AfterViewInit {
  @Output() getAddress: EventEmitter<any> = new EventEmitter();
  private element: HTMLInputElement;

  constructor(private elRef: ElementRef) {
    // elRef will get a reference to the element where
    // the directive is placed
    this.element = elRef.nativeElement;
  }

  getFormattedAddress(place) {
    // @params: place - Google Autocomplete place object
    // @returns: location_obj - An address object in human readable format
    const location_obj = {};
    if (place && place.address_components) {
      place.address_components.map(item => {
        location_obj['formatted_address'] = place.formatted_address;
        location_obj['address_name'] = place.name;
        if (item['types'].indexOf('administrative_area_level_3') > -1) {
          location_obj['locality_level_3'] = item['long_name'];
        } else if (item['types'].indexOf('locality') > -1) {
          location_obj['locality'] = item['long_name'];
        } else if (item['types'].indexOf('sublocality_level_1') > -1) {
          location_obj['sublocality'] = item['long_name'];
        } else if (item['types'].indexOf('administrative_area_level_1') > -1) {
          location_obj['admin_area_l1'] = item['short_name'];
        } else if (item['types'].indexOf('street_number') > -1) {
          location_obj['street_number'] = item['short_name'];
        } else if (item['types'].indexOf('route') > -1) {
          location_obj['route'] = item['long_name'];
        } else if (item['types'].indexOf('country') > -1) {
          location_obj['country'] = item['long_name'];
        } else if (item['types'].indexOf('postal_code') > -1) {
          location_obj['postal_code'] = item['short_name'];
        } else if (item['types'].indexOf('administrative_area_level_2') > -1) {
          const county = item['long_name'] ? item['long_name'].replace('County', '') : '';
          location_obj['administrative_area_level_2'] = county;
        }
      });


      if (!location_obj['locality']) {
        location_obj['locality'] = location_obj['sublocality'] ? location_obj['sublocality'] :
          location_obj['formatted_address'] ? location_obj['formatted_address'].split(', ')
          [location_obj['formatted_address'].split(', ').length - 3] : '';
      } else if (location_obj['locality_level_3']) {
        location_obj['locality'] = location_obj['locality_level_3'];
      }
      let address = '';
      if (location_obj['route']) {
        if (location_obj['locality'] && location_obj['formatted_address'].indexOf(location_obj['locality']) > -1) {
          address = this.subStringAfter(location_obj['formatted_address'], location_obj['locality']);
        } else if (location_obj['admin_area_l1'] && location_obj['formatted_address'].indexOf(location_obj['admin_area_l1']) > -1) {
          address = this.subStringAfter(location_obj['formatted_address'], location_obj['admin_area_l1']);
        } else {
          address = location_obj['formatted_address'];
        }
      } else {
        address = location_obj['formatted_address'];
      }
      const alreadypresent = location_obj && location_obj['formatted_address'] ? location_obj['formatted_address'].includes(
        location_obj['address_name']) : null;
      const display_address = alreadypresent ? address : location_obj['address_name'] + ', ' + address;
      location_obj['address'] = display_address;
      return location_obj;
    } else {
      return null;
    }
  }

  subStringAfter(original_str, sub_afterString): string {
    let return_str = '';
    return_str = original_str.substring(0, original_str.indexOf(sub_afterString));
    if (return_str) {
      return return_str.replace(/,\s*$/, ''); // to remove last comma
    } else {
      return original_str;
    }
  }
  ngAfterViewInit(): void {
    setTimeout(() => {
      const options = {
        componentRestrictions: { country: 'us' }, // 2-letters code
      };
      const autocomplete = new google.maps.places.Autocomplete(this.element, options);
      // Event listener to monitor place changes in the input
      google.maps.event.addListener(autocomplete, 'place_changed', () => {
        // Emit the new address object for the updated place
        this.getAddress.emit(this.getFormattedAddress(autocomplete.getPlace()));
      });
    }, 1000);
  }
  ngOnInit() {
  }

}
