import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cta-svg',
  templateUrl: './cta-svg.component.html',
  styleUrls: ['./cta-svg.component.scss'],
})
export class CtaSvgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
