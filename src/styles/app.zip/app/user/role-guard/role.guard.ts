import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { AsyncSubject, Observable } from 'rxjs';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { map } from 'rxjs/operators';

export abstract class RoleGuard implements CanActivate {
  protected constructor(protected securityService: SecurityService) { }

  protected abstract hasPermission(user: UserImpl, params: any): boolean;

  public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const canActivate = new AsyncSubject<boolean>();

    this.securityService.loggedIn$.pipe(
      map(loggedIn => loggedIn && loggedIn ? this.hasPermission(this.securityService.user, route.params) : true)
    ).subscribe(b => {
      canActivate.next(b);
      canActivate.complete();
    });

    return canActivate.asObservable();
  }
}
