import { JsonObject, JsonProperty } from 'json2typescript';
import { ProductType, ProductTypeImpl } from '../../product/product-type';
import { FileTypeImpl } from '../adjudication/file-type';

export interface AdjudicationConfiguration {
  requiresCreditScore: boolean;
  requiresKoQuestions: boolean;
  hasSoftHoldQuestions: boolean;
  creditScoreThreshold: number;
  requiresCollateral: boolean;
  productType: ProductType;
  fileTypes: FileTypeImpl[];
}

@JsonObject('AdjudicationConfigurationImpl')
export class AdjudicationConfigurationImpl implements AdjudicationConfiguration {
  @JsonProperty('requiresCreditScore', Boolean)
  requiresCreditScore = false;
  @JsonProperty('requiresKoQuestions', Boolean)
  requiresKoQuestions = false;
  @JsonProperty('hasSoftHoldQuestions', Boolean)
  hasSoftHoldQuestions = false;
  @JsonProperty('creditScoreThreshold', Number)
  creditScoreThreshold = -1;
  @JsonProperty('requiresCollateral', Boolean)
  requiresCollateral = false;
  @JsonProperty('productType', ProductTypeImpl)
  productType: ProductType = undefined;
  @JsonProperty('fileTypes', [FileTypeImpl])
  fileTypes: FileTypeImpl[] = undefined;
}
