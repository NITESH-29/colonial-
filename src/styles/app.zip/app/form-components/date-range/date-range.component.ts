import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-date-range',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.scss'],
})
export class DateRangeComponent implements OnInit {

  /**
   * I don't like using view child but sometimes, you gotta do what you gotta do.  And doing what I gotta do in this case
   * is being able to trigger closing this from the code .
   */

  @ViewChild('calendar') datePicker;

  @Input()
  control: FormControl;

  @Output()
  applyEvent: EventEmitter<void> = new EventEmitter<void>();

  constructor() {
  }

  ngOnInit() {
    const location = window.location.pathname;
    const loc = location.split('/');
    if (
      loc[loc.length - 1] === 'in-progress' || loc[loc.length - 1] === 'awaiting-payments'
      || loc[loc.length - 1] === 'pending' || loc[loc.length - 1] === 'renewal' || loc[loc.length - 1] === 'expired'
      || loc[loc.length - 1] === 'pending-renewal'
    ) {
      this.control.setValue(null);
    }
  }

  apply() {
    this.applyEvent.emit();
    this.datePicker.hideOverlay();
  }

  clearDateFilter() {
    this.control.setValue(null);
    this.applyEvent.emit();
    this.datePicker.hideOverlay();
  }

}
