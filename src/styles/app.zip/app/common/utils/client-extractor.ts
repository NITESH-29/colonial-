import { UserImpl } from '../../security/user';
import { ClientData, ClientDataImpl } from '../../user/client/client-data';

export class ClientExtractor {

  static getClientListFromUser(user: UserImpl, skipCompanies: boolean = false): ClientData[] {
    const clients: ClientData[] = [];
    // add the currently logged in users person object
    const clientPerson = new ClientDataImpl();
    clientPerson.id = user.person.id;
    clientPerson.clientType = 'P';
    clientPerson.uniqueId = `P:${user.person.id}`;
    clientPerson.displayType = 'Person';
    clientPerson.agentId = user.person.agentId;
    clientPerson.email = user.person.email;
    clientPerson.phone = user.person.phone;
    clientPerson.name = user.person.firstName + ' ' + user.person.lastName;
    clients.push(clientPerson);

    if (!skipCompanies && user.person.companyOfficePersons) {
      // add any of the company offices the user has associated with them
      for (const companyOfficePerson of user.person.companyOfficePersons) {
        const clientCompany = new ClientDataImpl();
        clientCompany.id = companyOfficePerson.companyOffice.id;
        clientCompany.clientType = 'C';
        clientCompany.uniqueId = `C:${companyOfficePerson.companyOffice.id}`;
        clientCompany.displayType = 'Company';
        clientCompany.agentId = companyOfficePerson.companyOffice.agentId;
        clientCompany.name = companyOfficePerson.companyOffice.company.name;
        clientCompany.email = companyOfficePerson.companyOffice.email;
        clientCompany.phone = companyOfficePerson.companyOffice.phone;
        clients.push(clientCompany);
      }
    }

    return clients;
  }

}
