import { Injectable } from '@angular/core';
import { RequestService } from './request.service';
import * as moment_ from 'moment';


@Injectable({
  providedIn: 'root',
})
export class VaFiduciaryRequestService {
  planObject = {};
  moment = moment_;
  private _quoteId: number = null;
  constructor(
    private requestService: RequestService
  ) { }

  getRequestdata(person, requestBody, formdata, dataSource, addpaymetNode?) {
    const expYr = formdata.cardExpiration ? formdata.cardExpiration.toString().slice(-2) : '';
    requestBody['data'].bondType = formdata.bondType;
    requestBody.quoteId = this.quoteId;
    requestBody['data'].bondDescription = formdata.bondDescription;
    requestBody['data'].effectiveDate = this.requestService.serializeDate(formdata.effectiveDate);
    requestBody['data'].expiryDate = this.requestService.serializeDate(formdata.expiryDate);
    requestBody['data'].firstName = formdata.firstName || null;
    requestBody['data'].lastName = formdata.lastName || null;
    requestBody['data'].applicantName = formdata.firstName + ' ' + formdata.lastName || null,
      // requestBody['data'].applicantName = formdata.applicantName;
      requestBody['data'].applicantEmail = formdata.applicantEmail;
    requestBody['data'].applicantAddress = this.getApplicantObject(formdata);
    requestBody['data'].applicantPhone = this.serializePhoneNumber(formdata.applicantPhone);
    // requestBody['data'].applicantFax = formdata.applicantFax;
    requestBody['data'].applicantSSNum = formdata.applicantSSNum;
    requestBody['data'].obligee = this.getObligeeObject(formdata);
    requestBody['data'].deliveryMethod = this.getDeliveryObject(formdata);
    requestBody['data'].readAndAgreeToTerms = formdata.readAndAgreeToTerms;
    requestBody['data'].applicantCounty = formdata.applicantCounty;
    requestBody['data'].creditCheckAuthorized = true;
    if (addpaymetNode) {
      requestBody['data'].paymentMethod = this.requestService.getpaymentPlanObject();
      if (requestBody['data'].paymentMethod.resetPaymentDetail) {
        requestBody['data'].paymentMethod.billingFirstName = formdata.billingFirstName;
        requestBody['data'].paymentMethod.billingLastName = formdata.billingLastName || ' ';
        requestBody['data'].paymentMethod.billingPhone = this.serializePhoneNumber(formdata.billingPhone);
        requestBody['data'].paymentMethod.billingAddress = {
          street1: formdata.billingAddress,
          street2: null,
          city: formdata.billingCity,
          state: formdata.billingState,
          zipCode: formdata.billingZipCode,
        },
          requestBody['data'].paymentMethod.cardNumber = this.serializeCardNumber(formdata.cardNumber);
        requestBody['data'].paymentMethod.cardCVV = formdata.cardCVV;
        requestBody['data'].paymentMethod.cardExpiration = formdata.month + '/' + expYr;
      }
    }
    // requestBody['data'].billingName = formdata.billingName;
    // requestBody['data'].billingPhone = formdata.billingPhone;
    // requestBody['data'].billingAddress = this.getPaymentObject(formdata);
    // requestBody['data'].cardNumber = formdata.cardNumber;
    // requestBody['data'].cardExpiration = formdata.month + '/' + expYr;
    // requestBody['data'].cardCVV = formdata.cardCVV;
    requestBody['data'].termsAndConditions = this.getTermsAndCondition(formdata);
    requestBody['data'].liabilitiesInsuranceExists = formdata.liabilitiesInsuranceExists ? formdata.liabilitiesInsuranceExists : null;
    requestBody['data'].insuranceCompanyName = formdata.insuranceCompanyName ? formdata.insuranceCompanyName : null;
    requestBody.person = person;
    if (formdata.productFor === 'company') {
      requestBody['data'].companyOwner = this.getOwnerInformation(formdata);
    }
    requestBody['data'].veteranAffairsDetails = this.getVeteranAffairsDetails(formdata);
    requestBody['data'].specialBondForm = formdata.specialBondForm ? formdata.specialBondForm : false;
    requestBody['data'].specialBondUpload = formdata.specialBondUpload ? formdata.specialBondUpload : false;
    requestBody['data'].specialBondFile = this.getSpecialBondFileInfo(formdata);
    return requestBody;
  }
  getSpecialBondFileInfo(formData) {
    return {
      id: formData.specialBondFile ? formData.specialBondFile.id : null,
      name: formData.specialBondFile ? formData.specialBondFile.name : null,
    };
  }
  getOwnerInformation(formData) {
    return {
      ownerName: formData.ownerName,
      ownerAddress: {
        street1: formData.street1,
        street2: formData.street2,
        city: formData.city,
        state: formData.state,
        zipCode: formData.zipCode,
      },
      ownerPhone: this.serializePhoneNumber(formData.ownerPhone),
      ownerFax: formData.ownerFax,
      ownerSSN: formData.ownerSSN,
    };
  }
  getApplicantObject(formdata) {
    return {
      street1: formdata.applicantStreet1,
      street2: formdata.applicantStreet2,
      city: formdata.applicantCity,
      state: formdata.applicantState,
      zipCode: formdata.applicantZipCode,
    };
  }

  getObligeeObject(formdata) {
    return {
      obligeeName: formdata.obligeeName,
      obligeeAddress: {
        street1: formdata.obligeeStreet1,
        street2: formdata.obligeeStreet2,
        city: formdata.obligeeCity,
        state: formdata.obligeeState,
        zipCode: formdata.obligeeZipCode,
      },
      obligeePhone: this.serializePhoneNumber(formdata.obligeePhone),
      // obligeeFax: formdata.obligeeFax,
    };
  }
  getDeliveryObject(formdata) {
    return {
      deliveryMethod: formdata.deliveryMethod,
      copyViaEmail: formdata.copyViaEmail,
    };
  }
  getPaymentObject(formdata) {
    return {
      billingAddress: formdata = {
        street1: formdata.street1,
        zipCode: formdata.zipCode,
        city: formdata.city,
        state: formdata.state,
      },
    };
  }
  getTermsAndCondition(formdata) {
    return {
      readAndAgreeToTerms: formdata.readAndAgreeToTerms,
      premiumAcknowledged: formdata.premiumAcknowledged,
      emailSignature: formdata.emailSignature,
    };
  }

  setPaymentPlanObject(planobj, flag) {
    if (flag) {
      this.planObject = planobj;
      this.planObject['resetPaymentDetail'] = false;
    } else {
      this.planObject = {
        resetPaymentDetail: true,
        paymentPlanTypeId: planobj.paymentPlanTypeId || null,
        billingProfileId: planobj.billingProfileId || null,
        secondaryBillingPersonBillingProfileId: null,
        response: {
          success: null,
          status: null,
          text: null,
          transaction: null,
          date: null,
        },
        personId: planobj.personId || null,
        paymentChannelCode: {
          persistenceId: planobj.persistenceId || null,
          paymentChannelType: {
            persistenceId: 'credit',
            electronic: planobj.electronic || null,
            defaultDisplayText: 'credit',
          },
          defaultDisplayText: planobj.defaultDisplayText || null,
          electronic: planobj.electronic || null,
          creditCard: planobj.creditCard || null,
        },
        billingFirstName: planobj.firstName ? planobj.firstName : '',
        billingLastName: planobj.lastName ? planobj.lastName || ' ' : ' ',
        billingPhone: planobj.billingPhone ? this.serializePhoneNumber(planobj.billingPhone) : null,
        billingAddress: planobj.billingAddress,
        cardNumber: this.serializeCardNumber(planobj.cardNumber),
        cardCVV: planobj.cardCVV,
        cardExpiration: planobj.cardExpiration,
      };
    }
  }
  getpaymentPlanObject() {
    return this.requestService.getpaymentPlanObject();
  }

  getVeteranAffairsDetails(formData) {
    return {
      nameOfVeteranWard: formData.nameOfVeteranWard,
      doYouHaveVeteranAffairsLetter: formData.doYouHaveVeteranAffairsLetter,
      veteranAffairsLetter: formData.veteranAffairsLetter,
    };
  }

  deserializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3') : phoneNumber;
  }

  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  deserializeCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber.replace(/(\d{4})(\d{4})(\d{4})(\d{4})/g, '$1-$2-$3-$4') : cardNumber;
  }

  serializeCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber.replace(/[^\d]/g, '') : cardNumber;
  }

  customDateFormatter(date: string): Date {
    return date ? new Date(this.moment(date).format('MM/DD/YYYY')) : new Date();
  }

  get quoteId() {
    return this._quoteId;
  }

  set quoteId(quoteId) {
    this._quoteId = quoteId;
  }
}
