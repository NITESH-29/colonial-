import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Product, ProductImpl } from '../product';
import { JsonConvert } from 'json2typescript';
import { JsonConvertService } from '../../common/utils/json-convert.service';
import { ProductRenewal } from './product-renewal';
import { PaymentMethod } from '../../enrollment/application/court/model/common/payment-method';

@Injectable({
  providedIn: 'root',
})
export class ProductRenewalService {
  private requestURL = 'api/renewal';
  private jsonConvert: JsonConvert = null;


  constructor(private http: HttpClient, private router: Router, private jsonConvertService: JsonConvertService) {
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  renewProduct(productId: number, renewalDate: Date, paymentMethod: PaymentMethod): Observable<Product> {
    const renewProductModel = {
      productId,
      renewalDate,
      'paymentMethod': this.jsonConvert.serialize(paymentMethod),
    };
    return this.http.put<Product>(this.requestURL, renewProductModel)
      .map((p) => this.jsonConvert.deserializeObject<Product>(p, ProductImpl));
  }

  getProductRenewals(productId: number): Observable<ProductRenewal[]> {
    return this.http.get<ProductRenewal[]>(`${this.requestURL}/${productId}`)
      .map((p) => this.jsonConvert.deserializeArray(p, ProductRenewal));
  }

  getOriginalProduct(productId: Number): Observable<Product> {
    return this.http.get<Product>(`${this.requestURL}/original/${productId}`)
      .map((p: Product) => this.jsonConvert.deserialize(p, ProductImpl) as Product);
  }
}
