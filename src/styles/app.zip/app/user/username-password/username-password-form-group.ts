import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputValidators } from '../../form-components/validators/input-validators';
import { PasswordValidators } from './password-validators';
import { PatternValidators } from '../../common/validators/pattern-validators';

export interface UsernamePassword {
  username: string;
  password: string;
  confirmPassword: string;
}

export class UsernamePasswordFormGroup extends FormGroup {

  constructor(disabled: boolean = false) {
    super({
      username: new FormControl({ value: null, disabled: disabled },
        [Validators.required, InputValidators.noSpaces, Validators.maxLength(50)]),
      password: new FormControl({ value: null, disabled: disabled },
        [Validators.required, Validators.minLength(10), Validators.maxLength(62), PatternValidators.alphanumeric()]),
      confirmPassword: new FormControl({ value: null, disabled: disabled },
        [Validators.required, Validators.minLength(10), Validators.maxLength(62)]),
    }, { validators: PasswordValidators.match });
  }


  // noinspection JSAnnotator
  patchValue(value: Partial<UsernamePassword>): void {
    super.patchValue({
      username: value.username,
      password: value.password,
      confirmPassword: value.confirmPassword,
    });
  }

  getRawValue(): UsernamePassword {
    return {
      username: this.username.value,
      password: this.password.value,
      confirmPassword: this.confirmPassword.value,
    } as UsernamePassword;
  }

  get username(): FormControl {
    return this.get('username') as FormControl;
  }

  get password(): FormControl {
    return this.get('password') as FormControl;
  }

  get confirmPassword(): FormControl {
    return this.get('confirmPassword') as FormControl;
  }

  get displayPasswordErrors(): boolean {
    return this.password.touched && this.confirmPassword.touched && this.invalid;
  }

  get displayPasswordLengthError(): boolean {
    return (this.password.hasError('minlength') || this.password.hasError('maxlength'))
      || (this.password.touched && (this.password.value === '' || this.password.value === null));
  }

  get displayAlphanumericError(): boolean {
    return (this.password.touched && this.password.hasError('pattern')) ||
      (this.password.touched && (this.password.value === '' || this.password.value === null));
  }

  // Conditions driving dynamic styles in template
  get validLengthCondition(): boolean {
    return !this.displayPasswordLengthError && this.password.touched;
  }

  get validPatternCondition(): boolean {
    return !this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }

  get invalidLengthCondition(): boolean {
    return this.displayPasswordLengthError && this.password.touched;
  }

  get invalidPatternCondition(): boolean {
    return (this.displayAlphanumericError && this.password.touched) ||
      (this.password.touched && this.password.value === '');
  }
}
