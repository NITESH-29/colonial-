import { Injectable } from '@angular/core';
import { RoleGuard } from './role.guard';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';

@Injectable()
export class EmployeePlusGuard extends RoleGuard {
  constructor(securityService: SecurityService) {
    super(securityService);
  }

  hasPermission(user: UserImpl): boolean {
    return user.hasEmployeePlusPermissions;
  }
}
