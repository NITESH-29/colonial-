import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from './auditable-object';

export interface Agent {
  id: number;
  personId: number;
  referralCode: string;
  statesPracticedIn: string[];
}

@JsonObject('AgentImpl')
export class AgentImpl extends AuditableObject {
  @JsonProperty('personId', Number, true)
  personId: number = null;

  @JsonProperty('referralCode', String, true)
  referralCode: string = null;

  @JsonProperty('statesPracticedIn', [String], true)
  statesPracticedIn: string[] = [];
}
