import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ConfirmationDialogComponent } from 'src/app/common/confirmation-dialog/confirmation-dialog.component';
import { RefundAmountDialogComponent } from './refund-amount-dialog/refund-amount-dialog.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-maintenance',
  templateUrl: './product-maintenance.component.html',
  styleUrls: ['./product-maintenance.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ProductMaintenanceComponent implements OnInit {
  // Test data just to check working of generic components

  productInformation = {
    'Product Number': '000001AS',
    'Product': 'Estate',
    'Amount': '$1,000,00',
    'Premium': '$1,000',
    'Status': 'Button',
    'Original Issue Date': '01/08/2019',
    'Renewal Date': '01/08/2019',
    'Delivery Option': 'Email',
    'Application Id': '123456',
  };

  paymentDetails = {
    'Payment Date': '7/22/2019',
    'Payment Method': 'Visa ****5555',
    'Payment Amount': '$1000.00',
    'Receipt': 'View',
  };

  clientInformation = {
    'Name': 'John Smith',
    'Address 1': '123 Fake St',
    'Address 2': ' ',
    'City': 'Media',
    'State': 'PA',
    'Zip': 19063,
    'Phone': '(555) 555-5555',
    'Email Address': 'john.smith@example.com',
  };

  attorneyInformation = {
    'Attorney': 'Lionel Hutz',
    'Phone': '(555) 555-5555',
    'Email Address': 'lionel.hutz@example.com',
    'Firm': 'Hutz Law & Associates',
  };

  obligeeInformation = {
    'Docket No': 2588,
    'Court Name': 'Main Court',
    'Address 1': '125 Court Ave',
    'Address 2': ' ',
    'City': 'Media',
    'State': 'PA',
    'Zip': 19063,
    'Phone': '(555) 555-5555',
  };

  panelOpenState = false;
  constructor(
    private matDialog: MatDialog,
    private serviceHandler: ServiceHandler,
    private router: Router
  ) { }

  ngOnInit() {
  }

  editProduct() {
    this.router.navigate(['product/product-edit']);
  }

  markAsDone() {
    const dialogRef = this.matDialog.open(ConfirmationDialogComponent, {
      data: {
        // title: 'Delete Document ?',
        confirmationRequestText: 'Are you sure you want to mark \n this product as done?',
        acceptLabel: 'Yes',
        acceptedResult: true,
        rejectLabel: 'Cancel',
        rejectedResult: false,
      },
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // console.log('Response Data : ', result);
        this.serviceHandler.handleConfirm(' This Product\'s status has been changed to Done.');
      }
    });
  }

  refundPayment() {
    const dialogRef = this.matDialog.open(RefundAmountDialogComponent, {
      data: {
        title: ' Refund Amount ',
        confirmationRequestText: 'Why do these changes need to be made ?',
        acceptLabel: 'Continue',
        acceptedResult: true,
        rejectLabel: 'Cancel',
        rejectedResult: false,
      },
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const dialogResponse = this.matDialog.open(ConfirmationDialogComponent, {
          data: {
            title: 'Confirm Refunding Payment',
            confirmationRequestText: 'Are you sure you want to refund?',
            acceptLabel: 'Confirm Refund',
            acceptedResult: true,
            rejectLabel: 'Cancel',
            rejectedResult: false,
            detailsText: `Refund Amount: ${`$800.00`}`,
          },
        });
        dialogResponse.afterClosed().subscribe(res => {
          if (res) {
            const confirmRefundDialog = this.matDialog.open(ConfirmationDialogComponent, {
              data: {
                title: 'Product Updated',
                confirmationRequestText: `This product has been updated <br>A refund has been issued to the original payment method`,
                refundDetails: 'John Smith',
                detailsText: `Refund Amount: ${`$800.00`}`,
                acceptLabel: 'Ok',
                acceptedResult: true,
              },
            });
            confirmRefundDialog.afterClosed().subscribe(data => {
              if (data) {
                // console.log('Response Data : ', result);
              }
            });
          }
        });
      }
    });
  }
  cancelProduct() {
    const dialogRef = this.matDialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Cancel Product',
        cancelDate: new Date(),
        confirmationRequestText: 'Why is this product being canceled ?*',
        chooseProduct: 'choose',
        descriptionText: 'Add your note',
        acceptLabel: 'Cancel product',
        acceptedResult: true,
        rejectLabel: 'Back',
        rejectedResult: false,
      },
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // console.log('Response Data : ', result);
        this.serviceHandler.handleConfirm(' This Product\'s status has been changed to Canceled.');
      }
    });
  }
}
