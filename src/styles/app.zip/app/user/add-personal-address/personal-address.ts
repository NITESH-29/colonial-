import { Auditable, AuditableProfile } from '../../common/auditable-object';
import { AddressImpl, AddressModel } from '../../common/address/address';
import { Person, PersonImpl } from '../../common/person';
import { JsonObject, JsonProperty } from 'json2typescript';

export interface PersonalAddress extends Auditable {
  id: number;
  address: AddressModel;
  person: Person;
  fromDate: Date;
  toDate: Date;
}

@JsonObject('PersonalAddressImpl')
export class PersonalAddressImpl extends AuditableProfile implements PersonalAddress {
  @JsonProperty('address', AddressImpl, true)
  address: AddressModel = new AddressImpl();

  @JsonProperty('person', PersonImpl, true)
  person: Person = new PersonImpl();
}
