import { Component, OnInit, Input, ElementRef, Inject } from '@angular/core';
import { ActivatedRoute, Router, RouterLink, NavigationEnd } from '@angular/router';
import { IbondBaseService } from '../service/ibond-base.service';
import { Product } from '../../product/product';
import { ProductDocument } from '../../product/product-documents/product-document';
import { ProductService } from '../../product/products.service';
import { AppConfigService } from '../../app-config-service';
import { DOCUMENT } from '@angular/common';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { UserImpl } from 'src/app/security/user';
import { Subscription } from 'rxjs';
import { SecurityService } from 'src/app/security/security.service';
import { SpinnerService } from '../service/spinner.service';
import { TitleCasePipe } from '@angular/common';
import { FileService } from 'src/app/common/file-upload/file.service';
import { RequestService } from '../service/request.service';
import { ApplicationPopulateService } from '../service/application-populate.service';

@Component({
  selector: 'app-application-submit',
  templateUrl: './application-submit.component.html',
  styleUrls: ['./application-submit.component.scss'],
})
export class ApplicationSubmitComponent implements OnInit {
  loader = false;
  imgPDF = 'assets/icons/pdf.svg';
  imgDownload = 'assets/icons/download.svg';
  imgPrint = 'assets/icons/print.svg';
  applicationData = [];
  heading = '';
  secondaryHeading = '';
  subheading = '';
  applicationId: number;
  productData: object;
  headingName = '';
  bondDescription = '';
  bondType: string;
  pdfDocData = [];
  applicationStatus = '';
  headingIcon = '';
  bondInsuredByCompany = ['employee_dishonesty', 'janitorial'];
  @Input()
  product: Product;
  productNo: number;
  productDocuments: ProductDocument[] = [];
  colonialPhoneNumber: string;
  overview = false;
  isLostCarBondOnShown = false;
  isLostCarBondOnHold = false;
  appConfig: any;
  user: UserImpl = null;
  loggedIn: boolean;
  loggedIn$: Subscription;
  bondClassification: string;
  premium: number;
  paymentCard: string;
  quoteId: string;
  classificationName: string;
  confirmationMessage = '';
  confirmationSecondaryMessage = '';
  showEmail = false;
  isApplicationCompletedSpecialForm = false;
  knockoutDialog = false;
  reasonSentence: string;
  reason: string;
  constructor(
    @Inject(DOCUMENT) private document,
    private elementRef: ElementRef,
    private activatedRoute: ActivatedRoute,
    private lpService: IbondBaseService,
    private productService: ProductService,
    private spinnerService: SpinnerService,
    private titleCasePipe: TitleCasePipe,
    public router: Router,
    appConfigService: AppConfigService,
    public gtmService: GoogleTagManagerService,
    public securityService: SecurityService,
    private fileService: FileService,
    private requestService: RequestService,
    private applicationPopulateService: ApplicationPopulateService) {
    appConfigService.getConfig().subscribe(config => this.colonialPhoneNumber = config.colonialPhoneNumber);
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(parms => {
      this.applicationId = parms.id;
      this.bondType = parms.bondType;
    });
    this.activatedRoute.data.subscribe(data => {
      if (data['queryString']) {
        this.overview = true;
        this.applicationId = this.activatedRoute.snapshot.queryParams['formId'];
      }
    });
    this.getApplicationDetailsById();
    this.viewInit();
    this.securityService.loggedIn$.subscribe(
      loggedIn$ => {
        this.loggedIn = loggedIn$;
        if (this.loggedIn) {
          this.user = this.securityService.user;
        }

      }
    );
    this.applicationPopulateService.resetApplicationData();

  }
  // Bing Code Snippet-add GTM script configuration
  viewInit() {
    const bingSnippet = this.document.createElement('script');
    bingSnippet.type = 'text/javascript';
    bingSnippet.innerHTML = `
      (function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function()
        {var o={ti:"15215878"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},
        n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function()
        {var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},
        i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})
        (window,document,"script","//bat.bing.com/bat.js","uetq");
      `;
    this.elementRef.nativeElement.appendChild(bingSnippet);
  }
  getInsuredName() {
    // if (this.bondInsuredByCompany.indexOf(this.bondType) !== -1) {
    //   return this.applicationData['data']['businessDetails'].ownerName;
    // } else {
    return this.titleCasePipe.transform(this.applicationData['data']['applicantName']);
    // }
  }

  getAddressDetails(fieldName) {
    // if (this.bondInsuredByCompany.indexOf(this.bondType) !== -1) {
    //   if (fieldName === 'street2' && this.applicationData['data']['businessDetails'].ownerAddress.street2) {
    //     return ', ' + this.applicationData['data']['businessDetails'].ownerAddress.street2;
    //   }
    //   return this.applicationData['data']['businessDetails'].ownerAddress[fieldName];
    // } else {
    if (fieldName === 'street2' && this.applicationData['data'].applicantAddress.street2) {
      return ', ' + this.applicationData['data'].applicantAddress.street2;
    }
    return this.applicationData['data'].applicantAddress[fieldName];
    // }
  }

  getApplicationDetailsById() {
    this.spinnerService.show();
    this.lpService.getApplicationDetailsById(this.applicationId).subscribe((data: any[]) => {
      this.applicationData = data;
      this.bondClassification = this.applicationData['data'].bondClassification ?
        this.applicationData['data'].bondClassification : '';
      this.premium = this.applicationData['data'].premium ? this.applicationData['data'].premium : '';
      this.classificationName = this.applicationData['data'].classificationName ?
        this.applicationData['data'].classificationName : '';
      this.paymentCard = this.applicationData['data'].paymentMethod ?
        (this.applicationData['data'].paymentMethod.paymentChannelCode ?
          this.applicationData['data'].paymentMethod.paymentChannelCode.defaultDisplayText : '') : '';
      this.quoteId = this.applicationData['quoteId'] ? this.applicationData['quoteId'] : '';
      this.applicationStatus = this.applicationData['status'];
      let gtmApplicationStatus: string;
      if (this.applicationStatus === 'Completed') {
        gtmApplicationStatus = 'Completed';
      } else if (this.applicationStatus === 'Declined') {
        gtmApplicationStatus = 'Declined';
      } else {
        gtmApplicationStatus = 'pending';
      }
      const gtmBondType = this.requestService.setBondType(this.bondType);
      const classificationName = this.applicationData['data'].bondDescription ? this.applicationData['data'].bondDescription : '';
      const IPgroup = this.requestService.ipGroup;
      this.confirmationPageGtmEvent('bond-app-complete', `${gtmBondType}`, this.premium,
        (this.user.hasAttorneyRole ? 'attorney' : 'individual'), IPgroup, classificationName,
        this.quoteId, 'new', this.applicationId,
        this.paymentCard, gtmApplicationStatus
      );
      // this.applicationStatus
      this.spinnerService.hide();
      this.headingIcon = 'assets/icons/checkmark.svg';
      if (this.applicationStatus === 'Completed') {
        // this.headingName = this.applicationData['data']['applicantName'];
        this.headingName = this.getInsuredName();
        this.bondDescription = this.getBondDescriptionText(this.applicationData['data'].bondDescription);
        const isSpecialForm = this.applicationData['data'].specialBondForm;
        this.productNo = this.applicationData['data'].productNo ? this.applicationData['data'].productNo : null;
        if (this.productNo) {
          this.getproductDetails(this.productNo);
          this.getProductDocuments(this.productNo);
        }

        // if (isSpecialForm) {
        //   // this.isApplicationCompletedSpecialForm = true;
        //   // this.getDocumentsList(this.applicationId, 'Application');
        // } else {
        //   this.getproductDetails(this.productNo);
        //   this.getProductDocuments(this.productNo);
        // }
        this.heading = '"' + this.titleCasePipe.transform(this.applicationData['data']['applicantName']) +
          '"  You have successfully purchased the ';
        this.secondaryHeading = this.bondDescription;
        this.subheading = 'Your bond is available for download below.';
      } else if (this.applicationStatus === 'Declined' && this.applicationData['data']['knockedOutReason'] === 'technicalError') {
        this.applicationtechnicalError();
      } else if (this.applicationStatus === 'Hold' && this.bondType === 'lost_instrument' &&
        this.applicationData['data'].productNo !== null) {
        this.isLostCarBondOnShown = true;
        this.isLostCarBondOnHold = false;
        this.headingName = this.getInsuredName();
        this.bondDescription = this.getBondDescriptionText(this.applicationData['data'].bondDescription);
        this.productNo = this.applicationData['data'].productNo;
        this.getproductDetails(this.productNo);
        this.getProductDocuments(this.productNo);
        this.heading = 'Thank you for your application. Please complete the Affidavit of Loss that has'
          + ' been emailed to you and return it to us.';
        this.secondaryHeading = 'We will process your bond upon receipt of that document.';
      } else {
        this.isLostCarBondOnShown = true;
        this.isLostCarBondOnHold = true;
        this.headingName = this.applicationData['data']['applicantName'];
        if (this.applicationStatus === 'Declined') {
          this.headingIcon = 'assets/icons/close.svg';
          this.heading = this.titleCasePipe.transform(this.applicationData['data']['applicantName']) +
            ' "Your application has been declined."';
        } else {
          this.heading = this.titleCasePipe.transform(this.applicationData['data']['applicantName']) +
            ' "Your application is being processed."';
        }
        this.subheading = '';
      }
      this.getInsuredName();
      this.getConfirmationMessage();
    }, (error: any) => {
      this.spinnerService.hide();
      // this.serviceHandlerSnackbar.showErrorMessage('Something went wrong..');
    });
  }

  applicationtechnicalError() {
    this.headingIcon = '';
    this.heading = '';
    this.subheading = '';
    this.knockoutDialog = true;
    this.checkLocks('technicalError');
  }

  getConfirmationMessage() {
    if (this.applicationStatus === 'Declined') {
      this.bondDescription = this.getBondDescriptionText(this.applicationData['data'].bondDescription);

      this.confirmationMessage = 'Sorry, at the moment we are unable to provide you with ' + this.bondDescription + '.';

      this.confirmationSecondaryMessage = 'If you have any questions, please call ' + this.colonialPhoneNumber +
        ' (Mon-Fri, 8am-6pm EST) or email us at ';
      this.showEmail = true;
    } else if (this.applicationStatus === 'Hold') {
      this.confirmationMessage =
        'Thank you, Your application is being processed. We will email you when it is ready.';
      this.confirmationSecondaryMessage = 'If you have any questions, please call ' + this.colonialPhoneNumber +
        ' (Mon-Fri, 8am-6pm EST) or email us at ';
      this.showEmail = true;

    } else {
      this.confirmationMessage = 'Thank you, Your application is being processed. We will email you when it is ready.';
      this.confirmationSecondaryMessage = 'For any further queries, Please contact us at ' + this.colonialPhoneNumber + '.';
    }
  }

  getDocumentsList(applicationId, fileType) {
    this.fileService.getFileList(applicationId + '', fileType).subscribe((data: any[]) => {
      if (this.applicationData['data'].specialBondForm) {
        this.pdfDocData = data;
      } else {
        this.pdfDocData = data.filter(val => val.fileTypeName !== 'specialBondFile');
      }
      this.pdfDocData.forEach(item => {
        item.name = item.name.replace(/_/g, '-');
      });
      this.spinnerService.hide();
    });
  }

  getBondDescriptionText(bondDescription): string {
    let returnString;
    if (bondDescription.includes('Bond')) {
      returnString = bondDescription;
    } else {
      returnString = bondDescription + ' Bond';
    }
    return returnString;
  }
  getproductDetails(id) {
    this.lpService.getProductDetailsById(id).subscribe((data: any[]) => {
      this.productData = data;
    });
  }
  getProductDocuments(productId) {
    this.productService.getProductDocuments(productId).subscribe((data: any[]) => {
      if (this.applicationData['data'].specialBondForm) {
        this.pdfDocData = data;
      } else {
        this.pdfDocData = data.filter(val => val.fileTypeName !== 'specialBondFile');
      }
      this.pdfDocData.forEach(item => {
        item.name = item.name.replace(/_/g, '-');
      });
      this.spinnerService.hide();
    });
  }

  returnHome() {
    const redirectToProductPage = this.applicationStatus === 'Submitted' || this.applicationStatus === 'Completed';
    this.router.navigate(['/dashboard'], { queryParams: { redirectToProductPage: redirectToProductPage } });
  }
  getTotalPlanAmount() {
    const selectDeliveryMethod = this.applicationData['data'].deliveryMethod.deliveryMethod;
    const deliveryMethodFees = ['FedEx', 'UPS'];
    if (deliveryMethodFees.indexOf(selectDeliveryMethod) > -1) {
      return this.applicationData['data'].applicationPaymentPlan.totalPlanAmount;
    } else {
      return this.applicationData['premium'];
    }
  }

  getDeliveryFeesAmount() {
    const selectDeliveryMethod = this.applicationData['data'].deliveryMethod.deliveryMethod;
    const deliveryMethodFees = ['FedEx', 'UPS'];
    if (deliveryMethodFees.indexOf(selectDeliveryMethod) > -1) {
      return this.applicationData['data'].applicationPaymentPlan.paymentPlanLines['0'].amount;
    } else {
      return 0;
    }
  }

  displayStatus() {
    return this.applicationStatus === 'Submitted' ? 'Pending Review' : this.applicationStatus;
  }

  get isBondOnHold() {
    return this.applicationStatus === 'Hold';
  }
  confirmationPageGtmEvent(event, bondType, bondPremium, userType, lpGroup, lpBond,
    quoteId?, bondClass?, applicationID?, paymentType?, status?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`,
      `${status}`
    );
  }
  checkLocks(reason): void {
    switch (reason) {
      case 'knockedOut':
        this.reasonSentence = 'We are unable to provide a bond due to your answers to our preliminary questions';
        break;
      case 'creditScore':
        this.reasonSentence = 'We are unable to provide a bond due to your credit score';
        break;
      case 'both':
        this.reasonSentence =
          'We are unable to provide a bond due to your answers to our preliminary questions and your credit score';
        break;
      case 'technicalError':
        this.reasonSentence =
          'We are unable to check your credit score at this time';
        break;
      default:
        this.reasonSentence = '';
    }
  }

  getImageName(fileName) {
    const fileType = fileName.split('.').reverse()[0];
    if (fileType === 'pdf' || fileType === 'PDF') {
      return 'assets/icons/pdf.svg';
    } else if (fileType === 'doc' || fileType === 'docx') {
      return 'assets/icons/doc.png';
    } else if (fileType === 'png' || fileType === 'PNG') {
      return 'assets/icons/img.png';
    } else if (fileType === 'jpeg' || fileType === 'JPEG') {
      return 'assets/icons/img.png';
    } else if (fileType === 'jpg' || fileType === 'JPG') {
      return 'assets/icons/img.png';
    } else {
      return 'assets/icons/doc.png';
    }
  }
}
