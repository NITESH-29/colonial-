import { BrowserModule } from '@angular/platform-browser';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule, ErrorHandler, APP_INITIALIZER } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { MaterialModule } from './material.module';
import { HeaderComponent } from './main/header/header.component';
import { FooterComponent } from './main/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './security/app.auth.guard';
import { ClientService } from './user/client/client.service';
import { CalendarModule, CheckboxModule, DataListModule } from 'primeng/primeng';
import { ServiceHandler } from './common/utils/service-handler.service';
import { CommonComponentsModule } from './common/common-components.module';
import { AuthInterceptor } from './security/auth.interceptor';
import { UtilService } from './common/utils/util.service';
import { FileService } from './common/utils/file.service';
import { LoadingHandlerService } from './common/utils/loading-handler.service';
import { UserService } from './security/user.service';
import { AppConfigService } from './app-config-service';
import { SecurityModule } from './security/security.module';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { BaseHrefInterceptor } from './common/utils/base-href-interceptor';
import { Router } from '@angular/router';
import { FormInsuranceComponentModule } from './form-insurance-components/form-insurance-components.module';
import { HttpErrorInterceptor } from './security/http-error.interceptor';
import { CustomErrorHandler } from './common/utils/custom-error-handler';
import { LoginComponent } from './ibond/login/login.component';
import { ChangeBondComponent } from './ibond/common/change-bond/change-bond.component';
import { ApplicationPopulateService } from './ibond/service/application-populate.service';
import { SendToClientComponent } from './ibond/common/send-to-client/send-to-client.component';
import { NavigationDialogComponent } from './main/navigation-dialog/navigation-dialog.component';
// import { DeviceDetectorModule } from 'ngx-device-detector';
import { UserIdleModule } from 'angular-user-idle';
import { ConfirmLoginDialogComponent } from './main/confirm-login-dialog/confirm-login-dialog.component';
import { AttorneyGuard } from './user/role-guard/attorney.guard';
import { EmployeeDefaultGuard } from './user/role-guard/employee-default.guard';
import { SecurityService } from './security/security.service';
import { StringConstants } from './insurance/constants/string-constants';

const appInitializer = (appConfig: AppConfigService) => {
  return () => {
    return appConfig.loadAppConfig();
  };
};

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    LoginComponent,
    NavigationDialogComponent,
    ConfirmLoginDialogComponent,
  ],
  imports: [
    BrowserModule,
    FormInsuranceComponentModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    CommonComponentsModule,
    SecurityModule.forRoot(),
    UserIdleModule.forRoot({ idle: 1800, timeout: 30, ping: null }),
    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    MaterialModule,

    // Material Stuff
    BrowserAnimationsModule,
    FlexLayoutModule,
    // DeviceDetectorModule,
  ],
  exports: [
  ],
  entryComponents: [
    LoginComponent,
    ChangeBondComponent,
    SendToClientComponent,
    NavigationDialogComponent,
    ConfirmLoginDialogComponent,
  ],
  providers: [
    AppConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializer,
      multi: true,
      deps: [AppConfigService],
    },
    {
      provide: ErrorHandler,
      useClass: CustomErrorHandler,
    },
    HttpClient,
    ServiceHandler,
    AuthGuard,
    AttorneyGuard,
    EmployeeDefaultGuard,
    UtilService,
    ApplicationPopulateService,
    ClientService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { showError: true }, // errors won't show in top of stepper  if this isn't included
    },
    FileService,
    UserService,
    LoadingHandlerService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: BaseHrefInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useFactory: function(router: Router, acs: AppConfigService, securityService: SecurityService, stringConstant: StringConstants) {
        return new HttpErrorInterceptor(router, acs, securityService, stringConstant);
      },
      multi: true,
      deps: [Router, AppConfigService],
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
