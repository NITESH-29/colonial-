import { JsonObject, JsonProperty } from 'json2typescript';
import { PhoneNumberConverter } from '../../common/utils/phone-number-converter';
import { Client, ClientImpl } from '../../common/client';
import { PersonImpl } from '../../common/person';

export type ClientType = 'P' | 'C';

export type ClientDisplayType = 'Person' | 'Company';

export interface ClientData {
  uniqueId: string;
  id: number;
  agentId: number;
  name: string;
  email: string;
  phone: string;
  companyName: string;
  clientType: ClientType;
  displayType: ClientDisplayType;
  companyOfficeId: number;
  contact: string;
  state?: string;
  city?: string;
  productCount: number;
  readonly isCompany: boolean;
  readonly isPerson: boolean;
  readonly fullName?: string;
  readonly businessName?: string;
  firstName?: string;
  lastName?: string;
}

@JsonObject('ClientDataImpl')
export class ClientDataImpl implements ClientData {
  @JsonProperty('uniqueId', String, true)
  uniqueId: string = null;

  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('companyOfficeId', Number, true)
  companyOfficeId: number = null;

  @JsonProperty('agentId', Number, true)
  agentId: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('email', String, true)
  email: string = null;

  @JsonProperty('phone', PhoneNumberConverter, true)
  phone: string = null;

  @JsonProperty('clientType', String, true)
  clientType: ClientType = null;

  @JsonProperty('displayType', String, true)
  displayType: ClientDisplayType = null;

  @JsonProperty('contact', String, true)
  contact: string = null;

  @JsonProperty('state', String, true)
  state: string = null;

  @JsonProperty('city', String, true)
  city: string = null;

  @JsonProperty('productCount', Number, true)
  productCount: number = null;

  @JsonProperty('companyName', String, true)
  companyName: string = null;

  @JsonProperty('firstName', String, true)
  firstName: string = null;

  @JsonProperty('lastName', String, true)
  lastName: string = null;

  get isCompany(): boolean {
    return this.clientType === 'C';
  }

  get isPerson(): boolean {
    return this.clientType === 'P';
  }

  get fullName(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  get businessName(): string {
    let name = '';
    if (this.clientType === 'C') {
      name = this.companyName;
    } else {
      name = this.name;
    }
    return name;
  }
}


export function convertClientToClientData(client: Client): ClientData | ClientData[] {
  if (client.isPerson && client.isCompany) {
    const personClient = new ClientImpl();
    personClient.person = client.person as PersonImpl;

    const companyOfficeClient = new ClientImpl();
    companyOfficeClient.companyOffice = client.companyOffice;

    return [personClient, companyOfficeClient].map(convertCompanyOfficeOrPersonClientToClientData);
  } else {
    return convertCompanyOfficeOrPersonClientToClientData(client);
  }
}

export function convertCompanyOfficeOrPersonClientToClientData(client: Client): ClientData {
  const clientData: ClientData = new ClientDataImpl();
  clientData.uniqueId = `${client.clientType}:${client.id}`;
  clientData.id = client.id;
  clientData.agentId = client.person && client.person.agentId;
  clientData.name = client.name;
  clientData.email = client.email;
  clientData.phone = client.phone;
  clientData.clientType = client.clientType;
  clientData.displayType = client.displayType;

  return clientData;
}
