import { FormControl, FormGroup } from '@angular/forms';
import {
  PersonalInformationFormGroup,
  PersonalInformationFormGroupOptions
} from '../personal-information/personal-information-form-group';
import { UsernamePasswordFormGroup } from '../username-password/username-password-form-group';
import { User, UserImpl } from '../../security/user';
import {
  BusinessOfficePersonInformationFormGroup,
  BusinessOfficePersonInformationFormGroupOptions
} from '../business-office-person-information/business-office-person-information-form-group';
import { AgentImpl } from '../../common/agent';

export class ProfileFormGroup extends FormGroup {
  constructor(
    user?: UserImpl,
    disableInput: boolean = false,
    personalInformationOptions: PersonalInformationFormGroupOptions | BusinessOfficePersonInformationFormGroupOptions = {}
  ) {
    let personalInformation: FormGroup;

    if (user && (user.hasAgentRole || user.hasAttorneyRole)) {
      const defaultOptions = {
        includeEmail: true,
        includeProfession: false,
        includeAddress: true,
        includePhone: true,
        includeTitle: true,
        isRequired: true,
      };
      const overridden = Object.assign({}, defaultOptions, personalInformationOptions);
      personalInformation = new BusinessOfficePersonInformationFormGroup(overridden, disableInput);
    } else {
      const defaultOptions = {
        includeEmail: true,
        includeProfession: true,
        includeAddress: true,
        includePhone: true,
        isRequired: true,
      };
      const overridden = Object.assign({}, defaultOptions, personalInformationOptions);
      personalInformation = new PersonalInformationFormGroup(overridden, disableInput);
    }

    super({
      personalInformation: personalInformation,
      usernamePassword: new UsernamePasswordFormGroup(true),
      statesPracticedIn: new FormControl([]),
    });
  }

  patchValue(value: Partial<User>): void {
    this.personalInformation.patchValue(value.person);
    this.usernamePassword.patchValue({
      username: value.username,
    });

    if (value.agent) {
      this.statesPracticedIn.setValue(value.agent.statesPracticedIn || []);
    }
  }

  getRawValue(): UserImpl {
    const user: UserImpl = new UserImpl();
    user.person = this.personalInformation.getRawValue();
    user.username = this.usernamePassword.getRawValue().username;
    user.agent = new AgentImpl();
    user.agent.statesPracticedIn = this.statesPracticedIn.value;
    return user;
  }

  get personalInformation(): PersonalInformationFormGroup {
    return this.get('personalInformation') as PersonalInformationFormGroup;
  }

  get usernamePassword(): UsernamePasswordFormGroup {
    return this.get('usernamePassword') as UsernamePasswordFormGroup;
  }

  get statesPracticedIn(): FormControl {
    return this.get('statesPracticedIn') as FormControl;
  }
}
