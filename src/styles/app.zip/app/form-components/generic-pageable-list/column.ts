

export interface Column {
  header: string;
  field: string;
  link?: boolean;
  icon?: boolean;
  iconList?: any;
  hideSort?: boolean;
}
