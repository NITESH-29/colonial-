import { ValidationErrors } from '@angular/forms';
import { UsernamePasswordFormGroup } from './username-password-form-group';


export class PasswordValidators {
  static match(control: UsernamePasswordFormGroup): ValidationErrors | null {
    return control.password.value !== null && control.confirmPassword !== null
      && control.password.value !== control.confirmPassword.value ? { 'match': true } : null;
  }
}



