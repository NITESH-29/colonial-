export interface EmailAvailabilityRequest {
  requestedEmail: string;
}
