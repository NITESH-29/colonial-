export class GlobalConstants {
  public static STEPPER_ARRAY = [
    {
      label: 'Product Information',
      status: 'active',
      step: 'step1',
    },
    {
      label: 'Agreement',
      status: 'not-Active',
      step: 'step2',
    },
    {
      label: 'Payment',
      status: 'not-Active',
      step: 'step3',
    },
  ];

  public static INSURANCE_PRODUCT_ICON_KEY_MAPPER = {
    pnl: 'assets/icons/pli.svg',
    cyber: 'assets/icons/cuber_liability_insurance.svg',
    epli: 'assets/icons/epli.svg',
    gl: 'assets/icons/gli.svg',
  };


  public static DELIVERY_METHOD = [
    {
      'name': 'Email only',
      'code': 'Email',
    },
    {
      'name': 'FedEx (extra $30 fee)',
      'code': 'FedEx',
    },
    {
      'name': 'UPS (extra $30 fee)',
      'code': 'UPS',
    },
    {
      'name': 'Regular Mail',
      'code': 'Regular Mail',
    },
  ];
  public static EXPIRATION_MONTH = [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
    '11',
    '12',
  ];
  public static NOTARY_STATES_MANDATORY_SPECIAL_BOND = [
    'AL',
    'AZ',
    'PA',
    'TX',
    'GU',
    'CA',
    'MI',
    'NM',
    'WA',
    'NE',
    'SD',
    'OK',
    'MS',
    'IL',
    'NV',
    'TN',
    'UT',
    'WY',
    'KY',
    'HI',
    'MO',
    'IN',
  ];


  public static IBOND_LIST = [
    {
      displayName: 'License & Permit',
      code: 'landp',
    },
    {
      displayName: 'Notary',
      code: 'notary',
    },
    {
      displayName: 'Public Official',
      code: 'po',
    },
    {
      displayName: 'Employee Dishonesty',
      code: 'employee_dishonesty',
    },
    {
      displayName: 'Airport Security',
      code: 'airport_security',
    },
    {
      displayName: 'RIA',
      code: 'ria',
    },
    {
      displayName: 'Janitorial & Home Services',
      code: 'janitorial',
    },
    {
      displayName: 'VA Fiduciary',
      code: 'vafiduciary',
    },
    {
      displayName: 'Lost Instrument',
      code: 'lost_instrument',
    },
    {
      displayName: 'Lost Car/Defective Vehicle Title',
      code: 'lost_car_title',
    },
  ];
  public static HOME_SERVICE_TYPE = [
    'Janitorial',
    'Pet Setting',
    'House Cleaning',
    'Other',
  ];

  public static IBOND_CODE_ARRAY = [
    'landp',
    'notary',
    'po',
    'airport_security',
    'employee_dishonesty',
    'ria',
    'janitorial',
    'vafiduciary',
    'lost_instrument',
    'lost_car_title',
  ];

  public static INSURANCE_CODE_ARRAY = [
    'pnl',
    'cyber',
    'epli',
  ];

  public static BOND_AMOUNT_EMPLOYEE_DISHONESTY = [
    '25000',
    '30000',
    '40000',
    '50000',
    '75000',
    '100000',
    '150000',
    '200000',
    '250000',
  ];

  public static BOND_AMOUNT_JANITORIAL = [
    '1000',
    '2000',
    '3000',
    '4000',
    '5000',
    '6000',
    '7000',
    '8000',
    '9000',
    '10000',
    '15000',
    '20000',
    '25000',
    '30000',
    '40000',
    '50000',
    '75000',
    '100000',
    '150000',
    '200000',
    '250000',
  ];

  public static LOST_INSTRUMENT_TYPE = [
    { name: 'Certificates of Deposit', id: 1 },
    { name: 'Certified or Cashier Checks', id: 1 },
    { name: 'Money Orders', id: 1 },
    { name: 'Other', id: 1 },
    { name: 'Real Estate Certificates', id: 1 },
    { name: 'Savings Passbooks', id: 1 },
    { name: 'Stock Certificates', id: 1 },
  ];
  public static BOND_TYPE_ARRAY = [
    { name: 'Sedan', value: 'Sedan' },
    { name: 'Coupe', value: 'Coupe' },
    { name: 'Truck', value: 'Truck' },
    { name: 'SUV', value: 'SUV' },
    { name: 'Convertible', value: 'Convertible' },
    { name: 'Trailer', value: 'Trailer' },
  ];
  public static BUSINESS_TYPE_ARRAY = [
    'Corporation',
    'Partnership',
    'Proprietorship',
    'S.Corp.',
    'LLC',
  ];

  public static BOND_CONFIG = [
    {
      displayName: 'License & Permit',
      code: 'landp',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the license or permit.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
    {
      displayName: 'Notary',
      code: 'notary',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the notary.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: false,
      showIndividualSignature: true,
    },
    {
      displayName: 'Public Official',
      code: 'po',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the public official.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
    {
      displayName: 'Employee Dishonesty',
      code: 'employee_dishonesty',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the Employee Dishonesty.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: false,
      showIndividualSignature: true,
    },
    {
      displayName: 'Airport Security',
      code: 'airport_security',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the airport security.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
    {
      displayName: 'RIA',
      code: 'ria',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the RIA.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
    {
      displayName: 'Janitorial & Home Services',
      code: 'janitorial',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the janitorial & home services.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: false,
      showIndividualSignature: true,
    },
    {
      displayName: 'VA Fiduciary',
      code: 'vafiduciary',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the VA fiduciary.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
    {
      displayName: 'Lost Instrument',
      code: 'lost_instrument',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the Lost Instrument.',
        'bod_holder_heading': 'Name of the financial institution that issued the document/ instrument',
        'bod_holder_description': 'Name of the financial institution that issued the document/ instrument',
      },
      notifyLossOptions: ['Transfer Agent', 'Police', 'Others'],
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
    {
      displayName: 'Lost Car Title',
      code: 'lost_car_title',
      accordion_details: {
        'bond_details_heading': 'Bond Details',
        'bond_details_description': 'Select your bond terms.',
        'applicant_details_heading': 'Principal/applicant details',
        'applicant_details_description': 'Details to apply for the Lost Car Title.',
        'bod_holder_heading': 'Obligee (the party that requires this bond)',
        'bod_holder_description': 'Obligee does not mean applicant’s name. Here it can be municipality, state, or township.',
      },
      showCompanySignature: false,
      showSSN: true,
      showIndividualSignature: true,
    },
  ];

  public static LICENSE_PERMIT_BONDS = [
    'ria',
    'landp',
    'airport_security',
    'lost_car_title',
  ];

  public static NON_COMPANY_FLOW_BOND_TYPE = [
    'notary',
    'po',
    'vafiduciary',
  ];

  public static ATTORNEY_FLOW_BOND_TYPE_IBOND = [
    'vafiduciary',
    'lost_instrument',
  ];

  public static AGENT_FLOW_BOND_TYPE_IBOND = [
    'landp',
    'notary',
    'po',
    'airport_security',
    'employee_dishonesty',
    'ria',
    'janitorial',
    'lost_car_title',
    'lost_instrument',
    'vafiduciary',
  ];

  public static RIA_CLASSIFICATION_ID = 539;
  public static AIRPORT_SECURITY_CLASSIFICATION_ID = 540;
  public static LOCAT_CAR_CLASSIFICATION_ID = 454;
  public static EFFECTIVE_DATE_VALID_UNTIL_MONTHS = 2;

}
