import { Injectable } from '@angular/core';
import * as moment_ from 'moment';
import { ApplicationPopulateService } from './application-populate.service';

@Injectable({
  providedIn: 'root',
})
export class RequestService {
  planObject = {};
  moment = moment_;
  private _quoteId: number = null;
  private _applicantSSN: number;
  private _ipGroup = '';
  constructor(
    public applicationPopulate: ApplicationPopulateService
  ) { }

  getRequestData(bondType, person, requestBody, formdata, dataSource, addAgreementNode, addpaymetNode) {
    // date
    const expYr = formdata.cardExpiration || null;
    const expMonth = formdata.month || null;
    requestBody['data'].effectiveDate = this.serializeDate(formdata.effectiveDate);
    requestBody['data'].expiryDate = this.serializeDate(formdata.expiryDate);

    // bondType&QuoteId
    requestBody['data'].bondType = formdata.bondType || null;
    requestBody.quoteId = this.quoteId;
    requestBody['data'].bondDescription = formdata.bondDescription || null;
    requestBody['data'].productFor = formdata.productFor ? formdata.productFor : 'individual';

    requestBody['data'].firstName = formdata.firstName || null;
    requestBody['data'].lastName = formdata.lastName || null;
    requestBody['data'].applicantEmail = person ? person.email : formdata.applicantEmail;
    requestBody['data'].middleInitial = person ? person.initial : null;
    requestBody['data'].individualEmailSignature = requestBody['data'].applicantEmail;
    requestBody['data'].applicantName = formdata.companyName ? formdata.companyName : (formdata.applicantName ?
      formdata.applicantName : '');
    requestBody['data'].applicantAddress = this.getApplicantObject(formdata);
    requestBody['data'].applicantPhone = this.serializePhoneNumber(formdata.applicantPhone);
    if (addAgreementNode) {
      requestBody['data'].applicantSSNum = formdata.ssn ? formdata.ssn : null;
      requestBody['data'].applicantPersonalName = formdata.applicantPersonalName ? formdata.applicantPersonalName : null;
      requestBody['data'].applicantCompanyName = formdata.applicantCompanyName ? formdata.applicantCompanyName : null;
    }
    if (requestBody['data'].applicantSSNum) {
      requestBody['data'].applicantCreditCheckAddress = this.getApplicantCreditCheckAddressObject(formdata);
      requestBody['data'].creditCheckAddressSameAsApplicant = formdata.ssnAddressCheckbox;
    }
    requestBody.agreeToAutoRenewal = formdata.agreeToAutoRenewal || null;
    requestBody['data'].specialBondForm = false;
    requestBody['data'].specialBondUpload = false;
    requestBody['data'].specialBondFile = {
      id: null,
      name: '',
    };

    if (addpaymetNode) {
      requestBody['data'].paymentMethod = this.addPaymentNodeAndResetData(formdata);
    }
    requestBody['data'].termsAndConditions = addAgreementNode ? this.getTermsAndCondition(formdata, requestBody) : null;

    requestBody['data'].deliveryMethod = this.getDeliveryObject(formdata);
    requestBody['data'].koqOverride = false;
    requestBody['data'].liabilitiesInsuranceExists = formdata.liabilitiesInsuranceExists ? formdata.liabilitiesInsuranceExists : null;
    requestBody['data'].insuranceCompanyName = formdata.insuranceCompanyName ? formdata.insuranceCompanyName : null;
    requestBody.person = person || null;
    requestBody['data'].uspsContractNumber = formdata.uspsContractNumber || null;
    requestBody['data'].typeOfOrganization = formdata.typeOfOrganization;
    requestBody['data'].readAndAgreeToTerms = formdata.readAndAgreeToTerms || null;
    requestBody['data'].applicantCounty = formdata.applicantCounty ? formdata.applicantCounty : '';
    requestBody['data'].creditCheckAuthorized = true;
    if (addAgreementNode && formdata.ssnCheckbox) {
      requestBody['data'].creditCheckAuthorized = formdata.ssnCheckbox;
    } else {
      requestBody['data'].creditCheckAuthorized = null;
    }
    if (requestBody['data'].applicantSSNum) {
      requestBody['data'].companyOwner = {
        ownerName: formdata.ownerName,
      };
    } else if (!requestBody['data'].companyOwner) {
      requestBody['data'].companyOwner = null;
    }
    if (formdata.vehicleDetails) {
      requestBody['data'].vehicleDetails = formdata.vehicleDetails;
    }
    if (formdata.applicantContactTitle) {
      requestBody['data'].contactTitle = formdata.applicantContactTitle ? formdata.applicantContactTitle : null;
    }
    if (requestBody['data']['paymentMethod'] && requestBody['data']['paymentMethod'].resetPaymentDetail) {
      delete requestBody['data']['paymentMethod'].resetPaymentDetail;
    }

    switch (bondType) {
      case 'employee_dishonesty':
      case 'janitorial':
        requestBody['data'].businessType = formdata.businessType ? formdata.businessType.lookupValue : formdata.businessType;
        requestBody['data'].staffDetails = dataSource;
        requestBody['data'].homeServiceType = formdata.homeService;
        requestBody['data'].otherHomeServiceTypeDetails = formdata.provideDetails;
        requestBody['data'].businessDetails = null;
        break;
      case 'vafiduciary':
        requestBody['data'].veteranAffairsDetails = this.getVeteranAffairsDetails(formdata);
        requestBody['data'].obligee = this.getObligeeObject(formdata);
        break;
      case 'lost_instrument':
        requestBody['data'].dateOfLoss = formdata.dateOfLoss ? this.serializeDate(formdata.dateOfLoss) : null;
        requestBody['data'].dateOfAcquisition = formdata.dateOfAcquisition ? this.serializeDate(formdata.dateOfAcquisition) : null;
        requestBody['data'].agreeToAutoRenewal = null;
        requestBody['data'].businessDetails = {
          businessType: formdata.businessType || null,
          state: formdata.businessState || null,
          establishedYear: formdata.establishedYear || null,
          yearsInOperation: formdata.yearsInOperation || null,
        };
        requestBody['data'].instrumentDetails = {
          basisForBond: formdata.basisForBond,
          lostInstrumentDescription: formdata.lostInstrumentDescription,
          instrumentType: formdata.instrumentType,
          instrumentTypeName: formdata.instrumentTypeName || null,
          instrumentTypeOthers: formdata.instrumentTypeOthers || null,
        };
        requestBody['data'].obligee = this.getObligeeObject(formdata);
        break;
      case 'lost_car_title':
        requestBody['data'].vehicleDetails = {
          vehicleIdentificationNumber: formdata.vehicleIdentificationNumber || null,
          licensePlate: formdata.licensePlate || null,
          year: formdata.year || null,
          bodyType: formdata.bodyType || null,
          make: formdata.make || null,
          model: formdata.model || null,
          detailsWhyYouAreApplying: formdata.detailsWhyYouAreApplying || null,
        };
        requestBody['data'].obligee = this.getObligeeObject(formdata);
        break;
      case 'po':
        requestBody['data'].agreeToAutoRenewal = null;
        requestBody['data'].obligee = this.getObligeeObject(formdata);
        break;
      case 'ria':
        requestBody['data'].registrationNo = formdata.applicantRegistrationNum ?
          formdata.applicantRegistrationNum : null;
        requestBody['data'].obligee = this.getObligeeObject(formdata);
        break;
      default:
        requestBody['data'].obligee = this.getObligeeObject(formdata);
    }
    requestBody['data'].knockoutQuestions = formdata.knockoutQuestions ? formdata.knockoutQuestions : null;
    requestBody['data'].applicantQuestions = formdata.applicantQuestions ? formdata.applicantQuestions : null;
    if (requestBody['data'].knockoutQuestions) {
      requestBody['data'].knockoutQuestions.forEach(ques => {
        if (ques.question.type === 'date') {
          ques.value = this.serializeDate(ques.value);
        }
      });
    }
    if (requestBody['data'].applicantQuestions) {
      requestBody['data'].applicantQuestions.forEach(ques => {
        if (ques.question.type === 'date') {
          ques.value = this.serializeDate(ques.value);
        }
      });
    }
    return requestBody;
  }

  getBusinessObject(formdata) {
    return {
      ownerName: formdata.individualName,
      ownerAddress: {
        street1: formdata.individualAddress,
        street2: formdata.individualAddress2,
        city: formdata.individualCity,
        state: formdata.individualState,
        zipCode: formdata.individualZip,
      },
      ownerPhone: this.serializePhoneNumber(formdata.individualPhone),
      // ownerFax: formdata.individualfax ? this.serializePhoneNumber(formdata.individualfax : null,
    };
  }

  getSpecialBondFileInfo(formData) {
    return {
      id: formData.specialBondFile ? formData.specialBondFile.id : null,
      name: formData.specialBondFile ? formData.specialBondFile.name : null,
    };
  }

  addPaymentNodeAndResetData(formdata) {
    const paymentNode = this.getpaymentPlanObject();
    paymentNode['response'] = {
      success: null,
      status: null,
      text: null,
      transaction: null,
      date: null,

    };

    if (paymentNode['resetPaymentDetail']) {
      paymentNode['billingFirstName'] = formdata.billingFirstName || null;
      paymentNode['billingLastName'] = formdata.billingLastName || '';
      paymentNode['billingPhone'] = formdata.billingPhone ? this.serializePhoneNumber(formdata.billingPhone) : null;
      paymentNode['billingAddress'] = {
        street1: formdata.billingAddress,
        street2: formdata.billingAddress2,
        city: formdata.billingCity,
        state: formdata.billingState,
        zipCode: formdata.billingZipCode,
      } || null,
        // paymentNode.cardNumber = formdata.cardNumber ? this.serializeCardNumber(formdata.cardNumber) : null;
        paymentNode['cardNumber'] = formdata.cardNumber ? formdata.cardNumber : null;
      paymentNode['cardCVV'] = formdata.cardCVV || null;
      const expYr = formdata.cardExpiration || null;
      const expMonth = formdata.month || null;
      paymentNode['cardExpiration'] = expMonth + '/' + expYr;
    }
    return paymentNode;
  }

  getApplicantCreditCheckAddressObject(formdata) {
    return {
      street1: formdata.street1,
      street2: formdata.street2,
      city: formdata.city,
      state: formdata.state,
      zipCode: formdata.zipCode,
    };
  }

  getVeteranAffairsDetails(formData) {
    return {
      nameOfVeteranWard: formData.nameOfVeteranWard,
      doYouHaveVeteranAffairsLetter: formData.doYouHaveVeteranAffairsLetter,
      veteranAffairsLetter: formData.veteranAffairsLetter,
    };
  }

  getOwnerInformation(formData) {
    if (formData.ownerFirstName || formData.ownerName) {
      return {
        ownerName: formData.ownerFirstName ? formData.ownerFirstName + ' ' + formData.ownerLastName : formData.ownerName,
        ownerAddress: {
          street1: formData.ownerStreet1,
          street2: formData.ownerStreet2,
          city: formData.ownerCity,
          state: formData.ownerState,
          zipCode: formData.ownerZipCode,
        },
        ownerPhone: formData.ownerPhone ? this.serializePhoneNumber(formData.ownerPhone) : null,
        // ownerFax: formData.ownerFax,
        ownerSSN: formData.ownerSSN,
        ownerEmail: formData.ownerEmail,
      };
    } else {
      return null;
    }
  }
  getApplicantObject(formdata) {
    return {
      street1: formdata.applicantStreet1,
      street2: formdata.applicantStreet2,
      city: formdata.applicantCity,
      state: formdata.applicantState,
      zipCode: formdata.applicantZipCode,
    };
  }

  getObligeeObject(formdata) {
    return {
      obligeeName: formdata.obligeeName,
      obligeeAddress: {
        street1: formdata.obligeestreet1,
        street2: formdata.obligeestreet2,
        city: formdata.obligeecity,
        state: formdata.obligeestate,
        zipCode: formdata.obligeezipCode,
      },
      obligeePhone: formdata.obligeePhone ? this.serializePhoneNumber(formdata.obligeePhone) : null,
      // obligeeFax: formdata.obligeeFax,
      obligeeCounty: formdata.obligeeCounty,
    };
  }
  getDeliveryObject(formdata) {
    return {
      deliveryMethod: 'Email',
      copyViaEmail: null,
    };
  }
  getPaymentObject(formdata) {
    return {
      billingAddress: formdata = {
        street1: formdata.street1,
        street2: formdata.street2,
        zipCode: formdata.zipCode,
        city: formdata.city,
        state: formdata.state,
      },
    };
  }
  getTermsAndCondition(formdata, requestBody) {
    let termsAndConditions;
    termsAndConditions = {
      readAndAgreeToTerms: formdata.readAndAgreeToTerms,
      readAndAgreeToTermsCompany: formdata.readAndAgreeToTermsCompany || null,
      premiumAcknowledged: formdata.premiumAcknowledged,
      agreementDate: this.serializeDate(new Date()),
    };
    if (this.applicationPopulate.emailSignatureValid) {
      termsAndConditions.emailSignature = formdata.emailSignature;
    } else if (requestBody['data'].termsAndConditions && requestBody['data'].termsAndConditions.emailSignature) {
      termsAndConditions.emailSignature = requestBody['data'].termsAndConditions.emailSignature;
    }
    if (this.applicationPopulate.companySignatureValid) {
      termsAndConditions.companyEmailSignature = formdata.companyEmailSignature;
    } else if (requestBody['data'].termsAndConditions && requestBody['data'].termsAndConditions.companyEmailSignature) {
      termsAndConditions.companyEmailSignature = requestBody['data'].termsAndConditions.companyEmailSignature;
    }
    return termsAndConditions;
  }

  setPaymentPlanObject(planobj, flag) {
    if (flag) {
      this.planObject = planobj;
      this.planObject['resetPaymentDetail'] = false;
    } else {
      this.planObject = {
        resetPaymentDetail: true,
        paymentPlanTypeId: planobj.paymentPlanTypeId || null,
        billingProfileId: planobj.billingProfileId || null,
        secondaryBillingPersonBillingProfileId: null,
        response: {
          success: null,
          status: null,
          text: null,
          transaction: null,
          date: null,
        },
        personId: planobj.personId || null,
        paymentChannelCode: {
          persistenceId: planobj.persistenceId || null,
          paymentChannelType: {
            persistenceId: 'credit',
            electronic: planobj.electronic || null,
            defaultDisplayText: 'credit',
          },
          defaultDisplayText: planobj.defaultDisplayText || null,
          electronic: planobj.electronic || null,
          creditCard: planobj.creditCard || null,
        },
        billingFirstName: planobj.firstName ? planobj.firstName : '',
        billingLastName: planobj.lastName ? planobj.lastName || ' ' : ' ',
        billingPhone: planobj.billingPhone ? this.serializePhoneNumber(planobj.billingPhone) : null,
        billingAddress: planobj.billingAddress,
        cardNumber: this.serializeCardNumber(planobj.cardNumber),
        cardCVV: planobj.cardCVV,
        cardExpiration: planobj.cardExpiration,
      };
    }
  }

  getpaymentPlanObject() {
    return this.planObject;
  }

  deserializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3') : phoneNumber;
  }

  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  deserializeCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber.replace(/(\d{4})(\d{4})(\d{4})(\d{4})/g, '$1-$2-$3-$4') : cardNumber;
  }

  serializeCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber.replace(/[^\d]/g, '') : cardNumber;
  }

  customDateFormatter(date: string): Date {
    return date ? new Date(this.moment(date).utcOffset('+0000').format('MM/DD/YYYY')) : new Date();
    // return date ? new Date(this.moment(date).format('MM/DD/YYYY')) : new Date();
  }

  get applicantSSN(): number {
    return this._applicantSSN;
  }

  set applicantSSN(applicantSSN: number) {
    this._applicantSSN = applicantSSN;
  }

  resetApplicantSSN() {
    this._applicantSSN = null;
  }

  serializeDate(date: Date): any {
    return this.moment(date).format('YYYY-MM-DD') + 'T12:00:00.000+0000';

  }

  get quoteId() {
    return this._quoteId;
  }

  set quoteId(quoteId) {
    this._quoteId = quoteId;
  }
  setBondType(bondType) {
    let gtmBondType: string;
    if (bondType === 'landp') {
      gtmBondType = 'license and permit';
    } else if (bondType === 'Registered Investment Adviser') {
      gtmBondType = 'ria';
    } else if (bondType === 'Airport Security') {
      gtmBondType = 'airport_security';
    } else if (bondType === 'Lost Car Title'
      || bondType === 'lost_car_title'
      || bondType === 'Lost Car Title/Defective Vehicle Title (Includes Donated Vehicle)') {
      gtmBondType = 'lost car';
    } else if (bondType === 'vafiduciary') {
      gtmBondType = 'va fiduciary';
    } else {
      gtmBondType = bondType;
    }
    return gtmBondType;
  }

  set ipGroup(data) {
    this._ipGroup = data;
  }

  get ipGroup() {
    return this._ipGroup;
  }

}
