import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CompanyModel, CompanyModelImpl } from '../models/company-model';
import { JsonConvert } from 'json2typescript';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { JsonConvertService } from '../../common/utils/json-convert.service';
import { AbstractService } from '../../common/services/abstract-service';
import { AgencyModel, AgencyModelImpl } from '../models/agency-model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserImpl } from 'src/app/security/user';
import { SecurityService } from 'src/app/security/security.service';

@Injectable()
export class PersonBusinessService extends AbstractService {
  private jsonConvert: JsonConvert;
  user: UserImpl = null;
  constructor(
    private http: HttpClient,
    private serviceHandler: ServiceHandler,
    jsonConvertService: JsonConvertService,
    private securityService: SecurityService
  ) {
    super();
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  async getBusinessesForPerson(personId: number): Promise<CompanyModel[] | AgencyModel[]> {
    return this.getOneOrMoreBusinessesForPerson(this.urlFor(personId)) as Promise<CompanyModel[] | AgencyModel[]>;
  }

  getBusinessesForPersonAsObservable(personId: number): Observable<CompanyModel[] | AgencyModel[]> {
    return this.getOneOrMoreBusinessesForPersonAsObservable(this.urlFor(personId)) as Observable<CompanyModel[] | AgencyModel[]>;
  }

  async getBusinessForPerson(personId: number, companyId: number): Promise<CompanyModel | AgencyModel> {
    return this.getOneOrMoreBusinessesForPerson(this.urlFor(personId, companyId)) as Promise<CompanyModel | AgencyModel>;
  }

  private async getOneOrMoreBusinessesForPerson(url): Promise<CompanyModel | CompanyModel[] | AgencyModel | AgencyModel[]> {
    return this.getOneOrMoreBusinessesForPersonAsObservable(url).toPromise();
  }

  private getOneOrMoreBusinessesForPersonAsObservable(url): Observable<CompanyModel | CompanyModel[] | AgencyModel | AgencyModel[]> {
    return this.http.get(url).pipe(map(r => this.jsonConvert.deserialize(r, determineDeserializationTargetFor(r))));
  }

  async createCompany(company: CompanyModel, personId: number): Promise<CompanyModel> {
    return this.createOrUpdateBusiness(company, personId, 'post') as Promise<CompanyModel>;
  }

  async updateCompany(company: CompanyModel, personId: number): Promise<CompanyModel> {
    return this.createOrUpdateBusiness(company, personId, 'put') as Promise<CompanyModel>;
  }

  async createAgency(agency: AgencyModel, personId: number): Promise<AgencyModel> {
    return this.createOrUpdateBusiness(agency, personId, 'post') as Promise<AgencyModel>;
  }

  async updateAgency(agency: AgencyModel, personId: number): Promise<AgencyModel> {
    return this.createOrUpdateBusiness(agency, personId, 'put') as Promise<AgencyModel>;
  }

  private async createOrUpdateBusiness(
    business: AgencyModel | CompanyModel,
    personId: number,
    httpMethod: 'post' | 'put'
  ): Promise<AgencyModel | CompanyModel> {
    const response = await this.http[httpMethod](this.urlFor(personId), this.jsonConvert.serialize(business)).toPromise();
    const isAgent = this.securityService.user.hasAgentRole;
    const message = isAgent ? 'Agency' : 'Company';
    this.serviceHandler.handleConfirm(`${message} information saved`);
    return this.jsonConvert.deserialize(response, determineDeserializationTargetFor(response));
  }

  private urlFor(personId: number, companyId?: number): string {
    return this.requestURL('/' + ['person', personId, 'company', companyId].filter(Boolean).join('/'));
  }
}

// Had to coerce this return type to `new () => any` in order to satisfy jsonConvert.deserialize :-(
// There must be a correct way to express the relationship between the response
// and the correct constructor function to return, I wish I knew what that was…
function determineDeserializationTargetFor(response: any): new () => any {
  if (response instanceof Array) {
    const [first] = response;
    return determineDeserializationTarget(first);
  } else {
    return determineDeserializationTarget(response);
  }
}

function determineDeserializationTarget(response: any): (new () => AgencyModelImpl) | (new () => CompanyModelImpl) {
  if (response && response.hasOwnProperty('memberOfNasbp') && response.hasOwnProperty('einNumber')) {
    return AgencyModelImpl;
  } else {
    return CompanyModelImpl;
  }
}

