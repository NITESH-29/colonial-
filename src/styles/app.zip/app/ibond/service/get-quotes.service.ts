import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API_URL } from '../constant/i-bond-constant';
import { P } from '@angular/cdk/keycodes';
import { CurrencyFormatter } from 'src/app/common/utils/currency-formatter';
@Injectable({
  providedIn: 'root',
})
export class GetQuotesService {
  private _bondPremiumForGTM: Number;

  constructor(private httpClient: HttpClient) { }

  getBondClassification() {
    return this.httpClient.get(API_URL.BOND_CLASSIFICATION);
  }
  getPremiumCalculationLandP(request_obj) {
    return this.httpClient.post(API_URL.LNP_CALCULATE_PREMIUM, request_obj);
  }
  getPremiumCalculation(request_obj, bondType) {
    const REQUEST_URL = 'api/premium/ibond/' + bondType;
    return this.httpClient.post(REQUEST_URL, request_obj);
  }
  createApplication(request_obj) {
    const REQUEST_URL = API_URL.CREATE_APPLICATION + request_obj.data['bondClassification'];
    return this.httpClient.post(REQUEST_URL, request_obj);
  }
  validateEmail(request_obj) {
    return this.httpClient.post(API_URL.EMAIL_AVAILABILITY, request_obj);
  }
  getNotaryStateList() {
    return this.httpClient.get(API_URL.GET_NOTARY_STATES);
  }
  createApplicationRequestLandP(quoteform, calculatedPremium) {
    return {
      'amount': Number(calculatedPremium.amount),
      'premium': Number(calculatedPremium.premium),
      'data': {
        'bondClassification': 'landp',
        'bondClassificationId': Number(quoteform.value.bondClassification.id),
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'classificationName': quoteform.value.classificationName,
        'productFor': quoteform.value.productType || 'individual',
        'creditScore': quoteform.value.creditScore,
        'bondTerm': quoteform.value.bondTerm,
        'premiumRate': quoteform.value.premiumRate,
        'smallLargeApplication': quoteform.value.smallLargeApplication,
        'individualEmailSignature': quoteform.value.individualEmail || null,
        'companyName': quoteform.value.companyName || null,
        'premiumRateId': calculatedPremium.premiumRateId,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'company': quoteform.value.company,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },

    };
  }
  createApplicationRequestNotary(quoteform, calculatedPremium) {
    return {
      'amount': Number(calculatedPremium.amount),
      'premium': Number(calculatedPremium.premium),
      'data': {
        'bondClassification': 'notary',
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'productFor': 'individual',
        'individualEmailSignature': quoteform.value.individualEmail || null,
        'notaryState': quoteform.value.selectState,
        'premiumRateId': calculatedPremium.premiumRateId,
        'companyName': quoteform.value.companyName || null,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'company': quoteform.value.company,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },

    };
  }

  createApplicationRequestPublicOfiicial(quoteform, calculatedPremium) {
    return {
      'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
      'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
      'data': {
        'bondClassification': 'po',
        'bondClassificationId': Number(quoteform.value.bondClassification.id),
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'productFor': 'individual',
        'classificationName': quoteform.value.classificationName,
        'individualEmailSignature': quoteform.value.publicFundsEmail || null,
        'creditScore': quoteform.value.creditScore,
        'premiumRate': quoteform.value.premiumRate,
        'smallLargeApplication': quoteform.value.smallLargeApplication,
        'publicFunds': quoteform.value.handlesPublicFund,
        'knockoutQuestions': quoteform.value.knockoutQuestions,
        'applicantQuestions': quoteform.value.applicantQuestions,
        'premiumRateId': calculatedPremium.premiumRateId,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'company': false,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
    };
  }

  createApplicationRequestAirportSecurity(quoteform, calculatedPremium, termForm) {
    return {
      'data': {
        'bondClassification': 'airport_security',
        'amount': CurrencyFormatter.toRawNumber(quoteform.value.amount),
        'premium': this.getPremiumAccordingTerm(calculatedPremium, termForm.value.bondTerm),
        'productFor': quoteform.value.productType || 'individual',
        'bondClassificationId': quoteform.value.bondClassification.id,
        'individualEmailSignature': quoteform.value.individualEmail || null,
        'companyName': quoteform.value.companyName || null,
        // tslint:disable-next-line: radix
        'bondTerm': parseInt(termForm.value.bondTerm),
        'classificationName': quoteform.value.classificationName,
        'applicantQuestions': quoteform.value.applicantQuestions,
        // tslint:disable-next-line:radix
        'premiumRateId': (parseInt(termForm.value.bondTerm) === 3) ?
          calculatedPremium.premiumRateIdForTermThree : calculatedPremium.premiumRateId,
        'creditScore': quoteform.value.creditScore,
        'premiumRate': quoteform.value.premiumRate,
        'email': quoteform.value.individualEmail,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'company': false,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(quoteform.value.amount),
      'premium': this.getPremiumAccordingTerm(calculatedPremium, termForm.value.bondTerm),
    };
  }

  createApplicationRequestRia(quoteform, calculatedPremium) {
    return {
      'data': {
        'bondClassification': 'ria',
        'amount': CurrencyFormatter.toRawNumber(quoteform.value.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'productFor': quoteform.value.productType || 'individual',
        'bondClassificationId': quoteform.value.bondClassification.id,
        'individualEmailSignature': quoteform.value.individualEmail || null,
        'companyName': quoteform.value.companyName || null,
        // tslint:disable-next-line: radix
        // 'bondTerm': parseInt(termForm.value.bondTerm),
        'classificationName': quoteform.value.classificationName,
        'creditScore': quoteform.value.creditScore,
        'knockoutQuestions': quoteform.value.knockoutQuestions,
        'applicantQuestions': quoteform.value.applicantQuestions,
        'premiumRateId': calculatedPremium.premiumRateId,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'company': false,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(quoteform.value.amount),
      'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
    };
  }
  getPremiumAccordingTerm(calculatedPremium, term) {
    let selectedPremium;
    switch (term) {
      case '1':
        selectedPremium = calculatedPremium.premium;
        break;
      case '2':
        selectedPremium = calculatedPremium.twoYearPremium;
        break;
      case '3':
        selectedPremium = calculatedPremium.threeYearPremium;
        break;
      default:
        selectedPremium = calculatedPremium.premium;
        break;
    }
    return CurrencyFormatter.toRawNumber(selectedPremium);
  }

  createApplicationEmployeeDishonesty(quoteform, calculatedPremium, termForm) {
    return {
      'data': {
        'bondClassification': 'employee_dishonesty',
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': this.getPremiumAccordingTerm(calculatedPremium, termForm.value.bondTerm),
        // tslint:disable-next-line: radix
        'numberOfEmployees': parseInt(quoteform.value.noOfEmployees),
        'productFor': quoteform.value.productType || 'individual',
        // tslint:disable-next-line: radix
        'bondTerm': parseInt(termForm.value.bondTerm),
        'knockoutQuestions': quoteform.value.knockoutQuestions,
        'applicantQuestions': quoteform.value.applicantQuestions,
        // tslint:disable-next-line:radix
        'premiumRateId': (parseInt(termForm.value.bondTerm) === 3) ?
          calculatedPremium.premiumRateIdForTermThree : calculatedPremium.premiumRateId,
        'companyName': quoteform.value.companyName || null,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'individualEmail': quoteform.value.individualEmail,
        'company': quoteform.value.companyName && quoteform.value.companyName.length ? true : false,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
      'premium': this.getPremiumAccordingTerm(calculatedPremium, termForm.value.bondTerm),
    };
  }
  createApplicationJanitorial(quoteform, calculatedPremium, termForm) {
    return {
      'data': {
        'bondClassification': 'janitorial',
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': this.getPremiumAccordingTerm(calculatedPremium, termForm.value.bondTerm),
        // tslint:disable-next-line: radix
        'numberOfEmployees': parseInt(quoteform.value.noOfEmployees),
        'productFor': quoteform.value.productType || 'individual',
        // tslint:disable-next-line: radix
        'bondTerm': parseInt(termForm.value.bondTerm),
        'knockoutQuestions': quoteform.value.knockoutQuestions,
        'applicantQuestions': quoteform.value.applicantQuestions,
        // tslint:disable-next-line:radix
        'premiumRateId': (parseInt(termForm.value.bondTerm) === 3) ?
          calculatedPremium.premiumRateIdForTermThree : calculatedPremium.premiumRateId,
        'companyName': quoteform.value.companyName || null,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'individualEmail': quoteform.value.individualEmail,
        'company': quoteform.value.companyName && quoteform.value.companyName.length ? true : false,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
      'premium': this.getPremiumAccordingTerm(calculatedPremium, termForm.value.bondTerm),
    };
  }

  createApplicationVafiduciary(quoteform, calculatedPremium) {
    return {
      'data': {
        'bondClassification': 'vafiduciary',
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'productFor': 'individual',
        'individualEmailSignature': quoteform.bondEmail,
        'vaFiduciaryType': quoteform.bondType,
        'vaFiduciarystate': quoteform.bondState,
        'classificationName': quoteform.classificationName,
        'creditScore': quoteform.creditScore,
        'applicantQuestions': quoteform.applicantQuestions,
        'premiumRateId': calculatedPremium.premiumRateId,
        'firstName': quoteform.firstName,
        'lastName': quoteform.lastName,
        'phone': this.serializePhoneNumber(quoteform.phone),
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
      'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
    };
  }
  createApplicationLostInstrument(quoteform, calculatedPremium) {
    return {
      'data': {
        'bondClassification': 'lost_instrument',
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'productFor': quoteform.value.productType || 'individual',
        'classificationName': quoteform.value.classificationName,
        'creditScore': quoteform.value.creditScore,
        'bondTerm': quoteform.value.bondTerm,
        'premiumRate': quoteform.value.premiumRate,
        'individualEmailSignature': quoteform.value.individualEmail || null,
        'companyName': quoteform.value.companyName || null,
        'knockoutQuestions': quoteform.value.knockoutQuestions,
        'applicantQuestions': quoteform.value.applicantQuestions,
        'premiumRateId': calculatedPremium.premiumRateId,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'company': quoteform.value.companyName && quoteform.value.companyName.length ? true : false,
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
      'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
    };
  }
  getPremiumCalculationNotary(request_obj) {
    return this.httpClient.post(API_URL.NOTARY_CALCULATE_PREMIUM, request_obj);
  }
  getBondClassificationForPO() {
    return this.httpClient.get(API_URL.BOND_CLASSIFICATION_PO);
  }
  getBondClassificatonForJanitorial() {
    return this.httpClient.get(API_URL.BOND_CLASSIFICATION_JANITORIAL);
  }
  getBondClassificatonForEmployeeDishonesty() {
    return this.httpClient.get(API_URL.BOND_CLASSIFICATION_EMPLOYEE_DISHONESTY);
  }
  getBondClassificatonForRIA() {
    return this.httpClient.get(API_URL.BOND_CLASSIFICATION_RIA);
  }
  getPremiunCalculationPublicOfficial(request_obj) {
    return this.httpClient.post(API_URL.PO_CALCULATE_PREMIUM, request_obj);
  }
  getPremiunCalculationAirportSecurity(request_obj) {
    return this.httpClient.post(API_URL.AS_CALCULATE_PREMIUM, request_obj);
  }
  getBondDetailsIdAirportSecurity() {
    return this.httpClient.get(API_URL.AS_GET_BOND_ID);
  }
  getPremiumEmployeeDishonesty(request_obj) {
    return this.httpClient.post(API_URL.EMP_DIS_CALCULATE_PREMIUM, request_obj);
  }
  getVafiduciaryTypes() {
    return this.httpClient.get(API_URL.VA_FIDUCIARY_TYPES);
  }
  getVafiduciaryStates() {
    return this.httpClient.get(API_URL.VA_FIDUCIARY_STATES);
  }
  getPremiunCalculationVafiduciary(request_obj) {
    return this.httpClient.post(API_URL.VA_FIDUCIARY_CALCULATE_PREMIUM, request_obj);
  }
  async getBondDetailsIdVafiduciary() {
    return await this.httpClient.get(API_URL.VA_FIDUCIARY_GET_BOND_ID).toPromise();
  }
  getPremiumJanitorial(request_obj) {
    return this.httpClient.post(API_URL.JANITORIAL_CALCULATE_PREMIUM, request_obj);
  }
  getBondListLostInstrument() {
    return this.httpClient.get(API_URL.LOST_INSTRUMENT_BOND_LIST);
  }
  getPremiunCalculationLostInstrument(request_obj) {
    return this.httpClient.post(API_URL.LOST_INSTRUMENT_CALCULATE_PREMIUM, request_obj);
  }
  getLostCarTitleStates() {
    return this.httpClient.get(API_URL.VA_FIDUCIARY_STATES);
  }
  getBondClassificationLostCarTitle() {
    return this.httpClient.get(API_URL.LOST_CAR_TITLE_BOND_LIST);
  }
  getPremiumLostCarTitle(request_obj) {
    return this.httpClient.post(API_URL.LOST_CAR_TITLE_CALCULATE_PREMIUM, request_obj);
  }
  createApplicationLostCarTitle(quoteform, calculatedPremium) {
    return {
      'data': {
        'bondClassification': 'lost_car_title',
        'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
        'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
        'productFor': quoteform.value.productType || 'individual',
        'creditScore': quoteform.value.creditScore,
        'individualEmailSignature': quoteform.value.individualEmail || null,
        'companyName': quoteform.value.companyName || null,
        'classificationName': quoteform.value.classificationName,
        'bondClassificationId': quoteform.value.bondClassification ? Number(quoteform.value.bondClassification.id) : 454,
        'stateDMV': quoteform.value.stateDMV,
        'smallLargeApplication': quoteform.value.smallLargeApplication,
        'knockoutQuestions': quoteform.value.knockoutQuestions,
        'applicantQuestions': quoteform.value.applicantQuestions,
        'premiumRateId': calculatedPremium.premiumRateId,
        'firstName': quoteform.value.firstName,
        'lastName': quoteform.value.lastName,
        'phone': this.serializePhoneNumber(quoteform.value.phone),
        'applicantPersonalName': null,
        'applicantCompanyName': null,
      },
      'amount': CurrencyFormatter.toRawNumber(calculatedPremium.amount),
      'premium': CurrencyFormatter.toRawNumber(calculatedPremium.premium),
    };
  }
  getBondClassificationRia() {
    return this.httpClient.get(API_URL.BOND_CLASSIFICATION_RIA);
  }

  serializePhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/[^\d]/g, '') : phoneNumber;
  }

  get bondPremiumForGTM(): Number {
    return this._bondPremiumForGTM;
  }

  set bondPremiumForGTM(premium: Number) {
    this._bondPremiumForGTM = premium;
  }
}
