import { JsonObject, JsonProperty } from 'json2typescript';
import { Auditable, AuditableObject } from '../../common/auditable-object';

export interface QuestionSummary extends Auditable {
  id: number;
  displayOrder: number;
  labelName: string;
  name: string;
  question: string;
  type: string;
  required: boolean;
}

@JsonObject('QuestionSummaryImpl')
export class QuestionSummaryImpl extends AuditableObject implements QuestionSummary {
  @JsonProperty('displayOrder', Number, true)
  displayOrder: number = null;

  @JsonProperty('labelName', String, true)
  labelName: string = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('question', String, true)
  question: string = null;

  @JsonProperty('type', String, true)
  type: string = null;

  @JsonProperty('required', Boolean, true)
  required: boolean = null;
}
