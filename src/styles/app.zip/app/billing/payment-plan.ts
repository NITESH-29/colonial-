import { AuditableObject } from '../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../common/utils/date-converter';

@JsonObject('PaymentPlan')
export class PaymentPlan extends AuditableObject {

  @JsonProperty('nextPaymentDueDate', DateConverter, true)
  nextPaymentDueDate: Date = null;

  @JsonProperty('paidThroughDate', DateConverter, true)
  paidThroughDate: Date = null;

  @JsonProperty('startDate', DateConverter, true)
  startDate: Date = null;

  @JsonProperty('endDate', DateConverter, true)
  endDate: Date = null;

  @JsonProperty('paymentPlanTypeId', Number, true)
  paymentPlanTypeId: Number = null;

  @JsonProperty('billingProfileId', Number, true)
  billingProfileId: Number = null;

  @JsonProperty('productId', Number, true)
  productId: Number = null;

  @JsonProperty('totalDueAmount', Number, true)
  totalDueAmount: Number = null;

  @JsonProperty('purchaseAmount', Number, true)
  purchaseAmount: Number = null;

  @JsonProperty('surchargeAmount', Number, true)
  surchargeAmount: Number = null;

  @JsonProperty('totalAmount', Number, true)
  totalAmount: Number = null;

  @JsonProperty('totalPaidAmount', Number, true)
  totalPaidAmount: Number = null;

  @JsonProperty('nextPaymentDueAmount', Number, true)
  nextPaymentDueAmount: Number = null;
}
