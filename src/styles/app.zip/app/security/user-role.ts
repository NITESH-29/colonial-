import { JsonObject, JsonProperty } from 'json2typescript';
import { UserRoleRef, UserRoleRefImpl } from './user-role-ref';
import { Auditable, AuditableObject } from '../common/auditable-object';

export interface UserRole extends Auditable {
  id: number;
  userRoleRef: UserRoleRef;
  authority: string;
}

@JsonObject('UserRoleImpl')
export class UserRoleImpl extends AuditableObject implements UserRole {
  @JsonProperty('userRoleRef', UserRoleRefImpl, true)
  userRoleRef: UserRoleRef = new UserRoleRefImpl();

  @JsonProperty('authority', String, true)
  authority: string = null;
}
