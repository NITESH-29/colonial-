import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../common/utils/date-converter';
import { AuditableObject } from '../common/auditable-object';

@JsonObject('ProductSummary')
export class ProductSummary extends AuditableObject {

  @JsonProperty('productNo', String, true)
  productNo: string = null;

  @JsonProperty('productTypeName', String, true)
  productTypeName: string = null;

  @JsonProperty('applicant', String, true)
  applicant: string = null;

  @JsonProperty('fromDate', DateConverter, true)
  fromDate: Date = null;

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('renewed', Boolean, true)
  renewed: boolean = null;

  @JsonProperty('renewal', Boolean, true)
  renewal: boolean = null;

  @JsonProperty('renewable', Boolean, true)
  renewable: boolean = null;

  @JsonProperty('lineOfBusinessName', String, true)
  lineOfBusinessName: string = null;

}
