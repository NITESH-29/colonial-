import { MatSnackBar, MatSnackBarRef } from '@angular/material';
import { ConfirmationSnackBarComponent } from './confirmation-snack-bar/confirmation-snack-bar.component';

export class UserInteraction {

  private _confirmDurationSeconds = 8;
  private _alertDurationSeconds = 5;

  constructor(private _snackBar: MatSnackBar) {
    console.log('UserInteraction constructed');
  }


  public sbConfirm(s: string): MatSnackBarRef<any> {
    return this._snackBar.openFromComponent(ConfirmationSnackBarComponent,
      {
        duration: this._confirmDurationSeconds * 1000,
        data: s,
      });
  }

  public sbAlert(msg: string, action?: string): MatSnackBarRef<any> {
    return this._snackBar.open(msg, action || 'Ok',
      { duration: this._alertDurationSeconds * 1000 });

  }
}
