import { Question } from './question';
import { ChildQuestionMap } from './dynamic-question/child-question-map';


export class DisplayQuestion {
  question: Question;
  childQuestionMap: ChildQuestionMap;

  constructor(question: Question, childQuestionMap: ChildQuestionMap) {
    this.question = question;
    this.childQuestionMap = childQuestionMap;
  }
}
