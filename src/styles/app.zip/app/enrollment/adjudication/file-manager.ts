import { AdjudicationControl } from './adjudication-control';
import { MatSnackBar, MatSnackBarRef } from '@angular/material';
import { ConfirmationSnackBarComponent } from './confirmation-snack-bar/confirmation-snack-bar.component';
import { AdjudicationFile } from './adjudication-file';
import { FormControl } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';
import { AdjudicationFileUploadComponent } from './adjudication-file-upload/adjudication-file-upload.component';
import { SecurityService } from '../../security/security.service';

export class FileManager extends AdjudicationControl {
  private _confirmDurationSeconds = 8;
  private _alertDurationSeconds = 5;

  constructor(
    securityService: SecurityService,
    protected _snackBar: MatSnackBar) {
    super(securityService);
  }

  sbConfirm(s: string): MatSnackBarRef<any> {
    return this._snackBar.openFromComponent(ConfirmationSnackBarComponent,
      {
        duration: this._confirmDurationSeconds * 1000,
        data: s,
      });
  }

  sbAlert(msg: string, action?: string): void {
    this._snackBar.open(msg, action || 'Ok',
      { duration: this._alertDurationSeconds * 1000 });

  }

  getControlFor(evp: AdjudicationFile): FormControl {
    const group = this.adjudicationFormGroup;
    const uniqueId = evp.uniqueId;
    if (!group.contains(uniqueId)) {
      group.addControl(uniqueId, new FormControl(evp.verified, null, null));
    }
    return group.get(evp.uniqueId) as FormControl;
  }

  toggleVerificationState(evp: AdjudicationFile) {
    const ctl: FormControl = this.getControlFor(evp);
    ctl.valueChanges.pipe(distinctUntilChanged())
      .subscribe(b => {
        evp.setVerified(b);
      });
  }

  uploadFileFor(evp: AdjudicationFile): void {
    const ref = this._snackBar.openFromComponent(AdjudicationFileUploadComponent,
      { data: evp });
    ref.afterDismissed().subscribe(sbd => {
      if (sbd.dismissedByAction) {
        this.sbAlert('Continuing with upload');
      } else {
        this.sbAlert('Aborting upload');
      }
    });
  }
  viewFileFor(evp: AdjudicationFile): void {
    if (!evp.existingFile) {
      this.sbAlert('Did you know there is no file to view?');
      return;
    }
    console.log(`Viewing file for ${evp}`);
    this.sbAlert(`Pretend ${evp.applicationFile.name} was viewed...`);
  }

  deleteFileFor(evp: AdjudicationFile): void {
    if (!evp.existingFile) {
      this.sbAlert('Did you know there is no file to delete?');
      return;
    }
    this.sbAlert(`Pretend ${evp.applicationFile.name} was deleted...`);
  }
}
