import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { CompanyAndOfficeInformation } from './company-and-office-information';
import { PatternValidators } from '../../common/validators/pattern-validators';
import { AddressFormGroup } from '../../common/address/address-form-group';

type IsRequiredFn = () => boolean;
export type FormGroupOptions<T> = { [P in keyof T]?: IsRequiredFn };
export type CompanyAndOfficeInformationFormGroupOptions = FormGroupOptions<CompanyAndOfficeInformation>;

const defaultCompanyAndOfficeInformationFormGroupOptions = {
  name: () => true,
  title: () => true,
  email: () => true,
  phone: () => true,
  sicCode: () => true,
  address: () => true,
};

export class CompanyAndOfficeInformationFormGroup extends FormGroup {
  constructor(opts: CompanyAndOfficeInformationFormGroupOptions = defaultCompanyAndOfficeInformationFormGroupOptions,
    disableInput: Boolean = false) {
    super({
      id: new FormControl(),
      name: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, opts.name),
      title: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, opts.title),
      website: new FormControl({ value: null, disabled: disableInput }, Validators.maxLength(50)),
      email: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, opts.email,
        [PatternValidators.email(), Validators.maxLength(75)]),
      phone: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, opts.phone,
        [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      fax: new FormControl({ value: null, disabled: disableInput }, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      sicCode: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, opts.sicCode, Validators.maxLength(8)),
      address: new AddressFormGroup(opts.address, disableInput),
    });
  }

  get id(): FormControl {
    return this.get('id') as FormControl;
  }

  get name(): FormControl {
    return this.get('name') as FormControl;
  }

  get title(): FormControl {
    return this.get('title') as FormControl;
  }

  get website(): FormControl {
    return this.get('website') as FormControl;
  }

  get email(): FormControl {
    return this.get('email') as FormControl;
  }

  get phone(): FormControl {
    return this.get('phone') as FormControl;
  }

  get fax(): FormControl {
    return this.get('fax') as FormControl;
  }

  get sicCode(): FormControl {
    return this.get('sicCode') as FormControl;
  }

  get address(): AddressFormGroup {
    return this.get('address') as AddressFormGroup;
  }
}
