import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PasswordOperationResponse, SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { Injectable } from '@angular/core';
import { HandoffEmailForm, HandoffEmailFormImpl } from '../application/handoff-email-form';
import { JsonConvertService } from '../../common/utils/json-convert.service';
import { JsonConvert } from 'json2typescript';
import { Observable } from 'rxjs';

@Injectable()
export class AgentHandoffService {
  private readonly jsonConvert: JsonConvert;
  private requestURL = 'api/application';

  constructor(private http: HttpClient,
    private securityService: SecurityService,
    private serviceHandler: ServiceHandler,
    private jsonConvertService: JsonConvertService) {
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }


  async getEmailContents(id: number): Promise<HandoffEmailForm> {
    const handOffEmail = await this.http.get<HandoffEmailForm>(`${this.requestURL}/hand-off/email/${id}`).toPromise()
      .catch((error) => this.serviceHandler.handleError(error));

    return this.jsonConvert.deserialize(handOffEmail, HandoffEmailFormImpl) as HandoffEmailFormImpl;
  }

  emailApplicantForHandOff(id: number, optionalMessage: string) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    const body = {
      optionalMessage,
    };
    const url = `${this.requestURL}/hand-off/secured/${id}`;
    return this.http.put<PasswordOperationResponse>(url, body, {
      headers: headers,
      observe: 'body',
    });
  }
}
