import { JsonConverter, JsonCustomConvert } from 'json2typescript';
import * as moment_ from 'moment';


@JsonConverter
export class DateStringOnlyConverter implements JsonCustomConvert<Date> {
  moment = moment_;

  deserialize(date: Date): any {
    if (date) {
      return this.moment.parseZone(date).format('MM/DD/YYYY');
    }
    return null;
  }

  serialize(date: any): Date {
    if (date) {
      return this.moment(date).toDate();
    }
    return null;
  }

}
