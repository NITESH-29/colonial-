import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { finalize } from 'rxjs/operators/finalize';
import { LoadingHandlerService } from '../common/utils/loading-handler.service';
import { Router } from '@angular/router';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  private loadingHandler;

  // Inject the "loading" service:
  constructor(loadingHandler: LoadingHandlerService) {
    if (!this.loadingHandler) {
      this.loadingHandler = loadingHandler;
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    // Don't overwrite login auth header
    if (req.url.includes('login')) {
      return next.handle(req);
    } else {
      // Get the auth header from the service.
      // Clone the request to add the new header.
      const authReq = req.clone(
        {
          headers: req.headers
            .append('Cache-Control', 'no-cache')
            .append('Pragma', 'no-cache')
            .append('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT'),
        });

      this.loadingHandler.showLoader();
      // Pass on the cloned request instead of the original request if not "/login".
      return next.handle(authReq).pipe(finalize(() => {
        this.loadingHandler.hideLoader();
      }));
    }
  }


}
