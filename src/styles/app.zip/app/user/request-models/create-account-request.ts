import { AgencyInformation, BusinessInformation } from '../business-information/business-information';
import { AgencyOfficeInformation, BusinessOfficeInformation } from '../business-office-information/business-office-information';
import { PersonalInformation } from '../personal-information/personal-information';
import { UsernamePassword } from '../username-password/username-password-form-group';
import { Person } from '../../common/person';
import { UserFormData } from './user-form-data';
import { PhoneNumberConverter } from '../../common/utils/phone-number-converter';
import { AgentFormData } from './agent-form-data';
import { OfficeType } from '../../common/company-office-summary';
import { AttorneyFormData } from './attorney-form-data';

export interface CreateAccountRequest {
  personalInformation: PersonalInformation;
  usernamePassword: UsernamePassword;
  businessInformation?: BusinessInformation;
  businessOfficeInformation?: BusinessOfficeInformation;
  referralCode?: string;
}

export function convertToAccountCreationRequest(formData: UserFormData): CreateAccountRequest {
  const pnc = new PhoneNumberConverter();
  const { personalInformation, companyAndOfficeInformation, usernamePassword, referralCode } = formData;

  personalInformation.phone = pnc.serialize(personalInformation.phone);
  companyAndOfficeInformation.phone = pnc.serialize(companyAndOfficeInformation.phone);
  companyAndOfficeInformation.fax = pnc.serialize(companyAndOfficeInformation.fax);

  const { name, title, website, phone, fax, email, sicCode, address } = companyAndOfficeInformation;
  const businessInformation = { name };
  const officeType: OfficeType = 'Main';
  const businessOfficeInformation = { name, website, email, phone, fax, sicCode, officeType, address, title };

  return {
    personalInformation: convertPersonalInformation(personalInformation),
    businessInformation,
    businessOfficeInformation,
    usernamePassword,
    referralCode,
  };
}

export interface CreateAgentAccountRequest {
  personalInformation: PersonalInformation;
  usernamePassword: UsernamePassword;
  agencyInformation: AgencyInformation;
  agencyOfficeInformation: AgencyOfficeInformation;
}

export interface CreateIBAccountRequest {
  personalInformation: PersonalInformation;
  usernamePassword: UsernamePassword;
  referralCode?: string;
}

export function convertToAgentAccountCreationRequest(formData: AgentFormData): CreateAgentAccountRequest {
  const pnc = new PhoneNumberConverter();
  const { personalInformation, agencyAndOfficeInformation, usernamePassword } = formData;

  personalInformation.phone = pnc.serialize(personalInformation.phone);
  agencyAndOfficeInformation.phone = pnc.serialize(agencyAndOfficeInformation.phone);
  agencyAndOfficeInformation.fax = pnc.serialize(agencyAndOfficeInformation.fax);

  const { address, einNumber, email, fax, licenseNumber, memberOfNasbp, name, phone, sicCode, website } = agencyAndOfficeInformation;
  const agencyInformation: AgencyInformation = { name, memberOfNasbp, einNumber };

  const officeType: OfficeType = 'Main';
  const title = personalInformation.title;
  const agencyOfficeInformation = { address, website, phone, fax, email, sicCode, licenseNumber, name, officeType, title };

  return {
    personalInformation: convertPersonalInformation(personalInformation),
    agencyInformation,
    agencyOfficeInformation,
    usernamePassword,
  };
}

export interface CreateAttorneyAccountRequest {
  personalInformation: PersonalInformation;
  usernamePassword: UsernamePassword;
  firmInformation: BusinessInformation;
  firmOfficeInformation: BusinessOfficeInformation;
  statesPracticedIn: string[];
}

export function convertToAttorneyAccountCreationRequest(formData: AttorneyFormData): CreateAttorneyAccountRequest {
  const pnc = new PhoneNumberConverter();
  const { personalInformation, firmAndOfficeInformation, usernamePassword, statesPracticedIn } = formData;

  personalInformation.phone = pnc.serialize(personalInformation.phone);
  firmAndOfficeInformation.phone = pnc.serialize(firmAndOfficeInformation.phone);
  firmAndOfficeInformation.fax = pnc.serialize(firmAndOfficeInformation.fax);

  const { address, email, fax, name, phone, sicCode, website } = firmAndOfficeInformation;
  const firmInformation: BusinessInformation = { name };

  const officeType: OfficeType = 'Main';
  const title = personalInformation.title;
  const firmOfficeInformation = { address, website, phone, fax, email, sicCode, name, officeType, title };

  return {
    personalInformation: convertPersonalInformation(personalInformation),
    firmInformation,
    firmOfficeInformation,
    usernamePassword,
    statesPracticedIn,
  };
}

function convertPersonalInformation(person: Person): PersonalInformation {
  const { personAddresses: [{ street1, street2, city, state, zipCode }] } = person;
  const address = { street1, street2, city, state, zipCode };

  const { firstName, initial, lastName, suffix, salutation, phone, email, profession } = person;
  const personalInformation = { firstName, initial, lastName, suffix, salutation, phone, email, profession, address };

  const allAddressFieldsFalsy = !Object.values(address).reduce((a, b) => a || b, null);

  if (allAddressFieldsFalsy) {
    delete personalInformation.address;
  }

  return personalInformation;
}
