import { PaymentChannelType } from './payment_channel_type';
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

/**
 * Enum implemented as class.
 */
@JsonObject('PaymentChannelCode')
export class PaymentChannelCode extends AbstractIdentifierEnum {
  private static _values: Map<string, PaymentChannelCode> = new Map<string, PaymentChannelCode>();
  public static CHECK = new PaymentChannelCode('paper-check', PaymentChannelType.PAPER_CHECK, 'Paper Check', null, null);
  public static VISA = new PaymentChannelCode('visa', PaymentChannelType.CREDIT, 'Visa', 'visa', 3);
  public static MASTER_CARD = new PaymentChannelCode('master-card', PaymentChannelType.CREDIT, 'MasterCard', 'mastercard', 3);
  public static AMEX = new PaymentChannelCode('american-express', PaymentChannelType.CREDIT, 'American Express', 'american-express', 4);
  public static DISCOVER = new PaymentChannelCode('discover', PaymentChannelType.CREDIT, 'Discover', 'discover', 3);
  public static ACH = new PaymentChannelCode('ach', PaymentChannelType.ACH, 'eCheck', null, null);

  get paymentChannelType(): PaymentChannelType {
    return this._paymentChannelType;
  }

  // We don't register defaultDisplayText with JSON->TypeScript lib as we don't need the server's value.
  get defaultDisplayText(): string {
    return this._defaultDisplayText;
  }

  get cardValidatorType(): string | null {
    return this._cardValidatorType;
  }

  get cvvLength(): number | null {
    return this._cvvLength;
  }

  public static valueOf(persistenceId: string | undefined): PaymentChannelCode {
    return PaymentChannelCode._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): PaymentChannelCode[] {
    return Array.from(PaymentChannelCode._values.values());
  }

  private constructor(
    persistenceId: string, // Relates the PaymentChannelCode with server representation.
    private _paymentChannelType: PaymentChannelType,
    private _defaultDisplayText: string,
    private _cardValidatorType: string | null, // The type of creditCard as known to the card validator (if a credit card).
    private _cvvLength: number | null // The number of digits in the CVV (if a credit card).
  ) {
    super(persistenceId);
  }

  protected registerEnum(): void {
    if (PaymentChannelCode._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid PaymentChannelCode 'enum' identifier: ${this.persistenceId}`);
    }
    PaymentChannelCode._values.set(this.persistenceId, this);
  }

  public isElectronic(): boolean {
    return this._paymentChannelType.isElectronic;
  }

  public isCreditCard(): boolean {
    return this._paymentChannelType === PaymentChannelType.CREDIT;
  }

  public isACH(): boolean {
    return this._paymentChannelType === PaymentChannelType.ACH;
  }

  public isPaperCheck(): boolean {
    return this._paymentChannelType === PaymentChannelType.PAPER_CHECK;
  }
}

@JsonConverter
export class PaymentChannelCodeConverter extends AbstractIdentifierEnumConverter<PaymentChannelCode> {
  deserialize(enumObject: any): PaymentChannelCode {
    let enumInstance: PaymentChannelCode;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = PaymentChannelCode.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}
