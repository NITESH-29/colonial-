export const environment = {
  production: true,
  downloadURI: 'quote/api/file/content/',
  showConsoleLogs: false,
  insuranceShowProductList: ['pnl', 'cyber', 'epli', 'gl'],
};
