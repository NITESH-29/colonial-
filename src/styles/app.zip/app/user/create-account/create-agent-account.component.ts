import { AccountCreator, AccountService } from '../account.service';
import { Component } from '@angular/core';
import { CreateAccountComponent } from './create-account.component';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../security/security.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { AgencyAndOfficeInformationFormGroup } from '../agency-and-office-information/agency-and-office-information-form-group';
import { FormGroup } from '@angular/forms';
import { UsernamePasswordFormGroup } from '../username-password/username-password-form-group';
import { BusinessOfficePersonInformationFormGroup } from '../business-office-person-information/business-office-person-information-form-group';
import { convertToAgentAccountCreationRequest, CreateAgentAccountRequest } from '../request-models/create-account-request';

@Component({
  selector: 'app-create-agent-component',
  templateUrl: './create-agent-account.component.html',
})
export class CreateAgentAccountComponent extends CreateAccountComponent {
  constructor(
    accountService: AccountService,
    securityService: SecurityService,
    serviceHandler: ServiceHandler,
    router: Router,
    activatedRoute: ActivatedRoute,
    location: Location
  ) {
    super(accountService, securityService, serviceHandler, router, activatedRoute, location);
  }

  protected accountCreationFunction(): AccountCreator {
    return this.accountService.createAgentAccount;
  }

  protected configureFormGroup(): void {
    this.formGroup = new FormGroup({
      personalInformation: new BusinessOfficePersonInformationFormGroup({
        isRequired: true,
        includeEmail: true,
        includePhone: true,
        includeAddress: false,
        includeProfession: false,
        includeTitle: true,
        isTitleRequired: true,
      }),
      agencyAndOfficeInformation: new AgencyAndOfficeInformationFormGroup(),
      usernamePassword: new UsernamePasswordFormGroup(),
    });

    // Insurance Agents, Brokers, and Service
    this.formGroup.patchValue({ agencyAndOfficeInformation: { sicCode: '6411' } });
  }

  get personalInformation(): BusinessOfficePersonInformationFormGroup {
    return this.formGroup.get('personalInformation') as BusinessOfficePersonInformationFormGroup;
  }

  get agencyAndOfficeInformation(): AgencyAndOfficeInformationFormGroup {
    return this.formGroup.get('agencyAndOfficeInformation') as AgencyAndOfficeInformationFormGroup;
  }

  protected prepareAccountCreationRequest(rawValue: any): CreateAgentAccountRequest {
    return convertToAgentAccountCreationRequest(rawValue);
  }
}
