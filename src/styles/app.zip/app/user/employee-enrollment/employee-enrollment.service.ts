import { Injectable } from '@angular/core';
import { JsonConvert } from 'json2typescript';
import { HttpClient } from '@angular/common/http';
import { UtilService } from '../../common/utils/util.service';


@Injectable()
export class EmployeeEnrollmentService {
  requestUrl = '/api/admin/employee-enrollment';
  private jsonConvert: JsonConvert;

  constructor(private http: HttpClient) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async createEmployeeUser(token: string, username: string, password: string, employeeId: string) {
    await this.http.post(this.requestUrl, {
      token: token,
      username: username,
      password: password,
      employeeId: +employeeId,
    }).toPromise();
  }
}
