import { Injectable } from '@angular/core';
import { CurrencyFormatter } from '../../common/utils/currency-formatter';
import { ClientData, convertCompanyOfficeOrPersonClientToClientData } from '../../user/client/client-data';
import { Application } from '../application/application';
import { ClientImpl } from '../../common/client';
import { PersonImpl } from '../../common/person';
import { ApplicationDetails, EnrollmentFacilitationService } from './enrollment-facilitation-service';
import { CourtBondType } from '../application/common/bond-types';
import { AnonymousQuote } from '../application/anonymous-quote';

/**
 * This class tracks the set of minimum information required to create a Court Bond Application. We need to know:
 *  - The Bond Type
 *  - The Bond Amount
 *  - The Bond Premium
 *  - The Bond Applicant - who is the bond for?
 *
 * The reasonable expectation is that every field exposed on the CourtBondApplicationDetails class,
 * should have a corresponding setter in the CourtBondFacilitationService.
 *
 * Every property on the class should be initialized to a default value, representing the "unknown" state - for most
 * situations, <code>undefined</code> should suffice.
 *
 * @see ApplicationDetails
 */
export class CourtBondApplicationDetails implements Partial<ApplicationDetails> {
  type?: CourtBondType = undefined;
  amount?: string = undefined;
  premium?: string = undefined;
  applicant?: ClientData = undefined;
  anonymousQuote?: AnonymousQuote = undefined;
  quoteId?: number = undefined;
}

/**
 * This service maintains a private static reference to a CourtBondApplicationDetails object. The applicationDetails
 * object begins with all of its fields set to <code>undefined</code> to represent that no court bond enrollment is
 * currently in progress.
 *
 * We assume that there is one or more places at which an enrollment can begin. As soon as one of the details required
 * for creating an application is known, your code should call the appropriate setter
 * on the CourtBondFacilitationService. You should inject the service wherever one or more of the
 * CourtBondApplicationDetails data can be set.
 *
 * We also assume that an enrollment is currently in progress when at least one of the CourtBondApplicationDetails
 * fields is no longer set to <code>undefined</code>.
 *
 * Finally, we assume that once all of the required details have been collected, that you either call the
 * resetApplicationDetails() method directly, if you're feeling so bold, or call the applicationCreated method, passing
 * an instance of the created application for comparison against the details the service has collected so far. If they
 * match, the method will reset the application details for you.
 *
 * @see EnrollmentFacilitationService
 */
@Injectable({ providedIn: 'root' })
export class CourtBondFacilitationService implements EnrollmentFacilitationService<Application, CourtBondApplicationDetails> {
  private applicationDetails: CourtBondApplicationDetails;
  private _isAlredyExistUser = false;
  private _alredyExistUserBondAmount: number;
  constructor() {
    this.applicationDetails = new CourtBondApplicationDetails();
  }

  setBondType(bondType: CourtBondType): void {
    this.applicationDetails.type = bondType;
  }

  setAmount(amount: string): void {
    const raw = CurrencyFormatter.toRawNumber(amount);
    if (raw) { this.applicationDetails.amount = raw.toString(); }
  }

  setQuoteId(quoteId: number): void {
    if (quoteId) { this.applicationDetails.quoteId = quoteId; }
  }

  getQuoteId(): number {
    return this.applicationDetails.quoteId;
  }

  setPremiumRateId(premiumRateId: number) {
    if (premiumRateId) { this.applicationDetails.anonymousQuote.premiumRateId = premiumRateId; }
  }

  getPremiumRateId(): number {
    return this.applicationDetails.anonymousQuote.premiumRateId;
  }

  setPremium(premium: number): void {
    const raw = CurrencyFormatter.toRawNumber(premium);
    if (raw) { this.applicationDetails.premium = raw.toString(); }
  }

  setApplicant(applicant: ClientData): void {
    if (applicant) { this.applicationDetails.applicant = applicant; }
  }

  setAnonymousQuote(anonymousQuote: AnonymousQuote) {
    this.applicationDetails.anonymousQuote = anonymousQuote;
  }

  getAnonymousQuote(): AnonymousQuote {
    return this.applicationDetails.anonymousQuote;
  }

  getApplicationDetails(): CourtBondApplicationDetails {
    return this.applicationDetails;
  }

  isEnrollmentInProgress(): boolean {
    // At least one field is not undefined
    return (Object.values(this.applicationDetails).reduce((a, b) => a || b) !== undefined) &&
      (Object.values(this.applicationDetails).reduce((a, b) => a || b) !== null);
  }

  resetApplicationDetails(): void {
    this.applicationDetails = new CourtBondApplicationDetails();
  }

  applicationCreated(application: Application): void {
    const { type, amount, premium, applicant: { uniqueId } } = this.getApplicationDetails();
    const createdDetails = applicationDetailsOf(application);

    const detailsMatch =
      type === createdDetails.type &&
      amount === createdDetails.amount &&
      premium === createdDetails.premium &&
      uniqueId === createdDetails.applicant.uniqueId;

    if (detailsMatch) {
      this.resetApplicationDetails();
    }
  }
  get isAlredyExistUser() {
    return this._isAlredyExistUser;
  }
  set isAlredyExistUser(value) {
    this._isAlredyExistUser = value;
  }
  get alredyExistUserBondAmount() {
    return this._alredyExistUserBondAmount;
  }
  set alredyExistUserBondAmount(value) {
    this._alredyExistUserBondAmount = value;
  }
}

function applicationDetailsOf(application: Application): CourtBondApplicationDetails {
  const details = new CourtBondApplicationDetails();
  details.type = application.data.bondClassification as CourtBondType;
  details.amount = application.amount.toString();
  details.premium = application.premium.toString();

  const client = new ClientImpl();
  client.person = application.person as PersonImpl;
  client.companyOffice = application.companyOffice;

  details.applicant = convertCompanyOfficeOrPersonClientToClientData(client);
  return details;
}
