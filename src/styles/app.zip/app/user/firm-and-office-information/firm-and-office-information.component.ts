import { Component, Input } from '@angular/core';
import { FirmAndOfficeInformationFormGroup } from './firm-and-office-information-form-group';

@Component({
  selector: 'app-firm-and-office-information',
  templateUrl: './firm-and-office-information.component.html',
})
export class FirmAndOfficeInformationComponent {
  @Input() formGroup: FirmAndOfficeInformationFormGroup;
}
