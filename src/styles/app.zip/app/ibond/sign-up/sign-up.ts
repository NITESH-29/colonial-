import { OfficeType } from 'src/app/common/company-office-summary';

export interface ISignUpIndividual {
  personalInformation: IPersonalInformationIndividual;
  usernamePassword: IUsernamePassword;
  referralCode?: string;
}

export interface ISignUpCompany {
  personalInformation: IPersonalInformationCompany;
  businessInformation: IBusinessInformation;
  businessOfficeInformation: IBusinessOfficeInformation;
  usernamePassword: IUsernamePassword;
  referralCode?: string;
}

export interface IBusinessInformation {
  name: string;
}

export interface IBusinessOfficeInformation {
  name: string;
  website?: string;
  email: string;
  phone: string;
  fax?: any;
  sicCode?: string;
  officeType?: OfficeType;
  address: IBusinessOfficeAddress | null;
  title?: string;
}

export interface IBusinessOfficeAddress {
  id?: null;
  createdBy?: null;
  createdAt?: null;
  updatedBy?: null;
  updatedAt?: null;
  fromDate?: null;
  toDate?: null;
  street1: string;
  street2?: string;
  city: string;
  state: string;
  zipCode: string;
  countyName?: string;
}
export interface IPersonalInformationIndividual {
  firstName: string;
  initial?: string;
  lastName: string;
  suffix?: string;
  salutation: string;
  phone: string;
  email: string;
  profession?: string;
  address: IAddressIndividual | null;
}

export interface IPersonalInformationCompany {
  firstName: string;
  initial?: string;
  lastName: string;
  suffix?: string;
  salutation: string;
  phone: string;
  email: string;
  profession?: string;
  address: null;
}
export interface IAddressIndividual {
  street1: string;
  street2?: string;
  city: string;
  state: string;
  zipCode: string;
}

export interface IUsernamePassword {
  username: string;
  password: string;
  confirmPassword: string;
  referralCode?: string;
}
