import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from '../security.service';
import { Router, NavigationExtras } from '@angular/router';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { UserImpl } from 'src/app/security/user';
import { Subscription } from 'rxjs';
import { RequestService } from '../../ibond/service/request.service';
import { IbondBaseService } from '../../ibond/service/ibond-base.service';
import { StringConstants } from '../../insurance/constants/string-constants';
import { StateService } from 'src/app/insurance/services/state.service';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { ProductConfigPipe } from 'src/app/insurance/pipe/product-config.pipe';
import { ProductConfigService } from 'src/app/insurance/services/product-config.service';

@Component({
  selector: 'app-login-popup',
  templateUrl: './login-popup.component.html',
  styleUrls: ['./login-popup.component.scss'],
  providers: [ProductConfigPipe],
})
export class LoginPopupComponent implements OnInit {
  hide = true;
  loginForm: FormGroup;
  errorMessage: string;
  redirectUrl;
  user: UserImpl = null;
  loggedIn: boolean;
  loggedIn$: Subscription;
  constructor(
    public dialogRef: MatDialogRef<LoginPopupComponent>,
    public fb: FormBuilder,
    private securityService: SecurityService,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private gtmService: GoogleTagManagerService,
    public requestService: RequestService,
    public baseService: IbondBaseService,
    public stringConstant: StringConstants,
    public stateService: StateService,
    private _snackBar: MatSnackBar,
    public productConfigPipe: ProductConfigPipe,
    public productConfig: ProductConfigService
  ) {
  }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: this.fb.control('', [Validators.required]),
      password: this.fb.control('', [Validators.required]),
    });
    if (this.data['url']) {
      this.redirectUrl = this.data['url'];
    }
    this.errorMessage = null;
    this.securityService.loggedIn$.subscribe(
      loggedIn$ => {
        this.loggedIn = loggedIn$;
        if (this.loggedIn) {
          this.user = this.securityService.user;
        }

      }
    );
    console.log('security create user insurance stateService -->', this.stateService);
  }

  close(): void {
    this.dialogRef.close();
  }
  onSignin(): void {
    if (this.loginForm.valid) {
      this.securityService.login(this.loginForm.value.username, this.loginForm.value.password).then((loginData) => {
        const returnData = {
          response: loginData,
          page: this.data,
        };
        const localData = JSON.parse(localStorage.getItem('temp_application'));
        const quoteId = localStorage.getItem('quote_id');
        const gtmBondType = localData ? this.requestService.setBondType(localData['data'].bondClassification) : '';
        const classification = localData.data.classificationName ? localData.data.classificationName : '';
        setTimeout(() => {
          if (localData) {
            this.registerUserGtmEvent('bond-app-login', gtmBondType, localData['data'].premium,
              (this.user.hasAttorneyRole ? 'attorney' : 'individual'), classification, classification, quoteId, 'new', ''
            );
          }
        }, 2000);
        this.baseService.setSignUpValue(false);

        // This is insurance code to handle prepoulated user details when user logged in using header login button
        if (!UtilMethodsService.isEmpty(returnData.response.person)) {
          if (this.productConfigPipe.transform(this.productConfig.LOGIN_INSURANCE_ALLOW_PRODUCT)) {
            // if anonyous user login using exsting account and user uses agent credential to login then
            // show error msg to user saying log in as non insurance agent
            if (this.securityService && this.securityService.user.hasAgentRole) {
              this.securityService.deleteCookie();
              this.securityService._loggedIn$.next(false);
              this._snackBar.open(this.stringConstant.CLIENT_LOGIN_AS_AGENT, 'X', {
                duration: 5000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
                panelClass: 'red-snackbar',
              });
              this.dialogRef.close();
              return;
            }

            const navigationExtras: NavigationExtras = {
              queryParams: {
                isAnonymousUser: true,
                bondClassification: this.stateService.insuranceDetails.questionAnswers['bondClassification'],
              },
            };
            this.router.navigate(['/insurance/evaluator'], navigationExtras);
            // if user don't fill any of details on get-quote page n login using header login button then just load application
            // no need to show error msg
            // if user fill any of detaills on get-quote then only clear out values n show error msg
            if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['firstName'])
              || !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['lastName'])
              || !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['applicantPhone'])
              || !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['applicantEmail'])
              || !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['state'])
              || !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['profession'])) {
              this._snackBar.open(this.stringConstant.APPLICATION_NOT_SAVED, 'X', {
                duration: 5000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
                panelClass: 'red-snackbar',
              });
            }
          }
        }
        this.dialogRef.close(returnData);
        if (this.redirectUrl) {
          this.router.navigate([this.redirectUrl]);
        }
      })
        .catch((error) => {
          if (![401, 403].includes(error.status)) {
            this.errorMessage = 'Unexpected Server Error. Please try again later.';
          } else {
            this.errorMessage = 'Invalid Username and Password';
          }
        });
    }
  }
  createAccount() {
    const localData = JSON.parse(localStorage.getItem('temp_application'));
    let gtmBondType: string;
    const checkBondType = localData ? localData['data'].bondClassification : '';
    if (checkBondType === 'landp') {
      gtmBondType = 'license and permit';
    } else if (checkBondType === 'lost_car_title') {
      gtmBondType = 'lost car';
    } else if (checkBondType === 'vafiduciary') {
      gtmBondType = 'va fiduciary';
    } else {
      gtmBondType = checkBondType;
    }
    const quoteId = localStorage.getItem('quote_id');
    this.dialogRef.close();
    this.registerUserGtmEvent('bond-app-register', gtmBondType,
      localData ? localData['data'].premium : '',
      this.user && this.user.userRoles ? (this.user.hasAttorneyRole ? 'attorney' : 'individual') : 'anonymous', 'ipGroup', 'ipGroup',
      quoteId, 'new', ''
    );
    if (this.redirectUrl) {
      this.router.navigate([`/user/create-client`], { state: { redirectUrl: this.redirectUrl } });
    } else {
      this.router.navigate([`/user/create-client`]);
    }
  }
  forgotPassword() {
    this.dialogRef.close();
    this.router.navigate([`/secure/forgot-password`]);
  }
  registerUserGtmEvent(event, bondType, bondPremium, userType, lpGroup, lpBond, quoteId, bondClass?, applicationID?) {
    this.gtmService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }
}
