import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserImpl } from './user';
import { ServiceHandler } from '../common/utils/service-handler.service';
import { SecurityService } from './security.service';
import { AbstractService } from '../common/services/abstract-service';
import { JsonConvertService } from '../common/utils/json-convert.service';
import { JsonConvert } from 'json2typescript';
import { HttpOptions } from '../common/http-options';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class UserService extends AbstractService {
  options: HttpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    observe: 'body',
  };

  private readonly jsonConvert: JsonConvert;

  constructor(
    private http: HttpClient,
    private serviceHandler: ServiceHandler,
    private securityService: SecurityService,
    jsonConvertService: JsonConvertService) {
    super();
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  async createUser(user: UserImpl): Promise<UserImpl> {
    const json = this.jsonConvert.serialize(user);
    const url = this.requestURL('/user');

    const createdUser = await this.http.post<UserImpl>(url, json, this.options).toPromise();
    this.serviceHandler.handleConfirm('Profile Created');

    return this.jsonConvert.deserialize(createdUser, UserImpl) as UserImpl;
  }

  async updateUser(user: UserImpl): Promise<UserImpl> {
    const json = this.jsonConvert.serialize(user);
    delete json['password'];

    const url = this.requestURL(`/user/${user.id}`);

    await this.http.put<UserImpl>(url, json, this.options).toPromise();
    this.serviceHandler.handleConfirm('Profile Updated');

    return await this.securityService.refreshCurrentUser().toPromise();
  }

  getUserByPersonId(personId: number): Promise<UserImpl> {
    return this.getUserByPersonIdAsObservable(personId).toPromise();
  }

  getUserByPersonIdAsObservable(personId: number): Observable<UserImpl> {
    const url = this.requestURL(`/user/person/${personId}`);
    return this.http.get<UserImpl>(url).pipe(
      map(r => this.jsonConvert.deserializeObject(r, UserImpl))
    );
  }
}
