import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TableDefaultDetails } from '../../form-components/generic-table-search/table-default-details';

@Component({
  selector: 'app-application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.scss'],
})
export class ApplicationListComponent implements OnInit {

  tableDefaultDetails: TableDefaultDetails;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    const status = this.route.snapshot.paramMap.get('status');
    if (status) {
      this.tableDefaultDetails = {
        defaultStatus: this.convertStatus(status),
        bondClassification: 'Court', // default to court cause it's the only one for now
      };
    } else {
      this.tableDefaultDetails = {
        defaultStatus: 'All',
        bondClassification: 'Court', // default to court cause it's the only one for now
      };
    }
  }

  convertStatus(statusParam: string): string {
    let defaultStatus;
    switch (statusParam) {
      case 'in-progress':
        defaultStatus = 'In Progress';
        break;
      case 'pending':
        defaultStatus = 'Submitted';
        break;
      case 'awaiting-payment':
        defaultStatus = 'Awaiting Payment';
        break;
      case 'hold':
        defaultStatus = 'Hold';
        break;
      case 'soft-hold':
        defaultStatus = 'Soft Hold';
        break;
      case 'pending-underwriting-review':
        defaultStatus = 'Hold,Submitted';
        break;
      case 'declined':
        defaultStatus = 'Declined';
        break;
      default:
        defaultStatus = 'All';
        break;
    }
    return defaultStatus;
  }

}
