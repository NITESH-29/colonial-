import { UserImpl } from '../../security/user';

export class AdjudicationDecision {
  adjudicatedBy: UserImpl = null;
  adjudicationDate: Date = null;
  status: string = null;
}
