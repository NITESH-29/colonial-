import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { AddressFormGroup } from '../../common/address/address-form-group';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { PatternValidators } from '../../common/validators/pattern-validators';
import { Person, PersonImpl } from '../../common/person';
import { PersonAddressImpl } from '../../common/person-address';

export class PersonalInformationFormGroup extends FormGroup {

  options: PersonalInformationFormGroupOptions;

  constructor(options?: PersonalInformationFormGroupOptions, disableInput: boolean = false) {
    options = checkNullsAndSetDefaults(options);
    const condition = () => options.isRequired;
    const controls: { [p: string]: AbstractControl } = {
      firstName: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, condition, Validators.maxLength(20)),
      lastName: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, condition, Validators.maxLength(30)),
    };
    if (options.includeInitial) {
      controls['initial'] = new FormControl({ value: null, disabled: disableInput }, Validators.maxLength(1));
    }
    if (options.includeSuffix) {
      controls['suffix'] = new FormControl({ value: null, disabled: disableInput }, Validators.maxLength(15));
    }
    if (options.includeSalutation) {
      controls['salutation'] = new FormControl({ value: null, disabled: disableInput }, Validators.maxLength(5));
    }
    if (options.includePhone) {
      controls['phone'] = new ConditionalRequireFormControl({ value: null, disabled: disableInput }, condition,
        [PatternValidators.phoneNumber(), Validators.maxLength(15)]);
    }
    if (options.includeEmail) {
      controls['email'] = new ConditionalRequireFormControl({ value: null, disabled: disableInput }, condition,
        [PatternValidators.email(), Validators.maxLength(75)]);
    }
    if (options.includeProfession) {
      controls['profession'] =
        new FormControl({ value: null, disabled: disableInput }, Validators.maxLength(255));
    }
    if (options.includeAddress) {
      controls['address'] = new AddressFormGroup(condition, disableInput);
    }
    super(controls);
    this.options = options;
  }

  // comment is so it won't complain about incompatible override.
  // noinspection JSAnnotator
  patchValue(value: Partial<Person>): void {
    super.patchValue({
      firstName: value.firstName,
      initial: value.initial,
      lastName: value.lastName,
      suffix: value.suffix,
      salutation: value.salutation,
      phone: value.phone,
      email: value.email,
      profession: value.profession,
    });
    if (value.personAddresses && value.personAddresses.length > 0 && this.address) {
      this.address.patchValue(value.personAddresses[0]);
    }
  }

  getRawValue(): Person {
    const person: PersonImpl = new PersonImpl();
    person.firstName = this.firstName.value;
    person.lastName = this.lastName.value;
    if (this.options.includeInitial) {
      person.initial = this.initial.value;
    }
    if (this.options.includeSuffix) {
      person.suffix = this.suffix.value;
    }
    if (this.options.includeSalutation) {
      person.salutation = this.salutation.value;
    }
    if (this.options.includePhone) {
      person.phone = this.phone.value;
    }
    if (this.options.includeEmail) {
      person.email = this.email.value;
    }
    if (this.options.includeProfession) {
      person.profession = this.profession && this.profession.value;
    }
    if (this.options.includeAddress) {
      person.personAddresses[0] = this.address && this.address.getRawValue() as PersonAddressImpl;
    }
    return person;
  }

  get firstName(): FormControl {
    return this.get('firstName') as FormControl;
  }

  get initial(): FormControl | undefined {
    return this.get('initial') as FormControl;
  }

  get lastName(): FormControl {
    return this.get('lastName') as FormControl;
  }

  get suffix(): FormControl | undefined {
    return this.get('suffix') as FormControl;
  }

  get salutation(): FormControl | undefined {
    return this.get('salutation') as FormControl;
  }

  get phone(): FormControl | undefined {
    return this.get('phone') as FormControl;
  }

  get email(): FormControl | undefined {
    return this.get('email') as FormControl;
  }

  get profession(): FormControl | undefined {
    return this.get('profession') as FormControl;
  }

  get address(): AddressFormGroup | undefined {
    return this.get('address') as AddressFormGroup;
  }
}

function checkNullsAndSetDefaults(options?: PersonalInformationFormGroupOptions): PersonalInformationFormGroupOptions {
  if (options === null || options === undefined) {
    options = {} as PersonalInformationFormGroupOptions;
  }
  setIfNullOrUndefined(options, 'isRequired', false);
  setIfNullOrUndefined(options, 'includeEmail', false);
  setIfNullOrUndefined(options, 'includePhone', false);
  setIfNullOrUndefined(options, 'includeAddress', false);
  setIfNullOrUndefined(options, 'includeProfession', false);
  setIfNullOrUndefined(options, 'includeSalutation', true);
  setIfNullOrUndefined(options, 'includeSuffix', true);
  setIfNullOrUndefined(options, 'includeInitial', true);
  return options;
}

function setIfNullOrUndefined(options: PersonalInformationFormGroupOptions, key: string, defaultValue: boolean): void {
  if (options[key] === null || options[key] === undefined) {
    options[key] = defaultValue;
  }
}

export interface PersonalInformationFormGroupOptions {
  isRequired?: boolean;
  includeEmail?: boolean;
  includePhone?: boolean;
  includeAddress?: boolean;
  includeProfession?: boolean;
  includeSalutation?: boolean;
  includeSuffix?: boolean;
  includeInitial?: boolean;
}



