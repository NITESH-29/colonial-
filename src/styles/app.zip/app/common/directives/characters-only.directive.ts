import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appCharacterOnly]',
})
export class CharactersOnlyDirective {
  allowedCharactersRegex = new RegExp('[a-zA-Z ]');
  allowedSpecialCharacter = ['\''];
  allowedActions = ['ArrowRight', 'ArrowLeft', 'Backspace', 'Tab'];

  @HostListener('keydown', ['$event'])
  public onKeyDown(event) {
    const key = event.key;
    if (!(this.allowedCharactersRegex.test(key) || this.allowedSpecialCharacter.includes(key) || this.allowedActions.includes(key))) {
      return false;
    }
  }
}
