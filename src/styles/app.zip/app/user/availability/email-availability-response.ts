export interface EmailAvailabilityResponse {
  email: string;
  available: boolean;
}
