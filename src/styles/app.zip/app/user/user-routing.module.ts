import { RouterModule, Routes } from '@angular/router';
import { AccountTypeSelectionComponent } from './account-type-selection/account-type-selection.component';
import { NgModule } from '@angular/core';
import { CreateClientAccountComponent } from './create-account/create-client-account.component';
import { CreateAttorneyAccountComponent } from './create-account/create-attorney-account.component';
import { CreateAgentAccountComponent } from './create-account/create-agent-account.component';
import { ProfileComponent } from './profile/profile.component';
import { AuthGuard } from '../security/app.auth.guard';
import { PersonCompanyResolver } from './providers/person-company.resolver';
import { AddEditClientComponent } from './client/add-edit-client/add-edit-client.component';
import { InitialPasswordComponent } from './initial-password/initial-password.component';
import { AdminGuard } from './role-guard/admin.guard';
import { EmployeeEnrollmentComponent } from './employee-enrollment/employee-enrollment.component';
import { ClientsComponent } from './client/clients/clients.component';
import { BillingProfileComponent } from './profile/billing-profile/billing-profile.component';
import { BusinessWithSingleOfficeComponent } from './business-with-single-office/business-with-single-office.component';
import { EmployeeDefaultGuard } from './role-guard/employee-default.guard';
import { ViewClientComponent } from './client/view-client/view-client.component';
import { PaymentComponent } from './payment/payment.component';

const routes: Routes = [
  { path: 'admin', loadChildren: './admin/admin.module#AdminModule', canActivate: [AuthGuard, AdminGuard] },
  { path: 'account-type', component: AccountTypeSelectionComponent },
  { path: 'create-agent', component: CreateAgentAccountComponent },
  // { path: 'create-attorney', component: CreateAttorneyAccountComponent },
  // { path: 'create-client', component: CreateClientAccountComponent },
  // { path: 'create-agent', redirectTo: '/ibond/create-user', pathMatch: 'full' },
  { path: 'create-attorney', redirectTo: '/ibond/create-user?type=attorney', pathMatch: 'full' },
  { path: 'create-client', redirectTo: '/ibond/create-user?type=client', pathMatch: 'full' },
  { path: 'my-profile', component: ProfileComponent, canActivate: [AuthGuard] },
  { path: 'company', component: BusinessWithSingleOfficeComponent, canActivate: [AuthGuard] },
  {
    path: 'company/:id',
    component: BusinessWithSingleOfficeComponent,
    resolve: { business: PersonCompanyResolver },
    canActivate: [AuthGuard],
  },
  { path: 'clients', component: ClientsComponent, canActivate: [AuthGuard] },
  { path: 'add-client', component: AddEditClientComponent, canActivate: [AuthGuard] },
  { path: 'edit-client/:clientType/:id', component: AddEditClientComponent, canActivate: [AuthGuard] },
  { path: 'view-client/:clientType/:id', component: ViewClientComponent, canActivate: [EmployeeDefaultGuard] },
  { path: 'initial-password/:bondType/:id', component: InitialPasswordComponent },
  { path: 'employee-enrollment/:id', component: EmployeeEnrollmentComponent },
  { path: 'billing/:personId/:billingProfileId', component: BillingProfileComponent },
  { path: 'payment-information', component: PaymentComponent, canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserRoutingModule { }
