import { paymentTypes } from './constants';
import { PaymentTypeUtils } from './payment-type-utils';

describe('PaymentTypeUtils', () => {
  const prettyNames = [], codes = [], codesByPrettyName = {}, prettyNamesByCode = {};

  paymentTypes.forEach(pt => {
    codesByPrettyName[pt.pretty] = pt.code;
    prettyNamesByCode[pt.code] = pt.pretty;
    prettyNames.push(pt.pretty);
    codes.push(pt.code);
  });

  describe('::getCodeFromPrettyName', () => {
    prettyNames.forEach(prettyName => {
      const code = codesByPrettyName[prettyName];
      it(`should return ${code} for ${prettyName}`, () => {
        expect(PaymentTypeUtils.getCodeFromPrettyName(prettyName)).toEqual(code);
      });
    });

    it('should return null for a non-pretty-name string', () => {
      expect(PaymentTypeUtils.getCodeFromPrettyName('foobar')).toEqual(null);
    });
  });

  describe('::getPrettyNameFromCode', () => {
    codes.forEach(code => {
      const prettyName = prettyNamesByCode[code];
      it(`should return ${prettyName} for ${code}`, () => {
        expect(PaymentTypeUtils.getPrettyNameFromCode(code)).toEqual(prettyName);
      });
    });

    it('should return null for a non-code string', () => {
      expect(PaymentTypeUtils.getPrettyNameFromCode('bazqux')).toEqual(null);
    });
  });
});
