import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { SecurityService } from '../security.service';
import { ValueMatchValidator } from '../../common/validators/value-match-validator';
import { Validators } from '@angular/forms';
import { AlertService } from '../../common/alert.service';
import { PatternValidators } from '../../common/validators/pattern-validators';

@Component({
  selector: 'app-change-password',
  providers: [AlertService],
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
})

export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  submitted = false;
  token: string;

  constructor(public fb: FormBuilder,
    private router: Router,
    private snackbar: MatSnackBar,
    private securityService: SecurityService) {
  }

  ngOnInit() {

    this.changePasswordForm = this.fb.group(
      {
        password: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(62), PatternValidators.alphanumeric()]],
        passwordConfirm: ['', [Validators.required, Validators.minLength(10)]],
      },
      {
        validator: ValueMatchValidator.matchingValues('password', 'passwordConfirm'),
      }
    );
  }

  changePassword() {
    const userName = this.securityService.user.username;
    const { password, passwordConfirm } = this.changePasswordForm.value;
    this.submitted = true;
    this.securityService.changePassword(userName, password, passwordConfirm)
      .subscribe((response) => {
        this.submitted = false;
        if (response) {
          // todo route to homepage
          this.router.navigate(['/user/my-profile']);
          this.snackbar.open('Your password has been changed.', null, {
            duration: 6000,
          });
        } else {
          this.snackbar.open('Sorry, the information you provided could not be verified', null, {
            duration: 6000,
            panelClass: ['alert_snack_bar'],
          });
        }
        this.changePasswordForm.reset();
      });
  }

  get password(): FormControl {
    return this.changePasswordForm.get('password') as FormControl;
  }

  get passwordConfirm(): FormControl {
    return this.changePasswordForm.get('passwordConfirm') as FormControl;
  }

  get confirmPasswordErrorMessage(): string {
    return this.passwordConfirm.hasError('required') ? 'Confirm New Password is required.' :
      this.passwordConfirm.hasError('minlength') ? 'Confirm New Password must have minimum length of 10.' :
        this.passwordConfirm.hasError('valueMatch') ? 'Passwords do not match.' : '';
  }

  get displayPasswordLengthError(): boolean {
    return (this.password.hasError('minlength') || this.password.hasError('maxlength'))
      || (this.password.touched && this.password.value === '');
  }

  get displayAlphanumericError(): boolean {
    return (this.password.touched && this.password.hasError('pattern')) || (this.password.touched && this.password.value === '');
  }

  // Conditions driving dynamic styles in template
  get validLengthCondition(): boolean {
    return !this.displayPasswordLengthError && this.password.touched;
  }

  get validPatternCondition(): boolean {
    return !this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }

  get invalidLengthCondition(): boolean {
    return this.displayPasswordLengthError && this.password.touched;
  }

  get invalidPatternCondition(): boolean {
    return (this.displayAlphanumericError && this.password.touched) ||
      (this.password.touched && this.password.value === '');
  }

  backToMyProfile() {
    history.back();
  }
}
