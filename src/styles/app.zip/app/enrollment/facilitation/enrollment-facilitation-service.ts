import { AnonymousQuote } from '../application/anonymous-quote';

/**
 * Start here when setting out to build your next EnrollmentFacilitationService implementation for another product line.
 *
 * This assumes very little about the prerequisites of creating an application for another product line, other than that
 * there will be some set of details required to create an application. You can create either of the following:
 *   - a class that implements the ApplicationDetails marker interface
 *   - an interface that extends the ApplicationDetails marker interface
 *
 * In essence, all that ApplicationDetails exists for is to denote that your particular type or interface wants to
 * participate in tracking and facilitating an enrollment for an application of the next Colonial product line.
 *
 * @see CourtBondApplicationDetails
 */
export interface ApplicationDetails {
  [key: string]: any;
}

/**
 * Your service should implement this interface, as well as provide types for the "ApplicationType" itself, representing
 * what a newly-created "application" for the new product line should look like, as well as the "DetailsType" that
 * implements the above interface.
 *
 * You will then be prompted by the type checker to provide implementations for the methods declared below. In addition,
 * your service should also expose setters, as many as are needed to capture the various details required to create
 * an application, whatever that may be.
 *
 * See CourtBondFacilitationService for some examples; all of its additional methods, which don't implement the methods
 * below, are dedicated to setting an individual field or fields on a CourtBondApplicationDetails object.
 *
 * In addition, while it isn't required, it might be a good idea to also have a programmatic mapping from
 * "ApplicationType" to "DetailsType", in order to make resetting the application details easier, when a new application
 * is created.
 *
 * @see CourtBondFacilitationService
 */
export interface EnrollmentFacilitationService<ApplicationType, DetailsType extends ApplicationDetails> {
  getApplicationDetails(): DetailsType;
  resetApplicationDetails(): void;
  isEnrollmentInProgress(): boolean;
  applicationCreated(ApplicationType: any): void;
  getAnonymousQuote(): AnonymousQuote;
  setAnonymousQuote(anonymousQuote: AnonymousQuote);
}
