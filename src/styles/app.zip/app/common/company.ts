import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from './auditable-object';

export interface Company {
  id: number;
  clientsId: number;
  name: string;
  siccode: string;
}

@JsonObject('CompanyImpl')
export class CompanyImpl extends AuditableObject implements Company {
  @JsonProperty('clientsId', Number, true)
  clientsId: number = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('siccode', String, true)
  siccode: string = null;
}
