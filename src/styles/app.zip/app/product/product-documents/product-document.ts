import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../../common/auditable-object';

@JsonObject('ProductDocument')
export class ProductDocument extends AuditableObject {


  @JsonProperty('fileTypeName', String, true)
  fileTypeName: String = null;

  @JsonProperty('parentObjectTypeName', String, true)
  parentObjectTypeName: String = null;

  @JsonProperty('parentObjectId', Number, true)
  parentObjectId: Number = null;

  @JsonProperty('productId', Number, true)
  productId: Number = null;

  @JsonProperty('fileTypeDescription', String, true)
  fileTypeDescription: String = null;

  @JsonProperty('name', String, true)
  name: String = null;
}
