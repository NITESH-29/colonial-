import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { SecurityService } from '../security.service';
import { ValueMatchValidator } from '../../common/validators/value-match-validator';
import { Validators } from '@angular/forms';
import { AlertService } from '../../common/alert.service';
import { CommonUtilities } from '../../common/utils/common-utilities';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { AppConfigService } from '../../app-config-service';

@Component({
  selector: 'app-forgot-password',
  providers: [AlertService],
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
})

export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  submitted = false;
  colonialPhoneNumber: string;

  constructor(public fb: FormBuilder,
    private router: Router,
    private snackbar: MatSnackBar,
    private authenticationService: SecurityService,
    private serviceHandler: ServiceHandler,
    appConfigService: AppConfigService) {
    appConfigService.getConfig().subscribe(config => this.colonialPhoneNumber = config.colonialPhoneNumber);
  }

  ngOnInit() {

    this.forgotPasswordForm = this.fb.group(
      {
        username: ['', [Validators.required]],
      },
      {
        validator: ValueMatchValidator.noSpaces('username'),
      }
    );
  }

  forgotPassword() {
    if (this.forgotPasswordForm.controls.username.valid) {
      this.submitted = true;
      this.authenticationService.requestPasswordReset(this.forgotPasswordForm.controls.username.value)
        .subscribe((response) => {
          this.submitted = false;
          if (response) {
            this.router.navigate(['/secure/login']);
            this.snackbar.open('A reset password link has been sent to you', null, {
              duration: 6000,
              panelClass: ['confirmation_snack_bar'],
            });
          } else {
            this.snackbar.open('Sorry, the information you provided could not be verified', null, {
              duration: 6000,
              panelClass: ['alert_snack_bar'],
            });
          }
          this.forgotPasswordForm.reset();
        }, (error) => {
          if (error.status === 403) {
            this.snackbar.open('Sorry, the username you provided could not be verified', null, {
              duration: 6000,
              panelClass: ['alert_snack_bar'],
            });
          } else if (error.status === 500 && error.error && error.error.responseDesc) {
            this.snackbar.open(error.error.responseDesc, null, {
              duration: 6000,
              panelClass: ['alert_snack_bar'],
            });
          }
        });
    } else {
      CommonUtilities.markAllTouched(this.forgotPasswordForm.controls.username);
      this.serviceHandler.showErrorMessage('Please fix validation errors before submitting.');
    }
  }

  backToLoginScreen() {
    this.router.navigate(['/secure/login']);
  }
}
