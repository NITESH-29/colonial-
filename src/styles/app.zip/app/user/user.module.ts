import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountTypeSelectionComponent } from './account-type-selection/account-type-selection.component';
import { CreateClientAccountComponent } from './create-account/create-client-account.component';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatCardModule,
  MatChipsModule, MatDialogModule,
  MatDividerModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule, MatRadioModule, MatSelectModule, MatTabsModule,
} from '@angular/material';
import { SelectionCardComponent } from './account-type-selection/selection-card/selection-card.component';
import { UserRoutingModule } from './user-routing.module';
import { UsernamePasswordComponent } from './username-password/username-password.component';
import { FormComponentsModule } from '../form-components/form-components.module';
import { ReactiveFormsModule } from '@angular/forms';
import { PersonalInformationComponent } from './personal-information/personal-information.component';
import { CommonComponentsModule } from '../common/common-components.module';
import { BusinessOfficeInformationComponent } from './business-office-information/business-office-information.component';
import { BusinessInformationComponent } from './business-information/business-information.component';
import { AccountService } from './account.service';
import { CreateAttorneyAccountComponent } from './create-account/create-attorney-account.component';
import { CreateAgentAccountComponent } from './create-account/create-agent-account.component';
import { ProfileComponent } from './profile/profile.component';
import { SecurityModule } from '../security/security.module';
import { CompanyWithOfficeListComponent } from './company-with-office-list/company-with-office-list.component';
import { BusinessWithSingleOfficeComponent } from './business-with-single-office/business-with-single-office.component';
import { AgencyWithSingleOfficeComponent } from './business-with-single-office/agency-with-single-office.component';
import { CompanyWithSingleOfficeComponent } from './business-with-single-office/company-with-single-office.component';
import { FirmWithSingleOfficeComponent } from './business-with-single-office/firm-with-single-office.component';
import { BusinessOfficeListComponent } from './business-office-information/business-office-list/business-office-list.component';
import { ReadAddCompanyComponent } from './profile/read-add-company/read-add-company.component';
import { ReadonlyCompanyComponent } from './profile/read-add-company/readonly-company.component';
import { ReadonlyCompanyOfficeComponent } from './profile/read-add-company/readonly-company-office.component';
import { ReadonlyAgencyComponent } from './profile/read-add-company/readonly-agency.component';
import { ReadonlyAgencyOfficeComponent } from './profile/read-add-company/readonly-agency-office.component';
import { PersonBusinessService } from './providers/person-business.service';
import { PersonCompanyResolver } from './providers/person-company.resolver';
import { ProfileService } from './profile/profile.service';
import { AddEditClientComponent } from './client/add-edit-client/add-edit-client.component';
import { InitialPasswordComponent } from './initial-password/initial-password.component';
import { EmployeeDefaultGuard } from './role-guard/employee-default.guard';
import { EmployeePlusGuard } from './role-guard/employee-plus.guard';
import { AdminGuard } from './role-guard/admin.guard';
import { SuperuserGuard } from './role-guard/superuser.guard';
import { EmployeeEnrollmentComponent } from './employee-enrollment/employee-enrollment.component';
import { EmployeeEnrollmentService } from './employee-enrollment/employee-enrollment.service';
import { ClientListComponent } from './client/client-list/client-list.component';
import { ClientService } from './client/client.service';
import { ClientsComponent } from './client/clients/clients.component';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { BillingProfilesSummaryComponent } from './profile/billing-profiles-summary/billing-profiles-summary.component';
import { BillingProfileComponent } from './profile/billing-profile/billing-profile.component';
import { BusinessOfficePersonInformationComponent } from './business-office-person-information/business-office-person-information.component';
import { AgencyAndOfficeInformationComponent } from './agency-and-office-information/agency-and-office-information.component';
import { AddPersonalAddressComponent } from './add-personal-address/add-personal-address.component';
import { PersonalAddressService } from './add-personal-address/personal-address.service';
import { FirmAndOfficeInformationComponent } from './firm-and-office-information/firm-and-office-information.component';
import { CompanyAndOfficeInformationComponent } from './company-and-office-information/company-and-office-information.component';
import { AttorneyReferralListEntryComponent } from './attorney-referral-list/attorney-referral-list-entry.component';
import { ReadonlyReferralInformationComponent } from './profile/readonly-referral-information/readonly-referral-information.component';
import { AddCompanyInfoFromAnonymousQuoteComponent } from './add-company-info/add-company-info-from-anonymous-quote.component';
import { ClientExistsDialogComponent } from './client/client-exists-dialog/client-exists-dialog.component';
import { ViewClientComponent } from './client/view-client/view-client.component';
import { PaymentComponent } from './payment/payment.component';
import { CardDetailComponent } from './payment/card-detail/card-detail.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AddEditClientPopupComponent } from './client/add-edit-client-popup/add-edit-client-popup.component';
import { MaterialModule } from '../material.module';
import { ClientListNewComponent } from './client/client-list-new/client-list-new.component';
import { DeleteClientPopupComponent } from './client/delete-client-popup/delete-client-popup.component';

@NgModule({
  declarations: [
    AccountTypeSelectionComponent,
    CreateAgentAccountComponent,
    CreateAttorneyAccountComponent,
    AttorneyReferralListEntryComponent,
    CreateClientAccountComponent,
    SelectionCardComponent,
    UsernamePasswordComponent,
    PersonalInformationComponent,
    BusinessOfficePersonInformationComponent,
    BusinessInformationComponent,
    BusinessOfficeInformationComponent,
    AgencyAndOfficeInformationComponent,
    FirmAndOfficeInformationComponent,
    CompanyAndOfficeInformationComponent,
    ProfileComponent,
    CompanyWithOfficeListComponent,
    BusinessWithSingleOfficeComponent,
    AgencyWithSingleOfficeComponent,
    CompanyWithSingleOfficeComponent,
    FirmWithSingleOfficeComponent,
    BusinessOfficeListComponent,
    ReadAddCompanyComponent,
    ReadonlyReferralInformationComponent,
    ReadonlyCompanyComponent,
    ReadonlyAgencyComponent,
    ReadonlyCompanyOfficeComponent,
    ReadonlyAgencyOfficeComponent,
    AddEditClientComponent,
    ViewClientComponent,
    InitialPasswordComponent,
    EmployeeEnrollmentComponent,
    ClientListComponent,
    ClientListNewComponent,
    ClientsComponent,
    BillingProfilesSummaryComponent,
    BillingProfileComponent,
    AddPersonalAddressComponent,
    AddCompanyInfoFromAnonymousQuoteComponent,
    ClientExistsDialogComponent,
    PaymentComponent,
    CardDetailComponent,
    AddEditClientPopupComponent,
    DeleteClientPopupComponent,
  ],
  imports: [
    MatAutocompleteModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatTabsModule,
    MatRadioModule,
    UserRoutingModule,
    SecurityModule,
    CommonModule,
    MatCardModule,
    MatIconModule,
    FormComponentsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatGridListModule,
    MatDividerModule,
    MatDialogModule,
    CommonComponentsModule,
    TableModule,
    PaginatorModule,
    FlexLayoutModule,
    MaterialModule,
  ],
  providers: [
    AccountService,
    ProfileService,
    EmployeeEnrollmentService,
    PersonBusinessService,
    PersonalAddressService,
    PersonCompanyResolver,
    ClientService,
    EmployeeDefaultGuard,
    EmployeePlusGuard,
    AdminGuard,
    SuperuserGuard,
  ],
  exports: [
    PersonalInformationComponent,
    ClientListComponent,
    ClientListNewComponent,
    AddEditClientComponent,
    AddPersonalAddressComponent,
    AddCompanyInfoFromAnonymousQuoteComponent,
  ],
  entryComponents: [
    ClientExistsDialogComponent,
    AddEditClientPopupComponent,
    DeleteClientPopupComponent,
  ],
})
export class UserModule {
}
