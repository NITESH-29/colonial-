import { JsonObject, JsonProperty } from 'json2typescript';

export interface DashboardData {
  applications: object;
  products: object;
}

@JsonObject('DashboardDataImpl')
export class DashboardDataImpl implements DashboardData {
  @JsonProperty('applications', Object, true)
  applications: object = undefined;

  @JsonProperty('products', Object, true)
  products: object = undefined;
}
