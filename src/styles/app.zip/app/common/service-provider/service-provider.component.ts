import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-service-provider',
  templateUrl: './service-provider.component.html',
  styleUrls: ['./service-provider.component.css'],
})
export class ServiceProviderComponent {

  @Input()
  serviceProviderFormGroup: FormGroup;

  constructor() { }

  get name(): FormControl {
    return this.serviceProviderFormGroup.get('name') as FormControl;
  }

  get phone(): FormControl {
    return this.serviceProviderFormGroup.get('phone') as FormControl;
  }

  get email(): FormControl {
    return this.serviceProviderFormGroup.get('email') as FormControl;
  }

  get address(): FormGroup {
    return this.serviceProviderFormGroup.get('address') as FormGroup;
  }

}
