import { JsonObject, JsonProperty } from 'json2typescript';

export interface CompanyOfficePersonModel {
  id: number;
  responsiblePerson: boolean;
  title: string;
}

@JsonObject('CompanyOfficePersonModelImpl')
export class CompanyOfficePersonModelImpl implements CompanyOfficePersonModel {

  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('responsiblePerson', Boolean, true)
  responsiblePerson: boolean = null;

  @JsonProperty('title', String, true)
  title: string = null;
}
