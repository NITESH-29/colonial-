import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-bank-info',
  templateUrl: './bank-info.component.html',
  styleUrls: ['./bank-info.component.css'],
})
export class BankInfoComponent {

  @Input()
  bankFormGroup: FormGroup;

  constructor() { }

  get name(): FormControl {
    return this.bankFormGroup.get('name') as FormControl;
  }

  get funds(): FormControl {
    return this.bankFormGroup.get('funds') as FormControl;
  }

  get address(): FormGroup {
    return this.bankFormGroup.get('address') as FormGroup;
  }

}
