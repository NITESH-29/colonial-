import { PersonSummary } from '../person-summary';
import { User } from '../../security/user';
import { Address } from '../../enrollment/application/court/model/common/address';

export class RolePaymentDefinition {
  /**
   * Mapping of a 'roleCode' to the appropriate RoleTexts.
   * Array is in order of descending 'privileges'.
   */
  static readonly ROLE_CODE_AGENT = 'agent';
  static readonly ROLE_CODE_ATTORNEY = 'attorney';
  static readonly ROLE_CODE_CLIENT = 'client';
  static readonly nonClientRolePaymentDefinitions: RolePaymentDefinition[] = [
    {
      roleCode: 'superuser',
      roleTexts: {
        selectionLabel: 'Super User',
        toOtherBillingPersonAlertTitle: ``,
        toThisBillingPersonAlertTitle: ``,
        toOtherBillingPersonAlertText: ``,
        toThisBillingPersonAlertText: ``,
        toOtherBillingPersonMessageText: ``,
        toThisBillingPersonMessageText: ``,
      },
    },
    {
      roleCode: 'admin',
      roleTexts: {
        selectionLabel: 'Admin',
        toOtherBillingPersonAlertTitle: ``,
        toThisBillingPersonAlertTitle: ``,
        toOtherBillingPersonAlertText: ``,
        toThisBillingPersonAlertText: ``,
        toOtherBillingPersonMessageText: ``,
        toThisBillingPersonMessageText: ``,
      },
    },
    {
      roleCode: 'clerk',
      roleTexts: {
        selectionLabel: 'Clerk',
        toOtherBillingPersonAlertTitle: ``,
        toThisBillingPersonAlertTitle: ``,
        toOtherBillingPersonAlertText: ``,
        toThisBillingPersonAlertText: ``,
        toOtherBillingPersonMessageText: ``,
        toThisBillingPersonMessageText: ``,
      },
    },
    {
      roleCode: RolePaymentDefinition.ROLE_CODE_AGENT,
      roleTexts: {
        selectionLabel: 'Agent',
        toOtherBillingPersonAlertTitle: `Use Your Client's Payment Method?`,
        toThisBillingPersonAlertTitle: `Use Your Payment Method?`,
        toOtherBillingPersonAlertText: `The payment method entered will be kept on file and associated with your client's account.`,
        toThisBillingPersonAlertText: `The payment method entered will be kept on file and associated with your account.`,
        toOtherBillingPersonMessageText: ``,
        toThisBillingPersonMessageText: ``,
        possessiveReplacementText: `agent's`,
      },
    },
    {
      roleCode: RolePaymentDefinition.ROLE_CODE_ATTORNEY,
      roleTexts: {
        selectionLabel: 'Attorney',
        toOtherBillingPersonAlertTitle: `Use Your Client's Payment Method?`,
        toThisBillingPersonAlertTitle: `Use Your Payment Method?`,
        toOtherBillingPersonAlertText: `The payment method entered will be kept on file and associated with your client's account.`,
        toThisBillingPersonAlertText: `The payment method entered will be kept on file and associated with your account.`,
        toOtherBillingPersonMessageText: ``,
        toThisBillingPersonMessageText: ``,
        possessiveReplacementText: `attorney's`,
      },
    },
  ];

  static readonly KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE = 'REPLACE_WITH_POSSESSIVE_OTHER_ROLE';
  static readonly clientRolePaymentDefinition: RolePaymentDefinition = {
    roleCode: RolePaymentDefinition.ROLE_CODE_CLIENT,
    roleTexts: {
      selectionLabel: 'Client',
      toOtherBillingPersonAlertTitle: `Use Your` +
        ` ${RolePaymentDefinition.KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE} Payment Method?`,
      toThisBillingPersonAlertTitle: `Use Your Payment Method?`,
      toOtherBillingPersonAlertText: `The premium will be charged to your` +
        ` ${RolePaymentDefinition.KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE} payment method.`,
      toThisBillingPersonAlertText: `The payment method entered will be kept on file and associated with your account.`,
      toOtherBillingPersonMessageText: `The premium will be charged to your` +
        ` ${RolePaymentDefinition.KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE} payment method.` +
        ` Select 'Client' above if you wish to change this to your own payment method.`,
      toThisBillingPersonMessageText: `The premium will be charged to your account.` +
        ``,
    },
  };

  readonly roleCode: string | null;
  readonly roleTexts: RoleTexts;
}

export interface RoleTexts {
  readonly selectionLabel: string;
  readonly toOtherBillingPersonAlertTitle: string;
  readonly toThisBillingPersonAlertTitle: string;
  readonly toOtherBillingPersonAlertText: string;
  readonly toThisBillingPersonAlertText: string;
  readonly toOtherBillingPersonMessageText: string;
  readonly toThisBillingPersonMessageText: string;
  readonly possessiveReplacementText?: string; // Optional text to be used when referencing this role in the possessive form.
}

export interface BillingPerson {
  readonly personId: number;
  readonly roleCode: string | null;
  readonly firstName: string;
  readonly lastName: string;
  readonly fullName: string;
  readonly phone: string;
  readonly billingAddress: Address; // Note that billing address is allowed to be different from person's address.
  readonly roleTexts: RoleTexts;
  readonly defaultBillingProfileId: number | null;
}

export class BillingPersonImpl implements BillingPerson {
  constructor(
    public personId: number,
    public roleCode: string,
    public firstName: string,
    public lastName: string,
    public fullName: string,
    public phone: string,
    public defaultBillingProfileId: number | null,
    public billingAddress: Address
  ) {
  }

  get roleTexts(): RoleTexts {
    let roleTexts: RoleTexts;
    roleTexts = BillingPersonImpl.findBillingPersonRoleTexts(this);
    return roleTexts;
  }

  static findBillingPersonRoleTexts?(billingPerson: BillingPerson): RoleTexts {
    let roleTexts: RoleTexts;
    // Extract the rolePaymentDefinition for this billingPerson's role.
    let rolePaymentDefinition: RolePaymentDefinition;

    if (!!billingPerson) {
      if (!rolePaymentDefinition) {
        rolePaymentDefinition = RolePaymentDefinition.nonClientRolePaymentDefinitions.find(candidateRoleDefinition => {
          return billingPerson.roleCode === candidateRoleDefinition.roleCode;
        });
      }
      if (!rolePaymentDefinition) {
        rolePaymentDefinition = billingPerson.roleCode === RolePaymentDefinition.clientRolePaymentDefinition.roleCode
          ? RolePaymentDefinition.clientRolePaymentDefinition : undefined;
      }
      if (!!rolePaymentDefinition) {
        roleTexts = rolePaymentDefinition.roleTexts;
      }
    }

    return roleTexts;
  }

  static createBillingPersonFromIndividualPersonSummary(personSummary: PersonSummary): BillingPerson {
    let billingPerson: BillingPerson;
    billingPerson =
      BillingPersonImpl.createBillingPersonFromPersonSummary(personSummary, RolePaymentDefinition.clientRolePaymentDefinition);
    return billingPerson;
  }

  static createBillingPersonFromPersonSummary(personSummary: PersonSummary
    , rolePaymentDefinition: RolePaymentDefinition
    , overrideAddress?: Address): BillingPerson {
    let billingPerson: BillingPersonImpl;

    const billingAddress = (!!overrideAddress) ? overrideAddress : personSummary.personAddresses[0];
    billingPerson = new BillingPersonImpl(
      personSummary.id,
      rolePaymentDefinition.roleCode,
      personSummary.firstName,
      personSummary.lastName,
      personSummary.fullName,
      personSummary.phone,
      personSummary.defaultBillingProfileId,
      billingAddress
    );
    return billingPerson;
  }

  static findRolePaymentDefinitionFromRoleCode?(roleCode: string): RolePaymentDefinition {
    let rolePaymentDefinition: RolePaymentDefinition;
    // Extract the highest 'privilege' for this user.
    const nonClientRolePaymentDefinition = RolePaymentDefinition.nonClientRolePaymentDefinitions.find(candidateRoleDefinition => {
      return candidateRoleDefinition.roleCode === roleCode;
    });
    if (!!nonClientRolePaymentDefinition) {
      rolePaymentDefinition = nonClientRolePaymentDefinition;
    } else {
      rolePaymentDefinition = RolePaymentDefinition.clientRolePaymentDefinition;
    }
    return rolePaymentDefinition;
  }

  static createBillingPersonFromUser(user: User, overrideAddress?: Address): BillingPerson {
    let billingPerson: BillingPerson;
    let rolePaymentDefinition: RolePaymentDefinition;
    // Extract the highest 'privilege' for this user.
    const nonClientRolePaymentDefinition = RolePaymentDefinition.nonClientRolePaymentDefinitions.find(candidateRoleDefinition => {
      return user.hasRole(candidateRoleDefinition.roleCode);
    });
    if (!!nonClientRolePaymentDefinition) {
      rolePaymentDefinition = nonClientRolePaymentDefinition;
    } else {
      rolePaymentDefinition = RolePaymentDefinition.clientRolePaymentDefinition;
    }

    billingPerson = BillingPersonImpl.createBillingPersonFromPersonSummary(user.person, rolePaymentDefinition, overrideAddress);
    return billingPerson;
  }
}

