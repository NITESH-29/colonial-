import {
  Component,
  OnInit,
} from '@angular/core';
import {
  Location,
} from '@angular/common';
import {
  ActivatedRoute, Event, NavigationEnd,
  Router
} from '@angular/router';
import { PaymentMethodSelectionService } from '../../common/payment-method-selection/payment-method-selection.service';
import { ProductService } from '../products.service';
import { ApplicationService } from '../../enrollment/application/application.service';
import { Product } from '../product';
import * as moment_ from 'moment';
import { PaymentPlanModel } from '../../common/payment-method-selection/payment-plan-model';
import { PaymentChannelCode } from '../../common/payment-method-selection/payment_channel_code';
import { PaymentPlanTypeModel } from '../../common/payment-method-selection/payment-plan-type-model';
import { PaymentFrequencyType } from '../../common/payment-method-selection/payment_frequency_type';
import { BillingProfileModel } from '../../common/payment-method-selection/billing-profile-model';
import { SendEmailDialogComponent } from '../../common/email/send-email-dialog/send-email-dialog.component';
import { MatDialog } from '@angular/material';
import { ProductRenewal } from '../product-renewal/product-renewal';
import { ProductRenewalService } from '../product-renewal/product-renewal.service';
import { CourtBondTypeDisplayNames, ProfessionalLiabilityBondType } from '../../enrollment/application/common/bond-types';
import { ApplicationData } from '../../enrollment/application/court/model/application-data';
import { CurrencyFormatter } from '../../common/utils/currency-formatter';
import { PaymentModel } from '../../common/billing/payment-model';
import { SecurityService } from '../../security/security.service';
import { AppConfigService } from '../../app-config-service';


@Component({
  selector: 'app-product-overview',
  templateUrl: './product-overview.component.html',
  styleUrls: ['./product-overview.component.scss'],
})

export class ProductOverviewComponent implements OnInit {
  overviewData: ApplicationData;

  formId = -1;
  bondClassification: string;
  initialized = false;
  paymentPlanModel: PaymentPlanModel;
  prod: Product;
  productRenewals: ProductRenewal[];
  originalProduct: Product;
  previousProduct: Product;
  statusColor: string;
  appStatus: string;

  constructor(private paymentMethodService: PaymentMethodSelectionService,
    private productService: ProductService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private applicationService: ApplicationService,
    private sendEmailDialog: MatDialog,
    private productRenewalService: ProductRenewalService,
    private location: Location,
    private securityService: SecurityService) { }


  async ngOnInit() {
    this.formId = this.activatedRoute.snapshot.queryParams['formId'];

    if (this.formId && this.formId > -1) {
      await this.loadData();

      this.router.events.subscribe(async (event: Event) => {
        if (event instanceof NavigationEnd) {
          // reload the product if the formId value changes
          const formId = this.activatedRoute.snapshot.queryParams['formId'];
          if (formId !== this.formId) {
            this.formId = formId;
            await this.loadData();
          }
        }
      });
    }

    this.getBadgeColorForStatus();
  }

  async loadData() {
    this.prod = await this.productService.getProductOverview(this.formId).toPromise();
    const app = await this.applicationService.getById(this.prod.applicationId);
    this.appStatus = app.status;
    this.productRenewals = await this.productRenewalService.getProductRenewals(this.formId).toPromise();
    this.productRenewals.sort((a: ProductRenewal, b: ProductRenewal) => {
      return b.previousProduct.id - a.previousProduct.id;
    });
    this.overviewData = app.data;

    this.originalProduct = this.productRenewals.length > 0 ?
      this.productRenewals[0].originalProduct :
      this.prod;

    this.previousProduct = this.productRenewals.length > 0 ?
      this.productRenewals[0].previousProduct :
      null;

    const paymentPlanModels: PaymentPlanModel[] =
      await this.paymentMethodService.getPaymentPlanModelsForProduct(this.formId).toPromise();

    // Extract the most recent paymentPlanModel.
    if (paymentPlanModels.length === 0) {
      this.paymentPlanModel = undefined;
    } else {
      this.paymentPlanModel = paymentPlanModels.reduce((ppm_accum, ppm_candidate) => {
        return ppm_candidate.endDate > ppm_accum.endDate ? ppm_candidate : ppm_accum;
      });
    }

    if (this.overviewData.bondClassification === ProfessionalLiabilityBondType.Pnl) {
      this.bondClassification = 'Professional Liability';
    } else {
      this.bondClassification = CourtBondTypeDisplayNames[this.overviewData.bondClassification];
    }

    this.initialized = true;
  }

  datediff(first: Date, second: Date) {
    const start = moment_(first);
    const end = moment_(second);
    return end.diff(start, 'days');
  }

  get paymentPlanTypeModel(): PaymentPlanTypeModel {
    return this.paymentPlanModel.paymentPlanTypeModel;
  }

  get paymentFrequencyType(): PaymentFrequencyType {
    return this.paymentPlanTypeModel.paymentFrequencyType;
  }

  get haveLatestPayment() {
    return !!this.latestPayment;
  }
  /**
   * Return the latest Payment on the PaymentPlan, if any.
   */
  get latestPayment(): PaymentModel | undefined {
    return this.paymentPlanModel.latestPayment;
  }

  /**
   * Return the defaultBillingProfile on the PaymentPlan, if any.
   * E.G. there'll be no defaultBillingProfile for products paid by paper-check in their entirety.
   */
  get defaultBillingProfile(): BillingProfileModel | undefined {
    return this.paymentPlanModel.billingProfileModel;
  }

  /**
   * Return the BillingProfile of the latest payment, if any.
   * The result will be undefined if:
   * - there is no latest payment.
   * - the latest payment was paid by paper-check.
   * To differentiate the two, use haveLatestPayment.
   */
  get latestPaymentBillingProfile(): BillingProfileModel | undefined {
    let billingProfileModel: BillingProfileModel | undefined;
    if (!!this.latestPayment) {
      billingProfileModel = this.latestPayment.billingProfileModel;
    }
    return billingProfileModel;
  }

  /**
   * Return the BillingProfile to be used for display purposes.
   * The result will be undefined if:
   * - the paymentPlan's defaultBillingProfile is undefined because product was paid by paper-check.
   * - the latest payment was paid by paper-check.
   * To differentiate the two, use haveLatestPayment.
   */
  get displayBillingProfile(): BillingProfileModel | undefined {
    let displayBillingProfile: BillingProfileModel;
    if (this.haveLatestPayment) {
      displayBillingProfile = this.latestPaymentBillingProfile;
    } else {
      displayBillingProfile = this.defaultBillingProfile;
    }
    return displayBillingProfile;
  }

  /**
   * Return the PaymentChannelCode to be displayed.
   */
  get displayPaymentChannelCode(): PaymentChannelCode {
    let displayPaymentChannelCode: PaymentChannelCode;
    const displayBillingProfile = this.displayBillingProfile;
    if (!!displayBillingProfile) {
      displayPaymentChannelCode = displayBillingProfile.paymentChannelCode;
    } else {
      displayPaymentChannelCode = PaymentChannelCode.CHECK;
    }
    return displayPaymentChannelCode;
  }

  cancel() {
    this.location.back();
  }

  renew() {
    this.router.navigateByUrl(`/product/renew-product?productId=${this.formId}`);
  }

  get showRenewal(): boolean {
    return this.datediff(new Date(), this.prod.toDate) <= 30 && !this.prod.renewed;
  }

  get fromDate(): Date {
    return this.prod.fromDate;
  }

  get toDate(): Date {
    return this.prod.toDate;
  }

  get productNo(): String {
    return this.prod.productNo;
  }

  get renewable(): Boolean {
    return this.prod.renewable;
  }

  get renewed(): Boolean {
    return this.prod.renewed;
  }

  get renewal(): Boolean {
    return this.prod.renewal;
  }

  async sendRenewalReminder() {

    this.sendEmailDialog.open(SendEmailDialogComponent, {
      data: {
        parentObjectTypeName: 'product',
        parentObjectId: this.prod.id,
        emailTypeCode: 'up_for_renewal',
      },
      autoFocus: false,
    });
  }

  get status(): String {
    return this.appStatus;
  }

  formatCurrency(amount: number): string {
    return CurrencyFormatter.formatMoney(amount);
  }

  isClient() {
    return !this.securityService.user.isSteward && !this.securityService.user.hasEmployeePermissions;
  }

  isSteward() {
    return this.securityService.user.isSteward;
  }

  isEmployee() {
    return this.securityService.user.hasEmployeePermissions;
  }


  async viewApplicantProfile() {
    if (this.isEmployee()) {
      const url = `user/view-client/P/${this.prod.person.id}`;
      await this.router.navigateByUrl(url);
    }

    if (this.isSteward()) {
      await this.router.navigateByUrl(`/user/edit-client/P/${this.prod.person.id}`);
    }

    if (this.isClient()) {
      await this.router.navigateByUrl(`user/my-profile`);
    }
  }

  getBadgeColorForStatus() {
    switch (this.prod.status) {
      case 'Open':
        this.statusColor = '#A6FA99';
        break;
      case 'Past Due':
        this.statusColor = '#FA9999';
        break;
      case 'Closed':
        this.statusColor = '#E699FA';
        break;
    }
  }
}
