import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../../common/auditable-object';

@JsonObject('LineOfBusiness')
export class LineOfBusiness extends AuditableObject {
  @JsonProperty('name', String, true)
  name: String = null;
}
