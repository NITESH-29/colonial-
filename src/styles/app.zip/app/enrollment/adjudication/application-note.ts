import { AuditableObject } from '../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject('ApplicationNote')
export class ApplicationNote extends AuditableObject {
  @JsonProperty('comments', String, true)
  comments: string = null;

  @JsonProperty('applicationId', Number, true)
  applicationId: number = null;

  @JsonProperty('systemGenerated', Boolean, true)
  systemGenerated: boolean = null;
}
