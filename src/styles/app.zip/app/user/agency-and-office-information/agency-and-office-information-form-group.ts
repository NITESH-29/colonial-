import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { AgencyAndOfficeInformation } from './agency-and-office-information';
import { PatternValidators } from '../../common/validators/pattern-validators';
import { AddressFormGroup } from '../../common/address/address-form-group';

type IsRequiredFn = () => boolean;
export type FormGroupOptions<T> = { [P in keyof T]?: IsRequiredFn };
export type AgencyAndOfficeInformationFormGroupOptions = FormGroupOptions<AgencyAndOfficeInformation>;

export class AgencyAndOfficeInformationFormGroup extends FormGroup {
  constructor(options: AgencyAndOfficeInformationFormGroupOptions = {}) {
    options = checkNullsAndSetDefaults(options);
    super({
      id: new FormControl(),
      name: new ConditionalRequireFormControl(null, options.name),
      website: new FormControl(null, Validators.maxLength(50)),
      phone: new ConditionalRequireFormControl(null, options.phone, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      fax: new FormControl(null, [PatternValidators.phoneNumber(), Validators.maxLength(15)]),
      email: new ConditionalRequireFormControl(null, options.email, [PatternValidators.email(), Validators.maxLength(75)]),
      sicCode: new ConditionalRequireFormControl(null, options.sicCode, Validators.maxLength(8)),
      einNumber: new FormControl(null, [Validators.maxLength(10), Validators.pattern(/^[1-9]\d?-\d{7}$/)]),
      licenseNumber: new FormControl(null, Validators.maxLength(450)),
      memberOfNasbp: new ConditionalRequireFormControl(null, options.memberOfNasbp),
      address: new AddressFormGroup(options.address),
    });
  }

  get id(): FormControl {
    return this.get('id') as FormControl;
  }

  get name(): FormControl {
    return this.get('name') as FormControl;
  }

  get website(): FormControl {
    return this.get('website') as FormControl;
  }

  get phone(): FormControl {
    return this.get('phone') as FormControl;
  }

  get fax(): FormControl {
    return this.get('fax') as FormControl;
  }

  get email(): FormControl {
    return this.get('email') as FormControl;
  }

  get sicCode(): FormControl {
    return this.get('sicCode') as FormControl;
  }

  get einNumber(): FormControl {
    return this.get('einNumber') as FormControl;
  }

  get licenseNumber(): FormControl {
    return this.get('licenseNumber') as FormControl;
  }

  get memberOfNasbp(): FormControl {
    return this.get('memberOfNasbp') as FormControl;
  }

  get address(): AddressFormGroup {
    return this.get('address') as AddressFormGroup;
  }
}

function checkNullsAndSetDefaults(
  options: Partial<AgencyAndOfficeInformationFormGroupOptions>
): AgencyAndOfficeInformationFormGroupOptions {
  const defaults = {
    name: () => true,
    phone: () => true,
    email: () => true,
    sicCode: () => true,
    address: () => true,
    memberOfNasbp: () => true,
  };

  return { ...defaults, ...options };
}
