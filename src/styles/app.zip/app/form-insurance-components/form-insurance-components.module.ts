import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material.module';
import { FlexLayoutModule } from '@angular/flex-layout';

import {
  BasicInputComponent, CurrencyInputComponent, BasicTextAreaComponent,
  NumberInputComponent, PhoneInputComponent, CheckboxComponent, RadiobuttonComponent,
  SelectComponent, SelectWithSearchComponent, DateComponent, FormInsuranceFooterComponent,
  StepIndicatorComponent, GoogleInputComponent, PasswordInputComponent, HelpTextComponent,
  FormInsurancePrintComponent, PercentageInputComponent, LabelComponent, SingleCheckboxComponent, DialogComponent,
  SeparatorLineComponent, FileInputComponent
} from './';

import {
  DynamicFieldDirective, InsuranceCurrencyFormatDirective,
  InsuranceNumberFormatDirective, InsuranceMaskDirective, InsurancePreventAutoEventDirective
} from '../insurance/directive';
import { AddressGridComponent } from './address-grid/address-grid.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    FlexLayoutModule,
  ],

  declarations: [
    DynamicFieldDirective,
    InsuranceCurrencyFormatDirective,
    InsuranceNumberFormatDirective,
    InsuranceMaskDirective,
    InsurancePreventAutoEventDirective,
    BasicInputComponent,
    LabelComponent,
    GoogleInputComponent,
    NumberInputComponent,
    CurrencyInputComponent,
    PhoneInputComponent,
    BasicTextAreaComponent,
    CheckboxComponent,
    SingleCheckboxComponent,
    RadiobuttonComponent,
    SelectComponent,
    SelectWithSearchComponent,
    DateComponent,
    FormInsuranceFooterComponent,
    StepIndicatorComponent,
    PasswordInputComponent,
    HelpTextComponent,
    FormInsurancePrintComponent,
    PercentageInputComponent,
    DialogComponent,
    SeparatorLineComponent,
    FileInputComponent,
    AddressGridComponent,
  ],
  entryComponents: [
    BasicInputComponent,
    LabelComponent,
    GoogleInputComponent,
    NumberInputComponent,
    CurrencyInputComponent,
    PhoneInputComponent,
    BasicTextAreaComponent,
    CheckboxComponent,
    SingleCheckboxComponent,
    RadiobuttonComponent,
    SelectComponent,
    SelectWithSearchComponent,
    DateComponent,
    FormInsuranceFooterComponent,
    StepIndicatorComponent,
    PasswordInputComponent,
    HelpTextComponent,
    FormInsurancePrintComponent,
    PercentageInputComponent,
    DialogComponent,
    SeparatorLineComponent,
    FileInputComponent,
    AddressGridComponent,
  ],
  exports: [
    DynamicFieldDirective,
    InsuranceCurrencyFormatDirective,
    InsuranceNumberFormatDirective,
    InsuranceMaskDirective,
    InsurancePreventAutoEventDirective,
    BasicInputComponent,
    LabelComponent,
    GoogleInputComponent,
    NumberInputComponent,
    CurrencyInputComponent,
    PhoneInputComponent,
    BasicTextAreaComponent,
    CheckboxComponent,
    SingleCheckboxComponent,
    RadiobuttonComponent,
    SelectComponent,
    SelectWithSearchComponent,
    DateComponent,
    FormInsuranceFooterComponent,
    StepIndicatorComponent,
    PasswordInputComponent,
    HelpTextComponent,
    FormInsurancePrintComponent,
    PercentageInputComponent,
    DialogComponent,
    SeparatorLineComponent,
    FileInputComponent,
    AddressGridComponent,
  ],
})
export class FormInsuranceComponentModule { }
