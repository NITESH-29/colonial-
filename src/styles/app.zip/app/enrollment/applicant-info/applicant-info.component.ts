import {
  Component,
  Input, OnInit
} from '@angular/core';
import {
  FormControl,
  FormGroup
} from '@angular/forms';
import { ApplicationData } from '../application/court/model/application-data';

@Component({
  selector: 'app-applicant-info',
  templateUrl: './applicant-info.component.html',
  styleUrls: ['./applicant-info.component.css'],
})

export class ApplicantInfoComponent implements OnInit {

  @Input()
  applicantInfoFormGroup: FormGroup;

  applicantFullName: string;

  get applicantAddress(): FormGroup {
    return this.applicantInfoFormGroup.get('applicantAddress') as FormGroup;
  }

  get applicantOfficePerson(): FormControl {
    return this.applicantInfoFormGroup.get('applicantOfficePerson') as FormControl;
  }

  get applicantEmail(): FormControl {
    return this.applicantInfoFormGroup.get('applicantEmail') as FormControl;
  }

  get applicantFax(): FormControl {
    return this.applicantInfoFormGroup.get('applicantFax') as FormControl;
  }

  get applicantPhone(): FormControl {
    return this.applicantInfoFormGroup.get('applicantPhone') as FormControl;
  }

  get applicantWebsite(): FormControl {
    return this.applicantInfoFormGroup.get('applicantWebsite') as FormControl;
  }

  get street1(): FormControl {
    return this.applicantAddress.get('street1') as FormControl;
  }

  get street2(): FormControl {
    return this.applicantAddress.get('street2') as FormControl;
  }

  get city(): FormControl {
    return this.applicantAddress.get('city') as FormControl;
  }

  get state(): FormControl {
    return this.applicantAddress.get('state') as FormControl;
  }

  get zipCode(): FormControl {
    return this.applicantAddress.get('zipCode') as FormControl;
  }

  ngOnInit(): void {
    this.deriveAndSetApplicantFullName(this.applicantInfoFormGroup.value);
    this.applicantInfoFormGroup.valueChanges.subscribe(this.deriveAndSetApplicantFullName.bind(this));
  }

  private deriveAndSetApplicantFullName(v: Partial<ApplicationData>) {
    let applicantFullName = [v.applicantSalutation, v.applicantName]
      .filter(Boolean)
      .join(' ');

    if (v.applicantSuffix) {
      applicantFullName += `, ${v.applicantSuffix}`;
    }

    this.applicantFullName = applicantFullName.trim();
  }
}

