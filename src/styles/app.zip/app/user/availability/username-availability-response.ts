export interface UsernameAvailabilityResponse {
  username: string;
  available: boolean;
}
