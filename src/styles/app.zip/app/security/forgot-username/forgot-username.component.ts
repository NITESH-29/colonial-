import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SecurityService } from '../security.service';
import { PatternValidators } from 'src/app/common/validators/pattern-validators';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

@Component({
  selector: 'app-forgot-username',
  templateUrl: './forgot-username.component.html',
  styleUrls: ['./forgot-username.component.scss'],
})
export class ForgotUsernameComponent implements OnInit {

  forgotUserNameFormControl: FormGroup;
  message: String;
  isError = false;
  isSuccess = false;

  constructor(
    private formBuilder: FormBuilder,
    private securityService: SecurityService,
    private serviceHandler: ServiceHandler
  ) { }

  ngOnInit() {
    this.forgotUserNameFormControl = this.formBuilder.group({
      email: ['', [Validators.required, PatternValidators.email()]],
    });
  }

  retrieveUsername() {
    const requestBody = this.forgotUserNameFormControl.value;
    this.securityService.retrieveUsername(requestBody).then((value) => {
      if (value['forgetUserNameOperationSuccessful']) {
        this.setMessage(false, value['message']);
      }
    }).catch((error) => {
      if (error.status === 409) {
        this.setMessage(true, error.error.message);
      } else {
        this.serviceHandler.handleError(error);
      }
    });
  }

  setMessage(error: Boolean, message: String) {
    if (error) {
      this.message = message;
      this.isError = true;
      this.isSuccess = false;
    } else {
      this.message = message;
      this.isSuccess = true;
      this.isError = false;
    }
  }

  get isEmailValid(): Boolean {
    return this.forgotUserNameFormControl.controls['email'].valid;
  }
}
