import { AbstractControl, FormControl, ValidatorFn } from '@angular/forms';

export class ConfirmationFieldValidators {
  /**
   * 'Flag' an error, on the confirmationControl (the control containing the confirmation value),
   * if the values of the primaryControl (the control containing the reference value) and confirmationControl don't match.
   * The 'matches' validation is only applied if the primaryControl is valid and the confirmationControl has content.
   * The resulting ValidatorFn must be registered with the confirmationControl.
   * @param primaryControl the control whose values must be matched by the confirmation control being validated.
   * @param errorKey the name of the property in the ValidatorFn's return object that will be set to errorValue upon validation failure.
   * @param errorValue the value of the 'errorKey' property in the ValidatorFn's return object that will be set upon validation failure.
   * @returns A validator function that returns an error map with the
   * errorKey property set to errorValue if the validation check fails, otherwise `null`.
   */
  static confirmationValueMatches(primaryControl: FormControl, errorKey: string, errorValue: any): ValidatorFn {
    return (confirmationControl: AbstractControl): { [key: string]: any } => {
      let validationFailure;
      // Note: ascertain that confirmationControl has an 'invalid' property as RequiredMaybeDirective
      // will submit a 'probe' empty object instead of a full-blown confirmationControl.
      // We want to apply this validation only on 'true' confirmationControls.
      // Also, we only apply the validator if the confirmationControl has content.
      const applyValidation = primaryControl !== null && !primaryControl.invalid
        && confirmationControl !== null && confirmationControl.invalid !== undefined && !confirmationControl.invalid
        && confirmationControl.value !== null && confirmationControl.value.length !== 0;

      if (applyValidation) {
        validationFailure = primaryControl.value !== confirmationControl.value;
      } else {
        validationFailure = false;
      }

      return validationFailure ? { [errorKey]: errorValue } : null;
    };
  }
}
