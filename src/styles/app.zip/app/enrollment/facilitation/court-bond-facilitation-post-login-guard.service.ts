import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CourtBondApplicationDetails, CourtBondFacilitationService } from './court-bond-facilitation.service';
import { ApplicationService } from '../application/application.service';
import { SecurityService } from '../../security/security.service';
import { determineApplicantIds } from '../application/pre-application/helpers';
import { ApplicationDataImpl } from '../application/court/model/application-data';
import { Observable, of } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { AnonymousQuote } from '../application/anonymous-quote';
import { ClientData } from '../../user/client/client-data';
import { ClientService } from '../../user/client/client.service';
import { CourtBondType, CourtBondTypesPurchasableByCompanies } from '../application/common/bond-types';

@Injectable({ providedIn: 'root' })
export class CourtBondFacilitationPostLoginGuard implements CanActivate {
  constructor(
    private courtBondFacilitationService: CourtBondFacilitationService,
    private clientService: ClientService,
    private securityService: SecurityService,
    private applicationService: ApplicationService,
    private router: Router
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> {
    return this.securityService.loggedIn$.pipe(
      mergeMap(someoneIsLoggedIn => {
        if (this.courtBondFacilitationService.isEnrollmentInProgress() && someoneIsLoggedIn) {
          const user = this.securityService.user;
          const details = this.courtBondFacilitationService.getApplicationDetails();
          const { type, amount, premium, anonymousQuote } = details;

          if (type && amount && premium) {
            const skipCompanies = !CourtBondTypesPurchasableByCompanies.includes(type);
            return this.clientService.getAllClientsFor(user, skipCompanies).pipe(
              mergeMap(clients => {
                if (clients.length > 1 || user.isSteward) {
                  const subRoute = 'select-applicant';

                  if (anonymousQuote) {
                    const personOfAnonQ = clients.find(personMatches(anonymousQuote));

                    if (personOfAnonQ) {
                      this.courtBondFacilitationService.setApplicant(personOfAnonQ);

                      if (anonymousQuote.isCompany) {
                        return this.clientService.companyClientOf(personOfAnonQ.id).pipe(
                          mergeMap(({ companyClient: companyOfAnonQ }) => {
                            if (companyOfAnonQ) {
                              return this.createApplicationAndObserveItsUrl(type, companyOfAnonQ, details, state);
                            } else {
                              return of(this.router.parseUrl(`${state.url}/application/${type}/add-company-info`));
                            }
                          })
                        );
                      } else {
                        return this.createApplicationAndObserveItsUrl(type, personOfAnonQ, details, state);
                      }
                    } else if (user.isSteward) {
                      // subRoute = 'add-applicant';
                    }
                  }

                  return of(this.router.parseUrl(`${state.url}/application/${type}/${subRoute}`));
                } else {
                  if (anonymousQuote && anonymousQuote.isCompany) {
                    // anonymous quote for a company but the person doesnt have a company so allow them to add one.
                    return of(this.router.parseUrl(`${state.url}/application/${type}/add-company-info`));
                  }
                  const [applicant] = clients;
                  return this.createApplicationAndObserveItsUrl(type, applicant, details, state);
                }
              })
            );
          }
        }

        return of(true);
      })
    );
  }

  private createApplicationAndObserveItsUrl(
    type: CourtBondType,
    applicant: ClientData,
    details: CourtBondApplicationDetails,
    state: RouterStateSnapshot
  ): Observable<UrlTree> {
    this.courtBondFacilitationService.setApplicant(applicant);

    const { personId, companyOfficeId } = determineApplicantIds(type, applicant);
    const { agent } = this.securityService.user;
    const agentId = agent && agent.id;

    const applicationData = new ApplicationDataImpl();
    applicationData.amount = details.amount;
    applicationData.premium = details.premium;

    return this.applicationService
      .createAsObservable(type, applicationData, { personId, companyOfficeId, agentId })
      .pipe(
        map(a => this.router.parseUrl(`${state.url}/application/${type}/${a.id}`)));
  }
}

function personMatches(aq: AnonymousQuote): (c: ClientData) => boolean {
  return function clientPredicate(c: ClientData) {
    return c.isPerson && c.email === aq.email;
  };
}
