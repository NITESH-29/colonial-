import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AgencyModel } from '../models/agency-model';
import { AgencyAndOfficeInformationFormGroup } from '../agency-and-office-information/agency-and-office-information-form-group';
import { SecurityService } from '../../security/security.service';
import { PersonBusinessService } from '../providers/person-business.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { CommonUtilities } from '../../common/utils/common-utilities';

@Component({
  selector: 'app-agency-with-single-office',
  templateUrl: './agency-with-single-office.component.html',
})
export class AgencyWithSingleOfficeComponent implements OnInit {
  @Input() agency: AgencyModel;
  @Output() agencySaved = new EventEmitter<AgencyModel>();

  formGroup: AgencyAndOfficeInformationFormGroup;

  constructor(
    private securityService: SecurityService,
    private personBusinessService: PersonBusinessService,
    private router: Router,
    private location: Location
  ) {
    this.agencySaved = new EventEmitter<AgencyModel>(true);
  }

  ngOnInit(): void {
    this.formGroup = new AgencyAndOfficeInformationFormGroup();

    if (this.agency) {

      const { id, name, einNumber, memberOfNasbp, agencyOffices: [agencyOffice] } = this.agency;
      const { website, phone, fax, email, sicCode, licenseNumber, address } = agencyOffice;

      this.formGroup.patchValue(
        { id, name, website, phone, fax, email, sicCode, einNumber, licenseNumber, memberOfNasbp, address }
      );
    }
  }

  async save(): Promise<void> {
    if (this.formGroup.valid) {
      const {
        name, website, phone, fax, email, sicCode, einNumber, licenseNumber, memberOfNasbp, address,
      } = this.formGroup.getRawValue();

      const { agencyOffices: [agencyOffice] } = this.agency;

      const updatedAgencyOffice = Object.assign(agencyOffice,
        { name, licenseNumber, address, email, website, phone, fax, sicCode }
      );

      this.agency = Object.assign(this.agency, {
        ...{ name, memberOfNasbp, einNumber, agencyOffices: [updatedAgencyOffice] },
      });

      const personId = this.securityService.user.person.id;

      const savedAgency = await this.personBusinessService.updateAgency(this.agency, personId);
      this.agencySaved.emit(savedAgency);
    } else {
      CommonUtilities.markAllTouched(this.formGroup);
    }
  }

  goBack(): void {
    this.location.back();
  }
}
