/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('AchAccountType')
export class AchAccountType extends AbstractIdentifierEnum {
  private static _values: Map<string, AchAccountType> = new Map<string, AchAccountType>();
  public static CHECKING = new AchAccountType('checking', 'Checking');
  public static SAVINGS = new AchAccountType('savings', 'Savings');

  // We don't register defaultDisplayText with JSON->TypeScript lib as we don't need the server's value.
  get defaultDisplayText(): string {
    return this._defaultDisplayText;
  }

  private constructor(
    persistenceId: string, // Relates the enum with the server enum representation.
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): AchAccountType {
    return AchAccountType._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): AchAccountType[] {
    return Array.from(AchAccountType._values.values());
  }

  protected registerEnum(): void {
    if (AchAccountType._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid AchAccountType 'enum' identifier: ${this.persistenceId}`);
    }
    AchAccountType._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class AchAccountTypeConverter extends AbstractIdentifierEnumConverter<AchAccountType> {
  deserialize(enumObject: any): AchAccountType {
    let enumInstance: AchAccountType;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = AchAccountType.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}
