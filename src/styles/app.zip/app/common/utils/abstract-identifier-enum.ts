import { JsonConverter, JsonCustomConvert, JsonProperty } from 'json2typescript';
import { IdentifierEnum } from './identifier-enum';

/**
 * Base implementation of enum-as-a-class with a 'persistenceId' that allows it to be associated with a servers-side enum.
 * The only field that needs to be exchanged with the server is the persistenceId.
 * All other fields are probably present in both client and server enum representations. If not, subclass can expose via @JsonProperty.
 */
export abstract class AbstractIdentifierEnum implements IdentifierEnum {
  public static extractPersistenceId(enumObject: any): string {
    let extractedPersistenceId: string;
    if (!!enumObject) {
      extractedPersistenceId = enumObject['persistenceId'];
    } else {
      extractedPersistenceId = undefined;
    }
    return extractedPersistenceId;
  }

  // We register persistenceId with JSON->TypeScript lib as we need to synchronize with the server's value.
  @JsonProperty('persistenceId', String, true)
  get persistenceId(): string {
    return this._persistenceId;
  }
  protected abstract registerEnum(): void;

  protected constructor(
    private _persistenceId: string // Relates the enum with the server enum representation.
  ) {
    this.registerEnum();
  }
}

@JsonConverter
export abstract class AbstractIdentifierEnumConverter<T extends AbstractIdentifierEnum> implements JsonCustomConvert<T> {
  abstract deserialize(data: any): T;

  serialize(enumInstance: T): any {
    let json: any;
    if (!!enumInstance) {
      json = { 'persistenceId': enumInstance.persistenceId };
    } else {
      json = null;
    }
    return json;
  }
}
